# Host visual evidence

See EVIDENCE/native/native-contrast-after.json for 72 theme/width/mode/state conditions and 1,020 passing computed-color measurements (minimum 4.9406:1). See native-visual-panel.json for fifteen fully bootstrapped width/theme cases, 100/150/200% Chrome extension-tab zoom and an independently attached browser-created native Side Panel target. actual-native-side-panel.png and repaired-*.png show corrected control labels. Screenshots are clearly distinguished from upstream fixtures. Native Side Panel operator zoom and assistive-technology review remain unverified.
