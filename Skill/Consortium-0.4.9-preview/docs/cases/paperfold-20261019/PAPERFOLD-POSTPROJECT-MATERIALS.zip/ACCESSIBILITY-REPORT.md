# Accessibility evidence and limits

Actual contextual-popover keyboard navigation, Escape dismissal and focus restoration pass. The native Side Panel accessibility tree has 26 unignored buttons, all named. Enabled text controls pass the sampled native contrast matrix. Chrome-generated composition events commit Japanese text through CM6 and persisted IndexedDB to a successful reload. The source retains native dialogs and semantic route/menu controls.

These observations do not certify real screen-reader output, physical OS IME/candidate-window operation, or operator workflows in native browser menus. Those remain explicit production debts in RELEASE-GATE.md.
