# Host verification checkpoint

The original W10 changed-files ZIP is complete and matches its pinned 212683-byte SHA256. The reconstructed review candidate contains 118 files; all 76 baseline files remain present, 73 byte-identical, and only sidepanel.html, sidepanel.css and sidepanel.js differ. See HOST-PREPARATION-RECEIPT.json.

Host evidence is separate from worker claims:

- host-evidence/regressions.json: 12 actual host syntax, regression and source-boundary commands pass.
- native-evidence/native-smoke.json: installed Chrome 155 extension bootstrap, five routes, production contextual popover and actual IndexedDB version 5 pass.
- native-evidence/native-data-journeys.json: 11 real runtime journeys pass, including CM6 save/reload/undo, Capture cancel zero-write, two-store commit, deduplication, stale-tab refusal, genuine IndexedDB transaction abort/rollback, positive retry, reload persistence and absent-origin-permission refusal. The abort is explicitly fault-injected against the real engine. Permission evidence is not a manual browser-prompt dismissal.
- native-evidence/native-visual-panel.json: 15 fully bootstrapped theme/width cases and native Chrome tab zoom 100/150/200% pass. Browser action creates a separate native Side Panel target, whose document initializes at 360 CSS pixels without a chrome.tabs.getCurrent tab. Native panel screenshot and accessibility tree are saved. These are headless Chrome runtime witnesses; screen-reader and hardware IME operation are unverified.

## Confirmed defect and automatic continuation

Actual screenshot inspection and computed colors defeated the earlier visual completion claim: Markdown formatting buttons, Live/Reading tabs and zoom reset text are near-black on black in explicit Black, and identical to their background in Auto dark. control-colors-before.json is the reproducible counterexample. W8 is reopened in its existing room as w8-contrast-repair; CSS-only ownership is preserved. No source fix has yet been received or applied. HOST-CONTINUATION.json records the next gate.

Production release remains BLOCKED. Open work includes the W8 contrast repair and host re-verification, seeded archive recovery/migration evidence, native panel zoom/context-menu paths, real hardware IME and assistive-technology operation. Original worker closures and original candidate ZIP remain historical evidence, not a PASS for the reopened candidate. The original project and daily Chrome profiles remain untouched.

## Additional host evidence after this checkpoint

native-evidence/native-archive-recovery.json contains six passing native archive/recovery cases: populated migration snapshots; actual native export; archive hashes; a corrupted-member negative control; helper-mediated atomic restoration of exported record sets and binary attachment; and subsequent full app reload. tools/verify_bundle.py also independently accepts the native-generated archive (29 files, 28 checksums). Restoration was performed by an explicit disposable-profile host harness. Paperfold still has no built-in workspace archive importer. Omitted migration-backup payloads/logs were not claimed restored.

The browser-created Side Panel accessibility tree has 26 unignored buttons, all named. This is structural Chrome accessibility evidence, not a screen-reader operator test. W8's contrast repair remains the current running dependency.

Browser composition evidence: native-evidence/native-composition.json records actual Chrome-generated composition events, Japanese composition commit, direct acknowledged IndexedDB record verification, and reload persistence. This passes the browser composition pipeline; physical OS IME operation is still unverified. Early harness attempts reloaded before the 450ms save acknowledgment and are retained as rejected harness evidence. No product source repair was inferred from those attempts.
