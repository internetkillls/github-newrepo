# W10 reverify release gate

**BLOCKED — NO DEPLOYMENT.** Candidate supplied for source review, not production installation.

| Gate | Result | Witness |
|---|---|---|
| Immutable v0.8 baseline & 76 files | PASS | Source SHA + sizes + hashes, 73 unchanged |
| Canonical W4/W7 and disjoint exact ownership | PASS | W7 closure + source manifest |
| W8/W9 repaired production source hashes | PASS | W8 and W9 delivered manifest comparison |
| Syntax + Node/Python baseline suites | PASS | `TEST-RECEIPTS.json` commands + exit 0 |
| Capture review no direct write | PASS, source/fixture-scoped | Static negative control + simulated ACK/abort/cancel |
| Actual IndexedDB two-store transaction/cancel/restore | UNVERIFIED | Opaque-origin simulated fixture only |
| Production contextual popover trigger/menu | PASS, DOM/fixture-scoped | W8 markup + W9 combined Chromium keyboard controls |
| Full bootstrapped installed native Side Panel | BLOCKED/UNVERIFIED | Disposable launch no MV3 service worker observed |
| CM6 real save/reload/undo/IME | UNVERIFIED | VM/synthetic editor only |
| Permissions denied + Chrome context menu | UNVERIFIED | Simulated denial only |
| Populated-data migration/backup/archive restore | UNVERIFIED | No actual data touched |
| Native zoom 100/150/200%, AT and all themes | UNVERIFIED | Sampled fixture contrasts/themes, no native zoom/AT |

**Concrete reopen condition:** disposable installed Chrome Side Panel runs complete save-reload/Capture cancel-commit-abort/dedup flows against genuine seeded IndexedDB, then exercises context menus, permissions, populated migration and archive restoration, and native zoom/accessibility with no critical regression. W8/W9 changed byte hashes must remain fixed or trigger re-review.
