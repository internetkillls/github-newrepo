# W8 Contrast Repair — scoped build report

**Role:** W8, contrast-only CSS repair; **status:** PASS for CSS-owned contrast gate; **release:** NOT AUTHORIZED.

## Provenance and ownership

- Immutable v0.8 `source.zip` SHA-256: `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10` (verified from supplied nested archive).
- Current input: `W8-CONTRAST-EVIDENCE.zip` → `candidate/sidepanel.css`, SHA-256 `3f66eab97ce83bfc27358e347b1aedddbfb00758109befed5806a653fe00baba`. Current `candidate/sidepanel.html` SHA-256 `dcba47cd2d652aaa61f3f71a782bcb010567f6983855e985be2446dd5bc91a77`; no HTML patch.
- New complete `sidepanel.css` SHA-256 `08d4c512609fa5598c897f337f35a4b2842b9ab5a86453d6d2c29d9521742d75`. **Only W8-owned `sidepanel.css` changed.** No JS, markup, persistence, permission, baseline schema or native profile modifications. No Git metadata exists.
- `SOURCE-HASH-MANIFEST.json` records baseline identity and the one delivered production file.

## Failure → negative control → corrective cause

The host's installed Chrome 155 evidence showed Black `rgb(16,16,16)` on `rgb(0,0,0)` and Auto-dark `rgb(17,19,24)` on the identical background for H1/Live/Reading/100%, while Paper stayed readable. This defect is corroborated by the **supplied native computed-style JSON**, not reclassified as a fixture finding.

The current W8 CSS contained a Black broad `button:not(...)` override and Auto-dark broad `button:not(...)` override. Both declared a dark foreground with greater specificity than individual transparent controls (`.format-button`, `.editor-view-tab`, `.zoom-value`) and other non-primary/tonal control rules. This is a **cascade defect**, not lost content.

**Correction:** Keep the base filled button's foreground as `color: var(--on-accent)` and define `--on-accent` by theme (Paper white; Black `#101010`; Auto/System dark `var(--bg)`; Auto light white). Delete both generic button overrides so transparent/editor/navigation/menu/tonal selectors retain `--text`, `--muted`, or their own semantic label colors. Adjust the Auto-light base muted token `#6a737d` → `#626c77` after a 4.453:1 near-miss. No `!important` added. No layout/review/route styles or Capture gate changed.

## Executed test and findings

- Reproduction: `python test_w8_contrast.py --html <current candidate/sidepanel.html> --before <current candidate/sidepanel.css> --after sidepanel.css --receipt receipt.json`; real Chromium executable `/usr/bin/chromium`, Playwright Python. Exit 0.
- **Negative control:** 72/72 asserted low-contrast pre-repair cases for H1, Live, Reading and zoomReset in Black, System dark and no-attribute dark, across 280/360/800 and both tab-active states.
- **Positive control:** 510/510 enabled text/control computed-color ratios >=4.5:1 (17 samples × 5 theme presentations × 3 widths × 2 tab states), minimum observed **4.826:1**. Additionally, 30/30 focus-visible outline probes passed (`outline-width >= 2px`). Verified all tested primary filled, toolbar, tabs, zoom, icons, More, nav, secondary, workspace, source-context trigger/menu controls.
- Effective background: computed backgrounds composited from element ancestry; ratio uses sRGB relative luminance. Hover/opacity overlay and assistive-technology output were not measured. Disabled Capture is excluded from enabled-text ratio requirements.
- Existing controls audited for inheritance: `.format-button`, `.editor-view-tab`, `.zoom-value`, `.icon-button`, `.cue-button`, `.review-note-link`, `.workspace-tab`, `.calendar-event`, `.pf-nav-item`, `.pf-more-menu button`, and `.pf-source-context-popover` menu items. Token approach avoids theme foreground clobbering across these surfaces; dynamically generated cue/annotation controls were source-inspected, not all runtime-exercised.
- Negative near-miss: first repaired token-only run failed Auto-light Reading and zoomReset at 4.453; corrected muted token and reran the same probe matrix to PASS. No other regression claimed from these limited samples.

## AntiSlop / RMC / Visual Pipeline closure

Scope gate: consumed the current W8 candidate and native evidence; did not replace with older source. Contract gate: CSS-only, exact ownership, preserve W4/W7 theme and route semantics. Falsification: pre-repair renders fail while token-controlled patch passes the same Chromium probes; filled-primary foreground and inactive tabs are independent positive controls. Visual pipeline: evidence → selectors/tokens → patch → real W8 markup preview → computed-style comparison → diagnose Auto-light near miss → correct → rerun → hash/transport. The unit fixture **is not installed Chrome**; original native screenshots are retained upstream, not re-created in this run.

## Release and remaining debts

**W8 CSS-owned contrast gate: PASS. Stage III: UNADJUDICATED/BLOCKED for this worker.** Host must re-test the new CSS in installed Chrome 155 native Side Panel, including actual theme auto-switch, zoom and hover/focus states, native extension boot, populated-data restoration, DB transaction/permission denial, Capture cancel/abort/commit/dedup, hardware IME, and assistive technology. Upstream native-data evidence was supplied and preserved conceptually but **not rerun here**. Reopen W8 if real computed foreground/composited background falls below 4.5:1 for any enabled control, if native focus/navigation regresses, or the merge does not match the hashed bytes.
