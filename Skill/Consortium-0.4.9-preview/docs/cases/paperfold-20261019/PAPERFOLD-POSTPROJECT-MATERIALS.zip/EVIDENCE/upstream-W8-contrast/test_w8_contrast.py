#!/usr/bin/env python3
"""W8 scoped Chromium cascade regression. pip install playwright; chromium required.
Run: python test_w8_contrast.py --html candidate/sidepanel.html \
    --before candidate/sidepanel.css --after sidepanel.css
CSS+real W8 markup fixture, NOT a bootstrapped Chrome extension or AT test.
"""
import argparse, json, pathlib, re, sys
from playwright.sync_api import sync_playwright

TARGET = '''(sels) => {
  const parse = (v) => { const a = v.match(/[\\d.]+/g).map(Number); return [a[0], a[1], a[2], a.length > 3 ? a[3] : 1]; };
  const blend = (top, under) => top.slice(0,3).map((x,i) => x*top[3] + under[i]*(1-top[3]));
  const effective = (el) => { let list=[]; for(let n=el;n;n=n.parentElement) list.push(n);
    let bg=[255,255,255]; for (const n of list.reverse()) {
      const c=getComputedStyle(n).backgroundColor; if(c!=='transparent') bg=blend(parse(c), bg);
    } return bg;
  };
  const lum = (c) => c.map(x=>{const y=x/255;return y<=.04045?y/12.92:Math.pow((y+.055)/1.055,2.4);})
    .reduce((a,b,i)=>a+b*[.2126,.7152,.0722][i],0);
  return Object.fromEntries(Object.entries(sels).map(([name,selector]) => {
    const n=document.querySelector(selector); if(!n) return [name,{error:'missing markup'}];
    const style=getComputedStyle(n), foreground=parse(style.color).slice(0,3),bg=effective(n);
    const x=lum(foreground),y=lum(bg);
    return [name,{fg:style.color,background:style.backgroundColor,bg:bg.map(v=>Math.round(v)),ratio:+((Math.max(x,y)+.05)/(Math.min(x,y)+.05)).toFixed(3),disabled:n.disabled,visibility:style.visibility}];
  }));
}'''
SAMPLES = {
 'H1': '#markdownToolbar .format-button',
 'H2': '#markdownToolbar [data-format="heading-2"]',
 'bold': '#markdownToolbar [data-format="bold"]',
 'italic': '#markdownToolbar [data-format="italic"]',
 'wikilink': '#markdownToolbar [data-format="wikilink"]',
 'Live': '#writeTabButton', 'Reading': '#previewTabButton', 'zoomReset': '#zoomResetButton',
 'zoomOut': '#zoomOutButton', 'zoomIn': '#zoomInButton',
 'primary': '#newNoteButton', 'secondary': '#openWorkspaceButton',
 'More': '.pf-more-menu button[data-pf-route="explore"]',
 'nav-inactive': '.pf-navigation button[data-pf-route="boards"]',
 'workspace-inactive': '.workspace-tab:not(.active)',
 'context-trigger': '#pfSourceContextTrigger',
 'context-item': '.pf-source-context-popover [role="menuitem"]',
}

def run(html,css,chromium,phase):
    rows=[]
    for theme,scheme in [('paper','light'),('black','dark'),('system-light','light'),('system-dark','dark'),('no-attr-dark','dark')]:
      ctx=chromium.new_context(color_scheme=scheme)
      for width in (280,360,800):
        page=ctx.new_page(); page.set_viewport_size({'width':width,'height':720})
        page.set_content(re.sub(r'<script\\b[^>]*>.*?</script>', '', html, flags=re.S|re.I))
        page.evaluate('(theme) => {if(theme === "no-attr-dark") document.documentElement.removeAttribute("data-paperfold-theme"); else document.documentElement.setAttribute("data-paperfold-theme", theme.startsWith("system-")?"system":theme);}',theme)
        page.add_style_tag(content=css)
        for selected in ('Live','Reading'):
          page.evaluate('(selected) => {for(const [id,active] of [["writeTabButton",selected==="Live"],["previewTabButton",selected==="Reading"]]) {const n=document.getElementById(id);n.classList.toggle("active",active);n.setAttribute("aria-selected", String(active));}}', selected)
          values=page.evaluate(TARGET,SAMPLES)
          focus=page.evaluate('''() => {const n=document.getElementById('writeTabButton');n.focus();const c=getComputedStyle(n);return {outline:c.outlineStyle,width:parseFloat(c.outlineWidth),focused:document.activeElement===n}}''')
          rows.append(dict(phase=phase,theme=theme,width=width,selected=selected,values=values,focus=focus))
        page.close()
      ctx.close()
    return rows

def main():
 p=argparse.ArgumentParser();p.add_argument('--html',required=True);p.add_argument('--before',required=True);p.add_argument('--after',required=True);p.add_argument('--receipt',default=None);p.add_argument('--browser-executable',default='/usr/bin/chromium');a=p.parse_args()
 html=pathlib.Path(a.html).read_text(encoding='utf8'); before=pathlib.Path(a.before).read_text(encoding='utf8');after=pathlib.Path(a.after).read_text(encoding='utf8')
 with sync_playwright() as playwright:
  browser=playwright.chromium.launch(headless=True,executable_path=a.browser_executable,args=['--no-sandbox'])
  before_rows=run(html,before,browser,'before'); after_rows=run(html,after,browser,'after'); browser.close()
 failures=[]
 for row in before_rows:
  if row['theme'] in ('black','system-dark','no-attr-dark'):
   for name in ('H1','Live','Reading','zoomReset'):
    val=row['values'][name]
    if 'error' in val or val['ratio'] >= 4.5: failures.append(f"negative control unexpectedly passes {row['theme']} {row['width']} {row['selected']} {name}: {val}")
 for row in after_rows:
  if not row['focus']['focused'] or row['focus']['outline'] == 'none' or row['focus']['width'] < 2:
   failures.append(f"focus regression {row['theme']} {row['width']} {row['selected']} {row['focus']}")
  for name,val in row['values'].items():
   if 'error' in val: failures.append(f"markup missing {name}");continue
   if not val['disabled'] and val['ratio'] < 4.5: failures.append(f"low contrast {row['theme']} {row['width']} {row['selected']} {name} {val['ratio']}")
 # Focus/active state selectors must stay in source; neither selector nor routing may be deleted.
 for token in ('button:focus-visible','.editor-view-tab.active','.pf-source-context-popover [role="menuitem"]:focus-visible','[aria-current="page"]'):
  if token not in after: failures.append('missing CSS control: '+token)
 receipt={'schema':'paperfold.w8-contrast-fixture.v1','scope':'W8 HTML/CSS in headless Chromium; no JS or installed extension/AT','browser':a.browser_executable,'cases':len(before_rows)+len(after_rows),'negativeExpectedFailures':len(before_rows)*4*3//5 if False else sum(1 for r in before_rows if r['theme'] in ('black','system-dark','no-attr-dark'))*4,'samplesPerCase':len(SAMPLES),'failures':failures, 'negative':before_rows,'positive':after_rows,'status':'PASS' if not failures else 'FAIL'}
 if a.receipt: pathlib.Path(a.receipt).write_text(json.dumps(receipt,indent=2),encoding='utf8')
 print(json.dumps({'status':receipt['status'],'cases':receipt['cases'],'positiveProbes':len(after_rows)*len(SAMPLES),'negativeControls':receipt['negativeExpectedFailures'],'failures':failures[:24]},indent=2))
 return 1 if failures else 0
if __name__=='__main__':sys.exit(main())
