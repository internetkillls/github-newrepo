# F — Paperfold P0 Verification Report

Artifact: staged Paperfold 0.8.0 working tree from immutable v0.7.0(2).zip. Environment: Linux container, Node.js 22.16.0, Python 3, Chromium binary available, no access to user's installed Windows Chrome profile. No actual profile/Google Drive/GitHub data was changed.

| Command / test | Result | Proven scope |
|---|---|---|
| `node tests/v05-modules.mjs` | PASS | Existing notes/workspace projections, archive generation fixtures |
| `node tests/v06-modules.mjs` | PASS | Board legacy graph logic, attachments, archive fixtures |
| `node tests/v07-literature.mjs` | PASS | DOI normalization/CSL/provider fallback with mocked fetch, sync URL validator |
| `node tests/v08-sessions.mjs` | PASS | Browser **mock** session capture and revision deduplication, session→Board association, missing-tab preview, restore to mock window, startup unmatched active state, local archive inclusion, callback contract |
| `python tests/v07-server-security.py` | PASS | Companion blocks unauthenticated/short-token LAN binding |
| `node --check` every bundled `.js` | PASS | Parse/syntax only |
| HTML static check | PASS | 180 unique HTML element IDs; 153 original sidepanel bindings resolve |
| Local import graph checks | PASS | No missing relative root-module imports |
| Manifest v0.8 permissions check | PASS | `tabGroups` added; no broad `history` permission |
| Isolated Chromium with `xvfb-run` | NOT WITNESSED | Chromium launched but remote-debug port/extension target not exposed; no UI interaction or browser restart test verified |
| Cloud sync conflicts, restore from full archive | NOT TESTED | P2 / future restore importer |
| Existing populated Chrome profile migration | NOT TESTED | Source schema additive, data safety must be independently witnessed |

## What unit tests do NOT prove

The fake browser API does not represent MV3 scheduling, real tab/window races, profile restoration, indexedDB upgrading from a live prior version, Google Drive API use or Chrome policy restrictions. `SOURCE-OBSERVED`, `CODE-WRITTEN`, `STATIC-CHECKED` and `UNIT-TESTED` apply to the new P0 slice; `BROWSER-WITNESSED`, `DEPLOYED` and `P0 EXIT ACCEPTED` do **not**.

## Potential gaps and distinguishing tests

1. Kill the isolated Chromium browser after rapid changes but before debounce. Measure lost events and compare periodic reconcile; document bounded durability, not zero-loss.
2. With 40 tabs/two windows, produce native groups, restart browser and compare stable Session IDs, group membership, active/pinned state and URL lists.
3. Let Chrome restore the original tabs itself; Paperfold preview must skip those URLs and not duplicate them when Restore is clicked.
4. Open a populated v0.7 test database, export, upgrade to v0.8, verify every old store count/record/annotation, then test a clean-profile archive restore using a future importer or other independently verified process.
5. Run 10/50/100/300 tab benchmarks and compare DB writes, revision retention, CPU and UI latency in the actual target browser; no performance guarantee is made by the current debounce choice.

## Recovery boundary

If new UI is unusable in the **isolated test profile**, remove that test profile and keep the original daily installation unchanged. Do not try to downgrade IndexedDB v5 in place by replacing the files with v0.7. Exported `.wv.tar.gz` is an archival copy; full automatic import and reconstruction of Chrome profile data is not supplied here.
