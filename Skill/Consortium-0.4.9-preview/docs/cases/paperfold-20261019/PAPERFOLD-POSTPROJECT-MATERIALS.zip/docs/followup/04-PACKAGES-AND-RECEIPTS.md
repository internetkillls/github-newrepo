# Paperfold follow-up — execution packets, verification and release gate

## Work package / decision ordering

| Slice | Ownership / files | Gate | Verification | Rollback |
|---|---|---|---|---|
| A safety | `db.js`, `provenance.js`, browser test harness; no production changes yet | populated v4→v5, clean restore, Chrome witness | preserve IDs, byte digests, restore error cases | remove isolated test profile; retain original ZIP |
| B shared commands | `service-worker.js`, `cm-editor.js`, `sidepanel.js` | A passed | same action and permission result across sidepanel/menu | restore specific source changes after DB unchanged |
| C lexical Discover prototype | NEW `prototypes/discover/lexical.js`, `query-ast.js`, `tests/v08-discover-prototype.mjs` | self-contained read-only | local Node test + negative control | delete prototype directory, no data touched |
| D offline model feasibility | optional packaged model adapter with separate license and CSP proof | A, measured baseline and privacy gates | cold/offline size, RAM, CSP, relevance comparison | keep `local-hash-v1`; remove model assets |
| E Discover UX | new UI using shared dispatcher, status/provenance review | A+B+C passed | Chrome interactivity, keyboard, source fidelity | feature flag off and revert UI |
| F scientific and multimodal capture | existing `provenance.js`, `literature.js`, editor | core regression and same data contract | round-trip export, DOI, anchor changed DOM | revert bounded capture change |
| G sync/other UI | opt-in cloud, popup, optional dashboard | tested importer, privacy & conflicts | multi-device offline conflict tests | disable transport, preserve local DB |

## Exact execution receipts

- `node tests/v05-modules.mjs` — exit `0` (original staging extracted tree).
- `node tests/v06-modules.mjs` — exit `0`.
- `node tests/v07-literature.mjs` — exit `0`.
- `node tests/v08-sessions.mjs` — exit `0` (mocked Chrome and repo).
- `python tests/v07-server-security.py` — exit `0`.
- `node tests/v08-discover-prototype.mjs` — exit `0` in isolated copy, tests no IO, proposal source evidence, dismissal suppression, sensitivity and provider operators.
- `python probe_browser.py` — BLOCKED/no extension service worker; not evidence of live extension behavior.
- `python test_idb_upgrade.py` — BLOCKED by policy (`net::ERR_BLOCKED_BY_ADMINISTRATOR`); v4→v5 real IndexedDB check NOT DONE.

**System:** Debian-like sandbox, Node v22.16.0, Python v3.13.5, `/usr/bin/chromium` installed but navigation is denied. No installed extension in the user's Chrome, no remote GitHub writes, no background agents. A mock passing ≠ browser witness.

## Independent adversarial review / negative controls

1. Similar vocabulary but contradictory claims: `related-to` only, never `supports`/`causes`.
2. Unapproved/private docs and insufficient corpus: exclude/abstain.
3. Dismissed pair or Board exclusion: hidden, not silently accepted.
4. Sensitive URL query, email, `api_key=`: query builder refuses; harmless academic phrases allowed.
5. Unsupported DuckDuckGo `filetype:csv`: error; Google CSV template works.
6. Google operator grammar is constrained; no syntactically unsupported assumptions about engines.
7. No new worker, plugin, store, permission or cloud transport in the prototype.
8. Unmodified original ZIP hash can be reproduced; diff must include only added prototype/tests/docs.

## RCC partition (policy packets only, NOT invoked as independent workers)

- I2 `baseline auditor`: inspect ZIP/DB/manifest, without consuming producer conclusions; close when paths and gate blockers named.
- I2 `browser security`: Chrome APIs, permission constraints and service worker; close when executable witness requirements named.
- I2 `lexical engineer`: approved corpus, n-grams and source evidence; close when negative controls pass.
- I3 `adversarial critic`: attempt counterexample: false causality, sensitive searches, silent reindex, mistaken restore proof.
- I4 `browser witness`: Chrome isolated real service worker + clean import; currently blocked by environment; cannot assert PASS.
- I1 `integrator`: compare closures, keep disputed and blocked claims open.

No consortium browser tabs or worker target IDs were returned in this environment; partitions are a handoff plan, not executed agents.

## Delivery boundary and next irreversible decision

Prototype ZIP is an **audit-and-research source bundle**, not a versioned installed extension upgrade. Existing `manifest.json` remains `0.8.0` and `db.js` stays v5, so no new sidepanel control, no new IndexedDB store, no release migration. A cautious developer can run pure tests and inspect the diagrams. Activation of Discover and any changes to the user's live install are blocked until Gate A passes on isolated real Chrome and restore drill is witnessed. On eventual upgrade, export + clean import must precede any active-profile overwrite; copying v0.7 files over v5 storage is invalid rollback.
