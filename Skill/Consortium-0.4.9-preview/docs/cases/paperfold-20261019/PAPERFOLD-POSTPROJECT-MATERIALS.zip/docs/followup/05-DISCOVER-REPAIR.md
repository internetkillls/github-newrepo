# Paperfold v0.8 — bounded Discover/query AST source correction

Classification: **GATED PROTOTYPE**, not a release or Chrome witness.

## Changes

- Q1: make printable text check stateless; reject consecutive control chars and malformed structured values.
- Q2: refuse literal operator grammar and unsafe literal quoting/escaping; support explicit provider-declared `inurl` field with existing `intitle` validation.
- Q3: UTC Gregorian date round trip prevents date normalization; reject zero year and malformed shape.
- Q4: require an array of 1–8 validated term entries, exact flag boolean; no silent truncation; retain 400-character query cap.
- D1: deduplicate eligible docs by stable ID (first valid row wins); encode pair identity separators.
- D2: require valid, nonempty disjoint Board membership; malformed or unknown membership cannot qualify.

## Tests and scope

The original nine-case portable adversarial script is copied as the unmodified first section of `tests/v08-discover-adversarial.mjs`, followed by eight added boundary suites. This file is permanent and run separately from `tests/v08-discover-prototype.mjs`. Both must pass after every source revision; all older regression suites must remain green. Node execution is not a Chrome deployment, and archive checksum/integrity is not an importer restore test.

## Invariant limitations

`related-to` is a proposed lexical similarity, not evidence of causal/support relations. The query safety heuristic is not comprehensive DLP or provider grammar validation. First-row precedence for conflicting document IDs is deterministic but should be followed by a corpus-consistency warning in any later UI integration. No changes to production extension source, Chrome permissions, IndexedDB schema, service worker or deployed files occurred in this repair.
