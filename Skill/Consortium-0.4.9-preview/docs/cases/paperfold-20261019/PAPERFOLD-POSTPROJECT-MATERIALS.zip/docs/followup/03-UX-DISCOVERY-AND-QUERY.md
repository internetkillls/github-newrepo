# Paperfold — UX, Discover and Query Studio design contract

**Status: DESIGN-PROPOSED, NOT IN APP.** UI decisions are constrained by observed `sidepanel.html`, `cm-editor.js`, `sidepanel.css` and distinct command implementations. Do not display prototype controls as functional in v0.8. Source preserves Board as public name and CM6 editor as center of attention.

## Current UX audit

- Editor visible immediately and central: good. Current top-level header includes Cue, export, Workspace, AI, WV bundle, Boards, Settings; numerous independent controls below. Cognitive density is high and keyboard discoverability uneven.
- `cm-editor.js` knows slash and @ completions, while `service-worker.js` separately registers native Chrome context menu. There is no one validated context dispatcher for every surface. Repair via contract tests before reworking event handlers.
- Current capture buttons sit under Current Tab; Bookmarks/annotations/scraps are separate lists. An inquiry-centered navigation must not force the user to remember which backend store owns an item.
- Current side panel has Paper/Black themes. Without a real Chrome witness we cannot assert color contrast, screen reader behavior, 320px viewport usability or popover placement.

## Three interaction alternatives — visually and behaviorally distinct

### A. Fast Capture (preferred small first slice, conditional)

```
[Paperfold]                         [Search] [More]
[Board: Critical Realism                         v]
[Current page title                                    ]
[ Clip selection ] [ Annotate ] [ Attach source ]
─────────────────────────────────────────────────────────
[ Markdown / CM6 editor                               ]
[ Non-blocking saved status                            ]
```

**Focus:** quick capture with minimal context switching. Quick Actions overlay max 3 actions + More. Preferred for high-frequency annotations. Risk: Discover hidden too deeply; solve with a nonmodal badge reviewing only approved saved notes. Keyboard focus/selection preserved; no interception inside text fields.

### B. Inspector rail

```
[Board / Current source]
[Card in editor]    [Source annotations]
[                 ][Related saved items]
[                 ][Why suggested?]
```

**Focus:** investigate provenance and inspect citations. Good at wide widths/full-tab; poor at narrow sidepanel width. Proposal: responsive as second-level inspector, not always displayed.

### C. Command-first palette

```
[Search notes, actions, sources...                   ]
  Clip this selection                 Alt+...
  Query Studio                        /query
  Discover saved relations            /discover
  Open Board ...
```

**Focus:** efficient keyboard work and accessibility; too opaque as the only capture entry point. Requires stable action IDs, discoverable documentation and permission-aware disabled states.

**Recommendation, not user-approved:** use A for first gesture, C for power users, B for deeper reading, all sharing one registered command system. No redesign until migration and browser test gates pass.

## Quick Action command contract (target)

Each action has `id`, label, eligibleContexts, JSON input schema, side-effect boundary, required permissions, success/failure, undo, accessibility label, shortcut and test. Pinned order overrides dynamic popularity. Only action identifiers and coarse context types are counted locally; never record user selection text in usage analytics. Rank/order freezes while an action menu is open. Scope examples: selection: annotate, clip, search; tab: attach, scrape (only with access), navigate; note: insert cue, relate to Board, export.

The extension service worker must validate message sender/shape before initiating privileged operations. Content scripts cannot declare that a user consented merely by sending a message.

## Discover operational model

- Input source: explicit `approved:true` entries generated from saved Cards/approved captures. Plain browser history and unsaved open tabs excluded by default. Board/Source exclusions win; `private:true` rows never enter the index.
- Lexical baseline: Unicode NFKC case-normalized tokens; frequent 1–4 word phrases. Document-frequency filtering excludes unique phrases and universal boilerplate. Source attribution is explicit in every proposal. The prototype is English/Indonesian heuristic, not language identification and not CJK semantic tokenization.
- Cross-Board proposal: overlapping 1–2 grams generate neutral `related-to` suggestions. Similarity is **not** evidence of causal, support or contradiction relations. No automatic writes. High overlap/near duplicates may be suppressed for serendipity.
- Explanation: always show observed shared tokens, doc/source IDs, and limitations. Proposal status only; in future reviewed UI feedback needs a durable dismissal key + model/index version.
- Offline: no network access or model dependencies in prototype. No neural embeddings are delivered here. `local-hash-v1` remains production baseline. Provider isolation must precede an ML upgrade.
- Corpus evaluation needed: manually labeled same-topic contradictions, jargon false positives, English/Indonesian paraphrases, cross-Board relations, boilerplate and unrelated same keywords. Measure precision@3, candidate diversity and meaningful abstentions before enabling.

## Search Studio contract

`prototypes/discover/query-ast.js` accepts explicit AST-like objects with provider, terms/exact quoting, excluded terms, optional site/filetype and provider-specific operators. It only returns a **preview URL**. User gesture is required for external open, and opening a provider transmits the query via URL. Typed AST is not a URL fragment from untrusted page text.

| Provider | Verified documented operators | Prototype enforced limitations |
|---|---|---|
| Google | quoted phrase, exclusion, `site:`, `filetype:`, `before:`, `after:` | no unverified `intitle`, `inurl`, or grouped arbitrary OR in this slice |
| DuckDuckGo | quoted phrase, exclusion, `site:`, `filetype:` (PDF/DOC/XLS/PPT/HTML family), `intitle:`, `inurl:` | `filetype:csv` rejected; engine warns advanced syntax may be inconsistent |

Operator references: [Google Search Help](https://support.google.com/websearch/answer/2466433?hl=en) and [DuckDuckGo advanced syntax](https://duckduckgo.com/duckduckgo-help-pages/results/syntax). These describe provider features, not verified quality of retrieved results. Queries need source/terminology review; use only user-approved vocabulary. Template proposals: literature PDF; public CSV dataset; GitHub implementation; counterarguments; PPTX presentations. One search request is not automatic crawling, and a generated query does not prove relevant results exist.

Sensitive input gate: reject obvious credentials, secret fields, PEM private keys, emails, invalid host filters, unprintable/oversized input, and unsupported file types. This is a conservative heuristic and **not a comprehensive DLP solution**. No external request before an explicit user action.

## Settings contract (proposed, not decorated controls)

| Key (proposal) | Default | Runtime effect | Persistence | Test needed |
|---|---|---|---|---|
| `discover.enabled` | false | no automated indexing | existing `settings` store after gate | disable stops work |
| `discover.scope` | saved-only | index approved items | existing settings | unsaved tab excluded |
| `discover.excludedBoardIds` | [] | Board scope blacklist | settings | blacklist precedence |
| `discover.feedback` | [] | suppress dismissed proposals | assessed persistence | reset feedback |
| `quickActions.pinnedIds` | capture, annotate, attach | stable primary actions | settings | inaccessible actions denied |
| `quickActions.adaptiveOrder` | false | no frequency-driven reorder | settings | freeze open menu |
| `query.provider` | google | previews a supported grammar | settings | invalid provider rejected |
| `query.externalConsent` | per-search | explicit button required | ephemeral | no traffic before click |
| `neuralModel.enabled` | false | no ML load | settings when model validated | offline CSP & OOM fallback |

No setting above has been activated. Settings are schema proposals with intended effects, not current UI switches.

## Representative user journeys (spec only)

1. Capture: select passage → contextual Annotate → permission check → source anchor + comment → reviewed commit → nonblocking feedback → optional Discover proposal queue.
2. Serendipity: user opens Board → inspect approved saved corpus → proposal shows two source anchors + reason → user accepts neutral relation or dismisses → nothing changes without review.
3. Query: pick source-backed specialized phrase → choose intent and provider → see query operator breakdown and privacy warning → edit/approve → external browser search, no automatically saved results.
4. Restricted page: native menu or sidepanel fallback, explain unavailable capture; maintain text selection/focus.
5. Model unavailable: lexical suggestions/search stay operational; no remote model download under `built-in offline` label.
6. Session restart: existing P0 data reconciled first; Discover is not entitled to scrape restored tabs.
7. Narrow screen/zoom: 320px width with editor primary, horizontally stacked actions folded into menu, focus visible, no hover-only affordances.

## Accessibility/visual QA checklist to witness

- Pure Black, Paper, System; readable text/focus border in both; not just accent colors for status.
- Keyboard-only focus traversal, Escape dismissal, Enter action, return focus to editor and no focus stealing on clip.
- Announced labels for proposal reasons/uncertainty and permission-denied states.
- 75%–175% zoom and reduced-motion settings do not clip controls.
- Popover avoids viewport edges and IME composition, no arbitrary mutation to native text inputs.
- Browser screenshot/probe is necessary to claim actual responsive/contrast success. None captured.
