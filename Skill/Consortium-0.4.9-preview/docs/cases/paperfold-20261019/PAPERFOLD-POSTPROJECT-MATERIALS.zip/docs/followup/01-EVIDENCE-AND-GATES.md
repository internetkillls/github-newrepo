# Paperfold v0.8 follow-up — source audit and gate register

**Status: SOURCE-OBSERVED / TESTED-WITH-MOCKS / DEPLOYMENT BLOCKED.** Baseline is the attached `Paperfold-v0.8.0-P0-STAGING.zip`, SHA-256 `68671806aa7a8c62be51cff2afdd381460f997941e752034d49e975c8094e4c9`, 65 entries. Extracted in an isolated workspace; original ZIP unmodified. Specification: `Pasted markdown(7).md`, 205 lines. Supporting earlier specification available: `Pasted text(20261015-183834).txt`; originally requested separate exports `Pasted text(20261015-190002).txt` and `Pasted text (2)(4).txt` are not present as exact files in this turn. Screenshots not provided as separate images. Do not treat previous prompt text as running functionality.

## Source inventory and boundary

| Capability | Classification | Witness / ownership |
|---|---|---|
| Manifest MV3, background, side panel | SOURCE-OBSERVED | `manifest.json`, `service-worker.js`, `sidepanel.html` |
| CM6 notes and commands | SOURCE-OBSERVED | `cm-editor.js`, `sidepanel.js`, `cues.js` |
| Board / Card + typed graph edges | SOURCE-OBSERVED | `card-model.js`, `db.js` (`maincards`, `memberships`, `cardEdges`) |
| Captured Sources, scraps, annotations | SOURCE-OBSERVED | `sidepanel.js`, `service-worker.js`, `provenance.js` |
| DOI / Crossref + DataCite | SOURCE-OBSERVED + UNIT-TESTED | `literature.js`, `tests/v07-literature.mjs` (fixtures, not real API) |
| Browser session events, snapshots and revisions | SOURCE-OBSERVED + MOCK-TESTED | `browser-sessions.js`, `session-model.js`, `db.js`, `tests/v08-sessions.mjs` |
| Session restore in a newly created window | SOURCE-OBSERVED + MOCK-TESTED | `browser-sessions.js`; no real restart witness |
| Workspace backup export includes Sessions | SOURCE-OBSERVED + UNIT-TESTED | `provenance.js` and existing tests; export is not import |
| Complete archive importer and clean restore | ABSENT for verified deployment | no demonstrated complete loader of `.wv.tar.gz` into new profile and graph; README-P0 explicitly warns |
| Google Drive scheduled backup / LAN companion | SOURCE-OBSERVED / BROWSER-UNVERIFIED | `service-worker.js`, `sync.js`, `companion/tabwoven_sync_server.py` |
| Built-in offline neural semantic model | ABSENT | `embedding.js` contains `local-hash-v1` only; hash vectors are not pretrained semantic inference |
| Topic/n-gram source-attributed suggestions | ABSENT IN BASELINE; PROTOTYPE ADDED | `prototypes/discover/lexical.js`; **not wired into extension** |
| Cross-Board serendipity | ABSENT IN BASELINE; PROTOTYPE ADDED | proposals are non-truth-claiming, read-only, with source IDs |
| Search Studio query AST, provider grammar | ABSENT IN BASELINE; PROTOTYPE ADDED | `prototypes/discover/query-ast.js`; **does not perform searches** |
| Shared validated action registry across all surfaces | PARTIAL | `cm-editor.js` command completions, `service-worker.js` context menus and sidepanel handlers are separate |
| Full-tab manager, popup, New Tab override | ABSENT | manifest has only action opener and sidePanel default path |
| Optional CJK search segmentation | ABSENT | no verified word segmentation / IME tests |
| Native tab discard optimization | ABSENT | session snapshots store `discarded` state only, no discard strategy |

**Baseline tests run on original extracted tree:**

- `node tests/v05-modules.mjs` — exit 0.
- `node tests/v06-modules.mjs` — exit 0.
- `node tests/v07-literature.mjs` — exit 0.
- `node tests/v08-sessions.mjs` — exit 0.
- `python tests/v07-server-security.py` — exit 0.

Environment: Node 22.16.0, Python 3.13.5, Chromium executable `/usr/bin/chromium`. Independent `python probe_browser.py` attempted an isolated extension load: the browser launched, but no extension service worker registered. Subsequent Chromium navigation to local HTTP, `file://` and `data:` URLs returned `ERR_BLOCKED_BY_ADMINISTRATOR`. An attempted populated v4→v5 real IndexedDB browser probe therefore **failed to execute**, not a pass or proven schema defect.

## P0 Gate A: decision

**BLOCKED for installation/upgrade on an active user profile.** Required before opening the gate:

1. Read-only copy of current workspace at time of upgrade and external SHA-256 manifest.
2. Isolated Chrome profile: load extension, create populated v4 fixture and execute the real v4→v5 upgrade. Assert note body, Board membership, source IDs, annotation anchors and attachments remain unchanged.
3. Validate a complete `.wv.tar.gz` importer in a *separate clean profile*. Negative cases: missing path, corrupt checksum, duplicate IDs, path traversal and truncated archive. Restore failure must leave a recoverable previous database.
4. Session browser witness: Chrome native restore vs Paperfold, close/restart, group IDs, 40 tabs/2 windows and duplicate prevention. Measure rather than assume save timing.
5. Confirm permission prompts and restricted pages with actual Chrome UI.

A checksum validates bytes of an archive; it does not prove a reconstructable database. Replacing v5 code with v4 source is **not** a rollback. Roll back through a verified import into an isolated profile or a backed-up profile snapshot, never by destroying the active IndexedDB.

## Findings prioritized

- **SUPPORTED-RISK:** before a real browser witness, MV3 lifetime, extension IDs, simultaneous write coordination and crash recovery remain unknown (see Chrome official service worker lifecycle).
- **SUPPORTED-RISK:** service-worker message dispatch has distinct action paths; shared context validation not centralized. A new popup/overlay should not duplicate dispatch handlers.
- **SUPPORTED-RISK:** broad captured browsing URL metadata can reveal sensitive interests. Discover requires explicit consent and exclusion before indexing Sessions/history.
- **NOT A DEFECT:** `maincards` physical store remains for backwards compatibility while visible terminology says Board.
- **NOT A DEFECT:** existing `local-hash-v1` is deterministic and lightweight; claiming it is neural semantic inference would be false.
- **BLOCKER:** clean restore path not witnessed; cannot claim deployment-safe new version.

## Citable primary reference set (read-only GitHub connector)

| Project/source | Verified ref | Borrowable idea | License evidence / risk | Action |
|---|---|---|---|---|
| [Tab Session Manager](https://github.com/sienori/Tab-Session-Manager/blob/master/README.md) | `master` README blob `0cc5546c162d7d1ac6012bb92750e14e3ade1f52` | autosave/restore UX and sessions as independent objects | License not inspected; no code copied | Research only |
| [Obsidian Web Clipper](https://github.com/obsidianmd/obsidian-clipper/blob/main/LICENSE) | `main` LICENSE blob `68d4ae5cd96c22a16eb0041c9004a865b8f734cf` | Markdown interoperability and conservative capture | MIT LICENSE verified; no code copied | Concept reference |
| [Floating UI](https://github.com/floating-ui/floating-ui/blob/master/LICENSE) | `master` LICENSE blob `5665118418c729036a5252c88ba99d3d33cf22d6` | collision-aware quick action popovers | MIT LICENSE verified; possible future dependency, not installed | Defer |
| [Transformers.js](https://github.com/huggingface/transformers.js/blob/main/LICENSE) | `main` LICENSE blob `d645695673349e3947e8e5ae42332d0ac3164cd7` | packaged offline inference feasibility | Apache-2.0 LICENSE verified; model weights have separate licenses; not installed | Model spike only |
| [Automerge Repo](https://github.com/automerge/automerge-repo/blob/main/LICENSE) | `main` LICENSE blob `e5018a45fd1fc5befbe3fa48c78154963d04d3ee` | conflict-aware sync alternative | License inspected, no code copied; substantial sync/identity cost | Defer |

Other named libraries in the master contract are research candidates, not vetted dependencies. The `lucaong/minisearch` LICENSE path returned 404 in the inspection attempt; no licensing claim is made about it. No source from third-party repositories is bundled by this prototype.

## Binding invariants for future work

- Board≠Session; typed suggestions≠typed evidentiary edges; generated query≠retrieved result.
- Explicit user-approved Saved Sources only; do not infer consent from a tab being open.
- No automatic remote requests, no new permission, no schema migration in prototype slice.
- No backed-up session should cascade-delete a Card, annotation or Source.
- A proposal carries source IDs and score reasons; approval creates neutral `related-to` only, never `supports` or `causes`.
