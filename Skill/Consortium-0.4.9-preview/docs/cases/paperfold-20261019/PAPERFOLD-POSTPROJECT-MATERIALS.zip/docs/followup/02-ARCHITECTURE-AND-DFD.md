# Paperfold architecture and flows — CURRENT versus PROPOSED

All diagrams are Mermaid source for review; rendering and browser interaction were **not witnessed** in the locked Chromium environment. A diagram node is not implemented code.

## CURRENT — Container architecture

```mermaid
flowchart TD
 A[Chrome tabs windows groups events] --> B[service-worker.js]
 B --> C[browser-sessions.js]
 B --> D[Capture and menu handlers]
 C --> E[(IndexedDB v5 tabwoven-notes)]
 D --> E
 F[sidepanel.html CM6 editor] --> G[sidepanel.js]
 G --> E
 G --> H[workspace.js and card-model.js]
 G --> I[literature.js DOI]
 G --> J[embedding.js local-hash-v1]
 G --> K[provenance.js export]
 L[Optional Google Drive and LAN companion] <-->|Backup/sync settings| B
```

## PROPOSED — Minimal composition, NOT deployed

```mermaid
flowchart TD
 A[Chrome events and explicit user gestures] --> B[Browser adapter and privacy/permission policy]
 B --> C[Validated shared command dispatcher]
 C --> D[Existing Capture and Sessions]
 C --> E[Discover lexical prototype]
 C --> F[Search Studio AST compiler]
 D --> G[(Current v5 IndexedDB)]
 E --> H[Consent-scoped read-only projection]
 H --> G
 F --> I[Editable user approved query preview]
 I --> J{User chooses search externally?}
 J -->|Yes| K[Provider-visible URL]
 J -->|No| L[No network request]
 M[Side Panel and eventual Quick Actions] --> C
 G --> N[Existing explicit export]
```

## CURRENT physical data model — v5 stores

```mermaid
erDiagram
 NOTES ||--o{ LINKS : refers
 SOURCES ||--o{ LINKS : referenced_by
 NOTES ||--o{ SCRAPS : owns
 NOTES ||--o{ ANNOTATIONS : comments
 SOURCES ||--o{ ANNOTATIONS : anchors
 NOTES ||--o{ ATTACHMENTS : owns
 NOTES ||--o{ CHUNKS : indexes
 MAINCARDS ||--o{ MEMBERSHIPS : contains
 NOTES ||--o{ MEMBERSHIPS : participates
 MAINCARDS ||--o{ CARDEDGES : scopes
 BROWSERSESSIONS ||--o{ SESSIONREVISIONS : versioned
 BROWSERSESSIONS }o--o{ MAINCARDS : boardIds
 NOTES { string id PK }
 SOURCES { string id PK string url UK }
 LINKS { string id PK string noteId string sourceId }
 MAINCARDS { string id PK }
 MEMBERSHIPS { string id PK string maincardId string cardId }
 CARDEDGES { string id PK string maincardId string type }
 BROWSERSESSIONS { string id PK string snapshotHash string status }
 SESSIONREVISIONS { string id PK string sessionId number sequence }
```

Other current physical stores: `logs`, `settings`, `chunks`, `ir`, `bookmarks`, `backups`, `transports`, `syncRuns`. `db.js` declares all 19. The Board↔Session relationship is serialized in `browserSessions.boardIds` (not an IndexedDB join store). `maincards` is a compatibility name, not the public product term.

## PROPOSED logical Discover and query model

```mermaid
erDiagram
 BOARD ||--o{ CARD : has_memberships
 CARD ||--o{ SOURCE : references
 SOURCE ||--o{ APPROVED_EXCERPT : contains
 APPROVED_EXCERPT ||--o{ TERM_EVIDENCE : witnesses
 TERM_CANDIDATE ||--o{ TERM_EVIDENCE : has
 CARD ||--o{ LINK_SUGGESTION : is_candidate_for
 BOARD ||--o{ QUERY_PLAN : contextualizes
 QUERY_PLAN ||--o{ SEARCH_EXECUTION : executed_only_with_approval
 TERM_CANDIDATE { string term string preprocessingVersion }
 TERM_EVIDENCE { string docId string sourceId }
 LINK_SUGGESTION { string leftId string rightId string status }
 QUERY_PLAN { string provider string typedAST }
 SEARCH_EXECUTION { string queryPlanId string approvedAt }
```

**Minimal physical delta: NONE in this prototype.** Terms and link suggestions are ephemeral JavaScript projections; no new stores and no schema bump. If future persistence is justified, add scoped settings/index object(s) with documented migration and export coverage—not eight stores merely because diagrams show logical entities.

## DFD L0 — Trust boundary

```mermaid
flowchart LR
 U[User explicit actions] --> X[Paperfold extension trust domain]
 W[External webpages untrusted] -->|selection or approved capture only| X
 X --> I[(Local v5 data)]
 X -->|manual backup| Z[User chosen export]
 X -->|explicit open query only| S[External search provider]
 X -.->|opt-in future only| C[Cloud or LAN sync]
```

## DFD L1 — Capture

```mermaid
flowchart LR
 A[Selection or active tab gesture] --> B{Permission and safe URL?}
 B -->|No| F[Explain denied scope]
 B -->|Yes| C[Normalize source and capture anchor]
 C --> D[Attach to active Card with user action]
 D --> E[(Source Annotation Link in v5)]
 E --> G[Optional explicit export]
```

## DFD L1 — Session recovery

```mermaid
flowchart LR
 A[Chrome tab and window events] --> B[Coalesce and snapshot all]
 B --> C[Resolve stable Session ID]
 C --> D[(Atomic parent and revision commit)]
 D --> E[On startup reconcile]
 E --> F{Existing Chrome tabs match?}
 F -->|Yes| G[Resume binding]
 F -->|No| H[Recovery needed]
 H --> I[Preview user chosen revision]
 I --> J[Restore only missing eligible URLs]
```

## DFD L1 — Discover proposal (prototype)

```mermaid
flowchart LR
 A[User-approved saved corpus] --> B[Scope and exclusion filtering]
 B --> C[Unicode tokens and 1-4 grams]
 C --> D[Document frequency and source evidence]
 D --> E[Cross Board lexical overlap]
 E --> F[PROPOSED related-to suggestions]
 F --> G{User reviews?}
 G -->|Dismiss| H[No graph mutation]
 G -->|Accept in future UI| I[Neutral related-to edge only]
```

## DFD L1 — Search Studio proposal

```mermaid
flowchart LR
 A[User question or approved term] --> B[Typed query AST]
 B --> C[Provider operator policy]
 C --> D{Valid and non sensitive?}
 D -->|No| E[Readable error]
 D -->|Yes| F[Local editable query and URL preview]
 F --> G{Explicit external search?}
 G -->|No| H[No transmission]
 G -->|Yes| I[Open provider URL]
```

## DFD L1 — Optional sync (deferred)

```mermaid
flowchart LR
 A[(Local committed state)] --> B[Backup export]
 B --> C{Explicit consent and verified restore?}
 C -->|No| D[Local only]
 C -->|Yes future gate| E[Authorized transport]
 E --> F[Remote encrypted storage policy]
 F --> G[Conflict and version review]
 G --> H[Reconcile into local state only after tests]
```

## Shared commands — proposed sequence

```mermaid
sequenceDiagram
 actor User
 participant UI as Side Panel / Quick Actions
 participant Dispatcher as Shared command registry
 participant Policy as Context permission policy
 participant Domain as Existing Capture or Discover
 participant DB as IndexedDB v5
 User->>UI: Request action
 UI->>Dispatcher: command ID and validated context
 Dispatcher->>Policy: Check eligibility
 alt Permission denied
  Policy-->>UI: Non-destructive fallback
 else Allowed
  Policy->>Domain: Execute bounded action
  Domain->>DB: Persist only confirmed mutation
  DB-->>UI: Result or error
 end
```

## State machines — proposed contracts

```mermaid
stateDiagram-v2
 [*] --> ACTIVE
 ACTIVE --> SAVED: checkpoint
 SAVED --> ACTIVE: new browser changes
 ACTIVE --> RECOVERY_NEEDED: unmatched after restart
 SAVED --> RECOVERY_NEEDED: unmatched after restart
 RECOVERY_NEEDED --> RESTORING: explicit preview and restore
 RESTORING --> ACTIVE: new working copy committed
 RESTORING --> RECOVERY_NEEDED: failed restore, source retained
 ACTIVE --> CLOSED: window closed
 CLOSED --> ARCHIVED: explicit archive
```

```mermaid
stateDiagram-v2
 [*] --> IDLE
 IDLE --> QUEUED: user approved AI indexing
 QUEUED --> RUNNING: idle resources permitted
 QUEUED --> CANCELLED: cancel
 RUNNING --> COMPLETED: output verified
 RUNNING --> FAILED: CSP or OOM or missing model
 RUNNING --> CANCELLED: cancel
 FAILED --> IDLE: fallback to lexical
```

```mermaid
stateDiagram-v2
 [*] --> CLOSED
 CLOSED --> OPEN: explicit user gesture
 OPEN --> EXECUTING: valid action selection
 OPEN --> CLOSED: Escape or blur
 EXECUTING --> OPEN: actionable recoverable error
 EXECUTING --> CLOSED: completed
```

**Trust boundary notes:** Chrome profile and extension origin are distinct from web page origin. Web page selections are untrusted inputs; public query URL reveals terms to selected provider only after a gesture. Privileged browser changes are dispatched only through extension-owned controls with context validation. Future WASM models must be packaged and verified under Chrome MV3 CSP.
