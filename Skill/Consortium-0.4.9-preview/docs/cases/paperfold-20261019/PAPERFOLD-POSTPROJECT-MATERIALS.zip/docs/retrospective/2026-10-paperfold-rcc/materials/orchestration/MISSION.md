# PAPERFOLD v0.8 — FULL UI/UX RECONSTRUCTION
## THREE CONSORTIA · TEN WORKERS · THREE EXECUTION STAGES

**EXECUTION MODE:** FULL DELIVERY — NOT CONCEPT-ONLY  
**ORCHESTRATOR:** Reasoning Consortium Controller  
**MANDATORY QUALITY SYSTEMS:** Visual Pipeline + AntiSlop  
**TARGET:** Complete, functional, responsive Paperfold UI/UX reconstruction  
**BASELINE:** Supplied Paperfold v0.8 GATED Prototype  
**RELEASE STATUS:** Production deployment remains blocked until required data-safety and real-Chrome gates pass.

---

# 0. NON-NEGOTIABLE MISSION

Reconstruct and implement the complete Paperfold user experience.

I reject the present interface architecture.

The problems include:

- Poor menu organization.
- Unconvincing visual hierarchy and layer design.
- Excessive pages, sections, and controls.
- Overcrowded headers and toolbars.
- Too many borders, separators, decorative boxes, and visual interruptions.
- Poorly organized Markdown editing workflows.
- Inadequate library and collection browsing.
- Dark-mode icon visibility defects.
- Unnecessary application-header logo.
- Broken Side Panel proportions and responsiveness.
- Navigation that reflects implementation history rather than user intentions.
- Inconsistency between Side Panel, full-tab workspace, modals, and contextual actions.

**Do not deliver another conceptual recommendation, a set of static mockups, or a CSS-only facelift.**

The objective is to complete the entire UI/UX reconstruction, from information architecture through actual source implementation, integration, screenshots, tests, and a deliverable candidate.

Do not stop after selecting a visual concept.

Do not ask the user to choose between competing wireframes. The consortium has delegated decision authority.

The three consortium stages must execute in sequence, and each must produce a canonical handoff that the next stage can use immediately.

---

# 1. PRODUCT AND DESIGN INVARIANTS

Paperfold is a local-first Chrome extension for collecting, editing, organizing, connecting, and retrieving Markdown-based research knowledge.

Its primary objects are:

- Board: persistent research/project context.
- Card: Markdown note or structured knowledge object.
- Source: external reference with provenance.
- Capture: saved content or source representation.
- Session: recoverable browser activity context.
- Discover: proposed knowledge relationships.
- Query Studio: structured research search preparation.

Preserve these distinctions.

Use **Board** in the user interface while maintaining compatibility with the existing `maincards` storage identifiers.

### Visual identity

- Remove the decorative Paperfold logo from all in-app headers.
- Display **Paperfold** as text only.
- Keep manifest-required extension icons where technically necessary.
- Preserve the approved Paper / Pure Black / System themes.
- Reuse the project's established palette instead of inventing a new one.
- Repair theme-dependent icon contrast.
- Minimize decorative iconography.
- Remove unnecessary outlines, separator lines, nested cards, and artificial depth.
- Prefer typography, spacing, and contextual grouping over ornamental containers.
- Keep the interface calm, highly readable, and functionally dense only where necessary.

### Experience identity

Study and critically compare:

- Notion: editorial clarity, content hierarchy, writing experience.
- Memex: source context, annotations, research connections.
- Karakeep: collection browsing, mixed-media organization, retrieval.
- Obsidian Web Clipper: rapid capture and Markdown preservation.
- Tiptap/Milkdown: editor behavior and possible interaction architecture.
- AFFiNE: relationships between documents and different workspace representations.

These are reference systems, not UI templates to copy.

A designer must demonstrate why a particular pattern improves Paperfold's actual workflow.

No default winner is predetermined.

---

# 2. REQUIRED WORKING SURFACES

The full redesign must account for:

1. Application navigation and workspace shell.
2. Markdown Card editor.
3. Boards and project navigation.
4. Library, bookmarks, Sources, and captures.
5. Search and filtering.
6. Discover suggestions and connection review.
7. Query Studio.
8. Browser Sessions and recovery.
9. Research annotation and citations.
10. Quick Capture and Chrome context-menu entry.
11. Contextual Paperfold popover.
12. Settings and account/integration configuration where already implemented.
13. Empty, loading, success, warning, error, and permission-denied states.
14. Expanded/full-tab workspace.
15. Narrow Chrome Side Panel.

Every existing feature must either receive a usable location or be explicitly documented as unavailable, staged, or blocked.

Do not make unsupported prototype functions appear production-ready.

---

# 3. CONSORTIUM TOPOLOGY

There are exactly three consortium stages and ten worker roles.

**The main orchestrator is not counted among the ten workers.**

It may route tasks, track closures, and handle operational handoffs, but it must not silently replace a specialist's work or become a hidden eleventh design contributor.

| Consortium | Roles | Workers |
|---|---|---|
| I — Wireframe Debate | 3 independent designers + 1 adjudicator | W1–W4 |
| II — Interaction/Motion & Build Specification | 2 interaction designers + 1 adjudicator and build planner | W5–W7 |
| III — Production Build | 2 independently owned builders + 1 integrator/verifier | W8–W10 |

No more than ten worker roles.

Do not create a separate worker for every small feature.

Reuse role-owned rooms/contexts where the RCC runtime supports this.

Each stage must report:

- Source inputs and revision identity.
- Decisions.
- Rejected alternatives.
- Design or code artifacts.
- Evidence anchors.
- Tests and validation.
- Unresolved risks.
- Handoff contract.
- Closure status.

Use RCC independence classes accurately.

Do not claim blind review after reviewers have already seen one another's proposals.

Do not claim a browser worker exists without a runtime target/room receipt.

---

# 4. MANDATORY VISUAL PIPELINE FOR ALL TEN WORKERS

Every worker, whether designer, adjudicator, builder, or verifier, must follow a Visual Pipeline-derived process:

**Evidence → Specification → Composition/Implementation → Preview → Compare → Diagnose → Correct → Validate → Handoff.**

Adapt the pipeline to UI/UX engineering. Do not introduce irrelevant video-rendering, venue-mapping, or animation deliverables.

For every owned UI component, preserve:

- Requirement ID.
- Surface and user journey.
- Approved design tokens.
- Container size constraints.
- Component state model.
- Interaction contract.
- Responsive behavior.
- Theme variants.
- Accessibility criteria.
- Source implementation reference.
- Preview or screenshot evidence.
- Acceptance result.

Visual work must remain measurable.

A mockup is not equivalent to a functioning application.

A CSS change is not equivalent to a validated responsive fix.

An animation preview is not equivalent to an accessible modal.

Every component must advance through real evidence states.

---

# 5. MANDATORY ANTISLOP FOR ALL TEN WORKERS

Apply AntiSlop at each decision and implementation boundary.

Audit the following classes of defects:

**Architectural slop**

Unnecessary abstractions, duplicated navigation, new frameworks without justification, or broken domain ownership.

**Interface slop**

Decorative buttons, excessive iconography, meaningless layers, duplicated settings, or unnecessarily complicated interactions.

**Responsive slop**

Desktop layouts compressed into the Side Panel, hidden overflow mistaken for a fix, or controls accessible only at wide widths.

**Interaction slop**

Fake actions, missing callbacks, animation without function, broken focus, stale selection, or unacknowledged save failures.

**Evidence slop**

Claiming test success from screenshots, claiming visual correctness from CSS source, or implying Chrome deployment from Node mocks.

**Source slop**

Confusing v0.7 reference behavior with the actual supplied v0.8 baseline.

**Product slop**

Making advanced functionality prominent merely because the source contains it, or inventing features to fill empty pages.

A finding requires source evidence, observed behavior, or a meaningful test.

Reject cosmetic fixes that leave the governing failure unchanged.

Include near-miss negative controls where appropriate.

---

# CONSORTIUM I — WIREFRAME DEBATE AND FINAL SELECTION
## Four workers: W1, W2, W3, W4

### W1 — Editorial and Writing-Centered Architecture
**Independence:** I2 BLIND

Mission:

Design a complete Paperfold information architecture prioritizing Markdown editing, writing focus, Board context, source insertion, and unobtrusive knowledge organization.

Do not assume this proposal must win.

Deliver:

- Complete navigation topology.
- Functional wireframes.
- Markdown editing workflow.
- Narrow Side Panel representation.
- Full-tab representation.
- Menu, toolbar, and settings organization.
- Feature relocation map.
- Key tradeoffs and risks.
- Testable UX claims.

### W2 — Research Collection Architecture
**Independence:** I2 BLIND

Mission:

Design a complete alternative emphasizing collection, retrieval, source previews, annotations, filtering, and efficient navigation across research objects.

Study Karakeep, Memex, and clipping workflows where relevant.

Deliver the same full-surface coverage as W1.

Do not merely restyle W1's architecture.

### W3 — Contextual Knowledge Architecture
**Independence:** I2 BLIND

Mission:

Design a complete alternative emphasizing the continuity between browsing, capturing, editing, Boards, and research discovery.

Investigate contextual navigation, progressive disclosure, shared commands, and interaction within constrained extension surfaces.

Deliver the same full-surface coverage as W1 and W2.

Do not build an intrusive AI dashboard.

### Debate protocol

W1, W2, and W3 first complete their independent designs without seeing the others' candidate conclusions.

After all three independent submissions are recorded, conduct one structured challenge round.

Each designer must identify:

1. The strongest quality of each rival proposal.
2. The rival's most consequential UX failure.
3. An everyday workflow where the rival performs better.
4. A real Side Panel constraint that challenges the rival.
5. A revision that would materially improve their own design.

Record this as debate evidence, not as three new worker roles.

### W4 — Wireframe Adjudicator
**Independence:** I1 CLOSURE-ONLY

W4 reviews the three wireframe closures, their evidence, and the debate.

W4 is the sole decision authority for Consortium I.

Compare designs on:

- Task discoverability.
- Markdown editor clarity.
- Collection usability.
- Navigation simplicity.
- Side Panel resilience.
- Full-tab scalability.
- Accessibility.
- Feature coverage.
- Implementation feasibility.
- Behavioral coherence.

**W4 must choose one canonical information architecture.**

Do not return three options to the user.

Do not simply average the proposals into a compromised design.

W4 may incorporate individually superior patterns from rejected alternatives only when they remain coherent with the selected architecture.

Required Consortium I output:

`UI-ARCHITECTURE-DECISION.md`

`INFORMATION-ARCHITECTURE.md`

`WIREFRAMES/`

`FEATURE-RELOCATION-MAP.md`

`CONSORTIUM-I-CLOSURE.json`

Exit gate:

Every existing feature has an identified destination, all critical user journeys are represented, and the selected wireframe architecture has an explicit responsive strategy.

Then automatically hand off to Consortium II.

---

# CONSORTIUM II — INTERACTION, ANIMATION, MODALS, AND BUILD PARTITION
## Three workers: W5, W6, W7

W5 and W6 receive the canonical Consortium I decision.

They must develop the interaction system immediately rather than restarting the wireframe debate.

### W5 — Motion, Modal, and Microinteraction Designer
**Independence:** I1 CLOSURE-ONLY

Mission:

Design the full motion and interaction language for the approved application architecture.

Scope:

- Modal opening and closing.
- Popovers.
- Contextual action menus.
- Hover and pressed states.
- Navigation transitions.
- Drawer behavior.
- Drag-and-drop feedback where necessary.
- Editor formatting controls.
- Source preview transitions.
- Collection selection.
- Toast notifications.
- Save-state indicators.
- Discover suggestion review.
- Recovery and error interactions.

Every animation must have a functional reason.

Motion should communicate state transitions, hierarchy, attention, or continuity.

Avoid constant decorative movement.

Specify:

- Trigger.
- Starting and ending states.
- Duration and easing.
- Interruption/cancellation behavior.
- Focus transition.
- Scroll behavior.
- Reduced-motion alternative.
- Performance risks.
- Failure fallback.

Do not invent unnecessary modals.

Simple actions should remain lightweight.

### W6 — Responsive Interaction and Accessibility Designer
**Independence:** I1 CLOSURE-ONLY

Mission:

Reconstruct the behavior of the same application across narrow Side Panel, standard Side Panel, and full-tab workspace contexts.

Scope:

- Responsive shell.
- Navigation collapse/expansion.
- Form stacking.
- Editor proportions.
- Search interactions.
- Menu and dialog placement.
- Collection list/grid behavior.
- Responsive previews.
- Keyboard navigation.
- Focus trapping where appropriate.
- Escape behavior.
- Selection preservation.
- Theme and icon consistency.
- Long content overflow.
- Browser zoom and text scaling.
- Screen-reader semantics.

Test representative container widths:

280, 320, 360, 420, 600, and 800px.

Test relevant viewport heights, 100–200% zoom/text scaling, and Paper/Pure Black/System themes.

Do not use arbitrary fixed aspect ratios for the application shell.

Image and audiovisual assets must retain appropriate intrinsic aspect ratios.

### W7 — Interaction Adjudicator and Build Partition Architect
**Independence:** I1 CLOSURE-ONLY

W7 compares W5 and W6, reconciles their interaction specifications, and makes the final Phase II decisions.

W7 must not simply concatenate two incompatible specifications.

W7 owns:

- Canonical design tokens.
- Component hierarchy.
- Page and route contracts.
- Modal and popover state machines.
- Responsive breakpoints or container rules.
- Animation contracts.
- Accessibility acceptance criteria.
- Theme behavior.
- Shared command/UI boundaries.
- Component API specifications.
- Exact source-file ownership for W8 and W9.
- Integration dependency order.
- Automated and visual test plan.

### Build split is mandatory

W7 must partition the implementation into two substantial, independently buildable work packages.

The partition must avoid simultaneous writes to shared source files.

If the current implementation is monolithic, use a defined component-module boundary or adapter contract instead of allowing two workers to rewrite the same entrypoint.

Provide a concrete file ownership matrix.

Recommended ownership:

**Build Package A:** Application shell, navigation, page composition, editor/collection integration, responsive layout ownership, and production mounting.

**Build Package B:** Isolated interaction components, modals, contextual popovers, motion tokens, settings controls, theme/icon components, and their tests.

This is a recommended technical division; W7 must verify actual source dependencies before freezing it.

All shared APIs, component events, CSS naming conventions, mounting points, and state contracts must be specified before the build starts.

Required Consortium II output:

`INTERACTION-SPEC.md`

`MOTION-AND-MODAL-CONTRACT.md`

`RESPONSIVE-CONTRACT.md`

`DESIGN-TOKENS.md`

`COMPONENT-API-CONTRACT.md`

`BUILD-PARTITION.md`

`ACCEPTANCE-MATRIX.md`

`CONSORTIUM-II-CLOSURE.json`

Exit gate:

A builder must be able to implement its assigned scope without asking another worker to invent missing navigation, design, or interaction decisions.

Then automatically hand off to Consortium III.

---

# CONSORTIUM III — PARALLEL BUILD, MERGE, AND VERIFICATION
## Three workers: W8, W9, W10

### W8 — Build Worker A
**Role:** Production application architecture and primary UI  
**Independence:** I1 CLOSURE-ONLY

Implement Build Package A using the approved Phase II contracts.

Own only assigned files and modules.

Deliver:

- Actual source changes.
- Functional page composition.
- Responsive shell behavior.
- Working editor and collection integration.
- Correct domain-service connections.
- Tests.
- Screenshots where browser execution exists.
- Diff and file hash manifest.
- Known limitations.

Do not redesign the selected architecture.

Do not edit files owned by W9.

### W9 — Build Worker B
**Role:** Production interaction and visual components  
**Independence:** I1 CLOSURE-ONLY

Implement Build Package B.

Own only assigned files and modules.

Deliver:

- Functional modal and popover components.
- Interaction and motion behavior.
- Theme/icon corrections.
- Configurable UI components.
- Accessible state transitions.
- Reduced-motion behavior.
- Contextual controls.
- Tests.
- Screenshots where browser execution exists.
- Diff and file hash manifest.
- Known limitations.

Do not redesign the selected architecture.

Do not edit files owned by W8.

### Parallel build contract

W8 and W9 must work from the same immutable canonical specification and source baseline.

Use separate Git worktrees or isolated source copies where supported.

Their work should proceed concurrently only when the execution runtime actually supports independent concurrent operations.

If RCC browser transport is serial-safe, maintain separate ownership and handoffs without falsely claiming simultaneous execution.

Neither builder may:

- Overwrite the other's files.
- Change public component contracts without adjudication.
- Change IndexedDB schema without an authorized migration plan.
- Modify unrelated repositories.
- Modify the user's active Chrome profile.
- Introduce unsupported remote services.
- Commit directly into a shared dirty working tree.

Every interface change must be supported by a real handler and meaningful state transition.

### W10 — Merger and Runtime Verifier
**Role:** Integration owner and final acceptance examiner

W10 receives:

- Canonical Consortium I architecture.
- Canonical Consortium II interaction/build contracts.
- W8 source artifact and tests.
- W9 source artifact and tests.
- Both file hash manifests.
- Existing Paperfold regression suites.
- The applicable staging release gates.

W10 must:

1. Verify source identities and changed-file ownership.
2. Merge W8 and W9 into an isolated integration checkout.
3. Resolve mechanical integration conflicts without introducing new product-design decisions.
4. Return unresolved architectural contradictions to the responsible upstream worker.
5. Run build and syntax checks.
6. Run existing regression suites.
7. Run changed-component tests.
8. Test actual navigation.
9. Test editor persistence.
10. Test contextual menu and modal behavior.
11. Verify responsive layouts at the required widths.
12. Verify all three themes.
13. Verify keyboard and accessibility behavior.
14. Compare the rendered UI with canonical design artifacts.
15. Generate a candidate package with exact file hashes.

W10 must distinguish its merge work from objective test evidence.

Because W10 performs both integration and verification, its review must not be misrepresented as fully independent blind verification. Preserve reproducible automated receipts and mark any genuinely independent witness requirement as outstanding when necessary.

If a required runtime is unavailable, mark the affected test UNVERIFIED.

Do not fabricate browser screenshots or test passes.

Required Consortium III output:

`PAPERFOLD-UI-REFACTOR-CANDIDATE.zip`

`INTEGRATION-REPORT.md`

`SOURCE-HASH-MANIFEST.json`

`TEST-RECEIPTS.json`

`VISUAL-REGRESSION-REPORT.md`

`ACCESSIBILITY-REPORT.md`

`RELEASE-GATE.md`

`CONSORTIUM-III-CLOSURE.json`

---

# 6. FULL-STACK IMPLEMENTATION RULES

This is not just a visual design exercise.

For every migrated UI control, maintain the chain:

**User action → UI event → Command handler → Domain service → Persistence → Confirmed result → User feedback.**

Every command must be genuinely functional.

No decorative buttons.

No fabricated save states.

No mock data in production screens unless clearly marked as fixture/demo content.

Preserve the existing:

- IndexedDB schema and data.
- Boards and Cards.
- Sources and annotations.
- Provenance relationships.
- Markdown content.
- Sessions and revisions.
- Search behavior.
- Existing backup/export paths.
- Existing settings.

Existing deferred Discover/Query Studio implementations must respect their known safety and regression gates.

Do not silently activate an unverified prototype simply because its UI is ready.

Do not present semantic similarity as a confirmed scientific relationship.

Do not undertake an unnecessary framework rewrite.

Do not change permissions or security architecture merely to support a visual redesign.

---

# 7. RESPONSIVE AND VISUAL ACCEPTANCE

### Mandatory Side Panel tests

At 280, 320, 360, 420, and 600px:

- No application-root horizontal overflow.
- No inaccessible navigation items.
- No clipped primary buttons.
- No overlapping text.
- No stretched image/video previews.
- No broken modal sizing.
- No dropdown outside the available viewport.
- No accidental loss of editor focus.
- No inaccessible action hidden behind overflow without an alternative.
- No broken scroll ownership.
- No fixed-width desktop composition.
- No inaccessible save or navigation state.

At expanded widths:

- Space is used meaningfully.
- Multiple panes appear only when useful.
- The editor remains readable.
- Graphs or spatial views have appropriate room.
- Functionality remains consistent with the Side Panel.

### Mandatory theme tests

Paper, Pure Black, and System:

- Correct text and background tokens.
- Correct icon contrast.
- Correct selected/focused/hover/disabled states.
- Correct code and Markdown syntax styling.
- No theme-specific invisible controls.
- No blanket inversion of photos, artwork, or favicons.

### Mandatory interaction tests

- Markdown edit, save, reload, and undo.
- Board navigation.
- Source capture and insertion.
- Search and filtering.
- Session navigation.
- Modal open, close, cancellation, and focus return.
- Contextual popover positioning.
- Keyboard-only operation.
- Reduced-motion behavior.
- Browser resize during active editing.
- Relevant permission-denied states.

Every UI surface must be exercised through representative user journeys, not only component snapshots.

---

# 8. ANIMATION QUALITY CONTRACT

Do not animate everything simply because the user requested animation.

Use animation to communicate:

- Opening and closing.
- Spatial continuity.
- State changes.
- Navigation transitions.
- Confirmation and recovery.
- Contextual reveal.

Prioritize transform/opacity-based transitions where appropriate.

Avoid long blocking sequences, excessive bouncing, or visually noisy motion.

Respect `prefers-reduced-motion`.

Preserve input responsiveness and cursor focus.

For every animation, specify:

- Trigger.
- Purpose.
- Transition states.
- Duration/easing.
- Cancellation behavior.
- Interaction lock rules.
- Focus behavior.
- Reduced-motion alternative.
- Measured or inspected runtime result.

Animations may not conceal a save failure or cause an action to execute twice.

---

# 9. FINAL CONSORTIUM MERGE GATE

The overall design/build closure may be marked PASS only if:

**CONSORTIUM I**

A single architecture was selected after genuine independent proposals and debate, with all primary features mapped.

**CONSORTIUM II**

The selected design has a complete interaction, motion, responsive, and build-partition contract.

**CONSORTIUM III**

Both assigned work packages were delivered, merged, and tested against the canonical specification.

**APPLICATION**

The delivered candidate:

- Builds successfully.
- Preserves required existing functionality.
- Has no known critical navigation regressions.
- Demonstrates corrected Side Panel behavior.
- Demonstrates usable Markdown editing.
- Demonstrates coherent Library, Board, and Session workflows.
- Has functioning modals and menus.
- Has verified dark-mode icon behavior.
- Includes actual verification receipts.
- Includes an exact source hash manifest.
- Remains rollback-capable within documented limits.

If any mandatory criterion fails, record the blocking defect and reopen the earliest responsible stage.

Do not average failures into a passing score.

### Separate production safety gate

A successful UI refactor does not automatically certify production deployment.

Existing populated migration, clean archive restoration, and real Chrome recovery requirements remain mandatory.

The UI candidate may be completed and packaged while production installation is still blocked.

Never recommend installing an unverified candidate over the daily user profile.

---

# 10. EXECUTION COMMAND TO THE ORCHESTRATOR

Start the three-consortium workflow immediately.

1. Verify the supplied source snapshot and tool capabilities.
2. Instantiate or prepare exactly ten role-owned worker packets.
3. Execute Consortium I: three independent wireframe proposals, debate, one decision.
4. Transfer only the canonical decision and necessary evidence to Consortium II.
5. Execute Consortium II: two full interaction/motion proposals, one decision and locked build partition.
6. Execute Consortium III: two separately owned builds, followed by merge and verification.
7. Produce the complete application candidate and verification artifacts.
8. Report runtime limitations without inventing worker executions.
9. Preserve rejected alternatives and unresolved debts in the decision records.
10. Finish with a concrete result, not another request for conceptual direction.

**No unnecessary pauses between consortium stages.**

The consortium owns the decisions it has been authorized to make.

Only stop for a genuine missing dependency, destructive data risk, authorization boundary, or unresolvable source conflict.

### Terminal response format

Return:

- Consortium I: selected design and rationale.
- Consortium II: final interaction system and build partition.
- Consortium III: build and merge results.
- Final application candidate.
- Actual test receipts.
- Source integrity and preservation result.
- Screenshots or visual evidence from real rendering.
- Outstanding defects.
- Production deployment status.

Explicitly separate:

`DESIGNED`

`IMPLEMENTED`

`BUILT`

`UNIT-TESTED`

`BROWSER-TESTED`

`INTEGRATED`

`RELEASE-READY`

Do not advance a status without observed evidence.

**FINAL DIRECTIVE: Build the full Paperfold experience, not another presentation about how Paperfold might look.**