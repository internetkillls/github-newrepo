# Official reference patterns verified at W4 adjudication

These references are **first-party descriptions**, not comparative test results. They license narrow interaction criteria, never a new feature assertion about Paperfold's current source.

| First-party resource | W4 evidence scope | Transfer to W1 canonical design | Do not infer |
|---|---|---|---|
| [Notion — sidebar navigation](https://www.notion.com/help/navigate-with-the-sidebar) | Help article confirms labeled routes and search/quick entry | Predictable Write/Boards/Library destinations, secondary route list | Infinite page nesting fits a 280px Side Panel |
| [Karakeep — search query language](https://docs.karakeep.app/using-karakeep/search-query-language/) | Official typed saved-item search mechanism | Library type facet and explicit query/filter persistence | Paperfold already supports an equivalent heterogeneous global index |
| [Memex — project repository](https://github.com/WorldBrain/Memex) | First-party project README describes retrieval/annotation workflows | Maintain Source/Annotation provenance when retrieving citations | Paperfold may import full browser history or use Memex backend |
| [Obsidian Web Clipper — official help](https://obsidian.md/help/web-clipper) | Official help URL reachable; W1/W2/W3 supporting description | Stage clip/selection/metadata and require user review | Paperfold can copy vault architecture, host access or template engine |
| [Tiptap — focus command](https://tiptap.dev/docs/editor/api/commands/selection/focus) | Official selection/focus API documentation | Preserve selection/focus through source command | Replace existing CM6 with Tiptap |
| [Milkdown — official project](https://milkdown.dev/) | Official project overview reachable | Evaluate Markdown editing tradeoffs against installed CM6 | Framework replacement is necessary for a UI redesign |
| AFFiNE blog | Upstream candidates supplied a first-party URL; W4 direct retrieval failed | Derived views as a **research pointer only** | Verified AFFiNE interaction mechanics or measured superiority |

W4 consulted the live official resources on 2026-10-16; no content was copied into the fixture, no network asset was loaded from reference systems, and all development claims rely on the supplied source/actual fixture receipts rather than these products' marketing descriptions.
