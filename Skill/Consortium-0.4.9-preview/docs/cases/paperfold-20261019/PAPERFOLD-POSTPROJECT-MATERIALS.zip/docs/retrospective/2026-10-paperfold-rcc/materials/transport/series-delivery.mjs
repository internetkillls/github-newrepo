import {readFileSync,writeFileSync} from 'node:fs';import {join} from 'node:path';import {digest} from './rules.mjs';
export function queuePiece(job,base,event){
 const index=job.collectedChunks.length;const path=job.seriesPath||'W5-INTERACTIONS.md',size=job.seriesBytes||18620,total=job.seriesCount||5;
 const request=`Existing-file transfer ONLY. Read ORIGINAL ${path} bytes. Return ONLY chunk ${index} of ${total} as ONE JSON code block in your FINAL REPLY. Slice raw bytes at offsets ${index*4096} through ${Math.min((index+1)*4096,size)} (end exclusive). File length is ${size}. Schema: {"schema":"paperfold.file-chunk.v1","path":"${path}","index":${index},"total":${total},"fileSha256":"COMPUTED_SHA256_OF_WHOLE_ORIGINAL_FILE","chunkSha256":"COMPUTED_SHA256_OF_THIS_BYTE_SLICE","content_base64":"ACTUAL_BASE64_OF_THIS_SLICE"}. This reply requires at most 5500 Base64 characters. Do not return other chunks, a table, handoff, ZIP or redesign. Compute from actual existing bytes, and copy this one complete JSON block into FINAL REPLY, not only tool output. If unavailable report BLOCKED.`;
 job.promptPath=join(base,job.role+'-piece-'+index+'.md');writeFileSync(job.promptPath,request);job.promptSha256=digest(readFileSync(job.promptPath));job.expectedPriorTurns=job.completedTurnCount;job.uploads=[];job.skipDependencyUpload=true;job.reconcilePreSendCount=true;job.turnKey=null;job.samples=[];job.codeBlocks=[];job.deadline=null;event(job,'PENDING',{reason:'Retrieve existing Markdown byte slice '+index+' of '+total});
}
export function handleSeries(job,base,event){
 if(!job.chunkSeries)return false;
 const index=job.collectedChunks.length;const path=job.seriesPath||'W5-INTERACTIONS.md',size=job.seriesBytes||18620,total=job.seriesCount||5;let matches=[];
 for(const raw of job.codeBlocks||[]){try{const o=JSON.parse(raw.replace(/^json\s*/i,''));if(o.schema==='paperfold.file-chunk.v1')matches.push(o);}catch{}}
 if(matches.length!==1)throw Error('Expected exactly one requested byte slice');
 const part=matches[0],bytes=Buffer.from(part.content_base64||'','base64');
 if(part.index!==index||part.total!==total||part.path!==path||bytes.length!==Math.min(4096,size-index*4096)||digest(bytes)!==part.chunkSha256)throw Error('Invalid requested byte slice');
 job.collectedChunks.push(part);writeFileSync(join(base,'evidence',job.role+'-series-chunks.json'),JSON.stringify(job.collectedChunks,null,2));
 if(job.collectedChunks.length<total){queuePiece(job,base,event);return true;}
 if(job.expectedTransferHash&&job.collectedChunks.some(p=>p.fileSha256!==job.expectedTransferHash))throw Error("Transfer manifest whole-file hash mismatch");job.codeBlocks=[...job.collectedChunks.map(p=>JSON.stringify(p)),...job.seriesHandoff];job.chunkSeries=false;return false;
}
