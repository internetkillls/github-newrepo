# W8 repair build report — scoped production markup/CSS

**Source**: immutable supplied v0.8 SHA-256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`. **Ownership**: W8 `sidepanel.html`, `sidepanel.css` only; W9 `sidepanel.js` untouched. **Stage III**: BLOCKED (not release-ready). **W8 owned markup/CSS exit**: PASS, subject to listed W9 and native debts. No Chrome profile, user data, permissions, schema, Git state or unchanged baseline file was modified.

## Evidence → contract → composition → preview → compare → diagnose → correct → validate → handoff

- **Source check:** `source.zip` binary hash verified; reused W8's reviewed complete HTML/CSS from dependency bundle rather than redesigning. Read `MISSION.md`, `SOURCE-MANIFEST.json`, W4 canonical component contracts and W7 canonical routes, ownership, token, interaction, responsive and modal contracts. No source changes outside two W8-owned paths.
- **Confirmed W10 defect:** no production `[data-pf-popover-trigger]` or `[data-pf-popover]`, no Capture review dialog; W9 had optional toggle functions and Capture direct-write listener. W8 added one real Library Current-tab source-action popover with three *already supported nonmutating W7 route actions*, and a native staged Capture review dialog with explicit fields, buttons, accessible labels, status and disabled commit.
- **New negative finding:** simply adding `data-pf-open-dialog` to `#attachCurrentButton` opened the modal but **also invoked the old direct-commit listener** in actual extracted W9 click handling. In the initial failed Chromium negative probe `__probeWrites` advanced from 0 to 1 before confirmation. This defeated a seemingly viable implementation; the patch was changed to safety-disable `#attachCurrentButton` on load. It is not a production Capture flow until W9 removes the bypass and then enables the button. No JS workaround was inserted into HTML/CSS.
- **Position/focus:** popover width/height are viewport-bounded, uses W9's anchored `positionPopover`; role-menu rows are keyboard-focusable with arrow/Home/End and Escape focus return; native dialog stays viewport-bounded with internal scrolling and sticky actions. Tokens are reused in Paper/Black/System and reduced-motion CSS stays active. No in-page content-script injection was implemented; W4's website-selection popover remains spec-only.
- **Materialized evidence:** `W8-REPAIR-EVIDENCE/static-receipt.json`, `browser-receipt.json` are actual command results. `test_w8_repair_browser.py` extracts W9 interaction methods from supplied reviewed W9 file and applies W10's documented `data-pf-active` mechanical integration fix *in browser fixture memory only*, so renders are **not** complete Chrome extension boot or IndexedDB evidence.

## Owned component-boundary checks

| Boundary | Actual checks and outcome | Negative control / remaining limitation |
|---|---|---|
| Source and routes | Original baseline ID set and prior W8 ID set retained; exactly eight W7 views | No new production JS and no changed schema |
| Context popover | Trigger/menu linkage, visible trigger, valid route values, W9 toggle/geometry, focus, Escape, outside click, resized viewport in Chromium fixture | It is a Side Panel context menu, **not** site-injected page selection |
| Capture review | Native dialog semantic labels, read-only fields, Cancel and disabled Save, bounded viewport and initial focus via W9 `openDialog` fixture | W9 legacy Capture direct write persists until replaced; capture disabled in production markup to prevent bypass |
| Themes and reduced motion | Chromium samples Paper/Black/System at multiple widths/heights; legacy motion-reduce rule active | No screen-reader, native zoom or native Side Panel verification |
| Persistence | None performed or claimed in markup/CSS | W9 must prove Cancel zero `sources`/`links` writes and Save storage ACK in real disposable IndexedDB |

## Reproducible tests and receipts

- Static (**17/17 PASS**): run `python W8-REPAIR-TESTS/test_w8_repair_static.py --patch . --baseline <extracted-v08> --prior-w8 <reviewed-w8-dir> --w9-source <reviewed-w9-sidepanel.js>`. Static receipt records passing assertions.
- Chromium (**6/6 scoped width×height×theme cases PASS**, sampled popover contrast ≥4.5:1): run `python W8-REPAIR-TESTS/test_w8_repair_browser.py --patch . --w9-source <reviewed-w9-sidepanel.js>`. This requires Playwright and available Chromium/Chrome (auto-detected or `--chromium`), and performs **six** discriminating width/height/theme combinations; browser receipt records true passing cases only. No portable production file contains the runtime executable path.
- Negative control from intermediate failed test is documented above, not laundered into the final positive test count. The frozen route data-pf-active integration fix is used only in the fixture and is not claimed as W8's new implementation.

## Applied AntiSlop/RMC and adapted Visual Pipeline

Scope/lineage first; distinguish W4/W7 canonical contracts from prior worker assertions; source-grounded DOM and event causality; falsify proposed safety gate by actually measuring the legacy click-through; repair earliest faulty boundary by safety-disabling until W9 acts; rerun new tests with observable browser receipts; preserve untested native/data gates. Each new component is mapped to requirement, token, view size, state, interaction, accessibility and explicit test/unknown. The critical failure is a **confirmed event fall-through**, not stylistic slop. Unsupported claim rejected: “a modal visible means Capture was safely staged.”

## Open debts/reopen criteria

1. **W9 MUST repair** `attachCurrentButton` direct `attachTab` click handler, bind staged review, enable the initially disabled control only after that listener is replaced, populate metadata, gate confirm, run Cancel zero-write and storage ACK tests. No W8-only implementation can satisfy this JS boundary. Do not treat W9's already shipped citation review as Capture review.
2. W10 must assemble exact owned patches and W9 repair, run full extension bootstrap and native Side Panel with seeded disposable IndexedDB including permission denial, duplicate/stale Capture, CM6 undo/IME, zoom at 100/150/200%, assistive technology and recovery.
3. W4 S11 website text-selection injection is not authorized/implemented by this in-app Library popover. Reopen W7 only if a distinct injected-page API/permission decision becomes mandatory.

**Scoped reopen condition:** loss of an original DOM ID, overlap with W9-owned file, missing/hidden menu on actual W9 load, failing keyboard/resize/theme tests attributable to W8, or a new canonical owner/API decision. Stage III cannot PASS from these fixtures.
