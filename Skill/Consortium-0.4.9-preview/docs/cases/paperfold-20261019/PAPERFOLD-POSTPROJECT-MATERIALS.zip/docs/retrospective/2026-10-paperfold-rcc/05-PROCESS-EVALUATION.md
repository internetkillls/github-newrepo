# Evaluation against the user's AI coding rules

The criterion source is [your Notion note](NOTION-CRITERIA.md). The assessment below is a post-project engineering/design judgment supported by artifacts. It is not a retrospective user satisfaction score.

| Criterion | What this project earned | What is missing | Next discriminating step |
|---|---|---|---|
| Start with cause and human situation | Mission named dense hierarchy and broken research continuity; three architectures answered different dominant tasks. W4 tied choice to resuming a Card. | No observed participant sessions or baseline task-distribution evidence. “Writer-first is intuitive” remains a hypothesis. | Observe real capture→inspect→write and retrieve→compare tasks; record where people hesitate or lose context. |
| Simplify the flow before adding technology | Four compact destinations; one Capture action; optional Board context; no editor framework replacement or required Context home. | Secondary recovery discoverability and substantial pre-editor controls remain. Simpler navigation can move difficulty elsewhere. | Compare current header with deferred controls and test recovery discoverability. |
| Atomic functions in the actual environment | Explicit preview, confirm, cancel, storage ACK, route, focus and record identity contracts; real Chrome/IDB checks. | Some broad spec language/fixture adapters were initially accepted without combined runtime evidence. | Build state/delta tests for each critical journey before broad visual matrix work. |
| Relevant precedents and data/rules | W4 compared labeled navigation, typed collection, provenance, capture review and focus preservation; kept existing data model/CM6. | Research access varied; W5/W7 recorded research debts. Pattern analogy is not evidence of Paperfold user benefit. | Trace each adopted pattern to the exact functional problem and test it locally. |
| Simplest usable representation | Writer surface, typed Library, secondary tools and narrow single-column contract. | Redundant headings, persistent Delete and dense toolbar remain visible candidates for simplification. | Test a reading/writing focus variant with unchanged functions and data. |
| Measure before and after | Extensive source, fixture, regression and native measurements; real failure/repair of contrast. | No comparable pre/post human task outcome, error rate, time-on-task or longitudinal research-quality result. | Establish baseline protocol and record actual human outcomes before claiming improvement. |
| WBS with deliverables and role/lens | Exactly ten role rooms, staged closures, exact filenames, invariants and source ownership. | WBS did not automatically become an expert system; stale task counter, gate assumptions and recovery complexity needed host judgment. | Model explicit rules/status dimensions with negative tests and machine-readable exit receipts. |
| Respect intuition without false clarification | Architectures preserved distinct writing/collection/context interpretations; W4 did not ask the user to choose mockups after delegated authority. | Persistent “continue” requests show orchestration consumed attention. Human lived experience remained represented mainly by model scenarios. | Ask for one concrete frustrating episode and preserve its desired result through implementation and evaluation. |

## What went well

The debate exposed a real violation of intent rather than only comparing aesthetics. W4 made a single architecture decision and preserved a serious rival. W7 converted source coupling into exact ownership and API obligations. W8/W9 stayed inside production-file boundaries, and W10 refused to imply production PASS from fixture success. The host then returned an actual native counterexample to W8 and checked the repaired bytes. Those are causal links between evidence and a changed artifact.

The project also preserved distinctions that often disappear in AI work: proposed versus canonical, inspection versus mutation, toast versus commit ACK, fixture versus installed extension, source transport versus runtime acceptance, and source application versus deployment.

## What did not work well enough

**Orchestration needed too much intervention.** The visible chat contains many “next,” “continue,” “check” and reports that nothing was sent. The event log has 822 records, including 83 UNCERTAIN and 52 BLOCKED entries. These are counts of status events, not unique failed jobs, duplicate sends or independent incidents. They nevertheless show a heavy recovery burden. A process advertised as automatic needed a durable runner, heartbeat and explicit stop conditions before it became a useful autonomous workflow.

**Artifact delivery dominated work that should have been finished.** W5 specification recovery and W10's 52 slices illustrate the cost. The receiver needed exact artifacts; a downloadable-looking response was insufficient. This improved integrity but exposed a missing reliable artifact channel. Future case planning should check deliverability early with a tiny representative package.

**The gate mixed status dimensions.** W10 could truthfully finish integration/source delivery while reporting missing native evidence. A PASS-only gate treated that honest result like unusable work. The future model needs independent `transport`, `deliverable`, `verification` and `release` fields.

**Some tests were broad but not deep enough at the risky boundary.** W8's six contrast samples and hundreds of layout combinations did not find the native cascade defect. W5's specification repeatedly used generic field language; meaningful interaction differences lived in the specific rules. The earliest serious integrated journey should precede a large screenshot matrix, and each critical state should have distinct data/focus/error semantics.

**The human outcome was never measured.** Before/after software invariants are valuable, but they do not establish that research feels more coherent. The honest portfolio story is an evidence-controlled design and implementation process with a defined usability study still needed.

## Priority improvements

1. Begin with one concrete incident and a measurable task, alongside the general product story. Preserve both through design and review.
2. Test one full native vertical journey early, including cancel/failure/reload, before expanding fixture coverage.
3. Validate artifact transport and full-document receipt before dependent planning. Retain a source/section inventory, not only a summary.
4. Split queue/delivery/behavior/release status. Preserve BLOCKED release debts without redoing completed source delivery.
5. Run a post-project interview in the original rooms, then independently corroborate claims. Feed only supported method improvements into RCC.

## What to put in the next prompt

“Evaluate against my causal problem → atomic function → simple interaction → measured outcome criteria. Show one concrete user episode, one serious rival, the smallest native test and a before/after protocol. Preserve unknowns. Do not call fixture success or worker consensus a human usability result.”
