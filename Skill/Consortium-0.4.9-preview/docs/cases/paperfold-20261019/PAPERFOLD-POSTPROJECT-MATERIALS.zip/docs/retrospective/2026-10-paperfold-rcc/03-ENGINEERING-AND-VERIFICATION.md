# Reducing bugs by making uncertainty executable

The consortium did not maintain a bug-free system. It constrained the edit surface, detected several defects, preserved failed attempts, and narrowed what passing results were allowed to mean. That is a stronger engineering account than claiming prevention from careful prompting.

## Preserve the system before changing the presentation

Every production builder received the same immutable baseline archive, SHA256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`, and a 76-file manifest. W7 assigned `sidepanel.html` and `sidepanel.css` to W8, and `sidepanel.js` to W9. Shared persistence, schema, manifest, permission, session and synchronization modules were outside that authority. The API contract preserved baseline IDs or explicit adapter mappings, so a calmer shell could still call the established behavior.

This prevented two builders from concurrently replacing the same file. It did not remove cross-file coupling. A JS route still needed the correct HTML node and CSS visibility state. The menu and `data-pf-active` repairs show why exact file ownership must be paired with semantic handshake tests. W10 was responsible for assembling both sides; fixes returned to the source owner.

The host reconstructed a complete candidate from baseline plus exact delivered changes, checked changed-file hashes, no deletion and ownership, reviewed the delivered harness before execution, and tested in disposable Chrome profiles. The later repository application kept original preimages and performed guarded replacement. Application itself is recorded in [UI-RECONSTRUCTION.md](../../UI-RECONSTRUCTION.md); historical reports saying “original project untouched” refer to the earlier candidate stage and must not be read as today's repository state.

## Cases that exposed real weaknesses

| Defect or gap | What revealed it | Repair or honest boundary | What it teaches |
|---|---|---|---|
| W1 Library fixture silently appended to a Card | Adversarial debate inspected `insertEvidence()` | Separate read-only inspection, staged target/caret review and explicit commit contract | A plausible happy path can violate user intent before persistence is even involved. |
| HTML/CSS/JS route and contextual menu did not form a complete integrated handshake | W10 integration/review and owner repair packets | W8 supplies semantic markup/state hooks; W9 owns paired behavior | Disjoint files still share an API. Test the assembled UI, not only selectors in each patch. |
| Capture needed stronger review/cancel/transaction boundaries | Integration repair and native data journeys | Explicit preview/confirm; no-write cancel; Source/link atomic transaction, stale URL refusal, dedup and abort checks | A UI cancel label is insufficient; inspect actual database deltas. |
| Dark editor controls became unreadable despite fixture contrast PASS | Host native screenshot and computed styles | W8 repaired semantic foreground/cascade; host repeated the real matrix | Sampling a handful of colors misses cascade, active, hover and theme-specific effects. |
| Early host harnesses raced save/reload or UI readiness | Preserved diagnostics and direct DB probes | Wait for the explicit save ACK, then inspect actual IndexedDB and reload | A failing harness can be wrong; preserve and diagnose it rather than silently relabeling the product. |
| Transport response/download was mistaken for obtainable source | Download failures and invalid/truncated Base64 | Verify existing bytes through bounded slices and full hash | A published-looking link does not prove the host has the artifact. |

## Evidence tiers and what each bought

**Source/contract checks** established baseline identity, ownership, required bindings and expected transitions. **Fixtures** exercised isolated HTML or behavior adapters. They helped diagnose states and layout cheaply but lacked the installed extension's real CSS/CM6/Chrome/service-worker/storage environment.

**Host regression commands** covered syntax, existing module families, interaction/static tests, security and integration boundaries. The [receipt](../../../EVIDENCE/host/regressions.json) records 12 commands. This is 12 command results, not 12 individual assertions and not complete feature coverage.

**Native checks** loaded the extension into disposable installed Chrome 155 profiles with seeded records. They provided stronger evidence for specific claims:

| Evidence | Observed scope | Limit that remains |
|---|---|---|
| [Data journeys](../../../EVIDENCE/native/native-data-journeys.json) | Real CM6 input/save/reload/undo; Capture preview/cancel; commit Source+link; repeated dedup; changed URL refusal; genuine `transaction.abort()` rollback; post-abort success; reload; absent-origin permission refusal | Eleven named journeys, not every editor/citation variant. Injected native abort is intentional fault injection; permission API refusal is not manual prompt dismissal. |
| [Native visual/panel](../../../EVIDENCE/native/native-visual-panel.json) | Actual extension routes/widths, Chrome tab zoom checks and browser-created Side Panel target | Browser-created panel bootstrap does not certify every human-operated native browser workflow. |
| [Contrast](../../../EVIDENCE/native/native-contrast-after.json) | Exact repaired CSS, 1,020 enabled-control text samples; minimum 4.9406118576:1 over tested widths/themes/modes/states | Not all icons, semantic accessibility, images or all future content. Do not generalize to full WCAG conformance. |
| [Composition](../../../EVIDENCE/native/native-composition.json) | Browser composition events and committed Japanese text, storage ACK and reload | Physical OS IME candidate-window operation unverified. |
| [Session recovery](../../../EVIDENCE/native/native-session-recovery.json) | Actual recovery preview/confirm, native window creation, preserved Board and repeated restore dedup | Does not restore form state, cookies, JS heap or arbitrary browser state. |
| [Archive recovery](../../../EVIDENCE/native/native-archive-recovery.json) | Populated real-IDB export, integrity negative control, migration snapshots, explicit host-harness atomic restore and reload | Host recovery harness is not a built-in product importer; intentionally omitted internal backup payloads/logs were not restored. |
| [Accessibility tree](../../../EVIDENCE/native/native-panel-accessibility-tree.json) | Named native-panel controls and scoped keyboard/focus checks elsewhere | An accessibility tree is not a screen-reader user session. |

Later native-panel evidence resolved an earlier `Extensions.triggerAction` target-type problem. The original data-journey receipt still records that earlier attempt as unverified; evidence is cumulative by named scope, not rewritten to hide failures.

## A useful example: Cancel as a database invariant

For Capture, a test starts with Source and Card-link record counts and identities. Preview may compute candidate content, but Cancel must leave both stores unchanged. Confirm must either commit both records or neither. A second identical capture must not add duplicates. An active-tab URL change between preview and confirmation must reject stale content. An actual native transaction abort must roll back both stores, followed by a positive control showing a subsequent transaction can succeed.

This atomic transaction is scoped to **reviewed global Capture**. As W9's source/interview explains, other historical attachment paths were not universally converted to this new transaction. Evidence for the reviewed path must not be applied to every method of attaching a Source.

Those negative controls discriminate working behavior from a decorative preview. Testing only that a dialog closes or a success toast appears would not.

## Reproducibility and release status

Final hashes are in [HOST-FINAL-REVIEW.json](../../../HOST-FINAL-REVIEW.json) and [SOURCE-HASH-MANIFEST.json](../../../SOURCE-HASH-MANIFEST.json). The baseline-plus-patch review has three changed production files, 73 unchanged baseline files and no deletion. The original application backup lives at the path recorded in the application receipt, outside the repo. No active user profile was installed over, and no deployment was performed.

The release remains BLOCKED for the residuals in [RELEASE-GATE.md](../../../RELEASE-GATE.md). This retrospective has not rerun product regressions because it changes documentation only. Documentary integrity checks are reported separately from historical product test evidence.

## What to put in the next prompt

Require each behavioral claim to name its input, state before/after, actual data store or browser surface, failure injection, positive control and receipt. Specify the exact source hash. Ask explicitly which required journey is still untested, rather than requesting a universal “no bugs” assurance.
