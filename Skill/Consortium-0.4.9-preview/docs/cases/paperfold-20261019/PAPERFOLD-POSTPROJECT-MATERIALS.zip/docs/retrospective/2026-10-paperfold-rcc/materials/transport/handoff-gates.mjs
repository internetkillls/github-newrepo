import {readFileSync,writeFileSync,mkdirSync,readdirSync,statSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseDelivery,digest} from './rules.mjs';
const base=dirname(fileURLToPath(import.meta.url));
export function control(blocks,job,source){
 const matches=blocks.flatMap(raw=>{try{const o=JSON.parse(raw.replace(/^json\s*/i,''));return o.schema==='paperfold.handoff.v1'?[o]:[];}catch{return [];}});
 if(matches.length!==1)throw Error('Exactly one typed handoff control required');
 const o=matches[0];
 if(o.task!==job.role||o.sourceSha256!==source||(o.status!=='PASS'&&!(job.allowBlockedSourceForIntegration===true&&job.requiresSource&&!job.stageGate&&o.status==='BLOCKED')))throw Error('Handoff blocked, wrong task or wrong source identity');
 if(job.stageGate&&(o.canonical!==true||o.stage!==job.stageGate))throw Error('Stage lacks canonical adjudicator authority');
 return o;
}
export function ownership(o){
 if(!o||!Array.isArray(o.w8)||!Array.isArray(o.w9)||!o.w8.length||!o.w9.length)throw Error('Missing exact W8/W9 ownership arrays');
 const paths=[...o.w8,...o.w9];
 if(paths.some(p=>typeof p!=='string'||!p||p.includes('\\')||p.includes('*')||p.includes(':')||p.startsWith('/')||p.split('/').some(s=>s==='..'||s==='.git')))throw Error('Ownership must use safe exact portable paths');
 if(new Set(paths.map(p=>p.toLowerCase())).size!==paths.length)throw Error('Overlapping build ownership');
 return o;
}
export async function validateHandoff(job,state,exec){
 const handoff=control(job.codeBlocks||[],job,state.sourceSha256);
 const directory=join(base,'artifacts',job.role,'validated');mkdirSync(directory,{recursive:true});
 const delivery=parseDelivery(job.codeBlocks);
 if(delivery)for(const f of delivery.files){const path=join(directory,...f.path.split('/'));mkdirSync(dirname(path),{recursive:true});writeFileSync(path,Buffer.from(f.content_base64,'base64'));}
 for(const a of job.artifacts||[])if(/\.zip$/i.test(a.path))await exec(state.python,[join(base,'extract-safe.py'),a.path,directory],{windowsHide:true});
 const walk=d=>readdirSync(d).flatMap(n=>{const p=join(d,n);return statSync(p).isDirectory()?walk(p):[p];});
 let files=walk(directory);
 // Plain downloadable reports also count; copy only the worker's own published artifacts.
 for(const a of job.artifacts||[])if(!/\.zip$/i.test(a.path)&&a.path!==join(base,'artifacts',job.role+'-closure.md'))files.push(a.path);
 const find=n=>files.filter(p=>p.replaceAll('\\','/').endsWith('/'+n));
 for(const n of job.requiredFiles||[])if(!find(n).length)throw Error('Required artifact absent: '+n);
 if(job.stageGate){
  const n=['','CONSORTIUM-I-CLOSURE.json','CONSORTIUM-II-CLOSURE.json','CONSORTIUM-III-CLOSURE.json'][job.stageGate];
  const candidates=find(n);if(candidates.length!==1)throw Error('Stage closure missing or ambiguous');
  const closure=JSON.parse(readFileSync(candidates[0],'utf8').replace(/^\uFEFF/,''));
  if(closure.status!=='PASS'||closure.canonical!==true||closure.sourceSha256!==state.sourceSha256)throw Error('Stage exit gate not passed in delivered artifact');
  if(job.stageGate===1&&!files.some(p=>p.replaceAll('\\','/').includes('/WIREFRAMES/')))throw Error('Wireframe artifacts absent');
  if(job.stageGate===2){job.ownership=ownership(closure.ownership);}
 }
 const ownerRole=job.workerRole||job.role;
 if(['w8','w9'].includes(ownerRole)){
  const owner=ownership(state.jobs.find(j=>j.role==='w7')?.ownership)[ownerRole];
  const candidates=find('SOURCE-HASH-MANIFEST.json');if(candidates.length!==1)throw Error('Builder manifest ambiguous');
  const m=JSON.parse(readFileSync(candidates[0],'utf8').replace(/^\uFEFF/,''));
  if(m.sourceSha256!==state.sourceSha256||!Array.isArray(m.changedFiles)||!m.changedFiles.length)throw Error('Builder changedFiles manifest missing');
  for(const f of m.changedFiles){
   if(!owner.includes(f.path))throw Error('Builder edited unowned source: '+f.path);
   const source=find(f.path);if(source.length!==1||digest(readFileSync(source[0]))!==f.sha256)throw Error('Builder actual source/hash missing or ambiguous: '+f.path);
  }
 }
 job.handoff=handoff;job.validatedFiles=files.map(p=>({path:p,sha256:digest(readFileSync(p))}));
 writeFileSync(join(base,'evidence',job.role+'-artifact-gate.json'),JSON.stringify({task:job.role,sourceSha256:state.sourceSha256,structuralGate:'PASS',semanticAuthority:'Assigned specialist; structural gate does not independently certify product/test claims',handoff,files:job.validatedFiles},null,2));
}
