# W3 — Feature relocation and behavior map (v0.8 baseline)

**Evidence class:** source-inspected, not live-extension-witnessed. Paths and anchors are relative to the 76-entry SHA256-verified source archive, not a v0.7 reference. **Destination classes:** `P` = primary destination, `C` = contextual inspector/action, `M` = scoped dialog/popover, `S` = settings/advanced, `G` = clearly gated design-only capability. The HTML wireframe simulates only local fixture state. No proposed relocation is yet implemented in the extension.

| ID | Existing feature or contract | Current source evidence | W3 destination and retrieval gesture | State/boundary |
|---|---|---|---|---|
| F01 | Application identity, multi-button header | `sidepanel.html:10–23`; `sidepanel.css:.app-header` | Text-only Paperfold header; Board context picker + Capture + More | P/C; remove logo only in future build, keep manifest icons |
| F02 | Select/create/delete Note (Card) | `sidepanel.html:27–30`; `sidepanel.js:550–601,692` | Write → Card chooser via Library; New Card in Write; destructive delete in Card More with confirmation | P/M; protect data |
| F03 | Markdown CM6 editing and persistence | `cm-editor.js`; `sidepanel.html:41–96`; `sidepanel.js:692` | Write primary canvas; compact formatting group; save state in editor context | P; no bogus saved indicator |
| F04 | Live / Reading rendering | `sidepanel.html:85–99`; `sidepanel.js:751` | Write → Reading preview within editor, not another application page | C; preserve undo/selection |
| F05 | Markdown format commands H1,H2,bold,italic,bullet,number,check,quote,code,math,wikilink | `sidepanel.html:71–82`; `cm-editor.js` | Write inline five frequent actions + contextual More for the rest | C; full keyboard/command equivalents |
| F06 | Markdown zoom +/-/reset | `sidepanel.html:89–92`; `sidepanel.js:839` | Write → Editor display options menu; shortcut retained | C; avoid overflowing 280px toolbar |
| F07 | Slash `/`, `@`, `[[` completion; Board aliases | `sidepanel.html:99`; `cm-editor.js`, `cues.js`, `card-model.js` | Write inline commands and shared command palette; `/maincard` remains legacy alias | C; no IME interception |
| F08 | Tab capture manual/on-writing policy | `sidepanel.html:45–53`; `sidepanel.js` | Write → Card More → Capture policy, or Settings → Capture | C/S; no implicit page data access |
| F09 | Thinking cue selection, palettes, modes | `sidepanel.html:54–69,213–257`; `cues.js` | Write → contextual Cues; Ctrl+K commands; actual Alt shortcut preserved | C/M; no AI dashboard |
| F10 | Cue library customize/reset and notation strip | `sidepanel.html:597–639`; `sidepanel.js:921–997` | Settings → Thinking cues; mini notation strip within cue dialog | S/M; mode-specific |
| F11 | Reminders, Chrome alarms and notification | `sidepanel.html:184–190,272–296`; `service-worker.js:127–143` | Write → contextual Reminder and Linked evidence → Reminders | C/M; require schedule acknowledgement |
| F12 | Active tab details and refresh | `sidepanel.html:117–135`; `sidepanel.js:404` | Context → Current page row; Capture dialog includes provenance | P/C; restricted tab state explicit |
| F13 | Attach active tab and multi-tab picker | `sidepanel.html:120–134,258–269`; `sidepanel.js:1230–1278` | Context → Capture → Attach; More → Add open tabs | M; no auto attachment on view |
| F14 | Scrape current page into paired Markdown scrap | `sidepanel.html:123`; `service-worker.js:109–119`; `sidepanel.js:1654–1676` | Context → Capture mode Scrape; Library → Captures/Files | M/P; optional site grants |
| F15 | Clip selection from context menu or panel | `sidepanel.html:126`; `service-worker.js:55–76,200–248` | Persistent Capture in header + Chrome native context entry + contextual popover | M/C; preserve browser selection |
| F16 | Site access request / permission hint | `sidepanel.html:129–131`; `sidepanel.js:420` | Capture → explicit denied/blocked state with grant and manual-link fallback | M; never silent success |
| F17 | Manual attachments file picker, text/binary handling | `sidepanel.html:162–172,322–345`; `sidepanel.js:2644–2750` | Write → Evidence → Attach file; Library → Files | C/M/P; raw + paired `.md` preserved |
| F18 | Source links, refresh, unlink | `sidepanel.html:142–149`; `sidepanel.js:1278–1356` | Write → Linked evidence inspector; Library → Sources → Detail actions | C/P; unlink is not delete source content |
| F19 | Bookmark toggle/source URL | `db.js:bookmarks`; `sidepanel.js:1317` | Library → Bookmarks; contextual Save Bookmark from Source detail | P/C; browser bookmarks separately modeled |
| F20 | Annotations (quote, DOM/TextQuote, comment, citation) | `sidepanel.html:173–181,297–321`; `sidepanel.js:1710–1900`; `provenance.js` | Context → Annotate selection; Write → Linked evidence → Annotation inspector | C/M/P; provenance not inferred |
| F21 | Annotation reopen/insert/delete | `sidepanel.js:1849–1887` | Library → Captures/Annotations via Source detail; Write inspector insertion | C; permission/anchor failures visible |
| F22 | Literature DOI detection/lookup | `sidepanel.html:137–141,477–487`; `literature.js`; `sidepanel.js:1357–1450` | Library → Literature; Write → Insert citation/Find DOI | P/C; explicit metadata request only |
| F23 | Citation token insertion/unlink | `sidepanel.js:1373–1375`; `markdown.js` | Write → Add/Insert source; contextual citation palette | C; no live lookup in fixture |
| F24 | Vector search over local notes/pages | `sidepanel.html:192–202`; `embedding.js`; `sidepanel.js:440–444` | Find landing: local search input, Cards/Sources filters and inspect actions | P; local-hash-v1 provenance shown |
| F25 | Search provider entries / selected-text search | `service-worker.js:199–249`; `sidepanel.html:520–534` | Settings → Search providers; Chrome native selection submenu unchanged | S/C; external query a user gesture |
| F26 | Activity log, per-entry delete, clear, keep toggle | `sidepanel.html:204–211,490–500`; `sidepanel.js:2025–2055` | Context → More → Activity; Settings → Data → retention policy | S/C; destructive clear confirmation |
| F27 | Board create/select/edit/delete | `sidepanel.html:346–375`; `card-model.js`; `sidepanel.js:2763–2849` | Board context switcher → Board overview/details; destructive action in Board More | P/M; UI word Board, store `maincards` |
| F28 | Board Markdown and governing perspective | `sidepanel.html:365–382`; `card-model.js` | Context → Board details; editable overview only where authorized | P/C; no additional workspace entity |
| F29 | Board Card membership, role, classification | `sidepanel.html:374–390`; `sidepanel.js:2858–2983` | Context → Board → Members → Add Card; inspect membership role inline | P/M; Card can live in multiple Boards |
| F30 | Explicit typed edges and removal | `sidepanel.html:391–402`; `sidepanel.js:2984–3030` | Context → Board → Relationships, advanced disclosure | C; never auto-promote similarity to edge |
| F31 | Board flatten JSON/Mermaid export | `sidepanel.html:358–363`; `card-model.js`; `sidepanel.js:2790+` | Board More → Export graph/flatten | C; file data preserved |
| F32 | Workspace Spreadsheet derived projection | `sidepanel.html:405–434`; `workspace.js` | Context → Review → Spreadsheet, shared route | P (secondary) |
| F33 | Workspace Calendar derived projection | same | Context → Review → Calendar | P (secondary); not Session calendar |
| F34 | Workspace provenance Flow derived projection | same; `provenance.js` | Context → Review → Flow; ≥720/1050 larger canvas | P (secondary) |
| F35 | Workspace Flatten and export CSV/JSON | `sidepanel.html:421–434`; `workspace.js` | Context → Review → Flatten/Export | C/P (secondary) |
| F36 | AI transport context bundle | `sidepanel.html:435–476`; `sidepanel.js:2376–2440` | Context → Review → Export/AI transport (advanced) | S/M; **file export**, not a remote AI task |
| F37 | Note Markdown and entire `.wv.tar.gz` export | `sidepanel.html:17,20,514–518`; `service-worker.js` | Write More → Export Markdown; Settings → Data & export → workspace backup | S/C; restore unverified |
| F38 | Export folder selector/clear | `sidepanel.html:535–548`; `sidepanel.js:462–463` | Settings → Data & export → Destination | S; Chrome picker explicit |
| F39 | Google Drive OAuth/manual/scheduled backup | `sidepanel.html:549–576`; `service-worker.js:152–181,673+` | Settings → Integrations → Google Drive | S; no fake logged-in state |
| F40 | Loopback/LAN companion push/pull/schedule | `sidepanel.html:577–596`; `companion/tabwoven_sync_server.py`; `sync.js` | Settings → Integrations → Local/LAN | S; bearer token privacy preserved |
| F41 | Keep activity and embedding provider | `sidepanel.html:490–510`; `embedding.js` | Settings → Data & export / Search | S; only existing local-hash provider |
| F42 | Appearance Paper/Pure Black/System | `sidepanel.html:510–515`; `sidepanel.css` | Settings → Appearance; global tokens from baseline | S; image/favicon not inverted |
| F43 | Session automatic checkpoint, list, revisions, status | `browser-sessions.js`; `service-worker.js`; `session-ui.js` | Sessions primary browsing destination | P; local-only, no content capture |
| F44 | Session rename and Board association | `sidepanel.html:715–746`; `session-ui.js` | Sessions → Session detail, Board association | P/C; Board ref only |
| F45 | Session capture current state, refresh | `session-ui.js`, `service-worker.js` | Sessions detail → manual capture/refresh | C; no side effects on mere inspect |
| F46 | Session preview/restore missing HTTP(S) tabs and groups | `session-ui.js`; `browser-sessions.js`; `docs/ARCHITECTURE-ADR.md` | Sessions → revision → preview → explicit confirmation | C/M; protected, never automatic |
| F47 | Context menu open palette/Boards/search/scrape/clip/attach | `service-worker.js:199–249` | Chrome native menu preserved; opens corresponding compact context surface | C; never replace OS-native menu UI |
| F48 | Discover lexical relation prototype | `prototypes/discover/lexical.js`; `docs/followup/03-UX-DISCOVERY-AND-QUERY.md` | Find → More → Discover (GATED) | G; no writes, no claim of causal relation |
| F49 | Query Studio AST + URL preview prototype | `prototypes/discover/query-ast.js`; `docs/followup/03-UX-DISCOVERY-AND-QUERY.md` | Find → More → Query Studio (GATED) | G; external URL only after consent; not wired |
| F50 | Full-tab expanded workspace | **ABSENT**: `manifest.json` declares `side_panel.default_path` only; `docs/FEATURE-AUDIT.md` | W3 wide-screen design representation; actual entrypoint requires W7/W8 implementation authorization | SPEC ONLY; no claim baseline ships full-tab |
| F51 | Contextual Paperfold popover | Chrome native menu exists; no full custom content-script popover proof in manifest | Candidate popover belongs to page-origin interaction only after permission/trust review | SPEC ONLY; never claim injected UI exists |
| F52 | Empty/loading/success/error/permission denied | `sidepanel.html:33–39,131`; `session-ui.js:showError`, `sidepanel.js` | Each contextual surface owns its inline states, not a new tab | SPEC + fixtures; browser QA pending |

## Interaction routing invariants

**Board → Card:** navigate without moving Card data or changing `maincards` identity. Board removal must not imply deletion of linked Cards. **Capture → Source/Annotation → Card:** native page selection and source origin survive an intentional modal, while permission-denied gives manual-link fallback. **Card → Library/Search → Card:** preserve unsaved edit buffer, cursor/undo history and focus; mark actual saved state only after persistence acknowledgement. **Session → Board:** association is a reference; never make Session restore a Board operation. **Discover → explicit review:** prototype cannot create typed edges or evaluate claims. **Query → outbound external search:** must preview encoded query and require a user click; no automatic remote request. **Export → restore:** backup and clean restore require distinct gates.

## Deliberate non-relocations

No giant AI command center; no new browser-history permission; no automatic Session syncing to Google Drive; no hidden navigation behind a desktop-only rail; no bulk IndexedDB/schema rename; no replacement of Chrome native context menu with an unverified injected popover; no invented account page. Prototypes remain visibly gated until source/runtime validation.
