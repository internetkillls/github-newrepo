# Paperfold v0.8 / W2 collection-first wireframe packet

**Scope:** I2 BLIND Consortium I research-collection candidate. **Not canonical, not production code, not release.** All data in screenshots and wireframe are synthetic fixtures. The source ZIP is NOT included or changed. No real Chrome profiles, permissions, IndexedDB, schemas, or network requests are touched by the runnable prototype.

## Start here

1. `W2-PROPOSAL.md` — independent architecture and workflows (the required primary deliverable).
2. `WIREFRAMES/index.html` — offline navigable mock; open in any modern browser. `prototype.css` and `prototype.js` reside next to it.
3. `WIREFRAMES.md` — full-tab, narrow Side Panel and editor spatial diagrams.
4. `FEATURE-RELOCATION-MAP.md` — 48 inventory entries covering all existing source functionality and explicitly absent/gated items.
5. `SURFACE-COVERAGE.json` + `W2-COMPONENT-CONTRACT.json` — all 15 surfaces, states, tokens, accessibility requirements and evidence anchors.
6. `UX-TEST-CONTRACT.md` and `W2-VALIDATION-REPORT.md` — falsifiable runtime acceptance requirements, negative controls, observed tests and unverified gates.
7. `PREVIEWS/` — real offline fixture screenshots, not installed Chrome images.
8. `TEST-RECEIPTS.json`, `BASELINE-TEST-RECEIPTS.json`, `SOURCE-AUDIT-RECEIPT.json` — bounded machine-readable observed test results.
9. `W2-HANDOFF.json` — orchestrator-scoped non-canonical handoff; `DELIVERY-MANIFEST.json` — artifact hashes.

## Reproduce in a permitted sandbox

- Source identity: `python TESTS/verify_source.py path/to/source.zip path/to/SOURCE-MANIFEST.json`
- Fixture checks and screenshot regeneration: `python TESTS/verify_wireframe.py` (requires Python `playwright` and a Chromium executable in PATH; in this environment `page.set_content` worked while URL navigation was blocked by administrator policy).
- JavaScript parse: `node --check WIREFRAMES/prototype.js`.
- Existing baseline suites require extraction of supplied source ZIP into a separate sandbox; tests should execute from the extracted source directory, not from this packet.

## W4 adoption notes

The source assertions correspond to 0.8, and all future integration requires verified routing from actual `sidepanel.js` / `service-worker.js` / `db.js`; no new data object or permission has been authorized. W4 can evaluate the proposal independently after W1 and W3 close. W5/W6/W7 must not treat demo screenshots as functional extension witnesses. W8/W9/W10 build ownership does not start from this packet until the canonical Consortium I and II artifacts exist.
