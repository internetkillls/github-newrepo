import pathlib,json,hashlib,shutil,re,datetime,subprocess
RUN=pathlib.Path(r'D:\Dev\.engineering\rcc\paperfold-ui-20261016')
BASE=RUN/'retrospective-20261019'
REPO=pathlib.Path(r'D:\Dev\repos\paperfold')
OUT=REPO/'docs/retrospective/2026-10-paperfold-rcc'
(OUT/'interviews').mkdir(exist_ok=True)
items=[]
for role in ['w'+str(i) for i in range(1,11)]:
    raw=BASE/'interviews'/f'{role}-response.md'
    if raw.is_file():
        for suffix in ['prompt.md','completion.json']:
            shutil.copy2(BASE/'interviews'/f'{role}-{suffix}',OUT/'interviews'/f'{role}-{suffix}')
        text=raw.read_text(encoding='utf-8')
        shutil.copy2(raw,OUT/'interviews'/f'{role}-response-raw.md')
        # The collector joined multiple public assistant segments; the label is host-added,
        # not evidence of A/B alternatives. The last segment contains the final interview.
        final=re.split(r' \[(?:ALTERNATIVE RESPONSE|ASSISTANT SEGMENT)\] ',text)[-1]
        final=re.sub(r'^ChatGPT said:\s*','',final)
        (OUT/'interviews'/f'{role}-response.md').write_text(final,encoding='utf-8')
        c=json.loads((BASE/'interviews'/f'{role}-completion.json').read_text(encoding='utf-8'))
        items.append({'role':role,'transport':'WITNESSED','selfReportedStatus':'PARTIAL' if re.search(r'Interview status:\s*PARTIAL',final,re.I) else 'ANSWERED','promptSha256':c['promptSha256'],'rawResponseSha256':c['responseSha256'],'finalResponseSha256':hashlib.sha256(final.encode()).hexdigest(),'conversationUrl':c['url'],'completionRef':f'interviews/{role}-completion.json','finalResponseRef':f'interviews/{role}-response.md'})
    else:
        shutil.copy2(BASE/'interviews'/f'{role}-prompt.md',OUT/'interviews'/f'{role}-prompt.md')
        items.append({'role':role,'transport':'NOT_SENT_ROOM_UNAVAILABLE','selfReportedStatus':'UNAVAILABLE','reason':'Existing W9 conversation repeatedly returned Could not load this ChatGPT conversation after bounded reload and Retry. No interview prompt sent; no substitute worker created.'})
for name in ['interview-events.jsonl','retry-events.jsonl','w9-recovery-events.jsonl','w9-final-readonly-recovery.json','interview-runner.mjs','retry-unsent.mjs','collect-materials.py','finalize-evidence.py']:
    if (BASE/name).is_file():shutil.copy2(BASE/name,OUT/'interviews'/name)
# Scoped final failure fact; do not export browser sidebar contents or unrelated chat names.
(OUT/'interviews/w9-history-recovery.json').write_text(json.dumps({'room':'https://chatgpt.com/c/6ad2840c-eb38-83ec-87e4-41d08896a39b','status':'USER_REOPENED_ROOM_RECONCILED','historicalError':'Could not load this ChatGPT conversation','promptSentDuringFailedLoad':False,'actions':['read-only observation','one reload','one in-page Retry','recurring history error','user reports W9 open','verified original history, empty draft, idle room and no interview echo','bounded original interview submission'],'unrelatedSidebarContentExcluded':True},indent=2)+'\n',encoding='utf-8')
summary={'schema':'paperfold.postproject-interview-index.v1','date':'2026-10-19','independence':'I0 retrospective AI self-report, supplied host summary, no human participants','maxActive':3,'coverage':'Original role rooms attempted, unavailable interviews explicitly retained','normalization':'Raw captures retain host-added segment separator; readable response selects final public assistant segment, never private reasoning. ALTERNATIVE RESPONSE marker in initial raw serializer does not prove A/B generation.','workers':items}
(OUT/'INTERVIEW-INDEX.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
tests=[]
def check(name,cond,detail=None):
    tests.append({'name':name,'status':'PASS' if cond else 'FAIL','detail':detail})
m=json.loads((OUT/'MATERIALS-MANIFEST.json').read_text(encoding='utf-8'))
check('documentary preimages match hashes',all(hashlib.sha256((OUT/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in m['files']),len(m['files']))
snapshot=json.loads((OUT/'materials/orchestration/SOURCE-SNAPSHOT.json').read_text(encoding='utf-8'))
check('original run state preserved',hashlib.sha256((RUN/'automation/state.json').read_bytes()).hexdigest()==snapshot['originalStateSha256'])
check('original run event log preserved',hashlib.sha256((RUN/'automation/events.jsonl').read_bytes()).hexdigest()==snapshot['originalEventsSha256'])
expected=json.loads((REPO/'HOST-FINAL-REVIEW.json').read_text(encoding='utf-8'))['changedFiles']
check('three production files still match reviewed source',all(hashlib.sha256((REPO/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in expected))
archive=RUN/'host-review/PAPERFOLD-W10-REVERIFY-SOURCE-TRANSFER.zip'
b=archive.read_bytes();check('W10 archive byte length and pinned SHA256',len(b)==212683 and hashlib.sha256(b).hexdigest()=='680ee19c3a98145fa4f127ca74be18da29aaea2ad737270660c8328b6618f417',{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
cold=json.loads((OUT/'COLD-ARTIFACTS-MANIFEST.json').read_text(encoding='utf-8'))
check('retained cold evidence matches hash inventory',all(hashlib.sha256((RUN/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in cold['files']),len(cold['files']))
missing=[]
for f in OUT.glob('*.md'):
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',f.read_text(encoding='utf-8')):
        if re.match(r'https?://|#',link):continue
        path=link.split('#')[0].strip('<>')
        if not (f.parent/path).exists():missing.append({'file':f.name,'link':link})
check('authored Markdown links resolve locally',not missing,missing)
for x in items:
    if x['transport']!='WITNESSED':continue
    c=json.loads((OUT/x['completionRef']).read_text(encoding='utf-8'));samples=c['samples'][-3:]
    check(x['role']+' prompt identity',hashlib.sha256((OUT/'interviews'/f"{x['role']}-prompt.md").read_bytes()).hexdigest()==c['promptSha256'])
    check(x['role']+' raw response identity',hashlib.sha256((OUT/'interviews'/f"{x['role']}-response-raw.md").read_bytes()).hexdigest()==c['responseSha256'])
    check(x['role']+' affirmative terminal samples',len(samples)==3 and samples[-1]['at']-samples[0]['at']>=10000 and all(s['assistantText']==samples[-1]['assistantText'] and s['assistantId']==samples[-1]['assistantId'] and s['turnKey']==samples[-1]['turnKey'] and s['turnState']=='complete' and s['regenerate'] and not s['stop'] for s in samples))
check('ten original-room responses witnessed',sum(x['transport']=='WITNESSED' for x in items)==10)
receipt={'schema':'paperfold.retrospective-document-checks.v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Documentation identity, source preservation and captured terminal evidence; no product regression rerun or human study','tests':tests,'status':'PASS' if all(t['status']=='PASS' for t in tests) else 'FAIL'}
(OUT/'DOCUMENTATION-CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'interviews':len([x for x in items if x['transport']=='WITNESSED']),'tests':len(tests),'failures':[t for t in tests if t['status']!='PASS']}))
