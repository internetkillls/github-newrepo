# Paperfold: from a crowded extension to a writing workspace

Post-project case study · 19 October 2026 · engineering and design review of source commit `317d37ac76437f4db9a6d114a5438aa30a494049`.

Paperfold's reconstruction changed its organizing principle: the current Markdown Card became the place to start and return to, with Boards and Library beside it and secondary tools behind More. Ten persistent AI worker roles developed competing architectures, challenged them, froze interaction contracts, built three production files, and integrated the result. The final source was applied to this repository and committed. It has substantial scoped browser evidence; the production release gate remains open.

The strongest accomplishment was connecting a design decision to source ownership and executable checks. The largest missing result is human evidence that the new organization actually makes research easier. Screenshots, fixture counts and worker agreement cannot answer that question.

## Read the story

| Document | What it answers |
|---|---|
| [Design story](01-DESIGN-STORY.md) | What problem was modeled, why writer-first won, how the UI expresses that choice, and what remains awkward |
| [W1–W10](02-WORKER-CONTRIBUTIONS.md) | Each worker's purpose, deliverables, decisions, evidence and limits |
| [Engineering and bugs](03-ENGINEERING-AND-VERIFICATION.md) | How contracts, ownership, regression tests and native evidence reduced risk; bugs that still escaped |
| [RCC transport](04-ORCHESTRATION-AND-CHUNKS.md) | Dependency packets, rooms, closures, locks, completion evidence and byte chunks |
| [Evaluation against your rules](05-PROCESS-EVALUATION.md) | Where the process met the Notion criteria and where it did not |
| [Worker interviews](06-POSTPROJECT-INTERVIEWS.md) | Retrospective responses, corroboration and proposed next experiments |
| [Reusable interview method](07-RCC-POSTPROJECT-METHOD.md) | How RCC can turn project evidence and worker reflection into bounded improvements |
| [Future prompts](08-FUTURE-PROMPT-PLAYBOOK.md) | What to ask for next, including concrete router and UI experiments |
| [Materials](MATERIALS-MANIFEST.json) | SHA256-indexed original documents and their host provenance |
| [Original archive index](ARCHIVE-INDEX.json) | Unique available worker ZIPs, original wireframes/images where retained, plus the immutable source baseline |

## What these documents can establish

The documentary corpus includes the original mission, available worker proposals/debates/contracts/reports, source and completion receipts, transport code, and the native evidence already in this repository. The [source snapshot](materials/orchestration/SOURCE-SNAPSHOT.json) pins the original runner state and event log. It records **10 roles, 13 originally planned tasks, and 17 actual job records** after repairs and reverification. The original `taskCount:13` field did not grow with those additional jobs; it is not a count of everything eventually executed.

This is a reconstruction of accessible project evidence, not a verbatim export of all account chats or private model reasoning. Historical worker test statements remain attributed unless independently backed by host receipts. A completed response establishes transport completion; it does not establish design quality or runtime correctness.

Your [Notion rules](https://app.notion.com/p/3fd0056a56ff806b9b81cdf1a27b3873), titled “What To Seek when I want to create Something,” were fetched through the Notion connector for this review. The returned metadata says Source=Self, State=To review, last edited 18 October 2026 12:54 UTC; Notion's verification state was unverified. They are the **current evaluation criteria**, not evidence that the 15 October kickoff was caused by that later document. The [criterion summary](NOTION-CRITERIA.md) separates the source from this review's interpretations.

## Delivered result and remaining limits

Only `sidepanel.html`, `sidepanel.css`, and `sidepanel.js` changed from the 76-file production baseline. Seventy-three baseline files remained byte-identical, and none were deleted. Supporting contracts, tests and evidence were added. [HOST-FINAL-REVIEW.json](../../../HOST-FINAL-REVIEW.json) records 12 host regression commands, real isolated Chrome/IndexedDB checks and 1,020 passing native contrast measurements. [RELEASE-GATE.md](../../../RELEASE-GATE.md) retains physical IME, real assistive-technology, human native browser workflows and product archive-import limits.

These documents add no production behavior, deployment or data migration. The previous commit request concerned the implementation; this new documentation task is left as reviewable working-tree changes unless separately committed.

## What to put in the next prompt

Name the real task situation, current source revision, target surface, measurable failure, evidence level, allowed files, rival workflow and stopping condition. Ask for a small experiment before a new architecture. Use the complete templates in [Future prompts](08-FUTURE-PROMPT-PLAYBOOK.md).
