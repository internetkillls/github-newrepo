import {readFileSync,writeFileSync,mkdirSync,appendFileSync,openSync,closeSync,unlinkSync,existsSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const base=dirname(fileURLToPath(import.meta.url));
const original=JSON.parse(readFileSync(join(base,'../automation/state.json'),'utf8'));
const vendor=original.rccRoot+'/runtime/chatgpt-pro-line/src/';
const {listTargets,CdpSession,evaluate,sleep}=await import(pathToFileURL(vendor+'cdp-client.mjs'));
const {pageProbe}=await import(pathToFileURL(vendor+'chatgpt-page.mjs'));
const {inputPrompt,submitPrompt}=await import(pathToFileURL(vendor+'chatgpt-composer.mjs'));
const {readChatGptChoices}=await import(pathToFileURL(vendor+'chatgpt-choices.mjs'));
const {acquireChatGptOperation}=await import(pathToFileURL(vendor+'chatgpt-operation.mjs'));
const {canonicalEcho,finalWitness,bound}=await import('../automation/rules.mjs');
const digest=v=>createHash('sha256').update(v).digest('hex');
mkdirSync(join(base,'interviews'),{recursive:true});
const lock=join(base,'interview.lock');const fd=openSync(lock,'wx');writeFileSync(fd,JSON.stringify({pid:process.pid,at:new Date().toISOString()}));
const roles=Array.from({length:10},(_,i)=>'w'+(i+1));
const special={w1:'Explain writer-first entry and your silent-append fixture defect/correction; distinguish fixture from shipped behavior.',w2:'Explain collection-first rejected alternative and which typed Library/provenance patterns survived. What user task mix would reverse the architecture choice?',w3:'Explain contextual continuity, optional Board context and five-slot dock tradeoff. What proves continuity beyond route reachability?',w4:'Explain why W1 won, subordinate W2/W3 patterns, evidence standards and missing real-user comparison.',w5:'Explain interaction state classes, confirmation/cancel/save acknowledgement, focus and reversible motion.',w6:'Explain narrow versus wide layout and accessibility/motion/zoom criteria; distinguish specification from witnessed native behavior.',w7:'Explain exact file ownership, cross-file DOM/event/route contracts, complete W5/W6 reread and motion conflict reconciliation.',w8:'Explain markup/CSS shell, menu and contrast repairs; what escaped fixture tests and what native evidence reopened your scope?',w9:'Explain routing and real persistence/Capture implementation, cancellation, abort, dedup and CM6 boundaries; disclose regressions and missing runtime proof.',w10:'Explain integration, immutable baseline plus changed files, transport hash checks, honest BLOCKED release gate and what host-native testing must add.'};
let jobs=roles.map(role=>{
 const old=original.jobs.filter(j=>j.workerRole===role&&j.conversationUrl).at(-1);
 const token='PAPERFOLD-POSTPROJECT-20261019-'+role.toUpperCase();
 const prompt=`${token}\nPOST-PROJECT INTERVIEW ONLY. The human user explicitly requests interviewing the existing W1-W10 workers to evaluate this project and improve RCC. Reuse your role; no new workers, no implementation, no production actions. Retain/apply AntiSlop and Reasoning Method Controller (RMC) from the supplied worker methods: reconstruct actual accessible evidence first; separate historical artifacts, current supplied host summary, self-report, inference and proposed future work. Do not invent recollection, human feedback, test execution or private chain-of-thought. This interview is I0 retrospective self-report, not independent validation.\nProject goals: calm, local-first research writing UI; preserve Board/Card/Source/Capture/Session identities, existing data/permissions, all feature locations, narrow Side Panel usability, Paper/Black/System themes. User's current Notion criteria (provided NOW, not asserted as historical instructions): causal problem story and human experience first; simplify the flow; decompose into atomic functions with precedents/data/rules; choose simplest usable representation; measure before/after; prompts derive from WBS, role/lens/AntiSlop, general context and lived task scenario.\nHOST-SUPPLIED CURRENT SUMMARY (not your own observation): source applied and committed as 317d37ac76437f4db9a6d114a5438aa30a494049; W8 owns sidepanel.html/css, W9 sidepanel.js; 73 baseline files unchanged, no deletion. Host reports 12 regression commands passed and real isolated Chrome/IndexedDB/CM6/Capture/native-panel/composition/session/archive-harness checks. A native contrast failure reopened W8 and host rerun measured 1020 samples >=4.94:1. Production gate remains BLOCKED: physical OS IME/AT, human-operated native zoom/context-menu/permission prompts, product archive importer absent. Do not certify these supplied claims yourself.\nROLE PROBE: ${special[role]}\nReturn 700-1100 words MAX in English, inline Markdown only (no ZIP/base64/downloads), with these eight sections: (1) owned purpose + exact artifact anchors available in this room; (2) concrete user situation and causal problem your design solved; (3) key decision, rejected rival and tradeoff; (4) actual work/test evidence versus specified or unknown; (5) own mistake/weakness and what exposed it, or explicitly no witnessed defect known; (6) critique of handoff/context/chunk communication, including what you could not inspect; (7) one next intuitive UI/workflow experiment with atomic function/data/state map, negative control, acceptance metric and reopen trigger; (8) one RCC routing/interview improvement linked to project evidence. End with interview status ANSWERED or PARTIAL and unavailable evidence. No zero-bug claim, no fabricated user studies, no long reasoning transcript. Stop after this answer.\n${token}`;
 writeFileSync(join(base,'interviews',role+'-prompt.md'),prompt);
 return {role,token,url:old.conversationUrl,prompt,sha256:digest(prompt),status:'PENDING',samples:[]};
});
let state={schema:'paperfold.postproject-interviews.v1',pid:process.pid,at:new Date().toISOString(),maxActive:3,originalStateUntouched:true,jobs};
if(process.argv.includes('--resume')){state=JSON.parse(readFileSync(join(base,'interview-state.json'),'utf8'));jobs=state.jobs;state.pid=process.pid;}
function save(){writeFileSync(join(base,'interview-state.json'),JSON.stringify(state,null,2));}
function event(j,status,detail={}){j.status=status;appendFileSync(join(base,'interview-events.jsonl'),JSON.stringify({at:new Date().toISOString(),role:j.role,status,...detail})+'\n');save();console.log(j.role+' '+status);}
async function snapshot(j){
 await evaluate(j.c,`(()=>{for(const t of document.querySelectorAll('[data-turn-key]'))for(const b of t.querySelectorAll('button'))if(b.innerText.trim()==='Show more')b.click()})()`);
 return evaluate(j.c,`(()=>{const norm=${canonicalEcho.toString()};const expected=${JSON.stringify(j.prompt)};const turns=[...document.querySelectorAll('[data-turn-key]')];const turn=turns.findLast(t=>{const h=[...t.querySelectorAll('h4')].find(e=>e.innerText==='You said:');return h&&norm(h.parentElement.innerText).includes(norm(expected))});const h=turn&&[...turn.querySelectorAll('h4')].find(e=>e.innerText==='You said:');const units=turn?[...turn.querySelectorAll('[data-conversation-role="assistant"]')].map(e=>e.closest('[data-chatgpt-search-message-ids]')).filter((e,i,a)=>e&&a.indexOf(e)===i):[];return {at:Date.now(),url:location.href,turnKey:turn?.getAttribute('data-turn-key'),userText:h?.parentElement.innerText||'',assistantId:units.map(a=>a.getAttribute('data-chatgpt-search-message-ids')).join(' | '),assistantText:units.map(a=>a.innerText).join(' [ALTERNATIVE RESPONSE] '),turnState:turn?.querySelector('[data-talvt-turn-state]')?.getAttribute('data-talvt-turn-state'),regenerate:!!turn?.querySelector('button[aria-label="Regenerate response"]'),stop:!!document.querySelector('button[aria-label="Stop"]')}})()`);
}
async function dispatch(j){
 let op,clicked=false;
 try{
  op=await acquireChatGptOperation({name:'paperfold-postproject-interview',alias:'rcc-postproject-'+j.role,requiresBrowser:true,lockTimeoutMs:10000});
  let targets=await listTargets(9222);let target=targets.find(t=>t.type==='page'&&t.url.split('?')[0]===j.url);
  if(!target){event(j,'TARGET_PROVISIONING');const r=await fetch('http://127.0.0.1:9222/json/new?'+encodeURIComponent(j.url),{method:'PUT'});if(!r.ok)throw Error('Target creation failed');target=await r.json();}
  j.targetId=target.id;j.targetReceipt={id:target.id,url:target.url,at:new Date().toISOString()};
  const c=await CdpSession.open(target.webSocketDebuggerUrl);Object.defineProperty(j,'c',{value:c,enumerable:false});
  await c.send('Page.bringToFront');
  let page;
  for(let i=0;i<20;i++){try{page=await pageProbe(c);if(page.composer)break;}catch{}await sleep(1000);}
  if(!page?.composer||page.isLoggedOut)throw Error('Authenticated composer unavailable; no send');
  if(page.url.split('?')[0]!==j.url)throw Error('Room URL mismatch');
  if(await evaluate(c,`!!document.querySelector('button[aria-label="Stop"]')`))throw Error('Existing generation active');
  const existing=await evaluate(c,`(()=>{const e=document.querySelector('#prompt-textarea')||document.querySelector('[contenteditable="true"][role="textbox"]')||document.querySelector('textarea');return e?.innerText||e?.value||''})()`);
  if(existing.trim())throw Error('Nonempty draft preserved; no send');
  j.choiceReadback=await readChatGptChoices(c,{includeModelOptions:false});
  event(j,'TARGET_READY');
  await inputPrompt(c,page.composer,j.prompt);event(j,'COMPOSER_FILLED');
  event(j,'SEND_UNCERTAIN');clicked=true;j.deadline=Date.now()+15*60*1000;
  await submitPrompt(c,{composer:page.composer,initialUserCount:page.userTurns.length,attempts:1});
  j.deadline=Date.now()+15*60*1000;
  const s=await snapshot(j);if(bound(s,j.prompt)){j.samples=[s];event(j,'OBSERVING',{turnKey:s.turnKey});}else event(j,'UNCERTAIN',{reason:'No exact prompt echo; automatic resend forbidden'});
 }catch(e){event(j,clicked?'UNCERTAIN':'BLOCKED',{reason:e.message});j.reason=e.message;}
 finally{if(op)await op.release();}
}
save();
try{
 if(process.argv.includes('--resume')){
  const targets=await listTargets(9222);
  for(const j of jobs.filter(j=>['UNCERTAIN','OBSERVING','OBSERVATION_BLOCKED'].includes(j.status))){
   const t=targets.find(t=>t.id===j.targetId&&t.url.split('?')[0]===j.url);if(!t)continue;
   Object.defineProperty(j,'c',{value:await CdpSession.open(t.webSocketDebuggerUrl),enumerable:false});
   const s=await snapshot(j);if(bound(s,j.prompt)){j.samples=[s];j.deadline||=Date.now()+15*60*1000;event(j,'OBSERVING',{reconciled:true,turnKey:s.turnKey,noResend:true});}
  }
 }
 const deadline=Date.now()+45*60*1000;
 while(Date.now()<deadline){
  for(const j of jobs.filter(j=>j.status==='OBSERVING')){
   try{const s=await snapshot(j);j.samples.push(s);j.samples=j.samples.slice(-3);
    if(finalWitness(j.samples,j.prompt)){j.responseSha256=digest(s.assistantText);writeFileSync(join(base,'interviews',j.role+'-response.md'),s.assistantText);writeFileSync(join(base,'interviews',j.role+'-completion.json'),JSON.stringify({role:j.role,promptSha256:j.sha256,responseSha256:j.responseSha256,url:j.url,targetId:j.targetId,choiceReadback:j.choiceReadback,samples:j.samples},null,2));event(j,'WITNESSED');}
    else if(Date.now()>j.deadline)event(j,'COMPLETION_UNCERTAIN',{reason:'Affirmative terminal evidence absent at deadline'});
   }catch(e){j.reason=e.message;event(j,'OBSERVATION_BLOCKED',{reason:e.message});}
  }
  // Uncertain submissions reserve a slot until reconciled, never trigger resends.
  let active=jobs.filter(j=>['OBSERVING','UNCERTAIN','SEND_UNCERTAIN','COMPLETION_UNCERTAIN','OBSERVATION_BLOCKED'].includes(j.status)).length;
  state.peakActive=Math.max(state.peakActive||0,active);save();
  for(const j of jobs.filter(j=>j.status==='PENDING')){if(active>=3)break;await dispatch(j);if(['OBSERVING','UNCERTAIN','SEND_UNCERTAIN'].includes(j.status))active++;state.peakActive=Math.max(state.peakActive||0,active);save();}
  if(!jobs.some(j=>['PENDING','OBSERVING'].includes(j.status)))break;
  await sleep(6000);
 }
 state.status=jobs.every(j=>j.status==='WITNESSED')?'ALL_INTERVIEWS_WITNESSED':'PARTIAL';save();
}finally{for(const j of jobs)if(j.c)await j.c.close();closeSync(fd);unlinkSync(lock);}
