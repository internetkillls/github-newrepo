# W6 — Responsive and accessibility closure

**Baseline:** source.zip SHA256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10` verified before extraction. **Dependency:** W4 canonical Stage I (I1 closure-only). No baseline source edited; no Chrome profile or schema touched.

## Binding design contract

Keep W4 Write / Boards / Library / More compact dock below 700px; at 700px and above use labeled rail with Find and Sessions. Do not introduce a Context home or a second primary capture button. Header text Paperfold, Capture action, and contextual workspace remain separate. At 280–320px, wrap noncritical metadata and tool controls; retain reachable Capture and four dock destinations. At 360–600px use one editorial column; do not force side context beside editor. At 800px use rail plus content, and only allow contextual second column when content width supports it (W4 currently uses 1110px breakpoint).

Shell uses content-driven height, no fixed aspect ratio. Dock belongs to shell, not document; editor and main content own vertical scrolling, formatting strip owns only its own horizontal overflow, wide data tables own horizontal overflow within `.table-scroll`. Avoid root horizontal overflow. Dialog uses native modal top layer, internal scroll limited by dynamic viewport height; do not allow page behind to become a competing scroll target. For short 400px viewports keep dialog close and primary action reachable by internal scrolling. Intrinsic media ratios are preserved; long titles, URLs and source excerpts wrap without clipping.

## Component boundary contract (Evidence → Specification → Composition → Preview → Compare → Diagnose → Correct → Validate → Handoff)

| Component | Required behavior and states | Acceptance evidence required in Stage III |
|---|---|---|
| Shell/header | text-only brand; Capture always reachable; no horizontal root scroll; compact vs wide nav | 6 widths × short/tall × 3 themes × 100/150/200% text |
| Navigation | four labeled dock items; expanded rail; active route announced with `aria-current`; keyboard Tab and Enter/Space | keyboard-only route transitions; focus returns to destination heading |
| Editor | one-column below wide breakpoint; independent toolbar horizontal scroll; caret preserved on library/evidence roundtrip | nonterminal selection insert, cancel, undo, IME, 200% native zoom |
| Library/search | typed filters wrap, long provenance URLs break, result lists remain readable; filter does not erase query | keyboard search/filter and empty-result announcement |
| Menus/dialogs | focus enters dialog, trapped while modal, Escape closes without mutation, focus returns to invoker; internal short-height scroll | focus order and Escape in installed Chrome Side Panel |
| Board/collection | single column in narrow views, responsive list/grid without card clipping; preserve Board/Card identity | populated data and long mixed-media regression |
| Status/toasts | polite announcement for nonurgent changes, never assert saved before acknowledged persistence | assistive tech and DB failure witness |
| Themes/icons | Paper, Pure Black, System contrast and focus rings; icons cannot be sole label | measured WCAG contrast + screen reader, dark/light OS |

## Preview and actual test boundaries

Executed Chromium against **W4's offline HTML/CSS/JS fixture**, not installed extension. `108` combinations across six widths, two heights (400,700px), three themes and three CSS text-size scales (100,150,200%). This is **text scaling**, not browser-native zoom. Root overflow/nav/capture checks: 0 failed combinations. Escape modal probe: opened=True, closed=True. Three PNG previews are fixture screenshots, not production captures. See `TEST-RESULTS.json`.

**Negative controls:** do not infer a production Side Panel PASS from fixture PASS; do not equate CSS root overflow with absence of clipped children; do not treat simulated 200% text as native browser zoom; do not treat dialog Escape alone as focus restoration/trap proof. W4 explicitly gates restore and persisted-save claims.

**Residual debts:** native 100–200% browser zoom, Chrome Side Panel actual height behavior, all-route 280px screenshots, keyboard focus order and return, assistive technology, WCAG measured contrasts, touch target sizing, full-tab real extension, source insertion undo/IME, real persistence, media sizing and populated long-content regression are unverified. Stage III must implement and run those tests.

**Reopen condition:** reproducible evidence at any specified width/height/theme/zoom that a required action is inaccessible, focus escapes a modal, content is lost/clipped, source insertion mutates before confirmation, or W4 navigation prevents a required journey.
