# W1 feature relocation map

**111 explicitly mapped source capabilities, prototypes and blockers**. All anchors resolve to the supplied v0.8 source snapshot. An anchor proves source text exists, not that Chrome executes successfully. `CURRENT_SOURCE` means code/markup observed, not browser tested.

| ID | Feature | New destination | Actual v0.8 source anchor | Truth |
|---|---|---|---|---|
| F001 | Application wordmark/icon | Shell/text-only | sidepanel.html:12 | CURRENT_SOURCE |
| F002 | Header cue palette | Write/Commands | sidepanel.html:16 | CURRENT_SOURCE |
| F003 | Header Card Markdown export | Write/Card actions | sidepanel.html:17 | CURRENT_SOURCE |
| F004 | Header workspace opener | More/Workspace | sidepanel.html:18 | CURRENT_SOURCE |
| F005 | Header AI transport opener | Write/Card actions | sidepanel.html:19 | CURRENT_SOURCE |
| F006 | Header archive export | Settings/Data & backup | sidepanel.html:20 | CURRENT_SOURCE |
| F007 | Header Boards opener | Boards | sidepanel.html:21 | CURRENT_SOURCE |
| F008 | Header settings opener | More/Settings | sidepanel.html:22 | CURRENT_SOURCE |
| F009 | Card switcher | Write/Card picker | sidepanel.html:28 | CURRENT_SOURCE |
| F010 | New Card | Write/Card picker | sidepanel.html:29 | CURRENT_SOURCE |
| F011 | Delete Card | Write/Card actions | sidepanel.html:30 | CURRENT_SOURCE |
| F012 | Card title and note body | Write/Card editor | sidepanel.html:42 | CURRENT_SOURCE |
| F013 | CodeMirror 6 editor | Write/Card editor | cm-editor.js:39 | CURRENT_SOURCE |
| F014 | Live and Reading modes | Write/Live Reading | sidepanel.html:87 | CURRENT_SOURCE |
| F015 | CM6 Markdown syntax/preview | Write/Card editor | markdown.js:73 | CURRENT_SOURCE |
| F016 | Markdown formatting H1/H2 | Write/Format more | sidepanel.html:72 | CURRENT_SOURCE |
| F017 | Markdown bold italic | Write/Format | sidepanel.html:74 | CURRENT_SOURCE |
| F018 | Markdown list checklist quote | Write/Format | sidepanel.html:78 | CURRENT_SOURCE |
| F019 | Markdown code math wikilink | Write/Format more | sidepanel.html:82 | CURRENT_SOURCE |
| F020 | Markdown editor zoom | Settings/Appearance, Write detail | sidepanel.html:90 | CURRENT_SOURCE |
| F021 | CM6 command completion | Write/slash and at completions | cm-editor.js:338 | CURRENT_SOURCE |
| F022 | Thinking cue modes | Write/Commands, Settings/Writing | cues.js:1 | CURRENT_SOURCE |
| F023 | Cue editor save/reset | Settings/Writing and commands | sidepanel.html:618 | CURRENT_SOURCE |
| F024 | Template insertion Stub | Write/Commands | sidepanel.html:110 | CURRENT_SOURCE |
| F025 | Template insertion Activity log | Write/Commands | sidepanel.html:111 | CURRENT_SOURCE |
| F026 | Template insertion Tracker | Write/Commands | sidepanel.html:112 | CURRENT_SOURCE |
| F027 | Template insertion Planner | Write/Commands | sidepanel.html:113 | CURRENT_SOURCE |
| F028 | YAML frontmatter parsing | Write/Card properties | yaml.js:3 | CURRENT_SOURCE |
| F029 | Tab capture manual/on-write | Write/Card details | sidepanel.html:47 | CURRENT_SOURCE |
| F030 | Current tab information | Capture/current page | sidepanel.html:121 | CURRENT_SOURCE |
| F031 | Refresh current tab | Capture/current page | sidepanel.html:123 | CURRENT_SOURCE |
| F032 | Attach active tab | Capture/page actions | sidepanel.html:126 | CURRENT_SOURCE |
| F033 | Attach multiple tabs | Capture/page actions | sidepanel.html:127 | CURRENT_SOURCE |
| F034 | Scrape page as paired Markdown | Capture/page actions | sidepanel.html:128 | CURRENT_SOURCE |
| F035 | Clip selection from tab | Capture/selection actions | sidepanel.html:130 | CURRENT_SOURCE |
| F036 | Optional site permission | Capture/permission gate | sidepanel.html:132 | CURRENT_SOURCE |
| F037 | Sources linked to a Card | Write/Sources drawer, Library | sidepanel.html:147 | CURRENT_SOURCE |
| F038 | Source Chrome bookmark link | Library/Bookmark action | sidepanel.html:653 | CURRENT_SOURCE |
| F039 | Source snapshot refresh | Library/Source action | sidepanel.html:654 | CURRENT_SOURCE |
| F040 | Source unlink from Card | Write/Sources drawer | sidepanel.html:655 | CURRENT_SOURCE |
| F041 | Scrap export and delete | Library/Scrap detail | sidepanel.html:669 | CURRENT_SOURCE |
| F042 | Manual attachment add | Capture/File, Library | sidepanel.html:131 | CURRENT_SOURCE |
| F043 | Attachment paired Markdown/raw Blob | Library/Attachment detail | provenance.js:144 | CURRENT_SOURCE |
| F044 | Attachment export/remove chunks | Library/Attachment detail | sidepanel.html:684 | CURRENT_SOURCE |
| F045 | DOI discovery | Write/Sources drawer | sidepanel.html:129 | CURRENT_SOURCE |
| F046 | DOI Crossref/DataCite lookup | Library/Literature | literature.js:65 | CURRENT_SOURCE |
| F047 | Linked Literature | Library/Literature, Write evidence | sidepanel.html:139 | CURRENT_SOURCE |
| F048 | Research annotation capture | Capture/Annotate | sidepanel.html:297 | CURRENT_SOURCE |
| F049 | Annotation source anchoring | Library/Annotation, Write evidence | service-worker.js:121 | CURRENT_SOURCE |
| F050 | Annotation reopen on page | Library/Annotation detail | sidepanel.html:697 | CURRENT_SOURCE |
| F051 | Insert annotation citation | Write/Sources drawer | sidepanel.html:698 | CURRENT_SOURCE |
| F052 | Annotation delete | Library/Annotation detail | sidepanel.html:699 | CURRENT_SOURCE |
| F053 | Reminder creation | Write/Details, More/Reminders | sidepanel.html:291 | CURRENT_SOURCE |
| F054 | Reminder notifications | More/Reminders | service-worker.js:73 | CURRENT_SOURCE |
| F055 | Local vector similarity search | Search/Local hash results | embedding.js:19 | CURRENT_SOURCE |
| F056 | Text/vector search UI | Search, Write search shortcut | sidepanel.html:198 | CURRENT_SOURCE |
| F057 | Activity log | Write/Card actions, Settings/Advanced | sidepanel.html:204 | CURRENT_SOURCE |
| F058 | Clear/activity single deletion | Settings/Advanced and Activity | sidepanel.html:207 | CURRENT_SOURCE |
| F059 | Boards legacy Maincards | Boards/index and detail | card-model.js:37 | CURRENT_SOURCE |
| F060 | Board memberships / reuse | Boards/Member actions | card-model.js:51 | CURRENT_SOURCE |
| F061 | Board role/classification | Boards/Member details | sidepanel.html:376 | CURRENT_SOURCE |
| F062 | Typed edges | Boards/Typed edge editor | card-model.js:65 | CURRENT_SOURCE |
| F063 | Board flatten JSON Mermaid | Boards/Export, Workspace/Flatten | card-model.js:129 | CURRENT_SOURCE |
| F064 | Board create edit delete | Boards/detail actions | sidepanel.html:358 | CURRENT_SOURCE |
| F065 | Spreadsheet projection | Workspace/Spreadsheet | sidepanel.html:415 | CURRENT_SOURCE |
| F066 | Calendar projection | Workspace/Calendar | sidepanel.html:416 | CURRENT_SOURCE |
| F067 | Provenance Flow projection | Workspace/Flow | sidepanel.html:417 | CURRENT_SOURCE |
| F068 | Workspace Flatten projection | Workspace/Flatten | sidepanel.html:418 | CURRENT_SOURCE |
| F069 | Spreadsheet CSV export | Workspace/Export | sidepanel.html:422 | CURRENT_SOURCE |
| F070 | Workspace flatten export | Workspace/Export | sidepanel.html:423 | CURRENT_SOURCE |
| F071 | Workspace AI transport | Workspace/Export & Send | sidepanel.html:424 | CURRENT_SOURCE |
| F072 | AI bundle create | Write/Card action, Workspace | sidepanel.html:472 | CURRENT_SOURCE |
| F073 | Full workspace backup export | Settings/Data & backup | sidepanel.html:517 | CURRENT_SOURCE |
| F074 | Woven tar archive | Settings/Data & backup | provenance.js:119 | CURRENT_SOURCE |
| F075 | Sticky notes JSON projection | Settings/Data & backup | provenance.js:267 | CURRENT_SOURCE |
| F076 | Export chosen local folder | Settings/Data & backup | sidepanel.html:543 | CURRENT_SOURCE |
| F077 | Download fallback | Settings/Data & backup | sidepanel.html:544 | CURRENT_SOURCE |
| F078 | Search provider editing | Settings/Search & commands | sidepanel.html:527 | CURRENT_SOURCE |
| F079 | Search provider reset | Settings/Search & commands | sidepanel.html:530 | CURRENT_SOURCE |
| F080 | Context menu root | Chrome native context menu | service-worker.js:13 | CURRENT_SOURCE |
| F081 | Context menu attach page | Chrome context/Attach | service-worker.js:16 | CURRENT_SOURCE |
| F082 | Context menu scrape page | Chrome context/Scrape | service-worker.js:15 | CURRENT_SOURCE |
| F083 | Context menu manual attachment | Chrome context/Add file | service-worker.js:17 | CURRENT_SOURCE |
| F084 | Context menu open Boards | Chrome context/Boards | service-worker.js:18 | CURRENT_SOURCE |
| F085 | Context menu annotate selection | Chrome context/Clip | service-worker.js:12 | CURRENT_SOURCE |
| F086 | Context menu provider search | Chrome context/Search selection | service-worker.js:19 | CURRENT_SOURCE |
| F087 | Browser cue keyboard shortcut | Write/Command palette | manifest.json:34 | CURRENT_SOURCE |
| F088 | Session autosave/checkpoint | Sessions/implicit service state | browser-sessions.js:72 | CURRENT_SOURCE |
| F089 | Session listing and rename | Sessions/list and details | session-ui.js:3 | CURRENT_SOURCE |
| F090 | Session group/tab/revision representation | Sessions/details and revisions | session-ui.js:3 | CURRENT_SOURCE |
| F091 | Session Board association | Sessions/Board association | browser-sessions.js:79 | CURRENT_SOURCE |
| F092 | Session preview restore | Sessions/Recovery preview | browser-sessions.js:99 | CURRENT_SOURCE |
| F093 | Session restore new window | Sessions/Recovery confirmation | browser-sessions.js:31 | CURRENT_SOURCE |
| F094 | Session model normalization | Sessions/domain (unchanged) | session-model.js:14 | CURRENT_SOURCE |
| F095 | Session checkpoint atomic data | Sessions/domain (unchanged) | db.js:176 | CURRENT_SOURCE |
| F096 | Appearance theme picker | Settings/Appearance | sidepanel.html:512 | CURRENT_SOURCE |
| F097 | Paper/Pure Black/System tokens | Shell/theme variants | sidepanel.css:10 | CURRENT_SOURCE |
| F098 | Google Drive OAuth | Settings/Integrations/Drive | sidepanel.html:569 | CURRENT_SOURCE |
| F099 | Google Drive backup schedule | Settings/Integrations/Drive | sidepanel.html:562 | CURRENT_SOURCE |
| F100 | Google Drive backup now/disconnect | Settings/Integrations/Drive | sidepanel.html:570 | CURRENT_SOURCE |
| F101 | Local LAN sync URL token | Settings/Integrations/Local | sidepanel.html:585 | CURRENT_SOURCE |
| F102 | Local LAN sync scheduled push | Settings/Integrations/Local | sidepanel.html:587 | CURRENT_SOURCE |
| F103 | Local LAN sync test/push/pull | Settings/Integrations/Local | sidepanel.html:592 | CURRENT_SOURCE |
| F104 | Local companion server | Settings/Integrations/Local companion | companion/tabwoven_sync_server.py:18 | CURRENT_SOURCE |
| F105 | Session revision store | Sessions/domain unchanged | db.js:6 | CURRENT_SOURCE |
| F106 | Saved-only Discover lexical prototype | Explore/Discover gated preview | prototypes/discover/lexical.js:38 | PROTOTYPE_NOT_WIRED |
| F107 | Query Studio AST prototype | Explore/Query Studio gated preview | prototypes/discover/query-ast.js:27 | PROTOTYPE_NOT_WIRED |
| F108 | Discover adversarial tests | Explore/gate evidence | tests/v08-discover-adversarial.mjs:7 | PROTOTYPE_NOT_WIRED |
| F109 | Dedicated full-tab app entrypoint | Expanded same-route projection | manifest.json:42 | PROPOSED_ABSENT |
| F110 | Contextual on-page Paperfold popover | Capture/page selection future contract | service-worker.js:55 | PROPOSED_ABSENT |
| F111 | Complete archive restore importer | Settings/Data & backup blocked | docs/followup/01-EVIDENCE-AND-GATES.md:44 | BLOCKED |

Design collisions: Spreadsheet, Calendar, Flow and Flatten are currently accessible through a workspace modal; this proposal moves them under Workspace views. Session content stays independent from Board/Card records. No rename or data migration is implied. Lab prototypes remain gated.

`FEATURE-RELOCATION.json` is the machine-readable contract; `FEATURE-RELOCATION.csv` is an operator-readable diff aid.
