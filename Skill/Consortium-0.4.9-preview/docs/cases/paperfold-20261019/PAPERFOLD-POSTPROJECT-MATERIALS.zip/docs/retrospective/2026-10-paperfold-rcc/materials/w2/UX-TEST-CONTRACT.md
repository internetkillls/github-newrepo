# W2 — Testable acceptance contract and AntiSlop negative controls

## Scope of this worker's actual checks

Source ZIP SHA-256, every extracted file against `SOURCE-MANIFEST`, static ID/service inventory and offline prototype controls are testable here. A Playwright Chromium screenshot can witness only the **fixture HTML layout**; it cannot certify Chrome sidePanel container behavior or data persistence. The prototype has no permission to change Chrome, IndexedDB, profile tabs, user files or remote services.

## Required independent implementation tests for W5/W6/W8–W10 (not claimed as passed here)

| ID | User task / width | Expected observable outcome | Close negative control / falsifier |
|---|---|---|---|
| UX01 | Library 280/320/360/420/600/800 | Search and facet results remain reachable and map to typed sources; root no overflow | Long URL, 220-char title and 200% zoom must not overflow; result may have no Board |
| UX02 | Source preview and citation | Source ID, quote, Card target retained through insertion and reload | Annotation record without source: disable citation, show lineage unknown |
| UX03 | Capture by context menu | Denied permission never extracts; grant retry explicit | Allowed host capture persists result and surface acknowledges; changing menu does not count as grant |
| UX04 | Markdown edit | CM6 cursor, undo, links and citations survive side width change and full-tab switch | Switch at 320px during active IME composition; no duplicated save or cursor jump |
| UX05 | Boards associations | Multiple Cards link without being moved; `maincards` IDs unchanged | Single Card in two Boards; deleting a Board must not delete its Card implicitly |
| UX06 | Sessions recovery | Preview read-only; successful confirmed restore missing safe URLs only | Unsafe `chrome://`, already-open tab, and changed revision are skipped / re-previewed |
| UX07 | Discover gated UI | Disabled/review-labeled until corpus/index tests and migration safety satisfied | Common word overlap but contradictory papers must not become “supports” edge |
| UX08 | Query Studio | Encoded query preview and explicit external-open gesture, sensitive fields rejected | `filetype:csv` on DuckDuckGo, credentials and malformed dates denied by parser |
| UX09 | Menus/modals | Escape cancels; focus returns to trigger; tab traversal readable | Menu anchored near lower-right at 280px never escapes viewport |
| UX10 | Themes | Paper, Pure Black, System text/status/icons accessible | System dark with white icon on white backdrop fails; no blanket image inversion |
| UX11 | Exports | Woven, Markdown, CSV, bundle, Drive and sync have correct path/status | Failed export or missing OAuth must NOT say “Saved” |
| UX12 | Search scope | Indexed source/chunk search labeled accurately; grouping and Board scope correct | Unindexed bookmark returns “not indexed,” never false `0 across everything` |
| UX13 | Dynamic source mutation | Insert source/annotation persists and reappears in appropriate facet | Duplicate URL treated as new distinct external source without duplicate policy must be reviewed |
| UX14 | Misc features | Reminders, cue set edit, activity log, DOI metadata, attachment, manual scrape discoverable | No-op settings/action fails even if visible |
| UX15 | Full-tab projection | Three-pane only when enough width; side panel and full-tab actions semantically identical | Resizing 800→280 during modal must preserve focus and scroll |

## UI-Adapted Visual Pipeline component contract

For every UI component at W2 stage: **evidence** source anchor → **specification** action/states/limits/theme → **composition** offline HTML fixture → **preview** when available → **comparison** against width/response claims → **diagnosis** overflow/focus/contrast mismatch → **correction** CSS/JS prototype only → **validation** automated fixture checks → **handoff** with unknowns and implementation owner. Component IDs are in `W2-COMPONENT-CONTRACT.json`; only evidence rows with actual receipts may have `observed=true`.

## AntiSlop audit / failure routing

- **Architectural:** reject creating new “smart collections” store or rewriting persisted `maincards`; collect views through bounded projection only.
- **Interface:** reject header full of icon-only controls and decorative layer-on-layer cards; keep clear text actions.
- **Responsive:** reject shrinking 3-column full tab to 320px or masking content with `overflow:hidden`; switch to one screen with reversible back path.
- **Interaction:** reject buttons that report save, capture, restore, sync or graph acceptance without handler/persistence receipt. Demo uses *explicit fixture-only notices* and disabled gated operations.
- **Evidence:** a mock screenshot is not Chrome E2E. Baseline static handler presence is not evidence of actual recovered tabs. The full-tab launcher is a proposed experience, not a current entry point.
- **Source:** document 0.8 manifests and actual files; legacy 0.7 audit is historical and cannot override v0.8 source.
- **Product:** do not surface AI/Discover as primary because prototype modules exist.

## Owned W2 exit criterion

PASS **only** when source identity passes, F01–F48 locations/statuses are mapped, 15 required surfaces have navigable locations, at least the seven primary journeys have path descriptions, one executable offline HTML prototype is reachable, local static/interactivity smoke checks pass, and limitations are explicit. This never means functional source refactor, a selected architecture, or release PASS. The falsifying independent event is W4 finding a source feature with no destination or an inaccessible 280px critical action.
