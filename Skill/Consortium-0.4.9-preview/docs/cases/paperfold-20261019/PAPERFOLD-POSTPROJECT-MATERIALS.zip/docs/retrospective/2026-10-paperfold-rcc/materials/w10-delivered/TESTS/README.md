# Reproduce W10 tests

From an extracted full candidate root, with Python 3.11+ (`playwright`, `beautifulsoup4`) and Node 18+:

`node --check sidepanel.js`

`node TESTS/w9-interactions.mjs`

`python TESTS/test_w9_repair_static.py --w8-dir . --w9-dir .`

`python TESTS/test_w9_repair_browser.py --w8-dir .`

`python TESTS/test_w8_repair_static.py --patch . --baseline ORIGINAL_EXTRACTED_BASELINE --prior-w8 . --w9-source TESTS/fixtures/previous-w9-sidepanel.js`

`python TESTS/test_w8_repair_browser.py --patch . --w9-source TESTS/fixtures/previous-w9-sidepanel.js`

`python TESTS/test_w10_reverify_boundaries.py --baseline ORIGINAL_EXTRACTED_BASELINE --w7-closure CONTRACTS/W7/CONSORTIUM-II-CLOSURE.json --old-w9 TESTS/fixtures/previous-w9-sidepanel.js`

`python TESTS/native_disposable_sidepanel.py --extension . --headed --receipt disposable-receipt.json`

The last command is disposable-profile only, requires locally installed Playwright Chromium supporting unpacked extensions, and **cannot alone certify native panel/real seeded data restore**. Complete manual/native gates from RELEASE-GATE.md separately. These tests do not require changing an active profile.
