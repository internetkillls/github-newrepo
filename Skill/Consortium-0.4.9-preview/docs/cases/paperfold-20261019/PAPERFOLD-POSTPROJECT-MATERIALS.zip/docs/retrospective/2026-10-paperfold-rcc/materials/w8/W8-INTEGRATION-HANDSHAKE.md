# W8 → W9/W10: locked DOM and CSS handshake

Case: `PAPERFOLD-UI-20261016`; input `source.zip` SHA256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`.

## Ownership and baseline

This is W8's shell half only. Apply `sidepanel.html` and `sidepanel.css` over an isolated copy of the *exact* v0.8 baseline, verify `SOURCE-HASH-MANIFEST.json`, then apply W9's `sidepanel.js` separately. Never merge either patch over a different source archive without reopening W7.

No JS module, database, schema, permissions, service worker, or manifest changes are authorized by W8. All 180 baseline `id` attributes are retained exactly once; use those production endpoints, not duplicates. `#attachCurrentButton` was moved to the global header, `#maincardsButton` to the Boards page, legacy settings/utility triggers to Settings, and all original dialogs remain present.

## Route adapter required in W9

- Bind `[data-pf-route]` on semantic buttons. Route keys are **exactly** `write`, `boards`, `library`, `find`, `sessions`, `explore`, `query`, `settings`.
- Switch `[data-pf-view]` by setting `data-pf-active="true"` on the current view and `"false"` elsewhere. CSS also recognizes `.is-active` or `.active` as compatibility aliases, but W9 should choose **one** source of truth. Avoid adding `hidden` to the current view.
- Apply `aria-current="page"` to each visible trigger matching the selected route and remove it from nonselected buttons; update `.is-active` for visual state. On wider widths Find/Sessions are rail buttons; compact equivalents inside native `<details class="pf-more">` are hidden beyond 700px.
- On compact widths, the four navigation destinations are Write, Boards, Library, and More. More is a native disclosure, **not a ninth app route**. When navigating from the disclosure, close it and restore/focus navigation appropriately. Escape and outside-click dismissal remain W9 obligations; the native disclosure toggle alone does not satisfy all keyboard/menu contracts.
- `#pf-main` owns main scrolling. Preserve per-route scroll and the active editor's draft and selection. On route entry focus destination heading or route container `[data-pf-view]` with `tabindex="-1"` without discarding the draft. Do not force focus away from an active IME composition.
- Library content is in `[data-pf-view="library"]` but still uses baseline data-bound lists and capture commands. Selection **does not** change Card/Board membership. Capture is a single existing `#attachCurrentButton` entry point, not a new unbound control; W9 must supply staged review before persistence as W5/W7 require.
- Boards opens existing `#maincardsDialog` through `#maincardsButton`; sessions opens `#sessionsDialog` through `#sessionsOpenButton`; settings retains `#settingsDialog` through `#settingsButton`. Don't assume they are already converted into full-page JS views or remove dialogs without a new ownership agreement.
- Explore/Query routes are intentionally read-only explanatory surfaces with **no new controls**. Don't activate the v0.8 prototypes without their separate safety gates. `#saveStatus` remains an existing save-state location; new `[data-pf-toast][aria-live]` is a W9 status hook. Success must follow the database ACK, not a timer.
- `[data-pf-modal]` is an additive marker on each existing `<dialog>` for focus/scroll management. Use native `showModal()` for blocking dialogs, save opener, trap focus, Escape cancel, and restore opener after close. The W8 CSS prevents viewport-size overflow, but neither a focus trap nor a persistence test is established by that CSS.

## Independent W8 witnesses and unresolved integrated gates

Static ID/route preservation PASS; headless Chromium HTML/CSS preview PASS for 336 view/width/height/theme combinations and 42 menu + 42 dialog sizing probes; 6 contrast cases PASS for sampled text only. These renderings deliberately exclude `sidepanel.js` and *manually inject* route state, so they are not navigation behavior or real Chrome side panel tests. An isolated headless extension service-worker start was not observed before timeout, leaving extension runtime behavior unverified. W10 must run real combined JS navigation, editor persistence, modal keyboard behavior, native zoom, permission denial, populated-data and recovery tests. Don't label a W8 preview screenshot an integrated screenshot.

**Reopen condition:** Missing baseline DOM IDs, W9 binding mismatch, a W10 navigation/persistence defect attributable to W8-owned markup/CSS, overflow/focus trap at required sizes, or a new authorized contract that changes the ownership boundary.
