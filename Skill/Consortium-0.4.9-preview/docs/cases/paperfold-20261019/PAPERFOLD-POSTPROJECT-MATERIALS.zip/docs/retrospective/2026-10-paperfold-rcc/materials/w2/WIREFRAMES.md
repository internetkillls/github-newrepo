# W2 navigable wireframe contract

The runnable wireframe is `WIREFRAMES/index.html` (open directly, no server). All content is labeled fixture/demo; W4 should judge the proposed hierarchy, not infer existing Chrome behavior. It covers fifteen required surfaces by four primary navigation destinations and contextual overlays.

## Full-tab, >=800px

```text
┌ Paperfold ────────────── Search everything ─────── Capture  More ─┐
│ Library   │ Results / facets          │ Source inspector          │
│ Boards    │ Search                      Source title               │
│ Cards     │ Type [Sources v]            URL/host · capture lineage │
│ Sessions  │ Board [All v]   Sort         Annotated quote / context │
│           │ [Source] Paper title        Open original · Annotate   │
│ Explore   │ [Scrap] chapter excerpt     Insert citation -> Card   │
│ Workspace │ [Annotation] exact quote    Associated Cards / Boards │
│           │ [Bookmark] web reference    provenance + limitations  │
└───────────┴───────────────────────────┴───────────────────────────┘
```

Navigation invariants: selecting a result updates inspector without replacing list/search position; switching type keeps query; source detail metadata never means a capture is confirmed. `Open original` from demo displays a non-mutating notice, no network.

## Side Panel, 280–420px

```text
┌ Paperfold                   More ┐
│ [ Search research...         ]  │
│ [ Capture page ]                │
├─────────────────────────────────┤
│ Library / Sources               │
│ Type: [All ▾] Board: [All ▾]   │
│                                  │
│ Source  • Example study         │
│ Annotation • Quoted phrase      │
│ Scrap • Web excerpt             │
│ ...                              │
├─────────────────────────────────┤
│ Library   Boards   Cards   More │
└─────────────────────────────────┘
            Select result
┌ Source detail            Back ┐
│ Title, host, original URL     │
│ Capture and annotation states │
│ Open original / Insert cite   │
│ Exact passage + provenance    │
│ Linked Cards / Board context  │
└───────────────────────────────┘
```

`More` carries Sessions, Explore, Workspace and Settings to avoid 8 persistent tabs; no icon-only critical controls. The small-shell `Back` returns to stable result list, not an unrelated Dashboard. 600px uses the same one-pane mode until the inspector has enough width.

## Cards/editor

```text
Cards > [Card title]           [Reading | Write] [More]
Board associations: [Theory A]   Source drawer: [Evidence]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  # Inference question
  Markdown body / citations preserved as plain text
  [save state: saved / saving / failed -- confirmed only]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 Evidence drawer: source ID, anchor, note target
```

The offline demo editor is a textarea for interaction testing only. Production implementation must retain CodeMirror and source editing features; no JS/DOM API integration is asserted.

## Other surfaces and state gates

- **Boards**: board selection, membership and typed-edge discussion; never rename `maincards` store.
- **Sessions**: revision preview and explicit restore is a disabled demo action; in real release use existing manager and user confirmation.
- **Explore**: Discover suggestions and Query Studio are labeled GATED and read-only. Query URL preview is synthetic, no actual provider request.
- **Workspace review**: move Spreadsheet, Calendar, Flow and Flatten to `More → Workspace` and maintain export actions.
- **Quick Capture**: header button + native context entry show target, capture method and permission preflight; no silent background text extraction.
- **Contextual popover**: quote-first action menu in Source inspector and Card evidence drawer; accessible Escape/back.
- **Settings**: group by need, including inherited theme, embeddings, keep-log, providers, exports, Google Drive, local sync and cue editor.
- **States**: visually distinguish empty vs loading, error, denied permission, uncommitted capture, success (when justified), and gated feature.

These compositions are a *specification and fixture preview*. The screenshots (if present) witness only an offline HTML prototype; W5/W6 must independently validate focus, menus, modality, theme and zoom under the chosen canonical design. See `UX-TEST-CONTRACT.md` for outcome-based gates.
