# W3 component-boundary contracts and responsive evidence

**Jurisdiction:** W3 *proposes* UX architecture and demonstrates it in a browser-rendered, local fixture. No source extension files are modified. `DESIGNED` and `WIREFRAME-BROWSER-TESTED` apply; `IMPLEMENTED-IN-EXTENSION`, `EXTENSION-BROWSER-TESTED`, `RELEASE-READY` do not. All components here use established source tokens `--bg`, `--surface`, `--surface-2`, `--text`, `--muted`, `--border`, `--accent`, `--accent-soft`, `--danger` defined in `sidepanel.css:1–32`; themes = Paper / Pure Black / System (auto). No logo in in-app header; manifest icons unchanged.

## Common protocol (every boundary)

- Evidence: source path and existing handler/service, including known gaps; never describe a wireframe action as saved to IndexedDB.
- Specification: `WIREFRAMES/index.html` + `wireframe.css` + `wireframe.js`, `FEATURE-RELOCATION-MAP.md` and requirements below.
- Composition/preview: local HTML only, fixture datasets and hand-authored flows. Rendered with headless Chromium via Playwright `page.set_content` because navigating directly to `file://` returns `ERR_BLOCKED_BY_ADMINISTRATOR` here.
- Compare/diagnose/correct: inspect screenshots and measured viewport overflow, review hidden/lost actions; the initial 200% zoom failure was corrected by small-width header wrapping and scrollable compact navigation, then retested.
- Validate/handoff: `tests/test_wireframe.py`, `tests/test-wireframe-static.mjs`, `receipts/*`; do not infer real Chrome behavior from fixture results.
- Semantics: buttons are `<button>`, inputs have programmatic labels, dialogue uses native `<dialog>` with Escape/focus return; modal actions without real browser/persistence APIs show a bounded fixture result or are disabled. No hover-only primary affordances. Status messages are live-region announcements; reduced motion never required for navigation. Primary functionality cannot depend on color alone.

## Interface surfaces (all fifteen)

| Requirement / component | Source evidence | Main journey and command contract | Container & responsive rule | States and accessible acceptance | Preview / disposition |
|---|---|---|---|---|---|
| W3-S01 shell | `sidepanel.html:10–31`, `manifest.json` | Header text, Board context, Capture, More; `route()` changes fixture view; full implementation needs no duplicate nav | 280–600 single column; ≥720 left 180 rail; ≥1050 optional 258 inspector | Active route announced and visible, no logo; theme contrast; focusable all actions; no root overflow | 320/800/1200 screenshots; fixture PASS |
| W3-S02 Markdown Card editor | `sidepanel.html:41–99`, `cm-editor.js`, `sidepanel.js:550–752` | Write → edit → source insertion/format → reading; production `saveNote` ack before Saved | Single-column content even at 600; readable main measure ≤850 wide; toolbar wraps, no forced horizontal scrolling | Blank/saving/saved/error/conflict; selection and undo preserved; keyboard formatting | Fixture draft retention PASS, persisted save UNVERIFIED |
| W3-S03 Board/project navigation | `card-model.js`, `sidepanel.html:346–405` | Board pill → Board → Card; membership and explicit typed edges separate | Picker fits viewport; Board members list vertically; wide add/relationship inspector optional | Empty/no Board/loading/delete confirm/error; no data cascade; aliased `maincards` | Fixture Board switch + details, source integration UNVERIFIED |
| W3-S04 Library, bookmarks, Sources, captures | `sidepanel.html:117–182`, `db.js`, `sidepanel.js:1278–1900` | Library filter by object type; inspect origin before edit/link | One list and filter at 280; ≥720 optional preview; no squashed grids | Empty/error/permission/unsupported media; source URL wrap; distinct kinds | Fixture filter and nav; real `chrome.bookmarks` UNVERIFIED |
| W3-S05 Search/filter | `sidepanel.html:192–202`, `embedding.js` | Find → query → type filter → open Card/Source; no auto external queries | Search input single-column; result tap target ≥34 CSS px | Empty/no match/indexing/permission/invalid terms; announced result count | Fixture filter PASS; real index ranking UNVERIFIED |
| W3-S06 Discover review | `prototypes/discover/lexical.js` | Find → Discover gate (read-only explanation, accept/dismiss disabled) | Compact review card only; no graph at 320 | Prototype unavailable, provenance and limitations visible, never writes typed edge | GATED, screenshot optional, disabled assertion PASS |
| W3-S07 Query Studio | `prototypes/discover/query-ast.js` | Find → Query gate; query preview only until later product gate | Stack fields at 280; no horizontal query overflow | No network calls; provider/AST limitations; outbound action disabled here | GATED, disabled assertion PASS |
| W3-S08 Browser Sessions | `browser-sessions.js`, `session-ui.js` | Sessions → revision → preview → explicit confirmation (not in fixture) | Vertical selector/list at 280; wide detail optional | ACTIVE / RECOVERY_NEEDED / no revision / permission failure / partial restore; never automatically reopens | Preview fixture PASS; restore disabled PASS; actual Chrome UNVERIFIED |
| W3-S09 Research annotation/citations | `sidepanel.html:297–321`, `provenance.js` | Selection → annotate quote/comment → citation option → Card; preserve anchor | Modal ≤min(560px, viewport−22px), vertical at 280 | No selection, anchor stale, permission denied, save failed, confirmed; return focus | Fixture annotation modal; anchor persistence UNVERIFIED |
| W3-S10 Quick Capture/native context menu | `service-worker.js:55–76,199–249` | Capture button OR Chrome native menu → same dispatch → permission gate → source/scrap/annotation | Capture button visible at 280; safe wrap at 200% | Empty selection/restricted page/grant required/confirmed result | Fixture capture memory PASS; native menu NOT TESTED |
| W3-S11 Contextual Paperfold popover | Existing Chrome menu only; no injected popover from manifest | Context-aware More actions by source/selection/card. **New injected page popover is not baseline** | Constrain popup right/top to visual viewport; max width viewport−24px | Pointer and keyboard menu, escape/close; don't consume editable target selection | Fixture popover; injection proposed and UNVERIFIED |
| W3-S12 Settings/integrations | `sidepanel.html:488–638`, `service-worker.js` | Settings → Appearance/Capture/Search/Cues/Data/Integrations | Single column forms at 280; ≥720 paired options only when useful | Paper/Black/System, Drive disconnected/connecting/error, LAN token, export path, no fake connect | Fixture theme PASS; OAuth/sync NOT EXECUTED |
| W3-S13 Empty/loading/success/warn/error/denied | `sidepanel.html:131`, `session-ui.js:showError` | Inline local state component, never full-screen for routine errors | Wrap message at 280; actions reachable by keyboard and screen reader | No saved results before confirmation; error retains draft; denied offers manual fallback | Fixture denied modal PASS; all runtime states spec-only |
| W3-S14 expanded/full-tab | **Not a current manifest entrypoint** (`manifest.json:action,side_panel`) | Same routes / same domain actions; inspect rail only ≥1050; focus writing measure | Use space for 180 nav + content + conditional 258 inspector; no fixed aspect ratio | Dragging/resizing may not lose edit buffer, no duplicate settings | 800/1200 screenshots PASS; real full-tab needs implementation |
| W3-S15 Chrome Side Panel | `manifest.json:side_panel`, `sidepanel.html` | Capture / write / lookup with pinned Board context, compact bottom destinations | Explicit 280,320,360,420,600; main flexes min-width:0, scroll ownership vertical; no cropped popovers | 200% and reduced motion, keyboard+Escape, all primary actions exposed; no root overflow | 280–600 viewport tests PASS; real extension witness outstanding |

## Layout rules / implementation handoff proposals

1. **280–359 CSS px:** header may wrap, text-only title stays; Board chooser + Capture + More second line. Five compact destinations remain visible at normal scale. At extreme browser text scaling, bottom destination bar becomes horizontally scrollable *as an explicit accessible fallback*, not root overflow. Scrollable navigation must support keyboard focus and an independent affordance (e.g. reveal partial next item), to be validated in the actual extension.
2. **360–719:** single vertical content lane. Source/annotation inspector is a drill-down, not squeezed alongside Markdown. Nav anchored below the viewport; content reserves padding so last action is reachable. Do not give editor a fixed aspect ratio or height tied to 16:9.
3. **720–1049:** persistent left rail; central writing/collection canvas. Do not create a right inspector until it actually adds context; popup/dialog never clipped by rail.
4. **≥1050:** conditional read-only inspector with the Board question, current Card and linked evidence. Writer can collapse it. Opening it must not duplicate independent editable state.
5. **Heights 600/800:** the main document scrolls; dialogs cap at `100dvh-25px`, with scrolling in their own body and anchored dismiss/confirm controls. No invisible actions behind the browser chrome or fixed footer.
6. **100–200% scaling:** test actual browser zoom in the release stage. W3 approximated stress with `body.style.zoom` and narrower width; those are proxies, not an actual extension zoom witness.
7. **Themes:** reuse explicit CSS tokens; status uses labels, focus ring contrasts with surface, icon font glyphs inherit `--text`, native SVG/icons must use `currentColor`. Do not invert bitmap or favicon content.
8. **Motion:** W3 wireframe uses no necessary animation. Later Stage II may add purposeful entrance/exit transitions; state changes must remain immediate under `prefers-reduced-motion`, with focus and Escape behavior identical.

## High-risk command contracts (implementation responsibility is downstream)

| Command | Input → event/handler → service | Confirmed feedback vs failure | Negative control |
|---|---|---|---|
| `card.save` | editor buffer → debounced handler → existing Note DB transaction | Saved only when acknowledged; failed state retains text and retry | Navigate away during pending save; do **not** show Saved |
| `capture.selection` | trusted user gesture/page anchor → content read with site access → provenance+scrap+annotation store | citeable captured source ID; denied UI otherwise | `chrome://` or denied host: manual link fallback; no false capture |
| `source.insertCitation` | chosen linked Source → cursor transaction in CM6 | caret restored; undo available | Empty/source deleted: do not insert dangling token |
| `board.addMember` | Card ID + Board ID + role/class → membership service | member appears without moving data | Shared Card removed from Board A remains on Board B |
| `session.preview` | session ID/revision → `PF_SESSION_PREVIEW` | read-only missing/skipped list | No browser tab writes before restore confirmation |
| `session.restore` | confirmed preview → `PF_SESSION_RESTORE` | created/skipped/failed counts from service | Unsupported URL and already-open URL never reopened |
| `discover.review` | approved-saved corpus + relationship proposal → explicit reviewer choice | gated until persistence/corpus evaluation pass | Keyword similarity alone never creates causal/supported-by edge |
| `query.openExternal` | supported provider AST → preview URL → explicit user click | external-open acknowledged; no silently collected results | invalid/sensitive query rejected before URL creation |
| `workspace.export` | exact scope + chosen destination → stream/archive | file creation acknowledged, independent restore test | Successful export is **not** restore evidence |
| `sync.connect` | permission and token/UI event → Drive/LAN request → returned auth/state | no fabricated connected state | Host unreachable or declined OAuth keeps Disconnected |

## What screenshots can and cannot prove

Recorded screenshot paths under `receipts/W3-*.png` prove only that our HTML fixture rendered in isolated system Chromium at the named viewport/theme when captured. They cannot prove local-first IndexedDB compatibility, Chrome Side Panel API behavior, native context-menu routing, Web Clipper selection preservation, actual extension focus return, user data migration, or restore safety. These are obligations for W7/W8/W9/W10, not W3-certified outcomes.
