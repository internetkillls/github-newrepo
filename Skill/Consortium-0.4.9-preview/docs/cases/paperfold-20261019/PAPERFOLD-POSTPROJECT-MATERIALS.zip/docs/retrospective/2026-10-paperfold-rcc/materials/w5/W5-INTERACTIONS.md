# W5 — Interaction, motion and modal contract

Scope: I1 closure-only; W4 canonical Write / Boards / Library / More architecture preserved. Source SHA256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`. No production extension changes.

## Shared tokens and invariants

Motion: `--motion-open:160ms`, `--motion-close:120ms`, `--motion-feedback:90ms`; opening cubic-bezier(.2,.8,.2,1), closing ease-in. Respect `prefers-reduced-motion:reduce` with zero duration. No animation is evidence of a write. Only compositor-friendly opacity and transform; avoid persistent motion. Blocking dialogs trap focus, restore opener focus, and lock background scroll. All other surfaces retain scroll and caret. Escape never silently commits.

## Per-interaction executable contract

### 1. Modal open/close
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Restore invoking element on dismiss; trap focus only for blocking dialog. Scroll: Lock underlying scroll only for blocking dialog.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Backdrop click cancels only non-destructive dialogs; destructive dialog requires explicit Cancel/Confirm. Initial focus heading or safe Cancel.

### 2. Popover
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Anchor to trigger, flip within viewport, dismiss on Escape/outside; no scroll lock.

### 3. Context action menu
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Arrow keys/Home/End navigate items; disabled actions expose reason; action runs once.

### 4. Hover/press
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Hover opacity 80ms, pressed scale .985 for pointer only; keyboard focus ring never suppressed.

### 5. Navigation
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Switch Write/Boards/Library/More instantly; optional 120ms content fade; preserve unsaved editor and scroll by surface.

### 6. Drawer
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Side Panel narrow drawers overlay rather than resize editor; Escape and close button; focus returns.

### 7. Drag/drop
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Only allow valid targets; highlight target without rearranging storage until confirmed; cancel with Escape.

### 8. Editor formatting
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Toolbar uses pointerdown caret preservation and aria-pressed; do not change editor engine or content schema.

### 9. Source preview
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Preview is read-only; staged citation review must explicitly confirm Card and insertion caret; cancel leaves Card unchanged.

### 10. Collection selection
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Selection changes filter/view, not membership; membership mutation requires explicit command.

### 11. Toast
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Success toast 3.5s dismissible, error persists until addressed; live region polite/assertive respectively.

### 12. Save indicator
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Retain focus or move to first actionable control; return focus on dismissal. Scroll: Preserve editor caret and viewport; scroll selected item into view only when necessary.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Dirty→saving→saved only on acknowledged persistence; error remains visible; no optimistic saved state.

### 13. Discover suggestion review
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Restore invoking element on dismiss; trap focus only for blocking dialog. Scroll: Lock underlying scroll only for blocking dialog.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Suggestion→review→explicit accept/reject; no automatic insertion or hidden side effect.

### 14. Recovery/error
Purpose: Make the state change legible without delaying the underlying action. Trigger: Explicit pointer, keyboard, or system event; never hover-only for essential actions.
Start → end: Inactive/hidden, no committed mutation → Visible/active or acknowledged settled state. Timing/easing: 160ms ease-out open, 120ms ease-in close; 90ms state feedback; zero for data commit.
Interruption: Escape/back/outside only when safe; cancel pending preview; never cancel committed write implicitly. Focus: Restore invoking element on dismiss; trap focus only for blocking dialog. Scroll: Lock underlying scroll only for blocking dialog.
Reduced motion: 0ms transitions, same semantics and focus. Performance: Animate opacity/transform only; avoid layout thrash and animated large shadows. Failure: Expose persistent actionable error; no fake success; retain input and retry affordance. Lock: Disable duplicate commit while in flight; navigation remains responsive unless destructive transaction.
Specific rule: Show failed operation and safe retry; avoid overwriting stored data; permission denial has guidance not auto-request.

## Boundary pipeline and provenance
Evidence: verified source ZIP hash; W4 closure and 15 W4 component contracts available. Specification: 14 interaction boundaries above; no new IA. Composition: self-contained HTML/CSS/JS fixture. Preview: static interactive preview file; not browser-executed in this worker. Compare: checked against W4 explicit citation review, preserved Card membership, and constrained Side Panel. Diagnose: no production editor/IndexedDB witness; avoid treating fixture state as persistence. Correct: disable automatic citation commit, duplicate save and destructive outside-dismissal. Validate: static checks on generated preview and contract; browser behavior remains unverified. Handoff: W6/W7 reconcile responsive and a11y behavior before build.

## Negative controls / acceptance
- Negative: clicking Library collection must not mutate Board membership.
- Negative: source preview cancellation must not insert a citation.
- Negative: toast display must not imply persistence success.
- Negative: reduced-motion mode must preserve dialog focus and action semantics.
- Exit: all 14 interaction classes specify required fields and preview contains functional open, close, Escape, focus return, menu, toast, save failure, reduced motion.

## Unverified
Real Chrome Side Panel, actual editor caret, screen reader, 200% zoom, storage writes, permissions, GPU performance and cross-browser behavior. Official reference-system web research not performed; reference-access debt remains.