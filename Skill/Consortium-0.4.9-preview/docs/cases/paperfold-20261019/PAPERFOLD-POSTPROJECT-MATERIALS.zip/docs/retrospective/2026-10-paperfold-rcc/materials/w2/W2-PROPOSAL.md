# W2 — Research Collection Architecture (independent wireframe candidate)

**Case:** PAPERFOLD-UI-20261016 · **Worker:** W2 · **Role:** Consortium I / I2 BLIND · **Status:** candidate only, not canonical · **Source:** Paperfold v0.8 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`.

## Thesis / governing user problem

An inquiry begins by finding a relevant source, confirming its identity/provenance, taking an explicit capture, and associating the evidence with an interpretation. The extant single-scroll Side Panel instead prioritizes an always-open note and exposes evidence as disparate lower sections. This alternative treats **Library / research collection** as the normal landing surface, while making source-to-Card insertion and Board context explicit. It is a genuinely collection-oriented candidate, not a generic editorial-first shell or a restyle.

**Baseline proven:** archive checksum verified, all 76 entries byte-for-byte aligned with provided SOURCE-MANIFEST; `sidepanel.html` has a dense header, note editor, sessions card, current-tab actions and separate Literature, Linked tabs, Markdown scraps, Manual attachments, Annotations, Reminders, Vector search, Activity log. Source has 19 IndexedDB stores (`db.js`); Board retains backing `maincards`. Source contains unmounted prototypes under `prototypes/discover/` (`docs/followup/03-UX-DISCOVERY-AND-QUERY.md` explicitly labels these DESIGN-PROPOSED, NOT IN APP). No Chrome safety certification from source reading.

## Proposed IA (explicitly NOT baseline)

1. **Library** — searchable *projection* across Sources/links, Chrome bookmarks, captures/scraps, annotations, literature and attachments. A projection is not a new DB store, automatic ingest, new permission, or canonical provenance merge. List/grid switch is visual only; filter semantics must match actual record relationships. A record type badge remains visible.
2. **Boards** — project/research perspectives; existing `maincards` IDs and memberships preserved. Board filter is applied to records via linked Cards rather than conflating Board with folders, Session or source.
3. **Cards** — Markdown authoring; current Card editor enters in one action, typography-first focused editing and an evidence drawer. Save status reflects persisted result in eventual implementation, not debounce intent.
4. **Sessions** — separate recovery and revision workflow with Preview → explicit Restore; no auto-reopening on navigation.
5. **Explore** submenu — Discover (prototype/gated), Query Studio (prototype/gated) and Workspace projections (existing spreadsheet/calendar/flow/flatten). No fake active connection review or automatic search results.
6. **More** — export/backup, AI transport, cue library, reminders, activity, preferences and connections. Quick Capture and Chrome context menu are entries into Library capture flow, not extra persistent top-level pages.

**Shell:** text `Paperfold`, contextual page title, global Search, one visible `Capture` and an overflow `More`. No in-app logo; manifest extension icons retained. Desktop: sidebar + results list + reading/annotation inspector; 600px and below: singular route stack with Back-to-results, saved list position, shared commands and no squeezed three columns. 280px has wrapping header and full-width controls. More is a *functional affordance* with explicit menu items and focus return, not a decoration.

**Domain ownership:** Board ≠ collection folder; Card ≠ capture; Source ≠ excerpt; annotation ≠ attached file; Session ≠ browser history; Discover suggestion ≠ confirmed link; Query Studio preview ≠ search result. Draft capture is never treated as saved source until acknowledged persist.

## Eight decisive user journeys

**J1 Find + verify:** Open Library → choose type `Sources` → search title/host → open source detail → inspect URL/DOI, associated Cards and explicit capture lineage → choose `Insert citation` → specify target Card and get confirmed write. Results preserve source ID across list and inspector.

**J2 Capture selected passage:** Chrome context-menu `Clip and annotate selected text` or `Capture` → provenance preview with domain + passage + permission state → optional comment → confirm → source/annotation/scrap linked to target Card under existing services. Cancel means no mutation; missing page permission gives grant UI rather than silent failure.

**J3 Retrieve a quotation:** Library `Annotations` facet → query fragment → selected quote shows source anchor and note association → navigate/reopen source with highlight and text-quote fallback; if the page is inaccessible, surface anchor/citation and error, do not claim highlight success.

**J4 Build research Board:** Boards → Board detail → associate existing Card(s) and inspect typed edges; filter Library by Board membership; no automatic conversion of session/tab into Card.

**J5 Write with evidence:** Cards → open → Markdown/Reading switch → source drawer → insert citation or source link into editor without losing selection; existing CodeMirror behavior must be reused, not overwritten by demo textarea.

**J6 Recover session:** Sessions → revision history → `Preview recovery` (read-only) → show missing URLs and skipped schemes → explicit confirm Restore into new window. Recovery is blocked if preview failed or current revision changed.

**J7 Critical exploration:** Explore → Discover; label `GATED PROTOTYPE`; surface only approved saved Cards, explanation and neutral proposed `related-to`; disallow acceptance until independent corpus and Chrome gate. Explore → Query Studio; preview provider URL and operator validation only; no query traffic before user gesture; never advertise real results.

**J8 Configure / export:** More → Settings displays themes, logs, embedding provider, search providers, cue sets, export folder, Drive backup and localhost sync; any credentials have separate reveal/security boundary. More → export active Markdown, woven bundle, CSV, flatten JSON, workspace backup, AI transport. Never display sync as healthy without witnessed handshake.

## Layout and navigation choices

- 280–359px: header wraps; bottom navigation tabs Library / Boards / Cards / More; Sessions via More + contextual recovery alert; one pane; list rows not thumbnail grids; action menu opens anchored within viewport, can scroll vertically; editor owns scrolling while composing.
- 360–599px: same single-pane route; explicit `Back to Library` within source preview; contextual actions are two visible buttons max with remaining in overflow; labels stay visible rather than ambiguous glyphs.
- 600–799px: list can use optional peek, but by default single pane if not enough room for 280px list + 300px meaningful inspector; switch based on *container* width, never Chrome window size alone.
- >=800px full tab: persistent nav at ~184–216px, list >=260px and flexible detail/editor, `minmax(0,1fr)` prevents overflow; inspector is not forcibly third column inside editing mode. Heights are content/viewport-based, not arbitrary aspect ratios.
- 100%–200% browser zoom/text: preserve semantic focus and scroll restoration; screen-level breakpoint is outcome not guarantee. Reduced motion disables reveal animation; no animation is required to complete task.
- Theme: reuse source `sidepanel.css` tokens `--bg`, `--surface`, `--surface-2`, `--text`, `--muted`, `--border`, `--accent`, `--accent-soft`, `--danger`, `--mark`; Paper / Pure Black / System select. Never filter/invert third-party artwork.

## Menu, toolbars, settings

Global header contains **Search**, **Capture**, **More**. Library toolbar contains query, type filter, Board scope and sort; row overflow contains source-sensitive actions. Source inspector contains `Open original`, `Add annotation`, `Insert citation` *only when applicable*. Card header contains title, explicit save status, `Reading/Write`, target Board(s), and evidence drawer; Markdown formatting is contextual and keyboard-capable, not eleven always-visible buttons. Sessions surface contains revision selection, recovery preview, explicit restore. More groups (1) Work: Explore, Workspace, Activity, Reminders, Cues; (2) Data: Export, Backup, AI transport; (3) Configuration: Settings and integrations. Settings categories: Appearance; Capture & search; Automation & reminders; Export & backup; Integrations; Advanced & diagnostics. Do not duplicate settings under every modal.

## Tradeoffs / strongest plausible rival

Research-first landing adds one navigation action for someone who only writes; provide persistent last-open Card navigation, keyboard command and `Cards` primary rail link, but **do not** auto-open editor and collection inspector simultaneously in a 320px panel. Unified Library projection improves retrieval but risks giving the impression all stores have identical ownership: clear type/lineage labels and a table-driven mapping are mandatory. Global result ordering and Board-scoped facets require consistent query semantics and performance measurement; the v0.8 vector search is partial, not a proof of global heterogeneous search. Annotation recovery depends on DOM/TextQuote anchor limitations. No silent upgrades of search/index/sync/permissions.

## UX hypotheses that can be defeated

H1. Given 12 mixed fixture objects, source retrieval by type and keyword takes ≤3 explicit navigations on 320px without opening Cards first. Falsifier: keyboard/pointer witness showing >3 navigations or hidden filter.

H2. At widths 280, 320, 360, 420, 600 and 800, viewport root scroll width <= inner width + 1px for Library, source, editor, sessions, settings, dialog, and menu states. Falsifier: measured overflow or unreachable action at 200% zoom.

H3. A source and its annotation remain distinguishable in list, inspector and citation operation. Falsifier: ambiguous row type or loss of sourceID/noteID in persisted contract.

H4. In production, declined/revoked optional host permission produces explanatory blocked state, with no request for page text and no fake `Saved` label. Falsifier: denial path still calls EXTRACT_TAB or claims capture committed.

H5. Opening and dismissing source detail or menu preserves result query, filter, scroll selection, editor cursor and returns focus. Falsifier: E2E keyboard probe losing selection/focus.

H6. Sessions Preview changes no tab/window state; Restore requires explicit confirmation and respects skipped URLs. Falsifier: changed tab count before consent.

H7. Discover/Query prototype affordances are explicitly gated; no user can be misled into believing suggestions are confirmed knowledge relations or an external query already executed. Falsifier: a control claiming accepted link without a backend gate.

H8. Eight user tasks J1–J8 remain reachable within one navigational hierarchy. Falsifier: unmapped source action or dead-end for a required surface.

## Delivery scope and next owner

The companion `WIREFRAMES/index.html` is an **offline interactive prototype with fixture data**, no Chrome APIs, IndexedDB, saving, page scraping, restored tabs, networks or production event handlers. A demo action is never evidence that the v0.8 extension performs it. A visual screenshot is evidence of layout only, not behavior in real Chrome Side Panel. Exact implementation/service mapping is in `FEATURE-RELOCATION-MAP.md`; proposed acceptance matrix is in `UX-TEST-CONTRACT.md`. W4 can select, reject or revise this I2 candidate. This role does not select canonical architecture, begin Consortium II, or certify a build.
