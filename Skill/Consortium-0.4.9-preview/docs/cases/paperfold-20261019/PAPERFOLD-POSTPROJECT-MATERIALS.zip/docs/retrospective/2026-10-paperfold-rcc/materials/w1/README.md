# Paperfold W1 — Editorial Wireframe Handoff

**Design-only independent W1 proposal, not the canonical Consortium I decision and not a production extension patch.** Source identity `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10` (v0.8 baseline). No Git metadata or other worker proposals were used.

Open `WIREFRAMES/index.html` in a normal local browser that permits file URLs. The fixture's navigable routes are Write, Boards, Library, Search, Sessions, Explore, Workspace views, Contextual capture, States & permissions, Settings and More. Narrower browser windows reproduce Side Panel proportions; a normal wider browser tab reproduces the *proposed* expanded layout. **Actions use fictional sample data held only in browser memory.** It does not load the real Chrome extension, database or APIs.

Read `W1-PROPOSAL.md` first, then `FEATURE-RELOCATION-MAP.md`, `COMPONENT-PIPELINE.json` and `EVIDENCE-AND-TESTS.md`. The screenshot PNGs are in `evidence/`, accompanied by machine-readable receipts. `W1-HANDOFF.json` is the formal noncanonical closure. W4 may use these as a challenge input but must not turn W1 into a canonical stage decision automatically.

To repeat the checks in an environment with Python, Playwright and Chromium installed:

```sh
python tests/test_w1_wireframe.py
python tests/test_w1_contract.py
python tests/verify_source.py path/to/source.zip path/to/SOURCE-MANIFEST.json
node --check WIREFRAMES/wireframe.js
```

The runtime test fixture injects exact supplied HTML/CSS/JS source contents into an isolated browser document because file URL navigation was blocked in the test environment; this limitation is not hidden. No installer, Chrome profile changes, network access, database migration, worker spawning or external publication is part of W1 output.
