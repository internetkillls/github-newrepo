# Asking for a more intuitive workflow next time

The next prompt should request an inspectable decision and evidence process. “Near deterministic chain of thought” is best implemented here as **repeatable routing rules, explicit inputs, typed state transitions, exact artifacts and falsifiable exit gates**. Models may produce different proposals on repeated runs. Neither a long reasoning transcript nor private chain-of-thought extraction would make them deterministic.

The stable object to reproduce is the observable workflow: why a task was routed, what evidence it used, what artifact changed, which check passed, and what would reopen the decision. Preserve concise decision rationales and test receipts; keep private reasoning private.

## What information the prompt needs

| Mention explicitly | Why it matters | Paperfold example |
|---|---|---|
| Concrete episode and desired outcome | Gives the design a human operation to preserve | “I found a quotation while drafting; I want to cite it without losing my paragraph.” |
| General story, separately | Stops the small episode from losing product context | Local-first research extension, narrow Chrome Side Panel, persistent knowledge objects |
| Source revision and surface | Prevents building against the wrong system | Commit/hash; current sidepanel source, not an old v0.7 description |
| Atomic function/data/state map | Makes design changes implementable | Inspect Source; stage target/caret; confirm or cancel; await storage ACK |
| Observed failure versus hypothesis | Avoids repairing an invented problem | “Control text invisible in native dark mode” versus “users may miss Sessions under More” |
| Rival and reversal condition | Makes intuition testable without dismissing it | Writer-first versus collection-first under a retrieval-heavy task mix |
| Evidence class | Prevents fixture/production laundering | Actual Chrome+IndexedDB; CSS-scale proxy labeled separately |
| WBS, ownership and dependency gates | Avoids duplicated or conflicting implementation | W8 HTML/CSS, W9 JS, W10 assembly/test |
| Negative controls and failure paths | Exposes accidental success | Cancel zero writes; abort rollback; stale target refuses; retry succeeds |
| Before/after protocol | Tests improvement, not just correctness | Task success, wrong-Card actions, time to resume writing, lost context |
| Automation and stop boundaries | Prevents both endless retries and stalled waiting | Three active, exact echo/completion, no uncertain resends, material-blocker stop |

## A router that learns from this case

Use a small observable decision tree before authoring a new design:

```mermaid
flowchart TD
    A[Concrete user episode] --> B{Do we know the causal failure?}
    B -->|no| O[Observe or reproduce the episode]
    B -->|yes| C[Map atomic functions, data owners and states]
    O --> C
    C --> D{Existing capability fits?}
    D -->|yes| E[Recompose flow or reveal existing action]
    D -->|no| F[Minimal new capability and precedent check]
    E --> G[Small native vertical test]
    F --> G
    G --> H{Contract fails?}
    H -->|yes| R[Reopen responsible owner]
    R --> G
    H -->|no| I[Human before-after task trial]
    I --> J{Outcome improves without harmful tradeoff?}
    J -->|no| C
    J -->|yes| K[Broaden coverage and deliver]
```

This is a proposed router policy, not a newly implemented scheduler. Its first test should be a small real project slice. Log the selected branch and exit artifact, not hidden deliberation. A route that repeatedly needs human correction should be changed on evidence rather than defended because it resembles a neat diagram.

## Three bounded UI experiments worth exploring

**1. More writing space without hiding meaning.** Compare the current 360px writer with a variant that defers Tab capture, Thinking cues and destructive actions into a labeled contextual control. Keep the same Card/data model. Measure time to first meaningful edit, successful retrieval of deferred actions, accidental delete activation and visible writing area. Include people who need those controls, not only expert keyboard users.

**2. Evidence-to-draft continuity.** Preserve query/filter/scroll, Source identity, target Card and caret across Library→review→Write→return. Test cancel, stale Card revision, different target Card and failed save. Measure correct task completion and time to resume the original paragraph. This is a candidate improvement; current native Capture proof does not certify all citation placement variants.

**3. Recovery discoverability.** Compare Sessions under More with a contextual recovery notice that appears only when recoverable browser state exists. Do not create an always-on dashboard or automatically restore windows. Measure unassisted recovery discovery, false alarms and duplicate windows. This tests the strongest known cost of writer-first rather than assuming it away.

Set study targets before seeing results. Worker-proposed 20%/25% improvements are hypotheses; adopt them only with a suitable baseline and task protocol. For small qualitative trials, report exact observations and limitations instead of presenting significance or general population claims.

## Prompt for an implementation experiment

```text
Role: senior product designer and software engineer. Use RCC for genuine
dependency/independence boundaries; AntiSlop and RMC in every worker packet.

General context: [product, objects, platform, constraints].
Human episode: [what I was doing, what broke my flow, what I wanted instead].
Frozen source: [repo, commit/hash, relevant files and existing contracts].

First reproduce/observe that episode. Distinguish observations from my design
intuition and from your hypotheses. Preserve the desired outcome even when
you challenge the mechanism. Do not replace this task with a new dashboard.

Map atomic functions -> data owners -> state transitions -> minimal UI.
Compare one serious rival. Prefer an existing capability if it solves the cause.
Give a WBS with concrete deliverables, exact file ownership and exit evidence.
Reuse existing role rooms; max three active; do not create extra specialists.

Implement one smallest native vertical journey before a large fixture matrix.
Test happy path, cancel/no mutation, stale identity, genuine failure, rollback,
dedup, reload and positive recovery control where relevant. Keep real user
profiles/data safe. Label fixtures, browser-native, human/AT and unknown evidence.

Measure baseline and candidate using [task success, errors, time to resume,
context loss]. State what result would reject your proposed design.
Stop at [review candidate boundary]; deployment/publishing needs its own scope.
Deliver source, exact receipts, a concise rationale, residual debts and reopen rule.
```

## Prompt to obtain new method improvements after the project

```text
Evaluate this completed project against my problem-story -> atomic-function ->
simple-representation -> measured-outcome rules, using [Notion/source version].
Freeze [repo revision], preserve the existing source/evidence archive, and
reconstruct all accessible role contributions without inventing missing history.

Interview the original workers in their own rooms, max three active, retaining
AntiSlop/RMC. Ask about their actual decision, strongest rival, concrete mistake,
evidence limitation, successor handoff and one next workflow experiment. Label
the interviews I0 AI self-report, not human feedback or independent certification.
Do not request private chain-of-thought; request concise decision rationales,
artifact anchors, tests, data/state invariants and what would change the result.

Corroborate material interview claims against exact files/receipts. Preserve
contradictions and inaccessible evidence. Compare intended design, implemented
behavior and human outcomes separately. Propose only improvements traceable to
a witnessed failure or explicit evidence gap.

For every RCC improvement record: failure signature, input, routing rule,
responsible owner, smallest change, negative control, acceptance metric and
reopen/stop condition. Separate transport/deliverable/runtime/release statuses.
Never resend an uncertain submission; reconcile exact prompt and completion.

Save a portfolio-readable design/engineering story and all documentary material
indices in the project repo. Save the reusable interview method, supported
findings and candidate regression cases in the existing RCC plugin, preserving
identity/audience/configuration and verifying the saved release. Distinguish a
saved account release from local runtime activation. End with exact local links,
evidence limits, and the next prompt needed for the highest-value experiment.
```
