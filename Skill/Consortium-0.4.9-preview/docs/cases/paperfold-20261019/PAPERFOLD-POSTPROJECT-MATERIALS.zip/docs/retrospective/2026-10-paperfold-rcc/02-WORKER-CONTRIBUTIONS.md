# What W1–W10 actually contributed

The table maps roles to delivered work, not ten people or ten independent runtime certifications. Role packets and available documentary outputs are preserved under [materials](MATERIALS-MANIFEST.json). Reported fixture totals are scoped to their respective harnesses and should never be added into a project quality score.

| Worker | Purpose and concrete achievement | Artifact anchors | Evidence boundary and design consequence |
|---|---|---|---|
| **W1 — editorial architect** | Built a writer-first proposal and navigable wireframes; mapped 111 anchored inventory items; defended Card return continuity; admitted and corrected silent source insertion during debate. | [Proposal](materials/w1/W1-PROPOSAL.md), [original response](materials/w1/ORIGINAL-RESPONSE.md), [feature map](materials/w1/FEATURE-RELOCATION-MAP.md) | Initial role I2; debate I0. Selected structural basis after correction. Fixture checks do not certify actual CM6 or IndexedDB. |
| **W2 — collection architect** | Built Library-first typed collection/search/source-detail alternative, 15-surface contracts and responsive previews. Challenged retrieval cost and provenance visibility. | [Proposal](materials/w2/W2-PROPOSAL.md), [original response](materials/w2/ORIGINAL-RESPONSE.md) | Reported 95 wireframe checks and baseline regressions. Rejected as landing architecture; typed Library and return-state mechanisms retained. No measured human preference. |
| **W3 — context architect** | Built Board/Card/Source continuity model, 52 grouped feature locations and narrow/wide fixtures. Reconsidered five-slot compact navigation under debate. | [Proposal](materials/w3/W3-PROPOSAL.md), [original response](materials/w3/ORIGINAL-RESPONSE.md) | Reported 67 fixture checks. Optional context survived; mandatory Context home did not. CSS/text-scale proxies were not native browser zoom. |
| **W4 — Stage I adjudicator** | Read three proposals and debates, selected W1 with bounded amendments, froze IA, relocation/status map and component contracts; implemented/tested adjudication fixture. | [Architecture decision](materials/w4/UI-ARCHITECTURE-DECISION.md), [IA](materials/w4/INFORMATION-ARCHITECTURE.md), [closure](materials/w4/CONSORTIUM-I-CLOSURE.json) | I1 closure-only adjudication, not a fourth blind proposal. Design/wireframe PASS, 82 fixture checks reported; no human A/B superiority claim. |
| **W5 — interaction designer** | Specified 14 interaction classes: triggers, transitions, interruption, focus, scrolling, reduced motion, failure and duplicate-action lock. Kept preview read-only and Saved behind storage ACK. | [Interaction specification](materials/w5/W5-INTERACTIONS.md) | Document/preview work, static checks; no browser execution claimed for its preview. Full 18,620-byte document eventually delivered in five slices. |
| **W6 — responsive/accessibility designer** | Specified compact/rail behavior, controlled overflow, short dialog height, focus, contrast and native acceptance conditions. Exercised W4 fixture at 108 combinations. | [Responsive specification](materials/w6/W6-RESPONSIVE.md) | Fixture Chromium, widths/heights/themes/text scales. Focus trap, AT and native zoom were still obligations, not earned PASS. |
| **W7 — Stage II planner** | Froze exact source ownership and DOM/behavior handshake; reconciled W5/W6 against W4; reread complete transferred specifications and corrected conflicting motion tokens. | [Stage II closure](materials/w7/CONSORTIUM-II-CLOSURE.json), [build partition](../../../CONTRACTS/W7/BUILD-PARTITION.md), [API contract](../../../CONTRACTS/W7/COMPONENT-API-CONTRACT.md) | Canonical build contract PASS, not runtime PASS. W8 HTML/CSS versus W9 JS, no shared-module edits without reopening ownership. |
| **W8 — markup/style builder** | Implemented writer-first shell in `sidepanel.html`/`.css`, preserving baseline binding IDs; supplied responsive/theme previews and tests. Later supplied menu/route repairs and exact contrast correction after host counterexample. | [Original response](materials/w8/ORIGINAL-RESPONSE.md), [contrast report](../../../EVIDENCE/upstream-W8-contrast/CONTRAST-REPORT.md) | Initial 336 visual combinations and six contrast samples missed a native cascade problem. Runtime attempt was blocked. Final host evidence, not initial fixture PASS, supports the repaired CSS. |
| **W9 — behavior builder** | Implemented route/menu/modal/keyboard adapters and persistence safeguards in `sidepanel.js`; repaired Capture preview/confirm/cancel, transaction, dedup and stale context boundaries through its existing room. | [Original response](materials/w9/ORIGINAL-RESPONSE.md), [repair response](materials/w9-repair/ORIGINAL-RESPONSE.md), [interaction tests](../../../tests/w9-interactions.mjs) | Initial scoped PASS was not combined extension certification. Repair retained native/runtime debts; host later tested named journeys with actual storage. |
| **W10 — integration/verifier** | Combined exact delivered changes with immutable baseline; produced integration/accessibility/visual reports, tests and native harness; returned an honest BLOCKED Stage III closure and transferred actual source archive. | [Recovered integration report](materials/w10-delivered/INTEGRATION-REPORT.md), [historical release gate](../../../EVIDENCE/upstream-W10/RELEASE-GATE.md), [host final review](../../../HOST-FINAL-REVIEW.json) | Transport success did not turn BLOCKED into release PASS. Host reviewed harness and executed isolated native checks; later CSS repair returned to W8 rather than being silently authored by W10. |

## How authority moved

```mermaid
flowchart TD
    W1[W1 writer-first] --> D[Shared W1-W3 challenge rounds]
    W2[W2 collection-first] --> D
    W3[W3 context-first] --> D
    D --> W4[W4 canonical architecture]
    W4 --> W5[W5 interaction semantics]
    W4 --> W6[W6 responsive and accessibility]
    W5 --> W7[W7 contracts and ownership]
    W6 --> W7
    W7 --> W8[W8 HTML and CSS]
    W7 --> W9[W9 JavaScript]
    W8 --> W10[W10 integration and evidence]
    W9 --> W10
    W10 --> H[Host native review]
    H --> R[Evidence-driven repair to W8 or W9]
    R --> H
```

The W1–W3 challenge rounds reused the same three rooms. Repairs and W10 reverification also reused role-owned conversations. Seventeen final job records therefore do not imply seventeen workers. The main host performed routing, transfer, inspection and native verification; it was not an unreported eleventh architect. The contrast repair was authored by W8, then independently checked on the host.

“All workers used AntiSlop and RMC” is supported as a **packet requirement**: original packets required the bundled instructions and explicit evidence/unknowns. It is not proof of hidden internal compliance. Observable compliance is assessed from source anchors, acknowledged defects, negative controls and truthful scope in their closures.

## What to put in the next prompt

Give each role a deliverable, evidence boundary, exact dependencies, forbidden actions and exit test. Require a successor to acknowledge full document identity and critical sections, rather than only saying it read a closure. Reopen the responsible role when a named contract fails.
