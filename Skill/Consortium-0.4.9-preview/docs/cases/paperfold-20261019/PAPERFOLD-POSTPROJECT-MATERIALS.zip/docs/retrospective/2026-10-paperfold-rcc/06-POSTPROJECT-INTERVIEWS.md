# Asking the workers what their own evidence did not establish

The host interviewed the original role-owned rooms on 19 October 2026 using eight shared questions and a role-specific probe. Every packet retained AntiSlop/RMC requirements. The packet supplied the user's current Notion criteria and a clearly labeled summary of later host results. These are **I0 AI retrospective responses**. No human research participant was interviewed.

The [index](INTERVIEW-INDEX.json) identifies prompts, readable responses, raw public assistant segments, SHA256 values and terminal-completion receipts. The collector required exact prompt/turn association and repeated affirmative completion evidence. A readable response selects the final public answer from a capture that may also contain a public preamble. An early serializer used the separator “ALTERNATIVE RESPONSE” between such segments; that host-added marker is not evidence of an A/B response comparison. Raw records remain available.

All ten original roles returned completed responses. Nine labeled their interview ANSWERED; W6 labeled it PARTIAL. Response completion and evidence completeness are separate statuses. The [findings ledger](INTERVIEW-FINDINGS.json) records corroboration and proposal boundaries.

## What each interview added

| Worker | Reflection and proposed improvement | How this review treats it |
|---|---|---|
| [W1](interviews/w1-response.md) | Owned the silent-append fixture defect and suggested an evidence/delivery ACK gate; noticed narrative 41 checks versus receipt/closure 42. | Silent append and count inconsistency corroborated by original debate/closure. Its proposed 20% faster evidence-to-citation target is unmeasured. |
| [W2](interviews/w2-response.md) | Explained the retrieval-heavy task mix that could defeat writer-first; admitted its own destination shortcut and proposed evidence-to-draft state mapping. | Serious rival preserved in W4. Final implementation survival is not established by W2's recollection; inspect source/native evidence by claim. |
| [W3](interviews/w3-response.md) | Distinguished route reachability from preserved research context; challenged five compact labels and compulsory Board classification. | Original proposal/debate support the tradeoff. Optional context must be tested through identities/query/caret, not route screenshots alone. |
| [W4](interviews/w4-response.md) | Acknowledged that reachability did not measure navigation comprehension; proposed Decision–Rival–Falsifier handoff. | Corroborated by W4's explicit lack of human comparison and preserved Library-first rival. Proposed comparative thresholds are future protocol choices. |
| [W5](interviews/w5-response.md) | Critiqued repeated generic specification fields and missing asynchronous operation/stale-response detail; proposed scenario-specific boundary records. | Repeated template is visible in full W5 text. Race failures are a supported risk, not witnessed product failures in this interview. |
| [W6](interviews/w6-response.md) | Explained broad matrix versus shallow assertions and missing native/AT evidence. Declared its interview PARTIAL because complete original receipts/previews/method files were not accessible. | Preserve PARTIAL despite completed response transport. Availability differs between host and worker; host copies do not imply W6 inspected them. |
| [W7](interviews/w7-response.md) | Identified initial W5 document incompleteness before canonical planning; proposed full artifact path/length/hash/authority gate. | Final W7 closure records full W5/W6 reread and motion-token correction. A summary alone had not earned the initial dependency. |
| [W8](interviews/w8-response.md) | Recounted Capture's legacy-handler bypass and insufficient contrast sampling; asked which failure could occur while its own tests still pass. | Both supported by W8 repair/contrast reports and host native contrast evidence. This is the most direct candidate for a boundary-falsification prompt. |
| [W9](interviews/w9-response.md) | Owned premature component closure, missing popover/route handshake and direct Capture write; proposed a cross-ownership interaction witness and clearer page→Card destination statement. | Repair reports/source and native Capture receipts corroborate the named boundary. Atomicity is scoped to reviewed global Capture; other attachment paths were not universally redesigned. |
| [W10](interviews/w10-response.md) | Separated archive integrity from successful outgoing-payload transfer; could not see the host's eventual chunk-49 acceptance. | Host reconstructed the complete pinned archive successfully. W10's lack of receiver ACK is an information gap, not evidence that final transport failed. |

## Findings that changed the method

**Receiver knowledge must be explicit.** W10 still lacked a trusted receiver ACK for chunk 49, while host evidence established the full archive's byte identity. W6 could explain its specification but could not inspect the complete original previews/results. A successor should receive both artifact identity and evidence scope, and the producer should receive a compact accepted/rejected receipt when relevant.

**Full-document receipt is a dependency, not a courtesy.** W7's corrected closure names the 18,620-byte W5 document and the 4,775-byte W6 document, their hashes, the 14 interaction classes and motion conflict. A later planner cannot validate an interface contract from a truncated or summary-only substitute.

**Boundary questions are more useful than self-evaluation scores.** W8 could enumerate two failures its initial checks missed: adding a dialog did not remove the old direct-write handler, and sampled contrast did not exercise all affected controls. Ask “what failure could occur while all your reported tests still pass?” and route its answer to an owner and discriminating test.

**Keep the rival alive after selection.** W2 and W4 independently emphasized that source retrieval could favor Library-first. The next usability study should test that task distribution. It should not merely ask people to approve the selected aesthetic.

**Interview coverage is not evidence coverage.** Completed transport can coexist with a PARTIAL interview, missing artifacts or unverified claims. Worker-proposed 20%/25% speed/action improvements and 90% task success are prospective criteria. None occurred as measured outcomes in this project.

## Execution limits and recovery

The first collector had a snapshot-escaping error, and one composer adapter reported no new user turn after a real send. Exact prompt echoes were reconciled before observation resumed, with no repeated submission. W7/W9 initially failed before sending because conversation history/model controls were unavailable. A bounded reload recovered W7. W9's history error recurred until the user reported its tab open; the host then verified the original room, idle/empty composer and absence of the interview token before submitting once. The scoped receipts exclude unrelated sidebar/chat names.

The supplied result summary and role-specific incident probes intentionally anchor the interviews to this project. That helps traceability but limits independence. A future method can first request unprompted reflection, then present disputed evidence in a second bounded pass. These conversations provide AI-worker explanations, not human lived-experience validation.

## What to put in the next prompt

“Interview the actual original roles. Ask what could fail while their own tests passed; require exact anchors and missing-access disclosure. Compare their answer with the successor's evidence. Preserve disagreement, separate I0 self-report from witness tests, and turn only corroborated findings into candidate method changes with negative controls.”
