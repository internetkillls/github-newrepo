# W8 repair → W9/W10 DOM, state and event handshake

Case `PAPERFOLD-UI-20261016`, task `w8-repair`. Immutable v0.8 `source.zip` SHA-256: `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`. W4/W7 remain canonical. W8 owns **only** `sidepanel.html` and `sidepanel.css`; W9 owns `sidepanel.js`; W10 integrates/verifies. This file defines hooks rather than claiming the W9 handlers already exist.

## 1. Production Source actions menu (nonmutating contextual popover)

The **Library → Current tab** heading includes the semantic `button#pfSourceContextTrigger[data-pf-popover-trigger="source-context"][aria-controls="pfSourceContextPopover"][aria-haspopup="menu"][aria-expanded="false"]` (label: “Source actions”). Exactly one matching global sibling of the workspace is `div#pfSourceContextPopover[data-pf-popover="source-context"][role="menu"][hidden]`, initially also `.hidden`. Its child buttons are `role="menuitem"` with the existing W7 `data-pf-route` values `find`, `boards`, `write` (labels: “Find related material”, “Review Boards”, “Return to Card”). These are contextual *navigation*, not source mutations or a Chrome page-injection popover. There is no fabricated `sourceId` or implicit Board membership change.

W9 already implements the route adapter and `togglePopover(trigger)`, `dismissPopover`, `positionPopover`, `handlePopoverKeydown`; wire these to the exact selectors. Opening: preserve editor selection; unhide one menu; set opener `aria-expanded=true`; call viewport-positioning; focus the first enabled item. Escape: dismiss and restore trigger focus; outside click: dismiss without forcing focus; ArrowUp/ArrowDown/Home/End: move among enabled items. Selecting a route must dismiss and reveal its `[data-pf-view]`, update `aria-current` and `[data-pf-active]` in coordination with W10's confirmed mechanical route fix, without any source/link write. On resize/scroll remeasure anchor. Do not use More's native `<details>` to substitute for this separate menu. Menu is initially hidden and cannot receive focus while hidden.

CSS renders the menu with `position:fixed`, viewport-clamped width and height, local scroll, background/text/focus from existing semantic tokens, z-index 110, and 40px minimum row height. Native W9 geometry still owns `top/left` inline styles. At 280px width and 400px height it must remain in the viewport. Popup typography and focus are theme-dependent; test Paper, Black and System. W9 should also close any menu when a modal opens so two overlays do not compete.

## 2. Capture review dialog (nonmutating markup; hard safety gate)

The existing global button **retains** `id="attachCurrentButton"` and gains `data-pf-capture-trigger`, `aria-haspopup="dialog"`, `aria-controls="pfCaptureReviewDialog"`, `aria-describedby="pfCaptureReviewGateStatus"`. It is **initially `disabled`**. The visually-hidden `#pfCaptureReviewGateStatus` reads “Capture unavailable until source review is enabled.” W9 MUST NOT remove `disabled` until replacing/removing the existing `attachCurrentButton.addEventListener('click', () => attachTab(...))` write path with a two-phase controller. Do **not** just add `data-pf-open-dialog`: W9's current document-level `[data-pf-open-dialog]` handler opens the dialog but does not call `stopPropagation`; the old element-level listener still reaches `attachTab()`. That precise bypass was witnessed in a Chromium adapter probe and is a release-blocking negative control. W8 HTML/CSS cannot repair that JS defect.

The **native** `dialog#pfCaptureReviewDialog[data-pf-modal][data-pf-capture-review][aria-labelledby="pfCaptureReviewTitle"][aria-describedby="pfCaptureReviewIntro"]` is initially closed and has no auto-submit form, script or persistence effect. Its content is:

| ID | Role / W9 operation |
|---|---|
| `pfCaptureReviewTitle` | Heading, “Review capture” |
| `pfCaptureReviewIntro` | Instruction: confirm explicitly before saving |
| `pfCaptureReviewPageTitle[data-pf-capture-field="title"]` | Read-only preview title; set with `textContent` |
| `pfCaptureReviewPageUrl[data-pf-capture-field="url"]` | Read-only preview URL; set with `textContent` (not `innerHTML`) |
| `pfCaptureReviewMode[data-pf-capture-field="mode"]` | Read-only current capture mode label |
| `pfCaptureReviewStatus[data-pf-capture-status][role="status"][aria-live="polite"]` | Loading/permission/error/saving/acknowledgment status, never invented success |
| `pfCaptureCancelButton[data-pf-close-dialog="pfCaptureReviewDialog"]` | `type=button`, cancel; zero `sources`/`links` writes |
| `pfCaptureCommitButton[data-pf-capture-commit]` | `type=button`, **initially disabled**; only W9 explicit click handler may initiate commit after preview was validated |

W9 required state transitions:

1. **Unbound**: global Capture disabled; no source writes possible by ordinary pointer/keyboard activation. Do not enable merely because DOM exists.
2. **Controller ready**: remove legacy direct-commit listener, bind an owned `#attachCurrentButton` handler, then enable. Capture click first reads the active tab and permissions, resets dialog fields/status, keeps commit disabled and opens native `showModal()` via `openDialog('pfCaptureReviewDialog', opener)`. It does not call `attachTab` or any `put` yet.
3. **Preview valid**: place metadata with `textContent`; verify usable current tab/permission and non-staleness; set status “Ready to save”; enable `#pfCaptureCommitButton`. If preview unavailable, permission denied, tab changed or overlay stale: keep disabled and show explanation. Never quietly request a permission or write.
4. **Confirm**: atomically deduplicate a single commit intent, set `pending` and disable commit while storing. W9 alone may call its source/persistence helpers; show success only after required `sources` and `links` store acknowledgments (and reconcile partial failures, rather than labeling a half-write success). Handle duplicate clicks, permission revocation and failed storage; offer safe retry without destroying editable drafts. `Escape`, Cancel and close before commit must write *zero* rows.
5. **Close**: restore focus to the *enabled* opener. The native dialog provides top-layer/inert semantics; W9 `closeDialog` handles focus and precommit cancel. Do not add legacy submit defaults; Backdrop click does not confirm.

**W9 positive acceptance:** Capture → dialog preview → explicit Save Source → observed `sources` and `links` persistence ACK, then success. **W9 negatives:** Cancel/Escape/outside click produces zero writes; disabled or stale review never persists; duplicate confirm never doubles a write; denied permission and failed save never announce success; global click cannot fall through to the old direct `attachTab()`. Run against actual IndexedDB in disposable Chrome profile. Existing W9 adapter mock/fixture is insufficient.

## 3. Integration and evidence boundary

W8's source-only checks preserve every original v0.8 and prior W8 DOM ID; all eight W7 routes survive. W8 exercised Chromium fixture dialogs/menus with extracted W9 adapter functions and the **documented W10-only `data-pf-active` shim**, but did **not** edit W9 or run installed Chrome Side Panel, IDB, CM6, permissions, user profiles, zoom/assistive technology, session restore or populated-data migration. The new menu is not an injected website text-selection popover: W4 S11 records that as **SPEC ONLY**, needing separate architecture/permissions authorization if intended. Stage III remains BLOCKED pending W9 Capture repair and W10 full native/data gates.
