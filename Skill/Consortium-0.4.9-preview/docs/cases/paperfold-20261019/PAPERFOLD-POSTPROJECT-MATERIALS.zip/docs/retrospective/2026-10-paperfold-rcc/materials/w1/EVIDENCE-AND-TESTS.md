# W1 Evidence, Checks, Negative Controls and Open Gates

**Case:** PAPERFOLD-UI-20261016 · **Source SHA-256:** `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10` · **Scope:** worker-owned noncanonical I2 design proposal.

## Source integrity

Actual uploaded archive was read, hash-checked, extracted into an isolated copy and compared byte-for-byte against 76 manifest entries. `evidence/SOURCE-INTEGRITY-RECEIPT.json`: `PASS`, 76/76, no missing or extra names and no digest or size differences. Source contains **no Git metadata**; this report does not infer any commit ID. Production source, permissions, schema and Chrome profiles were not modified. `tests/verify_source.py` accepts arbitrary user-supplied source/manifest paths; it never mutates either.

## Source anchors that change architectural decisions

| Claim | v0.8 source anchor | Observation type | Consequence |
|---|---|---|---|
| Header overfilled and workflow vertically stacked | `sidepanel.html:10–150` | Direct source markup | Replace with intent-based routes and editor-first composition |
| CM6 already exists | `cm-editor.js:createMarkdownEditor`; `sidepanel.js:initializeEditor` | Source code | Do not propose editor framework migration as default |
| Board = preserved legacy store | `db.js:STORE_NAMES` and `card-model.js:createMaincard/createMembership/createTypedEdge` | Source code | UI label Board; data stays maincards/memberships/cardEdges |
| Page capture and permission boundary | `service-worker.js:ensureContextMenus/CAPTURE_SELECTION/EXTRACT_TAB`; `sidepanel.js:grantCurrentSite` | Source code | Contextual Capture sheet and denied fallback, no new broad permissions |
| Sources have citations, scraps, DOI and attachments | `sidepanel.html:sourceList/scrapList/attachmentList/annotationList/literatureList`; `literature.js:resolveDoi` | Markup+source | One Evidence drawer and Library with distinct item types |
| Sessions and revisions independent | `db.js:browserSessions/sessionRevisions`; `browser-sessions.js:preview/restore`; `session-ui.js` | Source code | Separate Sessions route; preview never called a Board |
| Flat review views exist | `sidepanel.html:workspaceSpreadsheetView/workspaceCalendarView/workspaceFlowView/workspaceFlattenView` | Markup+source | Contextual Workspace destination, not permanent header actions |
| Theme is already established | `sidepanel.css:491–493`, `sidepanel.js:applyPaperfoldTheme` | Token/source evidence | Reuse Paper/Pure Black and System (`auto`) instead of inventing palette |
| Search is not neural | `embedding.js:EmbeddingRegistry/local-hash-v1` | Source code | Label local hash, no scientific relation claim |
| Discover/Query are not extension-wired | `prototypes/discover/lexical.js` and `prototypes/discover/query-ast.js`; docs/followup/05-DISCOVER-REPAIR.md | Source/docs corroborated | Gated Explore with disabled commit/external open |
| Full-tab app not implemented | `manifest.json:side_panel` and `action`; no full-tab entrypoint declared | Source absence limited to supplied ZIP | Full-tab is a W1 build proposal, not delivered runtime feature |
| No safe clean-profile restore witness | `docs/followup/01-EVIDENCE-AND-GATES.md` | Existing gate report | Keep production release BLOCKED regardless of W1 UX completion |

`FEATURE-RELOCATION.json` contains 111 individually anchored feature/status/destination entries, 105 current source features, three prototype features, two proposed-but-absent surfaces, and one blocked recovery capability. Absence of a feature in the index must be treated as a defect to W1's exit criteria and reopened with its source anchor.

## Actual execution and receipts

| Evidence | Command / test | Observed result | Warrant |
|---|---|---|---|
| Source verifier | `python tests/verify_source.py <source.zip> <SOURCE-MANIFEST.json>` | PASS / 76 of 76 | Original archive identity and content equality only |
| Wireframe syntax | `node --check WIREFRAMES/wireframe.js` | Exit 0 | JS parses as script |
| Chromium fixture suite | `python tests/test_w1_wireframe.py` | **57 PASS / 0 FAIL**, 17 screenshots, zero external requests | Navigable sample-data prototype with real layout engine; NOT installed extension |
| Static contract audit | `python tests/test_w1_contract.py` | **12 PASS / 0 FAIL** | Deliverable coverage/metadata/paths only |
| Screenshots | 17 `evidence/fixture-*.png` images covering key routes, widths and dialogs | Pixel captures from Chromium rendered source strings | Fixture appearance only, not side-panel extension witness |

Because the environment's Chromium policy blocked `file://` navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`, the test harness executed identical HTML/CSS/JS bytes using Playwright `set_content` + `add_style_tag` + `add_script_tag` on a synthetic document. Therefore: **BROWSER-TESTED FIXTURE** but **NOT BROWSER-TESTED EXTENSION**, and the test does not demonstrate a native Chrome side panel loaded as an extension.

The harness exercised routes by hash *and by actual narrow navigation clicks*, responsive container widths 280/320/360/420/600/800, Paper/Pure Black/System theme selection, modal Escape and focus return, Markdown citation at retained selection, Capture staging, Library filter, Board edge, query gating and Sessions preview. 200% content scaling was a CSS zoom approximation, not native browser zoom. Fixture screenshots do **not** verify all themes at every required width or actual icon contrast.

## Corrective Visual Pipeline record

1. **Evidence**: inspect current v0.8 HTML, JS, CSS, schema and manifest, not v0.7 historical recommendations.
2. **Specification**: 15 surfaces, Board/Card/Source/Session differentiation, 111 feature destinations, six concrete journeys.
3. **Composition**: render responsive writer-first fixture with source-accurate Paper/Black/System palette and gated advanced features.
4. **Preview**: Chromium screenshot at 280/320/420/600/800 and black 800; compare against no-horizontal-overflow, writing focus and negative-control criteria.
5. **Compare / diagnose**: early screenshot exposed redundant 'Evidence at hand' section **below** the editor at narrow width, recreating vertical overload. First palette version had non-source accent in black. Early citation inserted before closing the dialog, creating focus ambiguity; initial test selector counted hidden dialog rows.
6. **Correct**: remove contextual inspector below 1110px; use `sidepanel.css:491–493` token values; close modal before restoring editor focus/caret; scope Library selector to route. Fix test API invocation instead of dropping failing tests.
7. **Validate**: subsequent browser suite observed 57 PASS, zero FAIL, no network traffic; static contract suite observed 12 PASS.
8. **Handoff**: W4 to adjudicate after W1/W2/W3 comparison and challenge. **W1 does not choose canonical.**

## Controls designed to defeat plausible false passes

- **Capture**: empty text or `chrome://settings` URL is rejected; HTTP(S) manual fixture clip accepted, but never called real page extraction.
- **Board**: `from==to` test refuses meaningless self-edge; separate Cards allowed; Session Board association must not change memberships.
- **Search**: unmatched query returns an explicit empty state; only saved fixture items are in index, not unsaved live tabs.
- **Query / Discover**: query preview does not open a URL (zero observed requests), Discover `Accept` and external search stay disabled; shared words do not prove `supports`.
- **Recovery**: `Preview recovery` is allowed; fixture `Restore` stays disabled, rather than pretending to invoke Chrome tabs API.
- **Focus**: Escape closes native dialog and restores trigger focus; citation close returns focus to editor before inserting.
- **Data safety**: no changes to source ZIP, host Chrome profile, manifest permissions, `db.js` or sessions schema. ZIP checksum ≠ clean importer verification.

## Unknowns / open gates

Real Chrome extension load, populated IndexedDB v4→v5 migration, archive restore into clean Chrome profile, actual page-capture permission UX, real tab recovery, drag/drop group fidelity, screen reader semantics, all theme/font zoom combinations, DOI API responses, Drive/LAN credentials and sync, meaning of recent search rankings, and native modal/popover collision under page DOM remain **UNVERIFIED**. Do not mark production ready. Official reference-system URLs are in `W1-PROPOSAL.md`; Memex/AFFiNE official interaction verification remains an explicit evidence debt, not an invented comparison.

Reopen W1 upon a verified unmapped current feature, a failed narrow navigation path, a captured focus loss during citation insertion, a component with no defined responsive/theme/state contract, or source hash mismatch. W4 remains the authorized design decision maker.
