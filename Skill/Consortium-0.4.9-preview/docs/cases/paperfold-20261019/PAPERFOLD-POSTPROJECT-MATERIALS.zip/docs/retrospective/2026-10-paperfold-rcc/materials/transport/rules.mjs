import {assembleChunks} from './chunk-delivery.mjs';
export function canonicalEcho(value){return String(value||'').replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,(match,label,url)=>label===url?url:match).replace(/\\([*()[\]_#>~`])/g,'$1').replace(/\s/g,'');}
import {createHash} from 'node:crypto';
export const digest=s=>createHash('sha256').update(s).digest('hex');
export const normalize=s=>String(s||'').replace(/\s+/g,' ').trim();
export function bound(snapshot,prompt){return !!snapshot?.turnKey&&canonicalEcho(snapshot.userText).includes(canonicalEcho(prompt));}
export function finalWitness(samples,prompt,{minimumChars=400}={}){
 if(samples.length<3)return false;
 const s=samples.slice(-3),last=s.at(-1);
 return s.at(-1).at-s[0].at>=10000&&last.assistantText?.length>=minimumChars&&s.every(x=>bound(x,prompt)&&x.turnKey===last.turnKey&&x.assistantId===last.assistantId&&!!x.assistantId&&x.assistantText===last.assistantText&&x.turnState==='complete'&&x.regenerate&&!x.stop);
}
export function runnable(job,jobs){return job.status==='PENDING'&&job.dependencies.every(role=>jobs.find(j=>j.role===role)?.status==='WITNESSED');}
export function maySubmit(job,snapshot){return job.status==='SUBMITTING'&&snapshot.turnCount===(job.expectedPriorTurns??0)&&!snapshot.stop;}

export function parseDelivery(blocks){
 const chunked=assembleChunks(blocks);if(chunked)return parseDelivery([JSON.stringify(chunked)]);
 for(const raw of blocks||[]){
  let o;try{o=JSON.parse(raw.replace(/^json\s*/i,''));}catch{continue;}
  if(o.rcc_delivery!=='v1'||!Array.isArray(o.files)||!o.files.length)continue;
  let total=0;
  for(const f of o.files){
   if(typeof f.path!=='string'||!f.path||f.path.startsWith('/')||f.path.includes('\\')||f.path.includes(':')||f.path.split('/').some(s=>s==='..'||s==='.'||s==='.git'))throw Error('Unsafe delivery path');
   if(typeof f.content_base64!=='string'||!/^[A-Za-z0-9+/]*={0,2}$/.test(f.content_base64))throw Error('Invalid base64 payload');
   const b=Buffer.from(f.content_base64,'base64');total+=b.length;
   if(total>10*1024*1024||digest(b)!==f.sha256)throw Error('Delivery hash or size mismatch');
  }
  if(new Set(o.files.map(f=>f.path.toLowerCase())).size!==o.files.length)throw Error('Duplicate delivery path');
  return o;
 }
 return null;
}

