# W8 Build Report — Paperfold UI Reconstruction (Production Builder A)

**Case:** `PAPERFOLD-UI-20261016` · **Task:** `w8` · **Closure:** **PASS for W8's owned structural source patch only** · **Not integrated; not release-ready.**

## 1. Governing contract and provenance

Read/apply supplied AntiSlop router + engineering, RMC controller + stage machine + task-intent, and adapted Visual Pipeline. Source comes from the actual `source.zip` v0.8, SHA256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`. All **76/76** baseline manifest file hashes and byte lengths were verified. Git metadata was absent. Applied only W4 canonical Consortium I and W7 canonical Consortium II/ownership closures supplied within the dependency archive. W5/W6 were reviewed through their W7-adjudicated contracts; they are specifications, not production test evidence.

**W7 locked ownership:** `w8: ["sidepanel.html", "sidepanel.css"]`; `w9: ["sidepanel.js"]`. Exactly those two complete source files changed. Every other 74 extracted source file remained identical to the pinned source manifest, including the v0.8 application database and Chrome permissions. This ZIP contains **no unchanged source baseline**, no mock production source, and no W9 files. SHA-256 of each complete replacement is in `SOURCE-HASH-MANIFEST.json`; the before/after bytes and hashes are in `W8-EVIDENCE/source-integrity.json`.

No live profile was opened or edited. Experimental v0.8 Discover/Query Studio implementations were not moved into production. Naming remains **Board** in the UI and `maincards` in the original persistence API.

## 2. Source implementation

- `sidepanel.html`: writer-first shell, text-only Paperfold identity, one global Capture action reusing `#attachCurrentButton`, four compact destinations (Write/Boards/Library/More), six rail destinations at expanded widths (Write/Boards/Library/Find/Sessions/More), native More disclosure, eight `[data-pf-view]` routes, page-level headings/landmarks, preserved original editor/Board/Library/Session/search/utility nodes, eleven pre-existing dialogs marked `data-pf-modal`, and `data-pf-toast` live-region hook. The source retains **all 180 original IDs**, no duplicates.
- `sidepanel.css`: CSS-variable aliases resolving to original theme palette, editorial layout without decorative cards or logo, shell-owned vertical scrolling, compact bottom dock, >=700px labeled rail, >=1110px optional two-column Library (never forced into narrow layout), bounded native dialogs and More menu, 400px short-height fallback, 280–1110px size safeguards, reduced-motion branch and sampled icon/text contrast corrections. Original CodeMirror host, editor formatting overflow lane, preview and legacy style rules are retained.

Actual Board editing still uses existing `#maincardsDialog`; Session recovery still uses `#sessionsDialog`, and settings use `#settingsDialog`. This is intentional until W9/W10 prove safe in-place behavior. The W8 file pair does not implement JS route commands or a new persistence layer; W9 must bind the declared selectors. An unhandled route button in this isolated patch is not claimed to be a working integrated navigation function. See `W8-INTEGRATION-HANDSHAKE.md`.

## 3. Visual Pipeline: component-boundary checks

**Applied sequence for each boundary:** baseline evidence → W4/W7 specification → owner-only HTML/CSS implementation → real Chromium *static* preview → viewport/theme comparison → diagnostics → CSS correction → retest → handoff. Theme tokens: `--pf-bg/surface/text/muted/border-subtle/accent/focus/danger`, original palette; spacing 4/8/12/16/24/32; W7 motion 160ms open/120ms close/90ms feedback with reduced motion.

| Requirement / surface | State and interaction boundary | Size, theme, accessibility | Actual preview and acceptance |
|---|---|---|---|
| `W8-SHELL`, global header | Text-only identity; existing `#attachCurrentButton` remains single entry point. Runtime review/commit owned by W9 | Capture visible at 280px; meaningful focus ring; no logo | `write-320-paper.png`, `write-800-paper.png` — static PASS |
| `W8-NAV`, dock/rail/More | Eight exact routes; More is disclosure, not route; active `aria-current=page` hook; W9 controls changes | 4 destinations <700px; 6 destinations >=700px; menu flips at 400px | 42 menu bounds PASS after 6 initial failures corrected; W9 keyboard dismissal UNVERIFIED |
| `W8-WRITE`, editor/Card | Existing `#noteSelect`, `#noteTitle`, CodeMirror host, toolbar, read/write controls, `#saveStatus` and reminders | Writer stays one readable column; toolbar owns horizontal scroll; IME/undo need W9/W10 | `write-280-black.png`, `write-800-paper.png` — visual PASS; persistence UNVERIFIED |
| `W8-BOARDS`, research perspective | Existing `#maincardsButton` opens canonical `#maincardsDialog` with `#maincardSelect`/edges | No new Board schema, no implicit membership mutation | `boards-320-paper.png`; static IDs PASS, runtime Board updates UNVERIFIED |
| `W8-LIBRARY`, evidence collections | Current tab/capture tools, DOI, linked sources, scraps, attachments, annotations remain original ID-bound lists | One column narrow, optional two at 1110; text and URLs wrap; image aspect unchanged | `library-280-black.png`, `library-1110-paper.png` — static preview PASS; source linking UNVERIFIED |
| `W8-FIND`, retrieval | Reuses actual `#searchInput`, `#searchButton`, `#searchResults`; no fabricated results | Inputs compress without root overflow | `find-320-paper.png` — visual PASS; real indexed queries UNVERIFIED |
| `W8-SESSIONS`, recoverability | Existing `#sessionsOpenButton` and `#sessionStatus` reference full Session dialog | Separate from Board, recover dialog internally scrolls | 42 dialog bounds PASS; no live restore witness |
| `W8-GATES`, Explore/Query Studio | Informational review-only/preview-only regions, no invented active prototype commands | All 3 themes, narrow widths; no faux scientific relation acceptance | 336 view/viewport/theme states include gated routes; no runtime activation |
| `W8-SETTINGS`, utilities | Original setting, Cue, Workspace, export and AI transport triggers each kept once; Activity log intact | Buttons wrap; account and sync state remains inside original settings dialog | `settings-800-paper.png`; actual integration configuration UNVERIFIED |
| `W8-OVERLAY`, dialogs/toast | Existing 11 dialogs marked `data-pf-modal`; one live-region W9 hook; focus trap/opener/retry by W9 | `max-height: calc(100dvh - 32px)` with internal scroll; 400px witness | 42 viewport dialog probes PASS; focus/persistence UNVERIFIED |
| `W8-THEME`, light/dark/system | Pure Black, Paper and System preserve existing palette and visible nav/capture | 6 system preference/theme probes for inactive nav, heading, Capture | sampled text ≥4.5:1 PASS; this is **not** a full WCAG audit |

## 4. Observed tests and exact evidence category

1. **Source identity:** source ZIP SHA-256 and 76 manifest entries checked; ownership diff exactly `sidepanel.html` and `sidepanel.css`. `W8-EVIDENCE/source-integrity.json`: **PASS (byte evidence)**.
2. **W8 static contract:** `W8-TESTS/test_w8_static.py` executed with the original source archive: **23/23 PASS**, including all 180 IDs, no duplicate capture/Board trigger, exact routes, retained scripts/dialogs and two intentionally failing-mutation negative controls. `W8-EVIDENCE/static-receipt.json`: **STATIC_CHECKED**, not app behavior.
3. **Visual DOM/CSS preview:** Chromium headless with actual delivered HTML/CSS, but **JS modules explicitly excluded and view activation artificially injected by the test**: **336/336** page×width×height×theme cases PASS (7 widths, 2 heights, 3 themes, 8 views); **42/42** compact/wide nav checks; **42/42** native More menu bounds; **42/42** native dialog bounds; 40 actual Chromium screenshot previews. `W8-EVIDENCE/visual-receipt.json`: **CHROMIUM_STATIC_PREVIEW_ONLY**.
4. **Text contrast probe:** computed pixel colors in real Chromium (not screenshot-only assertion) for Paper, Black, and System across light/dark OS preference: **6/6 PASS**, nav inactive text / heading / Capture samples >= 4.5:1. `W8-EVIDENCE/contrast-receipt.json`: **sample probes only**, not comprehensive accessibility.
5. **Existing baseline module regressions:** ran five source-preserved Node suites: `v05-modules.mjs`, `v06-modules.mjs`, `v07-literature.mjs`, `v08-discover-prototype.mjs`, `v08-sessions.mjs`: **5/5 exited 0**. Their passes do not certify the new UI or Chrome permissions. `W8-EVIDENCE/baseline-regression-receipt.json`.
6. **Production Chrome probe:** attempted disposable-profile headless Chromium extension load. The service-worker event was **not observed before the 14s timeout**, so test infrastructure/extension startup was **BLOCKED**, and runtime behavior remains **UNVERIFIED**. No extension screenshot, functional editor persistence result or browser E2E PASS is asserted. `W8-EVIDENCE/runtime-receipt.json`.
7. **Packaged-script replay:** portable static, contrast and preview scripts were rerun from the *patch-only artifact directory*, against the original source archive; **all three PASS** with stdout in `W8-EVIDENCE/package-retest-*.txt`. These scripts require Python, BeautifulSoup, Playwright, and Chromium; the static ID test also requires the original source archive, intentionally not repackaged.

## 5. Diagnostics, negative controls and repairs

- **CONFIRMED fixture layout failure:** 6 of 42 initial More menu previews extended beyond the screen at **800/1110 × 400**; corrected via a short-height expanded-rail flip. All 42 bounds checks then PASS. This is rendered CSS evidence, not an event-routing test.
- **CONFIRMED sampled contrast failure:** System-dark inherited light-blue accent with white Capture text: **2.35:1**. CSS changed to use dark foreground in System/auto dark for primary non-nav controls; retested Capture **7.91:1**. Pure Black inactive navigation also gained a more specific theme selector; screenshot visually verified. Actual native zoom and all icon/disabled/read-only states require W10 tests.
- **Negative control:** synthetic removal of legacy `noteEditorHost` causes preservation condition to fail; removing a required route causes exact route check to fail. W8 retained both, checked against baseline.
- **Safety negative control:** no new interactive buttons in experimental Explore/Query views, no anonymous fake search results, no optimistic save success, no library selection data mutations, no schema/permissions changes, no unowned sources. The baseline `#saveStatus` says “Saved locally” before runtime initialization, as it did before; W9 must enforce pending/ACK/error semantics.
- **Missing extension service worker is an environment/runtime-access blocker**, not proof of a product bug or a successful W8 interaction. No Chrome runtime screenshot was fabricated.

## 6. Reference systems (verified official material, constrained use)

Retrieved current first-party docs for concrete *patterns only*: [Notion sidebar help](https://www.notion.com/en-gb/help/navigate-with-the-sidebar) supports labeled top-level destinations; [Karakeep query language](https://docs.karakeep.app/using-karakeep/search-query-language/) describes explicit typed filtering semantics and cautions against inventing filters beyond actual backend; [Obsidian Web Clipper capture help](https://obsidian.md/help/web-clipper/capture) distinguishes user-initiated capture, extracted content and saved output. None establishes empirical Paperfold usability or approves a new datastore. The W4 architecture, not these references, is authoritative.

## 7. Reproduction, merge and open gates

Extract the supplied original `source.zip` to a **fresh isolated directory**, verify its whole-archive SHA256, and copy **only** this patch's `sidepanel.html` and `sidepanel.css` over their exact matching relative paths. Combine with W9's exact `sidepanel.js` only at W10. Do not replace a daily profile, merge a different source version, or install this isolated W8 patch as a finished application.

To reproduce from this patch folder:

```sh
W8_SOURCE_ZIP=path/to/your/source.zip python W8-TESTS/test_w8_static.py
W8_CHROMIUM=path/to/chromium python W8-TESTS/test_w8_visual.py
W8_CHROMIUM=path/to/chromium python W8-TESTS/test_w8_contrast.py
```

If Playwright has a browser installed, `W8_CHROMIUM` may be omitted. Retest output is placed in `W8-RETEST-EVIDENCE/`; original signed screenshots/receipts are unchanged. The extension smoke test requires separately extracting a complete source tree and setting `W8_EXTENSION_SOURCE`; it was attempted but could not establish runtime startup here.

**W10 must verify** route switching/More dismissal and focus restoration, actual CM6 selection/IME/undo/save ACK + reload, Board membership, Library capture staged confirmation/cancel, Sessions preview/recovery, popup reposition on resize, alerts/permission denial, actual native 100/150/200% browser zoom, 280/320/360/420/600/800/1110 sizes with real data, both heights, all three themes, keyboard-only modal operation, independent persisted backups and production safety gates. Do not infer these from fixture screenshots.

**Scope status:** `IMPLEMENTED`, `STATIC_CHECKED`, `CHROMIUM_PREVIEWED`; module baseline `UNIT-TESTED`. **Not** `BROWSER-TESTED` for application behavior, **not** `INTEGRATED`, **not** `RELEASE-READY`.

**Reopen condition:** W9/W10 finds a required route/handler without a working DOM hook; any lost baseline ID, critical root horizontal overflow, focus/caret defect attributable to W8 DOM/CSS, unbounded modal/popover at contract sizes, a recorded data/permission regression, or an approved contract revision requiring source changes outside W8's locked file ownership. Reopen W7 for ownership changes rather than silently editing W9 or the data stack.
