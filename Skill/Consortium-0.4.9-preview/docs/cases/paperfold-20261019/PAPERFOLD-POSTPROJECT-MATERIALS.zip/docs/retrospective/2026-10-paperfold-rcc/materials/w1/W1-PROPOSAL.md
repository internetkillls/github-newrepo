# W1 — Editorial / Writing-Centered Paperfold Architecture

**CASE:** PAPERFOLD-UI-20261016 · **Worker:** W1 · **Independence:** I2 BLIND  
**Source ZIP SHA-256:** `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`  
**Design status:** PROPOSAL, not canonical, not production implementation. No rival closure or proposal inspected.  
**Primary output:** `WIREFRAMES/index.html` — locally openable, interactive navigable *fixture* with 15 surface registrations, not the extension.

## 1. Decision in one sentence

**Make the current Markdown Card the stable center of activity; treat Board as a persistent research context, Sources as attachable evidence, Library as a cross-object shelf, Sessions as restorable browser state, and advanced review/backup as context-specific destinations rather than permanent header buttons.**

The central failure in current source is *composition*: `sidepanel.html` puts a seven-control global header, note selector, Sessions card, editor, Organize, Current tab, Literature, Linked tabs, Scraps, Attachments, Annotations, Reminders, Search and Log into a vertical sequence. Users must scroll across competing categories to edit and cite. The editor is already CodeMirror 6 (`cm-editor.js`); replacing the editor engine is not justified by this UX problem. Board is correctly backed by `maincards`, `memberships`, `cardEdges` (`db.js`); do not rename stores. Current v0.8 only has `side_panel.default_path` and an action opener (`manifest.json`), not an implemented full-tab route. Expanded workspace below is a **proposed new entrypoint**, not a current fact.

## 2. Navigation topology and user-facing labels

```text
Paperfold [text-only]            [Capture] [More]
│
├── WRITE (landing; remembered active Card)
│    ├── Card picker / recent Cards / New Card
│    ├── Board breadcrumb + switch/join Board
│    ├── Editable title, Markdown/Reading tabs, contextual format toolbar
│    ├── Source drawer: Linked Sources | Clips | Annotations | DOI | Attachments
│    ├── Details drawer: YAML, capture policy, thinking cues, reminders
│    └── Overflow: delete Card, export Card, view Activity, AI transport
├── BOARDS (all Boards → Board detail)
│    ├── Perspective / overview, constituent Cards, Add or reuse Card
│    ├── Typed edges with deliberate classification (never inferred truth)
│    └── Flatten export / Board settings (with confirmation on deletion)
├── LIBRARY (all saved research objects; NOT tab history)
│    ├── Saved Sources & Chrome bookmarks
│    ├── Captures / Markdown scraps / manual attachments
│    ├── Literature / DOI references, annotations
│    └── Linked Card and Board context + filters
├── SEARCH (global explicit retrieval)
│    ├── Text search / results / kind chips / Board scope / source
│    ├── Local hash similarity marked 'local hash', not semantic ML
│    └── Provider search selected text (external browser user gesture)
├── SESSIONS (browser recovery separately owned)
│    ├── Saved Sessions / groups / tab inventory
│    ├── Revision history / associate Board (no moving records)
│    └── Recovery preview → confirm open missing HTTP(S) tabs in new window
├── EXPLORE (gated research lab, not automatic activity)
│    ├── Discover: source-attributed neutral suggestions — UNAVAILABLE until integrated/gated
│    └── Query Studio: preview/validate query AST — PROTOTYPE ONLY, external send on gesture
├── WORKSPACE VIEWS (via Board / Library overflow, not root tab)
│    └── Spreadsheet | Calendar | Provenance Flow | Flatten / export
├── COMMANDS (global palette, also ` / `, ` @ ` and `[[` in editor)
│    └── Templates, cue sets, search, navigation, attachments, sync etc.
└── SETTINGS / SUPPORT (More → Settings)
     ├── Appearance: Paper / Pure Black / System, editor font zoom
     ├── Writing: capture policy, thinking cues, cue editor
     ├── Capture/search: provider editor, permission explanation
     ├── Data/backup: Markdown, Workspace, `.wv.tar.gz`, folder
     ├── Integrations: Google Drive OAuth/backup, local/LAN sync (token)
     └── Privacy/technical: storage, activity logging, limitations, keyboard

Chrome context menu (outside shell)
└── Capture selection/annotate | Attach page | Scrape page | Add file |
    Open Boards | Open palette | Search selected text with configured provider

Contextual page popover (separate proposed projection)
└── Selected text / current page → Clip | Annotate | Attach to Card;
    permission-gated, no auto-scraping on hover
```

**Navigation density rule.** At ≤699 CSS px, bottom 4-way navigation `Write | Boards | Library | More`; `More` is a reachable route list for Search, Sessions, Explore, Workspace, Settings. At ≥700 CSS px, persistent labeled rail; no squeezed multi-pane desktop layout. Context actions are always accessible from source/editor inline actions and a single overflow. The shell never depends on screen aspect ratio.

## 3. Explicit 15-surface matrix

| ID | Mission surface | Proposed entry/representation | Contract and failure state |
|---|---|---|---|
| S01 | Navigation / shell | Text-only Paperfold, one Capture action, rail or bottom nav + More | Exact same route IDs in panel/full tab; restore same Card selection on switch |
| S02 | Markdown Card editor | Write > Card; title then continuous CM6 page; contextual toolbar; Live/Reading | Save only after persistence confirmation; undo/selection survive side-panel resize |
| S03 | Boards | Boards > Board detail; inline membership and typed edges | Store stays `maincards`; Card may belong to several Boards; no cascade delete |
| S04 | Library/bookmarks/Sources/captures | Library > segmented object filter and contextual details | Bookmarks not silently converted; saved objects ≠ live tabs |
| S05 | Search/filtering | Search route; contextual search opens same route scoped | No claim that v0.8 searches Sessions/bookmarks globally; source scopes shown |
| S06 | Discover | Explore > Discover, visibly gated | Prototype lexical neutral `related-to`, no automatic edge creation |
| S07 | Query Studio | Explore > Query Studio, visibly gated | AST URL preview only; no external request until user gesture/authorized integration |
| S08 | Browser Sessions | Sessions > history > preview restore | Preview is non-mutating; missing HTTP(S) tabs only, new window confirmation |
| S09 | Annotation/citations | Write > Sources drawer > Annotation or Library > annotations | Quote + locator + citation insert at selection, permission errors visible |
| S10 | Quick Capture/context menu | Global Capture + native right-click | Context menu remains in service worker, selection is explicit and permission-gated |
| S11 | Contextual Paperfold popover | After real page selection/capture, anchored actions; compact sheet fallback | Proposed, not implemented; pointer and keyboard, never changes original page state without user act |
| S12 | Settings/integrations | More > Settings grouped tabs with statuses | No invented account; Google Drive is optional connection, LAN sync is explicit |
| S13 | Empty/loading/success/error/permission | Every route has per-surface status line; deliberate retry | Save-error keeps editing state; never show success without domain acknowledgment |
| S14 | Expanded full-tab | New proposed full-tab entrypoint using same routes with optional evidence pane | Do not imply current manifest implements it; no separate state store |
| S15 | Narrow Chrome Side Panel | 280–600 CSS px single pane, bottom nav, drawers as route sheets | No horizontal root overflow, dropdown/offscreen clipping or hover-only action |

## 4. Journeys and functional wireframes

**J1 · Write with source context (primary):** Open Write → select/create Card → optional Board breadcrumb switch (Board membership is NOT Card identity) → edit CM6 Markdown → save state transitions `dirty → saving → persisted` or `error` → Sources action opens drawer rather than navigating away → filter linked Sources/annotations/scraps/DOI → select annotation → Insert citation at memorized editor selection → return focus/caret. Capturing a page opens a staged preview before attaching; denied permission shows `Enable page text` action. The demo implements only fixture text insertion, not actual Chrome capture/persistence.

**J2 · Build a research Board:** Boards → select Board → update perspective (stored Board body) → find/create/reuse Card → classify membership role → optionally add typed edge via explicit from/type/to/label → review card excerpt/evidence → Flatten or Flow; never assign a semantic edge merely from Discover similarity. Deleting a Board must confirm what remains unaffected; user-visible Board means legacy `maincards` compatibility.

**J3 · Capture while browsing:** Chrome selection context menu or Capture → choose Clip + annotation / attach tab / scrape to paired Markdown / manual attachment → permission request only for the relevant operation → inspect title, URL, selection/metadata → choose target Card and review → commit → success message with `Open Card`. If restricted `chrome://` page or denied optional host, retain selection in a safe fallback with explicit no-capture explanation; no invisible broken action.

**J4 · Recover Session:** Sessions → choose saved Session and revision → Preview recovery (no write) → inspect missing count, already-open/skipped, and group fidelity limits → confirm Restore missing tabs to *new* window → visible result/error. Session ↔ Board association remains metadata only. Never substitute 'restore' for verified archive import.

**J5 · Retrieve research:** Search → query with text / object type / Board chip → result rows explicitly label Card/Source/annotation/scrap/bookmark → open in detail / insert URL/citation into active Card. Basic v0.8 source vectors are `local-hash-v1`: avoid describing them as neural. Full unified search remains a planned wiring task, not a source-observed implementation.

**J6 · Inspect lab features responsibly:** Explore → Discover neutral suggestions with contributing saved-document IDs, safety limitations, and `Review` (disabled in demo); Query Studio preview provider URL and warning that opening transmits terms. Prototype-only view does not create relationships, send requests or modify database. Distinguish available source pieces from accepted functionality.

**J7 · Context and settings:** More → Workspace views (Spreadsheet, Calendar, Flow, Flatten), AI transport, export, reminders, cue editor, Search Providers, Drive, LAN sync; intrusive operations are context-specific, not repeated in the header. Saving tokens or external sync must show explicit status and never auto-act from a mere navigation event.

The wireframes contain real navigable click states and fixture write/source insertion to exercise topology. Neither fixture success nor screenshot constitutes tested extension behavior.

## 5. Responsive & content rules

| Container width | Structural rule | Writing/editor constraint | Source and context |
|---|---|---|---|
| 280px | Single column, 4-label bottom dock, More route | Header text + Capture fit on one row, 100% editor; toolbar scrolls inside its own region, not page | Sources opens full-height in-app sheet with close/back |
| 320px | Same, no fixed side columns | Title wraps; Save line remains visible; menus fit viewport | Source rows min-width 0, URLs wrap |
| 360px | Single column | Optional second toolbar item visible; no clipped primary CTA | Bottom navigation labels remain readable |
| 420px | Single column with wider measure | Live/Reading and selected Board visible | Detail sheet; no desktop miniaturization |
| 600px | Single column; optional in-view two-column *content list* only | Editor optimum line length capped ~74ch | Source list may display inline on wider full-tab only |
| 800px | Labeled 180–208px rail, main min-width 0 | Editorial column max-width ~760px | Source inspector is overlay or optional right column only ≥1100px |
| ≥1100px | Rail + content; optional resizable source inspector | Editor retains 62–78ch reading measure | Inspector width min 280px, may collapse without changing route |

At height 400px, keep one scroll owner in main and persist visible navigation; at 200% browser zoom recalc *CSS pixel* layout, do not detect physical display size. No arbitrary `aspect-ratio` on shell. Keep media natural sizing (`max-width:100%; height:auto; object-fit:contain`). Avoid source preview stealing editor selection. Prefer route-level sheets to modal stacks on a 280px panel.

## 6. Writing interactions, menus and settings

* Toolbar shown above CM6 only when editing: 5 initial actions `H1`, Bold, Italic, List, Link, then `Format ▾` with H2, numbered/check, quote, code, math, wikilink. Avoid 11 equally-weighted buttons by default. Every format command must preserve selection and focus; `Ctrl/Cmd+B`, `Ctrl/Cmd+I` remain usable.
* Inline typing `/`, `@`, `[[` keeps source `cm-editor.js` completion contract, with a *shared action registry* proposed for consistency; don't duplicate service-worker dispatch in visual components.
* Live/Reading are **modes of one Card**, not additional pages. Reading is not an editing state; switching back must preserve last caret/scroll position. Display persistence status as text `Saving…`, `Saved locally`, `Couldn't save` (retry), never a merely optimistic checkmark.
* Card overflow holds New, Duplicate (proposed only if implemented), Delete, export Markdown, Activity log, AI transport. Destructive actions require confirmation and explicit type/target. Board overflow holds Add/reuse Card, typed edge, flatten export, change perspective. Global More holds Sessions, Search, Explore, Workspace, Settings, Backups. Context menus prefer text labels, no icon-only labelling.
* Settings grouped `Appearance`, `Writing & capture`, `Search & commands`, `Data & backup`, `Integrations`, `Advanced & privacy`. Include current `keepLog`, `embeddingProvider`, `editorZoom`, `paperfoldTheme`, `cueLibrary`, `searchProviders`, `exportDestination`, local sync config, Drive config in the *same persistent owners*. Do not invent a user account, neural toggle, Discover enable setting, default automations or cross-device sync.
* Global capture opens scoped sheet; native right-click remains the most contextual capture. A contextual on-page popover is **future UI contract** and must be permission-scoped, nonblocking, keyboard reachable, and must not auto-inject into arbitrary pages.

### Canonical component boundary proposal (not implementation ownership)

| Component | Requirement | Source/owner bridge | State | Visual pipeline evidence needed |
|---|---|---|---|---|
| `AppShell` | S01/S14/S15 | `sidepanel.html/.css/.js`, proposed full-tab HTML | `mode, route, activeCardId`, nav menu open | Render 280/320/360/420/600/800px; theme and zoom screenshots |
| `CardComposer` | S02 | `cm-editor.js`, `sidepanel.js`, `db.js:notes` | `draft, saving, persisted, error`, cursor | Real CM6 edit→reload→undo in Chrome, not demo textarea |
| `BoardContext` | S03 | `card-model.js`, `db.js:maincards/memberships/cardEdges` | board, role, classification, edge | Multi-Board membership persists; no cascade deletion |
| `EvidenceDrawer` | S04/S09 | `sidepanel.js` annotation/source/attachment/literature, `provenance.js` | kind, item, selection, permission | Reopen quote + insert citation into restored cursor |
| `CaptureSheet` | S10/S11 | service worker context menu + `CAPTURE_SELECTION`, `EXTRACT_TAB` | staged, permission, commit, error | Denied/allowed near-miss; focus return; no fake success |
| `LibraryIndex` | S04/S05 | `db.js`, `sidepanel.js`, `workspace.js` | filter, collection, result | Type filters and source privacy distinguish saved from live |
| `SessionsView` | S08 | `browser-sessions.js`, `session-ui.js` | selected revision, preview, restore | Preview no tabs created, restore explicit new window |
| `ExploreGate` | S06/S07 | `prototypes/discover/*` only | gated, preview | No production route that calls prototype without acceptance gates |
| `SettingsSections` | S12 | `sidepanel.js`, `service-worker.js`, `sync.js` | dirty/persisted/error integration-specific | Verify no data/schema/permission changes from navigation |
| `StateFeedback` | S13 | status/error chain per domain | idle, loading, empty, success, warning, error, denied | Screen-reader live announcement and accessible recovery action |

Use existing tokens `--bg, --surface, --surface-2, --text, --muted, --border, --accent, --accent-soft, --danger, --shadow, --mark` from v0.8; the demo uses their actual shipped values. Stop decorating every group with a border or shadow. Global line separators reserved for structural transitions; interaction focus states may still use a visible outline. In Pure Black/System, icon contrast must be verified at runtime and image assets must not be blanket-inverted.

## 7. Design challenge / alternatives / measurable claims

**Strongest rival to writing-first:** A collection-first architecture reduces the path from saved web research to retrieval and may be objectively faster for users who primarily clip, classify and search. This proposal deliberately makes Library top-level and links it to the writer, but does not promise that the writing center wins. **Second rival:** browser-context-first popover could minimize switching while browsing, but cannot safely own the entire dense editor, recoverable Sessions and batch review. Never force broad extension host permissions to enable this rival.

**Rejected for this proposal:** (a) seven-action persistent header — high visual noise and poor width scaling; (b) separate root page for each subfeature — duplicates location and fractures context; (c) replacing CodeMirror with Milkdown/Tiptap during a layout repair — substantial Markdown/selection regression surface without a measured failing editor primitive; (d) always-on triple-pane at 320/420px — clips editor; (e) one generic 'Knowledge' entity — loses Board/Card/Source/Session boundaries; (f) enabling Discover automatically — conflates lexical overlap with fact; (g) introducing account login to group Drive and LAN integration — no supported account model.

| Claim to falsify | Proposed measurement, with exact fail condition |
|---|---|
| C1: Writer-first lowers time-to-write | With 12 representative existing users, paired tasks (baseline vs candidate) and counterbalanced order; median time from panel open to typing meaningful first character must decrease ≥20% without increasing correction rate. Otherwise reject claim. |
| C2: Evidence insertion does not break focus | 20 runs across each width; insert annotation at existing CM6 cursor, compare resulting Markdown and cursor; any silent insertion into wrong Card / missing citation is a fail. |
| C3: Navigation is findable, even at 280px | 10 unfamiliar participants, locate Session restore / provider settings / Board edge / literature within 45 s with ≥8 successes each; hidden route is a fail. |
| C4: Side Panel remains usable | Screenshot + keyboard/browser assertions at 280/320/360/420/600/800 px, 100/200% zoom and three themes; any root horizontal scroll, clipped Save/More, overlapping menus fails. |
| C5: Library is not sacrificed | Capture→find→open saved Source in ≤3 intentional navigation steps and retrieve citation in ≤4; if worse than tested baseline, revisit prominence. |
| C6: Recovery truthfulness | Preview must not create tabs; restore must require confirmation and open only eligible missing HTTP(S), with explicit skipped count; any mutation before confirm fails. |
| C7: No accidental outbound query | Network probe in Query Studio; zero provider requests until affirmative external-open action. Any implicit outbound request fails. |
| C8: Recognizable features without ornamental UI | Independently label search, Sessions, Board and Settings; ≥8/10 first-click placement successes; icon-only guessing rates trigger revision. |

Numbers are **acceptance targets**, not measured outcomes. The bundled test receipt reports only actual fixture-level tests.

## 8. Visual Pipeline record, negative controls, risk register

**Evidence**: verified 76 v0.8 source files (not a v0.7 extrapolation); source anchors listed in `EVIDENCE-AND-TESTS.md`. **Specification**: S01–S15 table + journeys + feature relocation. **Composition**: responsive HTML/CSS/JS fixture preserving Paper/Pure Black/System tokens and object distinctions. **Preview**: automated screenshots only if browser executable successfully renders fixture; screenshots are labeled fixture. **Compare**: check against task / invariants and baseline structure (not a made-up approval mockup). **Diagnose**: root overdraw, missing focus semantics, route leakage, prototype truthfulness. **Correct**: recorded corrections in receipts when made. **Validate**: feature destination, routes, overflow and keyboard probes in available browser. **Handoff**: this proposal to W4; W4 adjudicates, no canonical claim by W1.

**AntiSlop applied at boundaries:** Source-vs-feature status and Chrome-vs-demo checks; nav complexity audit; discover/prototype gate; permission-denied and negative-control assertions; browser screenshot not conflated with actual extension. **RMC design route applied:** task-intent/S0 → source-supported scope/S1–S3 → distinguish and compare alternative architectures/S4 → falsifiable probes/S5 → official reference-source verification/S6 → integrate/S7 → scoped exit check/S8 → artifact/S9. No private reasoning or unseen workers implied.

**Near-miss controls to preserve in successor tests:** Saved bookmark may appear in Library, but unapproved currently open tab must not; Board association may appear in Session, but must not move Card; 'related-to' lexical suggestion must not create `supports`; editor fixture `Saved` must not be mistaken for IndexedDB acknowledgement; screenshot of a responsive fixture must not certify real Chrome Side Panel; a verified ZIP/sha256 cannot certify archive restore. All are covered by contract and some by fixture tests, **not** by live-data tests.

**Open debt:** extension full-tab entrypoint, unified library indices and action registry need production design/build; rendering in real Chrome/Windows, populated migration/restore, actual context-menu page permissions, external DOI, accessible screen-reader interpretation and persisted editor focus remain unverified. No source files were edited. Production safety gate remains BLOCKED independently from design quality.

## 9. Official reference-system evidence (borrow selectively)

- Notion [sidebar guidance](https://www.notion.com/help/navigate-with-the-sidebar): group documents/navigation by user intent; *reject infinite nested sidebar depth in a 280px panel*. Source verified during W1 research.
- Obsidian [Web Clipper capture](https://obsidian.md/help/web-clipper/capture) and [templates](https://obsidian.md/help/web-clipper/templates): selected page/selection → inspect content/metadata → user saves; *do not copy an Obsidian vault model into Paperfold's IndexedDB*.
- Karakeep [bookmark types](https://docs.karakeep.app/using-karakeep/bookmarking/) and [search query language](https://docs.karakeep.app/using-karakeep/search-query-language/): type-aware saved-item retrieval, not treating every object as a Markdown note; *do not infer Paperfold has Karakeep AI or indexing features*.
- Tiptap [focus command](https://tiptap.dev/docs/editor/api/commands/selection/focus) and [custom menus](https://tiptap.dev/docs/editor/getting-started/style-editor/custom-menus): protect editor focus when format controls are activated; *do not migrate the already vendored CM6 editor without behavior evidence*.
- Milkdown [getting started](https://milkdown.dev/docs/guide/getting-started): viable Markdown-WYSIWYG alternative but with migration cost; reference for writing controls, **not** a proposal to install it.
- Memex and AFFiNE: no authoritative official interaction page adequately verified in this W1 source search. They remain requested comparators with access/evidence debt, not invented product claims.

## 10. W1 scoped exit test

W1 exit is met **only if**: 76/76 source+manifest matches, exactly 15 surfaces assigned, every source-discovered current feature mapped, full-tab and ≤280px navigation both shown, locally navigable wireframe controls work on fixtures, design tokens/theme states are defined, and a test receipt + negative control demonstrates scope. Passing W1 says **DESIGNED + WIREFRAME-TESTED**, never IMPLEMENTED, BUILT, BROWSER-TESTED EXTENSION, INTEGRATED, or RELEASE-READY. W4 may reject this proposal after blind challenge and empirical tests. Reopen if source inventory is incomplete, any existing feature has no destination, a verified nontrivial workflow cannot be reached at 280px, or the proposed layout loses selected Markdown caret/evidence relationship in actual browser acceptance.
