import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';
import {dirname,join} from 'node:path';import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const base=dirname(fileURLToPath(import.meta.url));
const old=JSON.parse(readFileSync(join(base,'interview-state.json'),'utf8'));
const vendor='C:/Users/joshu/.codex/plugins/cache/created-by-me-remote/reasoning-consortium-controller/0.4.6-preview/runtime/chatgpt-pro-line/src/';
const {listTargets,CdpSession,evaluate,sleep}=await import(pathToFileURL(vendor+'cdp-client.mjs'));
const {pageProbe}=await import(pathToFileURL(vendor+'chatgpt-page.mjs'));
const {inputPrompt,submitPrompt}=await import(pathToFileURL(vendor+'chatgpt-composer.mjs'));
const {readChatGptChoices}=await import(pathToFileURL(vendor+'chatgpt-choices.mjs'));
const {acquireChatGptOperation}=await import(pathToFileURL(vendor+'chatgpt-operation.mjs'));
const {canonicalEcho,finalWitness,bound}=await import('../automation/rules.mjs');
const digest=v=>createHash('sha256').update(v).digest('hex');
const onlyW9=process.argv.includes('--w9');
const jobs=(onlyW9?['w9']:['w7','w9']).map(role=>({...old.jobs.find(j=>j.role===role),samples:[]}));
const state={schema:'paperfold.unsent-interview-recovery.v1',pid:process.pid,originalStateReadOnly:true,jobs};
const save=()=>writeFileSync(join(base,onlyW9?'w9-recovery-state.json':'retry-state.json'),JSON.stringify(state,null,2));
function event(j,status,detail={}){j.status=status;appendFileSync(join(base,onlyW9?'w9-recovery-events.jsonl':'retry-events.jsonl'),JSON.stringify({at:new Date().toISOString(),role:j.role,status,...detail})+'\n');save();console.log(j.role+' '+status);}
async function snapshot(j){
 await evaluate(j.c,`(()=>{for(const t of document.querySelectorAll('[data-turn-key]'))for(const b of t.querySelectorAll('button'))if(b.innerText.trim()==='Show more')b.click()})()`);
 return evaluate(j.c,`(()=>{const norm=${canonicalEcho.toString()};const turn=[...document.querySelectorAll('[data-turn-key]')].findLast(t=>{const h=[...t.querySelectorAll('h4')].find(e=>e.innerText==='You said:');return h&&norm(h.parentElement.innerText).includes(norm(${JSON.stringify(j.prompt)}))});const h=turn&&[...turn.querySelectorAll('h4')].find(e=>e.innerText==='You said:');const units=turn?[...turn.querySelectorAll('[data-conversation-role="assistant"]')].map(e=>e.closest('[data-chatgpt-search-message-ids]')).filter((e,i,a)=>e&&a.indexOf(e)===i):[];return {at:Date.now(),url:location.href,turnKey:turn?.getAttribute('data-turn-key'),userText:h?.parentElement.innerText||'',assistantId:units.map(a=>a.getAttribute('data-chatgpt-search-message-ids')).join(' | '),assistantText:units.map(a=>a.innerText).join(' [ASSISTANT SEGMENT] '),turnState:turn?.querySelector('[data-talvt-turn-state]')?.getAttribute('data-talvt-turn-state'),regenerate:!!turn?.querySelector('button[aria-label="Regenerate response"]'),stop:!!document.querySelector('button[aria-label="Stop"]')}})()`);
}
try{
 const events=readFileSync(join(base,'interview-events.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
 for(const j of jobs){
  if(j.status!=='BLOCKED'||events.some(e=>e.role===j.role&&e.status==='SEND_UNCERTAIN'))throw Error('Not proven unsent: '+j.role);
  const t=(await listTargets(9222)).find(t=>t.id===j.targetId&&t.url.split('?')[0]===j.url);if(!t)throw Error('Room mismatch');
  Object.defineProperty(j,'c',{value:await CdpSession.open(t.webSocketDebuggerUrl),enumerable:false});
  let op,clicked=false;
  try{
   op=await acquireChatGptOperation({name:'paperfold-unsent-interview-recovery',alias:'rcc-postproject-'+j.role,requiresBrowser:true,lockTimeoutMs:10000});
   await j.c.send('Page.bringToFront');let s=await snapshot(j);let page=await pageProbe(j.c);
   if(!page.composer&&/Could not load this ChatGPT conversation/.test(page.bodyText)){
    event(j,'READ_ONLY_RELOAD',{reason:'Known conversation history load failed; no submission occurred'});
    await j.c.send('Page.reload',{ignoreCache:false});
    for(let i=0;i<25;i++){await sleep(1000);try{page=await pageProbe(j.c);if(page.composer)break;}catch{}}
    s=await snapshot(j);
   }
   if(s.turnKey||s.stop||!page.composer||page.isLoggedOut)throw Error('Existing prompt, active generation or unavailable composer');
   const draft=await evaluate(j.c,`(()=>{const e=document.querySelector('#prompt-textarea')||document.querySelector('[contenteditable="true"][role="textbox"]')||document.querySelector('textarea');return e?.innerText||e?.value||''})()`);if(draft.trim())throw Error('Draft preserved');
   // Count all generation controls, not only this recovery's jobs.
   let active=0;for(const target of (await listTargets(9222)).filter(t=>t.type==='page'&&t.url.startsWith('https://chatgpt.com/c/'))){const c=await CdpSession.open(target.webSocketDebuggerUrl);active+=await evaluate(c,`Number(!!document.querySelector('button[aria-label="Stop"]'))`);await c.close();}
   if(active>=3)throw Error('Active cap already reached');
   j.preSendEvidence={at:new Date().toISOString(),tokenAbsent:true,emptyDraft:true,idle:true,otherActive:active,priorEventsProveNoSend:true};
   j.choiceReadback=await readChatGptChoices(j.c,{includeModelOptions:false});event(j,'TARGET_READY');
   await inputPrompt(j.c,page.composer,j.prompt);event(j,'COMPOSER_FILLED');event(j,'SEND_UNCERTAIN');clicked=true;
   try{await submitPrompt(j.c,{composer:page.composer,initialUserCount:page.userTurns.length,attempts:1});}catch(e){j.submitAdapterError=e.message;}
   const after=await snapshot(j);if(!bound(after,j.prompt))throw Error('Exact echo absent; never resend');j.samples=[after];event(j,'OBSERVING',{turnKey:after.turnKey});
  }catch(e){event(j,clicked?'UNCERTAIN':'BLOCKED',{reason:e.message});}finally{if(op)await op.release();}
 }
 const deadline=Date.now()+15*60*1000;
 while(Date.now()<deadline&&jobs.some(j=>j.status==='OBSERVING')){
  for(const j of jobs.filter(j=>j.status==='OBSERVING')){const s=await snapshot(j);j.samples.push(s);j.samples=j.samples.slice(-3);if(finalWitness(j.samples,j.prompt)){j.responseSha256=digest(s.assistantText);writeFileSync(join(base,'interviews',j.role+'-response.md'),s.assistantText);writeFileSync(join(base,'interviews',j.role+'-completion.json'),JSON.stringify({role:j.role,promptSha256:j.sha256,responseSha256:j.responseSha256,url:j.url,targetId:j.targetId,choiceReadback:j.choiceReadback,preSendEvidence:j.preSendEvidence,samples:j.samples},null,2));event(j,'WITNESSED');}}
  await sleep(6000);
 }
 state.status=jobs.every(j=>j.status==='WITNESSED')?'RECOVERED_WITHOUT_RESEND':'PARTIAL';save();
}finally{for(const j of jobs)if(j.c)await j.c.close();}
