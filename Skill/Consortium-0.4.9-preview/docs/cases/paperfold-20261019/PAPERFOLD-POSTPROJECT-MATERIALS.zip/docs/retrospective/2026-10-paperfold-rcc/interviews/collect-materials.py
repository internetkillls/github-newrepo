"""Copy scoped documentary evidence, never browser profiles or mutable runner state."""
import hashlib, json, pathlib, shutil, subprocess, zipfile
RUN=pathlib.Path(r'D:\Dev\.engineering\rcc\paperfold-ui-20261016')
REPO=pathlib.Path(r'D:\Dev\repos\paperfold')
OUT=REPO/'docs/retrospective/2026-10-paperfold-rcc'
OUT.mkdir(parents=True, exist_ok=True)
records=[]
def copy(src, rel, kind):
    src=pathlib.Path(src)
    if not src.is_file(): return
    dest=OUT/rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    data=src.read_bytes();dest.write_bytes(data)
    records.append(dict(path=dest.relative_to(OUT).as_posix(),source=str(src),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),kind=kind))
archives=[];seen=set()
for f in sorted((RUN/'automation/artifacts').rglob('*.zip')):
    data=f.read_bytes();digest=hashlib.sha256(data).hexdigest()
    if digest in seen:continue
    seen.add(digest)
    if not zipfile.is_zipfile(f):continue
    with zipfile.ZipFile(f) as z:
        if z.testzip() is not None:raise ValueError('CRC failure '+str(f))
        count=len(z.infolist())
    role=f.relative_to(RUN/'automation/artifacts').parts[0]
    rel=pathlib.Path('archives')/role/f.name
    copy(f,rel,'historical-worker-archive')
    archives.append({'role':role,'path':rel.as_posix(),'bytes':len(data),'sha256':digest,'entries':count,'scope':'Historical delivered bytes; CRC checked, not a runtime/release PASS'})
copy(RUN/'evidence/source.zip','archives/immutable-source.zip','immutable-source-baseline')
(OUT/'ARCHIVE-INDEX.json').write_text(json.dumps({'scope':'All unique valid worker ZIPs retained under automation/artifacts; not unavailable files remaining only in remote worker sandboxes. Original wireframes/images retained when present in those ZIPs.','files':archives},indent=2)+'\n',encoding='utf-8')
s=json.loads((RUN/'automation/state.json').read_text(encoding='utf-8'))
for j in s['jobs']:
    role=j['role']
    for f in (RUN/'automation/artifacts'/role/'validated').rglob('*'):
        if f.is_file() and f.suffix.lower() in {'.md','.json','.csv','.svg','.txt'} and f.stat().st_size<1024*1024:
            copy(f, pathlib.Path('materials')/role/f.relative_to(RUN/'automation/artifacts'/role/'validated'),'delivered-document')
    # Original reports retain the historical scope; skip later Base64 transport replies.
    f=RUN/'automation/artifacts'/f'{role}-original-closure.md'
    if f.is_file() and f.stat().st_size<20000:copy(f,pathlib.Path('materials')/role/'ORIGINAL-RESPONSE.md','historical-worker-response')
    prompt=RUN/'automation'/f'{role}-packet.md'
    if prompt.is_file():copy(prompt,pathlib.Path('materials/prompts')/prompt.name,'historical-prompt')
for name in ['MISSION.md','SOURCE-MANIFEST.json','TEN-WORKER-BINDINGS.json','UI-ADAPTATION.md']:
    copy(RUN/'evidence'/name,pathlib.Path('materials/orchestration')/name,'original-input')
for name in ['README.md','FINAL-DELIVERY-RECEIPT.json','REPO-APPLICATION-LATEST.json']:
    copy(RUN/name,pathlib.Path('materials/orchestration')/name,'host-record')
for name in ['rules.mjs','handoff-gates.mjs','series-delivery.mjs','transfer-manifest.mjs','chunk-delivery.mjs','test-chunks.mjs','test-transfer-manifest.mjs','test-gates.mjs']:
    copy(RUN/'automation'/name,pathlib.Path('materials/transport')/name,'case-runner-source')
for name in ['run-host-regressions.mjs','native-smoke.mjs','native-data-journeys.mjs','native-visual-panel.mjs','verify-native-contrast.mjs','native-archive-recovery.mjs','native-composition.mjs','native-session-recovery.mjs']:
    copy(RUN/'host-review'/name,pathlib.Path('materials/host-tests')/name,'historical-host-harness')
application=json.loads((RUN/'REPO-APPLICATION-LATEST.json').read_text(encoding='utf-8'))
# Exact known application epoch, retained independently from candidate evidence.
for name in ['APPLICATION-PLAN.json','APPLICATION-RECEIPT.json','verification/regressions.json','native-evidence/native-smoke.json']:
    copy(RUN/'repo-application/20261019T023228Z'/name,pathlib.Path('materials/repo-application')/name,'actual-repository-verification')
events=[json.loads(x) for x in (RUN/'automation/events.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
overview={'schema':'paperfold.retrospective-source-snapshot.v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'originalStateSha256':hashlib.sha256((RUN/'automation/state.json').read_bytes()).hexdigest(),'originalEventsSha256':hashlib.sha256((RUN/'automation/events.jsonl').read_bytes()).hexdigest(),'plannedTasksDeclared':s['taskCount'],'actualJobRecords':len(s['jobs']),'workerRoles':s['workerRoles'],'eventRecords':len(events),'firstEvent':events[0]['at'],'lastEvent':events[-1]['at'],'eventsByStatus':dict(__import__('collections').Counter(e['status'] for e in events)),'jobs':[{k:j.get(k) for k in ['role','workerRole','case','status','dependencies','conversationUrl','uiModel','uiEffort','responseSha256','witnessPath','promptSha256']} for j in s['jobs']]}
(OUT/'materials/orchestration/SOURCE-SNAPSHOT.json').write_text(json.dumps(overview,indent=2)+'\n',encoding='utf-8')
# Readable documents from W10's exact recovered source archive, independently verified previously.
for f in (RUN/'host-review/delivered').rglob('*'):
    if f.is_file() and f.suffix.lower() in {'.md','.json'} and f.stat().st_size<1024*1024:
        copy(f,pathlib.Path('materials/w10-delivered')/f.relative_to(RUN/'host-review/delivered'),'recovered-delivery-document')
(OUT/'MATERIALS-MANIFEST.json').write_text(json.dumps({'schema':'paperfold.retrospective-materials.v1','scope':'Documentary files selected by collect-materials.py; original full ZIPs and raw UI/byte-slice evidence remain at source paths. Not a complete account conversation export.','files':records},indent=2)+'\n',encoding='utf-8')
cold=[]
for root in [RUN/'automation/artifacts',RUN/'automation/evidence',RUN/'evidence',RUN/'host-review/delivered']:
    for f in root.rglob('*'):
        if f.is_file():
            b=f.read_bytes();cold.append({'path':f.relative_to(RUN).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
for f in [RUN/'automation/events.jsonl',RUN/'automation/state.json',RUN/'host-review/PAPERFOLD-W10-REVERIFY-SOURCE-TRANSFER.zip']:
    if f.is_file():
        b=f.read_bytes();cold.append({'path':f.relative_to(RUN).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(OUT/'COLD-ARTIFACTS-MANIFEST.json').write_text(json.dumps({'runRoot':str(RUN),'scope':'Full inventory of these evidence roots, including original ZIPs, code, images and transfer envelopes. Local retention only; browser profile directories are excluded.','files':cold},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'documents':len(records),'bytes':sum(x['bytes'] for x in records),'out':str(OUT)}))
