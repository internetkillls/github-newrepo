# W9 repair — Source-owned interaction closure

**Case:** `PAPERFOLD-UI-20261016` · **Task:** `w9-repair` · **Result:** CODE_WRITTEN / STATIC_CHECKED / COMBINED-FIXTURE OBSERVED; **owned closure BLOCKED** on real IndexedDB proof. **Stage III release remains BLOCKED.**

## Intake and immutable jurisdiction (RMC S0–S2)

User-authorized goal: repair *only* W9 `sidepanel.js` against already delivered W8-repair `sidepanel.html`/`sidepanel.css`, retaining W4 architecture and W7 ownership, preserving W10’s narrow mechanical fixes. Source archive SHA-256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`; all 76 `SOURCE-MANIFEST.json` entries independently byte checked. W7 canonical source ownership W8=`sidepanel.html, sidepanel.css`; W9=`sidepanel.js`; intersection empty. W8-repair delivered HTML and CSS byte hashes also checked. Original W9 prior patch used as direct starting bytes, not v0.7. No Git metadata. No W8, schema, permissions, user data or Chrome daily profile modified. Only owned production path in transfer is `sidepanel.js` SHA-256 `e0a46369bafa660e1828e59f7564065d83d8beca929e6fd6cb684f4d1db1adef`.

## Evidence → specification → patch → preview → compare → correct → validate (RMC S3–S9)

- **Failure observed in W10 and W8 reports:** `attachCurrentButton` bound directly to `attachTab(..., "manual")`, bypassing mandatory approval; context popover existed only in adapter fixture before W8 repair; W8 CSS hid routes lacking `data-pf-active`.
- **Source-level correction:** line 429 replaces the direct-commit binding with `bindCaptureReview`; the controller near line 3559 fail-closes disabled initial Capture until handlers exist. Opening review reads active tab, checks HTTP(S), existing host permission and stable tab identity; preview metadata is assigned with `textContent`. No pre-confirm source/link write.
- **Commit:** line 3623 synchronously latches pending, disables confirm/cancel, revalidates active tab, permission and Card; only explicitly confirmed `attachTab(..., reviewedCapture:true)` writes. The source/link branch near line 1314 uses a single **existing-schema** IndexedDB transaction on `sources` and `links`, acknowledging success only after `transaction.oncomplete`. A rejected/aborted transaction cannot half-write those two records. Postcommit logs/UI refresh errors do not redefine the two-store ACK as failure or erase drafts. No automatic uncertain retry.
- **Popup action boundary:** real W8 `#pfSourceContextTrigger` → `#pfSourceContextPopover` uses existing W9 `togglePopover`/`handlePopoverKeydown` at line 3711. Provides anchored geometry, first-item focus, Up/Down/Home/End, Escape focus restoration, outside-click dismissal, and Find/Boards/Write navigation only. Opening a blocking dialog dismisses transient popovers; no source/Board mutation on menu use.
- **W10 corrections preserved explicitly:** `activateRoute` line 3412 now writes `node.dataset.pfActive=String(active)` alongside `hidden`/`aria-hidden`, repairing the W8 CSS route handshake; native `details.pf-more` closes on route navigation, document Escape, or outside click (Escape handler line 989). These are mechanical state reconciliations, not new navigation.
- **Bootstrap safeguard:** W9 top-level `PF_ROUTES` / `PF_FOCUS` and Capture state constants initialized before the `await initialize()` invocation; avoids temporal-dead-zone access during boot. Original role/contract unaffected.

## Actual test receipts and negative controls

1. `node --check sidepanel.js` **PASS**. `node tests/w9-interactions.mjs` **PASS**; all seven prior baseline Node suites **PASS**; baseline Python v0.7 server security **PASS**, each executed on the merged isolated baseline + W8-repair HTML/CSS + W9-repair JS.
2. `python TESTS/test_w9_repair_static.py --w8-dir <W8_REPAIR_DIR>` **PASS**: markup hook, source ownership seam, disabled Capture, no legacy direct write, atomic branch, route/More invariants, early constants and text-only metadata.
3. `python TESTS/test_w9_repair_browser.py --w8-dir <W8_REPAIR_DIR>` **PASS** using actual full W8 HTML+CSS and full W9 JS (app initialization omitted; chrome/storage stubs). Viewports: 280×400 Paper, 320×700 Black, 420×400 System, 800×700 Paper. Confirmed visible routes, menu bounds, arrow/Home/End, Escape/focus return, outside dismissal, real menu route actions, native More dismissal, modal cancellation and source metadata HTML-injection resistance, reduced-motion CSS. Negative checks: precommit Cancel/Escape have zero `sources`/`links` writes; denied host permission and stale tab have zero writes; simulated failed transaction has zero writes and never announces success; duplicate confirm yields one link; repeated capture does not duplicate it; success waits simulated storage ACK. Test transactions are **simulated** because Chromium's opaque origin cannot access real IndexedDB.
4. **Unexecuted mandatory independent native evidence:** Chromium blocks file:// and localhost navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`; synthetic-route HTTPS navigation is blocked too; opaque-origin `set_content` denies IndexedDB. No installed Chrome extension, service worker, true IndexedDB transaction, CM6 editing/IME/undo, permission prompt, populated backup/restore, native zoom/assistive technology or true Side Panel screenshot was observed. Do **not** infer native/data/release PASS from the above.

## Adapted visual pipeline, per component boundary

| Boundary | Spec / preview and comparison | Actual scope / result |
|---|---|---|
| Global Capture (W8 modal → W9 controller → DB) | Initially disabled, preview read-only, pending/error/saved states, native Escape/cancel/focus | Controlled full-W8 Chromium fixture; mocked ACK and failure **PASS**; **real IndexedDB BLOCKED** |
| Contextual Source menu (W8 trigger/menu → W9 route) | Semantic role=menu, first item, Arrow/Home/End, Escape/outside, viewport clamp | Real W8 HTML/CSS+W9 adapter at 280–800px **PASS fixture**, no native Side Panel |
| Routes (W8 CSS → W9 activateRoute) | `aria-current`, `hidden`, `data-pf-active`, focus, scroll state | 4 combined fixtures **PASS**, native history/restore unknown |
| Native More (W8 details → W9 event adapter) | dismiss on navigation/Escape/outside | Combined fixture **PASS** |
| Editor & Save (W4 CM6 → W9 ACK) | Draft retained, success after ACK, duplicate suppression | Existing W9 VM **PASS**; real editing/IDB **UNVERIFIED** |
| Theme/motion (W8 CSS → W9 settings) | Paper/Black/System and `prefers-reduced-motion` | Combined fixture **PASS** in sampled modes; native zoom/AT unknown |

## AntiSlop negative control and release boundary

Avoided positive claims from implementation text, source-only screenshots, console output or fixture save simulation. Rejected direct Capture listener, silently granting site permission, implicit Board writes, schema changes, unowned markup edits and custom dialog replacement. Transaction ACK is the source of truth for a persisted global Capture; no success toast before it. Reopen **W9 owned gate** when W10 can demonstrate genuine installed disposable-profile Chrome Side Panel with seeded real IndexedDB source+link transaction, cancellation, denial, aborted transaction, save-reload, and keyboard/CM6 behavior on the exact W8/W9 merged bytes. W10 must continue Stage III release/data/permission gates independently. No deployment authorized.

## Artifact contents

`sidepanel.js`, `SOURCE-HASH-MANIFEST.json`, `W9-REPAIR-REPORT.md`, `TEST-RECEIPTS.json`, `TESTS/test_w9_repair_static.py`, `TESTS/test_w9_repair_browser.py`, `TESTS/w9-interactions.mjs`, `DIFF/sidepanel.js.diff`. The portable patch excludes W8 production markup/CSS, unchanged baseline and screenshots; the Chromium test expects an explicit `--w8-dir` pointing to delivered W8-repair source files.
