# Paperfold UI reconstruction — orchestration receipt

Scope: the user's full reconstruction brief is preserved in `evidence/MISSION.md`.

There are exactly ten role-owned Chrome rooms, bound through the selected RCC 0.4.3-preview release. Three additional debate tasks reuse W1–W3 rooms, making thirteen tasks, not thirteen workers. The baseline is the actual v0.8 folder archived in `evidence/source.zip`, with per-file SHA256 in `evidence/SOURCE-MANIFEST.json`. No Git metadata was present.

The independent local Node process runs `automation/orchestrator.mjs`. It uses RCC's CDP/composer/upload/choice/operation-lock adapters and a case-specific scheduler. This is a custom case runner, not the RCC deferred Stop-hook service. No service, scheduled job, hidden approval bypass, or Codex auto-resume was installed. The user-authorized active-generation limit is 3. Browser uploads/submissions remain serialized under the RCC operation lock. Independent eligible workers may generate concurrently; full C1 validation is not claimed.

Sequence: W1, W2, W3 blind proposals → three challenge tasks in their original rooms → W4 architecture adjudication → W5 and W6 interaction proposals → W7 contracts and exact disjoint source ownership → W8 and W9 isolated builds → W10 integration and verification. No later stage starts before its required closures and artifact gates pass.

Every packet includes actual AntiSlop/RMC instructions and the UI-adapted Visual Pipeline in `worker-methods.zip`. Source and prompt hashes are pinned. Actual model/effort readbacks, attachment receipts, prompt echoes, response anchors, final controls, artifacts, and structural gate receipts are recorded separately. A completed browser response is not a canonical architecture or passing application test.

The runner requires three consistent anchored terminal observations across at least ten seconds. It stops uncertain submissions without resending. Missing artifacts, declared failed gates, source identity mismatch, ownership overlap, invalid Windows/archive paths, or failed dependency gates block progression. Canonical decisions remain the named adjudicator's responsibility; structural checks do not independently certify the semantics of their assertions.

Live state: `automation/state.json`; event history: `automation/events.jsonl`; process errors: `automation/stderr.log`; worker outputs: `automation/artifacts/`; witness and artifact-gate receipts: `automation/evidence/`; ten room bindings: `evidence/TEN-WORKER-BINDINGS.json`.

Final source delivery is restricted to an isolated candidate. Production installation remains blocked by the original populated-migration, restoration and real-Chrome recovery gates. Browser workers operate in their remote sandboxes; they cannot claim access to this host's extension runtime. Unavailable real-Chrome tests must stay UNVERIFIED and may block final acceptance.

Local verification: `node automation/test-gates.mjs` exercises positive and negative handoff/source/stage/ownership/path/completion/no-resend cases. Syntax checks passed. These tests certify scheduler guards only, not the reconstructed UI.

