# W3 deliverable — how to inspect

1. Open `W3-PROPOSAL.md` for the design hypothesis, navigable wireframes, source-grounded decisions, references and falsifiers.
2. Open `WIREFRAMES/index.html` in a browser that permits local HTML files. It is an offline **fixture prototype** with illustrative records only. The page has no Chrome extension APIs, stores, network requests or real file writes. For inspection in a sandbox where local `file://` is blocked, the Python test runner embeds HTML/CSS/JS using Playwright `set_content`.
3. Use the five contextual destinations, switch Board, edit Markdown fixture, capture in memory, inspect Sources and Sessions, open More → Review, Settings, Discover and Query. Labels distinguish actual source features from gated source prototypes.
4. `FEATURE-RELOCATION-MAP.md` accounts for 52 current feature groups and two missing/new surfaces without implying production wiring.
5. `COMPONENT-AND-RESPONSIVE-CONTRACT.md` is the 15-surface component boundary and Stage II implementation handoff.
6. Run `node tests/test-wireframe-static.mjs`, `node --check WIREFRAMES/wireframe.js`, `python tests/test_wireframe.py` from this bundle folder. Python requires Playwright and an installed headless Chromium executable available on PATH, or a bundled Playwright Chromium browser (all project paths are relative). If unavailable, mark visual runtime tests UNVERIFIED rather than claiming PASS.
7. `receipts/` contains isolated-browser screenshot and machine-readable test results. Do not confuse fixtures with extension screenshots.

Identity: `source.zip` SHA-256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`. Baseline was never modified. No Git metadata was in the supplied source. No peer proposals used.

Scope PASS can mean the W3 wireframe deliverable is complete and tested; it does NOT mean the official Paperfold v0.8 extension was edited, installed, integrated or safe for deployment.
