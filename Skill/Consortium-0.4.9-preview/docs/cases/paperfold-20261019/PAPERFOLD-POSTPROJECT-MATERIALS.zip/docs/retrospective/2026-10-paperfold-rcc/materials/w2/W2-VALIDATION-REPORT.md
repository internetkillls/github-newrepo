# W2 validation and closure evidence

## Identity / access

- Supplied `source.zip` archive SHA-256: `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10` — **observed matching** on both uploads (same archive bytes).
- Pinned per-file manifest: **76/76 matched**, zero omissions/extras/mismatches. `SOURCE-AUDIT-RECEIPT.json` records the machine-readable result.
- Worker methods: read the provided `AntiSlop/router.md`, `AntiSlop/engineering.md`, `RMC/controller.md`, `RMC/stage-machine.md`, `RMC/task-intent.md`, and `UI-ADAPTATION.md`; only rule application and test evidence, not external plugin execution, is asserted.
- Independence: **I2 BLIND**; no W1/W3 candidate or parent closure inspected; no dependency closures were supplied. No Git metadata; source copied to an isolated extracted folder, originals untouched.

## Observed tests

1. Existing baseline suite: `node tests/v05-modules.mjs`, `v06-modules.mjs`, `v07-literature.mjs`, `v08-sessions.mjs`, `v08-discover-prototype.mjs`, `v08-discover-adversarial.mjs`, and `python tests/v07-server-security.py` — all **exit 0**, see `BASELINE-TEST-RECEIPTS.json`. The Discover suite reports 17/17 cases. These are *pre-existing functional/unit suites*, not browser verification.
2. `node --check WIREFRAMES/prototype.js` — exit 0 (syntax only).
3. `python TESTS/verify_source.py <original-source-zip> <wrapped-source-manifest>` — exit 0; source archive and 76 individual entries hashed.
4. `python TESTS/verify_wireframe.py` — **95 PASS, 0 FAIL**. Real Chromium rendering and DOM interaction via Playwright `page.set_content()` with full inlined local HTML/CSS/JS; no URL navigation, network, Chrome profile or IndexedDB. Assertions: route rendering and no root overflow for seven primary routes at 280/320/360/420/600/800; mobile bottom navigation visibility; source/annotation preview, filter, search empty state, keyboard Escape/focus return, capture denied vs allowed fixture addition, read-only session preview, gated Discover, query preview, theme sampling, 200% root-text scaling and dialogue containment. `TEST-RECEIPTS.json` has exact check outcomes.
5. 26 screenshots from that in-memory fixture render exist under `PREVIEWS/`. They are **real screenshot evidence of the constructed wireframe**, not evidence of the installed Chrome extension or original v0.8 UI.

## Visual Pipeline review and correction example

Evidence: original v0.8 CSS defined `html { min-width:280px }` and a densely nested monolithic column. Specification: W2 provides a single-pane mode at 280px with persistent bottom navigation. Composition: collection list and source-detail route in independent HTML. Preview: Chromium at 280px showed the multi-line demo banner pushing the bottom navigation off-screen. Compare/diagnose: subtraction of a fixed 28px ribbon height did not reflect actual 2-line banner height; this was a responsive slop failure despite root horizontal overflow passing. Correct: switch `body` to column flex with `.shell{flex:1;min-height:0}`; keep banner intrinsic. Validate: `mobile-navigation-visible/280,320,360,420,600` and all route overflow checks PASS. A default keyboard-programmatic focus outline was separately removed from `main` only; interactive controls retain `:focus-visible` outlines. Handoff: W4 may reuse layout logic, but W6 must independently test it against real Chrome viewport and zoom.

## Specific AntiSlop checks with negative controls

- Scope/provenance: v0.8 source and 19 stores inspected, not v0.7 claims. Feature-mapping F01–F48 gives status and destination, separated from absence/debt.
- UI causality: a “Capture” success claim is forbidden in the demo; negative control simulates denied permission, disables fixture commit, and verifies record count unchanged. Positive control adds **fixture only**, labeled no persistence.
- Product/research: Discover accept button is disabled; Query URL preview explicitly states no external open. Negative control `filetype:csv` in DuckDuckGo is source-prototype test, not a UI promise.
- Recovery: Session `Restore` disabled despite positive fixture preview. No browser operations attempted.
- Layout: 280px full-tab compression would be invalid; collection-list → back-to-list transition, 200% font-scale screenshot, no root overflow, actual bottom-navigation bounding box measured. No hard-coded application aspect ratio.
- Theme: Paper/Pure Black/System custom-property presence sampled in Chromium; **contrast-ratio, dark system emulation and user screen-reader automation are outstanding**.
- Architectural: no new DB stores, OAuth scope, host permission, remote calls or untested build entry points.

## Unverified and blocked

**Not verified:** actual installed Chrome Side Panel, real full-tab launch, runtime navigation on extension URL, 100–200% *browser zoom* (as distinct from in-memory 200% root-font-size simulation), keyboard IME, screen reader, contrast measurement, focus preservation during CodeMirror active selection, actual capture/DOM/TextQuote restoration, live DOI APIs, Drive OAuth, LAN sync, archive restore, populated DB migration, recovery after real crash, Discover corpus precision, production deployment.

Local browser `file://` and loopback navigation returned `net::ERR_BLOCKED_BY_ADMINISTRATOR`; `page.set_content()` in a blank Chromium page succeeded without navigation and enabled honest fixture-only visual witnesses. This is a bounded workaround, **not permission to claim the blocked real-Chrome tests passed**.

## Owned W2 gate

The required W2 output is an independent complete research-collection architecture, reachable offline wireframes, navigation and all 15 surfaces, inventory of existing features, menu/settings placement, Side Panel and full-tab strategy, tradeoffs and falsifiable hypotheses, with reproducible tests and debt. This bounded owned artifact gate **passes**. It does NOT imply selection by W4, implementation by W8/W9, product safety, or release readiness.

**Reopen if:** W4 identifies one v0.8 feature missing from F01–F48, an owned user journey without a reachable wireframe entry, or a measured 280px active control that is inaccessible without a keyboard alternative. The next independent test should be a real unpacked-extension Chrome Side Panel run with a disposable profile and populated fixture database after safety authorization.
