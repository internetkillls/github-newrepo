# W3 independent proposal — Paperfold contextual knowledge architecture

**CASE:** PAPERFOLD-UI-20261016 · `TASK:w3` · `WORKER:W3` · `I2 BLIND`  
**Snapshot:** Supplied **v0.8.0 staging prototype**, `source.zip` SHA-256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`. Manifest names 76 paths; each extracted byte hash matched. Git metadata is absent. No peer designer proposals or upstream closures were inspected.  
**Status:** `DESIGNED + WIREFRAME-BROWSER-TESTED`. Not extension-implemented, not Chrome-extension-tested, not production-safe. This is a **competing, independent Stage I design candidate**, not a canonical selection.

## A. Governing problem and design hypothesis

The current `sidepanel.html` puts Note selector, Session status, Markdown editor, organization, current tab, literature, linked tabs, scraps, attachments, annotations, reminders, vector search and activity log sequentially in one scroll with another long set of modal surfaces. The header adds Cue, note export, Workspace, AI transport, archive export, Board and Settings buttons (`sidepanel.html:10–22`). This is not merely too much ornament: it forces a researcher to lose **which Board/Card/source/selection is currently governing the next action** while scrolling between implementation-era sections.

**W3's hypothesis:** Paperfold should feel like *one research context with a continuous transition between browsing, capturing, writing and retrieving*, rather than a collection of mini-apps or an AI dashboard. The main navigational unit is the **working context**, typically a Board + active Card + current/linked Source. Sessions are explicitly *separate recoverable browsing contexts*. Neither Board membership nor session recovery implies content ownership.

**Minimal navigation**: Context | Write | Library | Find | Sessions. Context, Write, Library and Find are primary research activity modes; Sessions is the separately protected browser-activity mode. Capture is a persistent contextual action; Settings and derived Review/Discover/Query utilities are under **More** or a well-labeled secondary context. There is no generic Home dashboard, Inbox duplication, assistant-generated stream, activity carousel, nor overloaded global toolbar. The bottom five compact destinations are a means for narrow Chrome widths, not five heavyweight desktop pages.

## B. Information architecture and state continuity

```text
Paperfold [text] — [Current Board ▼] [Capture] [More]
│
├── CONTEXT  /board/:boardId    one Board's governing question, Cards, current browsing
│      ├── Board overview & members
│      ├── Board details (Markdown, perspective, relations, roles)
│      ├── Current page  → Capture / Annotate / Attach
│      └── Review (advanced) → Spreadsheet / Calendar / Flow / Flatten
├── WRITE    /card/:cardId     Markdown Card in Board context
│      ├── Compose ↔ Reading; CM6 toolbar / slash commands / cue insertion
│      ├── Source inspector → linked tabs, scraps, files, annotations, DOI
│      ├── Captures and citations at the caret
│      └── Card options (new, export, delete with confirmation)
├── LIBRARY  /library?kind=…   local objects, *distinguished* by type
│      ├── Cards / Sources / Captures / Bookmarks / Literature / Files
│      └── object detail → open in correct mode (no entity rebinding)
├── FIND     /find             local vector search with type-specific filters
│      ├── saved Card/Source results → inspect / use
│      ├── Discover (GATED: isolated lexical code only)
│      └── Query Studio (GATED: isolated provider AST only)
├── SESSIONS /sessions         separate browsing-time state + revisions
│      ├── list → revision → read-only recovery preview
│      └── explicit restore confirmation (production service only)
└── MORE (contextual action group)
       ├── Settings: Appearance, Capture, Search, Cues, Data, Integrations
       ├── Review (when there is a workspace projection)
       └── command palette (search actions / destinations)
```

**The context trail** is not a breadcrumb that binds objects into a false hierarchy: `Board / Current mode`, with active Card and Source held as independent IDs. UI navigation state is ephemeral; domain associations remain in `memberships`, `links`, typed edges and `browserSessions.boardIds`. A Card may belong to several Boards. Opening Card from a Board does not migrate it; opening a Source from Library does not automatically attach it. Selecting a Session never restores tabs as a side effect.

**Shared command vocabulary, proposed for Stage II:** `context.board.select`, `card.open/new/edit/save/preview`, `capture.selection/page/link`, `source.inspect/link/unlink/insertCitation`, `library.filter`, `search.local`, `session.select/preview/restore`, `workspace.project/export`, `settings.open`, `cue.insert`. W7 must define real command IDs/adapters by reconciling with existing source handlers; these names are **design contracts**, not shipped APIs. A command must carry `{eligibleContext, requiredPermission, input, pending, acknowledgedSuccess, error, cancellation, undo/fallback, accessibleLabel}`; the view must not own a second copy of domain data.

## C. Navigable functional wireframes

Open `WIREFRAMES/index.html` (local HTML fixture; no build, dependency or permissions required where local navigation is allowed). The real wireframe has separate `wireframe.css` and `wireframe.js`. The browser verification runner instead inlines these resources into a sandboxed document because local file navigation was denied by this test host. Fixture content is explicitly labeled, and no network, Chrome API, IndexedDB or persistent storage call exists. Files are intentionally **not** a replacement build of Paperfold.

### 1. Compact Chrome Side Panel — 320px, capture before editing

```text
┌──────────────────────────────┐
│ Paperfold      W3 FIXTURE    │  text brand, no decorative logo
│ [Board: Critical R... ▼]     │  Board context persists
│ [Capture]             [···] │
├──────────────────────────────┤
│ ← Board / Context   Commands │
│ ACTIVE BOARD                 │
│ Critical Realism             │
│ Governing question           │
│ [Write a Card] [Add tab]     │
│ In this context             │
│ • Card A                  Edit│
│ • Card B                  Edit│
│ Current browsing            │
│ • Current page         Capture│
│ • Session status       Review │
├──────────────────────────────┤
│Context Write Library Find Sess│  visible at normal 320px; scrollable at extreme zoom
└──────────────────────────────┘
```

Tap Capture → choose *Clip selection*, *Scrape to Markdown*, or *Attach tab*, with destination Board/Card and optional comment. A grant-needed state is a real stop condition; restricted URLs offer manual text/link fallback. Capture completion should return a source/capture link and clear result, not disappear into a global toast alone.

### 2. Compact Card composing — 280–420px

```text
Paperfold [Board ▼] [Capture] [···]
← Board / Write               Commands
[All Cards] [+ New] [Options] [Source]
Explanatory critique — working note
Unsaved / Saving / Saved / Error (only acknowledged)
[Bold] [Italic] [Heading] [List] [Quote] [More]
┌─────────────────────────────────┐
│ # Explanatory critique          │
│ claim, citation, Markdown...    │
│                                 │
└─────────────────────────────────┘
[Reading]  / @ [[ command guidance
Linked evidence
• Source, DOI, citation      [Insert]
• Annotation + text quote    [Open]
• Scraps, file attachments   [Browse]
```

The Markdown editor owns the vertical space and remains a single column. No permanent second inspector at 320px, no large modal for formatting, no header packed with export, AI and backup buttons. Source insertion restores cursor/selection and preserves CM6 undo. The wireframe proves only in-memory draft continuity across its own navigation, not real CM6 retention or save acknowledgement.

### 3. Contextual capture/annotation and command popup

```text
[Capture this page]        [X]
Mode:  (Selection / Page / Link)
To:    Board [Critical Realism ▼]
       Card  [Current Card ▼] (actual build)
Note:   Why is this source relevant?
[Cancel]           [Save capture]
```

Annotation is separate from raw capture: quote with source/anchor provenance + research comment + optional citation token. If clipping is denied, the dialog explains the denied permission and non-destructive fallback. Context popup is a proposal for future qualified page integrations, not an assertion that a custom injected popover already exists. Chrome's existing native context-menu entry remains functional and must not be replaced before a security/scripting audit (`service-worker.js:199–249`).

### 4. Library and retrieval

```text
Library
[All][Cards][Sources][Captures][Bookmarks][Literature][Files]
Filter: [title, provenance, kind ...]
• Explanatory critique           Card  [Edit]
• Scientific Realism ...         Source [Inspect]
• Current page selection         Capture [Inspect]
• Research link                  Bookmark [Open]
• DOI reference                  Literature [Cite]
• Paired Markdown and original   Files [Review]
```

One list with type filters and a shared search affordance (not a duplicate knowledge store) is more robust than exposing linked tabs, scrap, attachment, DOI and bookmark panels simultaneously. Type-specific controls remain available on detail. The active Board can narrow retrieval, but `all Boards` must be reachable; one Card may appear on several Boards without duplicate data.

### 5. Sessions (not a browser tab manager dashboard)

```text
Sessions → choose saved context
Session name / ACTIVE or RECOVERY_NEEDED / revision
Associated Board (reference only)
[Capture state] [Refresh] [Preview recovery]
Preview: missing HTTP(S), already-open, unsupported URLs
[Restore missing tabs…] only after revalidated preview + consent
```

Wireframe Restore remains disabled; there is no Chrome context to inspect. In the real source, Session operations use `PF_SESSION_*` messaging in `session-ui.js`. Restore cannot close existing tabs, clone already-open URLs or claim restored form/cookie state. Section placement must not imply session tabs are Board-owned Cards.

### 6. Wide full-tab layout (future entry point)

At 800px: text brand/header + 180px left navigation + one elastic content lane. At 1200px: add a **conditional** 258px right inspector with Board question, active Card and linked evidence; editor line measure stays readable. Screen width is not stretched into an arbitrary fixed-ratio panel. The user can hide the inspector when writing; W7 must specify mounting semantics and W8 must create an actual full-tab launch (baseline manifest only declares `side_panel`). Desktop and Side Panel share navigation and domain action IDs; they differ only in disclosure and composition. **No existing full-tab workspace is asserted.**

### 7. Settings, derived Review and gated research

Settings are one destination with Appearance, Capture, Search, Thinking cues, Data/export, Integrations. Review is *one* secondary mode with Spreadsheet, Calendar, Flow and Flatten projections, not four new destinations. Discover and Query Studio are conspicuously gated; their isolated source prototypes must not look like operating an online AI/research service. Paper / Pure Black / System settings reuse source palette values; no blanket inversion of image assets or favicons.

## D. Five everyday journeys and why the routing exists

| Journey | Shortest intended action path | Success and critical failure to catch |
|---|---|---|
| J1: read web evidence, clip, comment, resume writing | Chrome selection or Capture → Clip/Annotate → Board/Card → Write caret | One intentional capture record with source anchor; does not steal editor focus or silently request permissions |
| J2: write first, later organize | Write Card → Board context picker → relationship/member detail → back to Write | Same Card ID, undo/caret maintained; Board membership many-to-many |
| J3: retrieve an old quote with its meaning | Find → Source result → annotation/provenance → Insert citation in Card | Source origin and comment visible; no link-only proxy treated as citation |
| J4: resume an interrupted reading session | Sessions → choose revision → preview missing URLs → explicit restore | Never auto-restore on inspect; unsupported URLs skipped; Board/Card untouched |
| J5: reflect across several notes | Context → Review derived view → select Card → Write | Derived YAML/provenance projections reuse original notes; no cloned spreadsheet data |

**Empty and failure journeys** are equally first-class: no Board or Card → explicit create; no source match → revise query, not fake results; stale annotation anchor → show source reopen/manual reference; denial → offer paste/link; pending save → leave state visibly pending; failed Drive backup → no green confirmation; `RECOVERY_NEEDED` → inspect before restore; Discover/Query → disabled and explanatory by default.

## E. Resilience across surfaces

| Container width | Composition | What must never happen |
|---|---|---|
| 280px | wrapped header, Board context and Capture on their own row, vertical body, compact five-item nav | no root horizontal overflow or clipped capture button; tabs remain keyboard reachable at extreme text scaling |
| 320px | same with slightly more text; source inspector as a drill-down | no two-column editor; no toolbar scrolling without alternatives |
| 360px | inline header when space permits; wrap tool controls | no clipped citation label; no fixed-height editor truncation |
| 420px | vertical Card/editor with flexible Library cards | no fake desktop panel hierarchy |
| 600px | content-first single lane; optional expanded previews only where useful | no skinny 3-column imitation |
| 800px | 180px left rail, main content | no wasted large whitespace or cramped editor |
| 1050px+ | rail + elastic main + conditional 258px inspector | inspector cannot steal write focus or duplicate editable content |

The wireframe's initial 200% scaling stress exposed a 3px root overflow. Corrective CSS wraps the header below 360px, caps the Board label and makes the compact nav horizontally scrollable if necessary; retest passed. Testing `body.style.zoom` is a stress proxy and cannot stand in for actual extension-browser zoom/Chrome side-panel resizing. The full intended acceptance is specified in `COMPONENT-AND-RESPONSIVE-CONTRACT.md`.

## F. Reference-system evidence, with transfer limitation

1. **Notion**: its official sidebar documentation describes navigation hierarchy and customizable disclosure. **Transfer:** predictable structural location for Boards and contextual content, not an infinitely nested Side Panel. https://www.notion.com/help/navigate-with-the-sidebar
2. **Memex (WorldBrain)**: first-party repository describes full-text retrieval across saved/annotated pages and source highlighting. **Transfer:** quote/source-context continuity on retrieval, not a global web-history permission or wholesale copying of its architecture. https://github.com/WorldBrain/Memex
3. **Karakeep**: official docs describe organizing captured bookmarks into lists and searching stored content. **Transfer:** unified Library type filters and mixed source browseability; **rejected:** automatically installing AI tagging/crawlers into Paperfold. https://docs.karakeep.app/
4. **Obsidian Web Clipper**: official guide documents web highlights, clipping and templates. **Transfer:** capture form keeps meaningful destination/provenance context near a selection; **rejected:** replacing the existing proprietary Card/Source graph with an Obsidian vault model. https://obsidian.md/help/web-clipper
5. **Tiptap**: official documentation describes editor state, selection and command transactions. **Transfer:** command state/focus correctness as a quality criterion; **rejected:** framework migration without comparing actual CM6 requirements and loss risk. https://tiptap.dev/docs/editor/core-concepts/introduction
6. **Milkdown**: official site describes a plugin-driven Markdown editor. **Transfer:** preview/editor distinction and extensibility as criteria; **rejected:** a new WYSIWYG parser layer only for visual polish. https://milkdown.dev/
7. **AFFiNE**: official page/edgeless explanation describes changing representation of the same document, not duplicating files. **Transfer:** Workspace Review as a derived representation; **rejected:** implementing a whiteboard before source/graph integrity gates. https://getaffineapp.com/blog/getting-started-with-affine

These are first-party descriptions or project docs checked on **2026-10-16**; none establish measured superiority in Paperfold. The 2026 AFFiNE blog is explanatory and itself states some illustrations are diagrams rather than product screenshots. Reference research informs hypotheses only; Paperfold's actual code and user task remain decisive.

## G. Tradeoffs and alternatives rejected (not peer proposals)

- **Versus always-on inspector everywhere:** our narrow drill-down adds one tap for annotations, but avoids crushing editor to <250px. Falsifier: if annotating now requires 3+ additional actions and breaks selection, design must adopt a quicker inline annotation affordance.
- **Versus Library-first as the only root:** quick capture and active Board remain prominent. Tradeoff: historical sources require explicit Library entry; mitigated by Cmd/Ctrl+K global commands and recent context trail. Falsifier: people repeatedly navigate >3 steps to find saved evidence while context view adds no benefit.
- **Versus perpetual command-palette navigation:** power users retain search commands, newcomers see explicit Capture/Write/Library/Find/Sessions. Tradeoff: nav occupies one narrow bottom strip; extreme zoom needs scrolling fallback and screen-reader test.
- **Versus a dedicated AI/Discover front page:** advanced prototypes are gated behind Find; this avoids implied validity and reduces menu noise but reduces serendipity visibility. Reopen only after evaluation and explicit review-persistence contracts.
- **Versus CSS-only facelift:** existing `sidepanel.js` is a 141,980-byte monolith with handlers spanning roughly 3,100 lines. Layout composition and routing must be decoupled at interfaces by Stage II before two builders edit it. Do not perform a speculative framework rewrite; preserve CM6, DB v5 and existing message boundary.

## H. Falsifiable claims and smallest meaningful probes

| Claim | Real Chrome evaluation method | Success criterion, negative control, reopen condition |
|---|---|---|
| UX-01 Context reduces task fragmentation | Six representative actors each perform Board→capture→annotate→Card without guidance; record interruptions/time/actions vs staging baseline | At least no newly required context reset; control: researcher starts without a Board and can still capture as unassigned source; reopen if forced Board required |
| UX-02 Narrow editor remains usable | Resizable Side Panel at 280,320,360,420,600 and 100%,150%,200%; keyboard only + IME | No root overflow, clipped primary actions, lost focus/selection, or trapped scroll; control: 200% + 280px effective width; reopen on any inaccessible primary control |
| UX-03 Capture is truthfully permission-aware | Chrome restricted URL + allowed HTTPS + denied HTTPS | Denied cannot report saved; allowed succeeds only after ack; control: decline site grant; reopen on deceptive success |
| UX-04 Citation round-trip is intact | Save source/annotation with anchor, insert cite, undo, reload and reopen | Link points to same persisted Source/annotation; control: stale/deleted source; reopen on dangling citation or selection loss |
| UX-05 Board and Session remain independent | Shared Card on two Boards; link Session to Board; rename and restore preview | No Card deletion/movement or unintended tab open on preview; control: two Sessions same Board; reopen if identity conflates |
| UX-06 Gated features cannot leak actions | Click every Discover/Query surface while prototype gates off | No edge write/network outbound action; control: disabled option should remain reachable/readable but not executable; reopen if write or request observed |
| UX-07 Full-tab represents same workflow | Run J1–J5 in both modes, compare IDs, action dispatch and save output | No duplicate stores or divergent successful results; control: resize during unsaved edit; reopen if draft lost |
| UX-08 Theme supports reading in all surfaces | Inspect Paper/Pure Black/System with nested dialogs, buttons, CodeMirror syntax, favicons | No invisible icons/status; no inverted images; control: bitmap favicon is not color-inverted; reopen on contrast failure |
| UX-09 Export leaves data recoverable | Verified archive plus *separate* clean-room restore on populated v4→v5 candidate | Full reference counts and content hashes reconcile; negative control: export-success-only must NOT clear restore gate |

**No percentages or speed improvements are claimed without comparative observations.** Tasks can be benchmarked in Stage II/III, but W3 does not have a production participant study.

## I. Source-grounded audit, findings, controls and debts

**Applied methods:** AntiSlop scope/version/provenance routing; architectural/interface/responsive/evidence slop checks; RMC design-debug route with source admissibility and minimal rendering falsifier; UI-adapted Visual Pipeline at all 15 component boundaries. See `COMPONENT-AND-RESPONSIVE-CONTRACT.md` for requirement, composition, state, responsive, theme, accessibility and evidence per boundary. The method docs guide execution; they do not prove product behavior.

**Observed checks:** expected ZIP SHA-256 matches; all 76 path hashes match source manifest; source `manifest.json` v0.8.0 and `sidepanel.js` inspected; 52 feature groups mapped; wireframe static JS test run, browser-rendered widths 280/320/360/420/600/800/1200 with 600 and 800 height, modal/focus/capture/session/Discover/Query/command/theme paths; screenshot receipts from a real headless Chromium *fixture*; initial 2× zoom stress overflow corrected and retested. Exact automation statuses in `receipts/WIRE-FRAME-TEST-RECEIPTS.json`.

**Negative controls:** Discover Accept and Query External action disabled; Session Restore disabled; no Chrome/network/IndexedDB/storage API in fixture JS; denied permission does not assert success; context menu stays native; no automatic Board renaming or schema migration; a screenshot cannot certify installed extension. Control against rival interpretations: a Session remains a separate identity, an AI transport export is a local artifact, and semantic similarity cannot license a scientific edge.

**Unknowns/debts:** real Side Panel height and browser zoom behavior; exact CodeMirror selection and undo transfer; populated v4→v5 migration/clean restore; Chrome-host permission denial and context-menu state; native popover placement; interactive accessibility of scroll fallback; System theme under actual OS; Google Drive/OAuth and LAN state; remote DOI metadata; user task performance. No in-place Chrome extension source modification or daily profile access. **A W3 PASS never clears release safety gates.**

**Handoff to W4:** Evaluate W3 as an independent candidate against W1/W2 *only after their independent proposals close*. Compare Context+Capture continuity, visible command cost at narrow widths, all-feature coverage, editor and retrieval, and implementation complexity. W4 alone selects canonical Stage I architecture; W3 does not claim decision authority. If W3 is selected, W7 must freeze the command registry, state/URL adapters, responsive behavior and exact source ownership before two workers begin code changes.

**Concrete reopen condition:** A reproducible task in which Board context forces extra navigation, loses a source-selection/editor caret, obscures a required control at 280–420px, or prompts any unsanctioned browser write; or a discovered baseline feature absent from the 52-entry relocation map. Return to the earliest responsible architecture boundary rather than cosmetically retouching the screen.
