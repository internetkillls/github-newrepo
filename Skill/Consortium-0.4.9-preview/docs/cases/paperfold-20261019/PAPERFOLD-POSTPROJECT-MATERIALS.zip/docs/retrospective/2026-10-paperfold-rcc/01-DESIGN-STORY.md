# Designing around the act of returning to a thought

## The problem behind the interface

Paperfold already had many research capabilities: Markdown Cards, Boards, saved Sources and captures, annotations, Sessions, Discover and Query Studio. The [original mission](materials/orchestration/MISSION.md) described a dense toolbar, weak hierarchy and navigation that reflected implementation history. The design problem was not a lack of destinations. It was that a narrow Side Panel asked the researcher to interpret too many competing controls before continuing a task.

A useful human scenario is a researcher reading an article beside an unfinished Card. They want to inspect an excerpt, decide whether it supports their paragraph, and return to the same thought. Losing the Card, caret or source provenance creates work even if every feature is technically reachable. This is a scenario derived from the mission and design contracts, **not an observed user-study session**.

The project modeled several distinct objects. A Board gives project context; a Card holds authored knowledge; a Source supplies external provenance; Capture is an acquisition operation; a Session represents recoverable browser activity. Conflating these objects would make navigation superficially simpler while changing what actions mean. The implementation therefore kept the underlying `maincards` storage identity while presenting Board in the UI.

## Three serious alternatives

W1 proposed an editorial workspace: reopen the current Card, keep writing central, and bring evidence toward it. W2 proposed a collection workspace: Library first, typed saved objects and provenance inspection, then writing. W3 proposed a contextual workspace: research context connects Board, Card and Source across browser activity. Each was a different answer to “what should be waiting when I open Paperfold?”

Their original proposals were assigned I2 blind roles. The subsequent debate was shared-context I0 work. Blindness ended when proposals were exchanged. The [W4 decision](materials/w4/UI-ARCHITECTURE-DECISION.md) preserves that distinction and rejects comparing fixture test totals as quality scores.

W4 chose **W1 as the structural basis**, with amendments. This was an adjudicated design judgment: stable writing continuity fit the mission and the existing CM6 editor without adding a mandatory home step. It was not an A/B finding that writer-first universally beats collection-first. W2 remains a plausible winner for a user who mostly retrieves and compares saved sources.

W2's typed Library filters and source-detail/return pattern survived inside the chosen architecture. W3's optional Board context and return token survived without its separate Context home or original five-slot compact dock. This matters: a coherent structure can adopt a subordinate mechanism without averaging three conflicting landing pages.

## What changed in the composition

The compact shell offers **Write, Boards, Library, More**, with a text-only Paperfold header and one Capture action. At larger widths the specified rail exposes Find and Sessions as labeled routes. Advanced tools stay secondary; an existing prototype does not become a live feature merely because it receives a destination. The relocation map assigns a location or explicit availability status to the inventoried features.

The layout's first constraint was the Side Panel rather than a desktop canvas compressed afterward. W6 specified one column in narrow widths, wrapping metadata, independent overflow for formatting tools and data tables, internally scrollable dialogs, and additional context only when space supports it. Paper, Pure Black and System retain the project's palette. Typography and spacing carry more hierarchy than decorative nested cards or header imagery.

![Reviewed Paper theme at 360 CSS pixels](../../../EVIDENCE/native/repaired-paper-light-360.png)

![Reviewed Black theme at 360 CSS pixels](../../../EVIDENCE/native/repaired-black-light-360.png)

These are host Chrome evidence images of the repaired candidate. They demonstrate a visible composition at one condition each; they do not prove task efficiency, screen-reader usability or universal responsive correctness.

There is still design debt visible in these images. The Card chooser, New/Delete, title, Tab capture, Thinking cues and formatting controls occupy substantial height before the writing surface. Destructive Delete is persistently exposed beside New. The formatting strip is dense and requires horizontal discovery at this width. Those are supported redesign opportunities, not measured usability failures. A next experiment should test whether deferring metadata and infrequent controls gives the writer more useful space without hiding essential actions.

## A design defect that changed the contract

The original W1 fixture's `insertEvidence()` appended to a Card while the person was inspecting Library. W1 acknowledged the defect in debate; W4 treated it as disqualifying unless repaired. Inspection and mutation had been collapsed into one action.

The corrected **design contract** separates them:

```mermaid
stateDiagram-v2
    [*] --> InspectSource
    InspectSource --> ReviewInsertion: stage Source + Card + caret
    ReviewInsertion --> InspectSource: cancel / no write
    ReviewInsertion --> ApplyTransaction: explicit confirm
    ApplyTransaction --> Saved: persistence acknowledged
    ApplyTransaction --> Error: failure / keep recoverable input
```

W4 demonstrated a fixture version, then passed CM6 transaction, persistence, undo and error feedback obligations downstream. This diagram describes the contract. The host's later Capture tests prove named Source/link operations; they do **not automatically prove every citation-at-caret variant in the design specification**. Treating related journeys as identical would repeat the same evidence error the process was intended to prevent.

W5 supplied semantics for modals, popovers, context menus, navigation, drag/drop, formatting, source review, selection, toast/save status, Discover review and recovery. W6 supplied viewport, focus and accessibility obligations. W7 reconciled them into builder contracts rather than asking the builders to invent missing behavior independently.

## What the portfolio claim can honestly be

“I directed a ten-role AI consortium from competing task models to a writer-first Chrome extension candidate, preserved domain/data boundaries, translated design into disjoint implementation contracts, and used native counterexamples to reopen and repair weak areas.”

Do not add “validated with users,” “bug-free,” “fully accessible,” “all 15 surfaces production-ready” or “deployed.” The material supports a substantial implemented candidate with scoped tests, plus explicit unavailable/prototype surfaces and unresolved production gates.

## What to put in the next prompt

Ask for a task trial comparing the current writer-first flow with a metadata-collapsed variant and a source-retrieval-first rival. Specify real participants or label simulation; measure correct completion, wrong-object actions, time to resume writing and retained context. Do not use click count alone as proof of intuition.
