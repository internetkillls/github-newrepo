# How RCC divided the work and moved the bytes

RCC supplied role/room policy and local CDP transport primitives. A case-specific Node runner supplied this project's scheduling. The account plugin alone did not operate Chrome. The project used a dedicated logged-in Chrome profile; the runner reused persistent ChatGPT conversations, serialized browser mutations with an operation lock, and allowed up to three eligible worker generations. This case behavior is not a general C1 concurrency certification for RCC.

## Three kinds of chunk must stay separate

1. **Work slice:** a bounded question or file ownership assignment, such as W2's collection architecture or W8's HTML/CSS. This determines authority and dependencies.
2. **Knowledge packet/closure:** a minimum useful handoff: decisions, invariants, evidence anchors, rejected alternatives, open debts and next entry contract. This keeps later rooms from inheriting every discarded conversation.
3. **Byte slice:** a transport fallback for an already-created file. A 4,096-byte slice contains no new design decision; it merely moves exact bytes when downloads or long replies fail.

Confusing these would make a transport repair look like new reasoning or make a delivered document look like an accepted design.

## Dependency and communication path

The host sent bounded packets with role, actual source identity, allowed evidence, parent closures, deliverable filenames, forbidden moves, acceptance and stop conditions. W1–W3 initially had no rival outputs. Debate tasks then received the proposals and reused the same rooms. W4 received all proposals/debates and was the sole Stage I selector. W5/W6 received W4; W7 received W4/W5/W6; W8/W9 received the frozen contracts; W10 received the builders' actual files and contracts.

Workers did not silently share a live filesystem with the host. They produced files in their remote environments. The host obtained, hashed and bundled those files into explicit dependency archives. Thus a successor's report that it had inspected a source file needed an actual delivered artifact, not a prose summary of what another worker supposedly wrote.

The [source snapshot](materials/orchestration/SOURCE-SNAPSHOT.json) preserves job dependencies, room URLs, model/effort readbacks and source/response identities. Worker packets required AntiSlop and RMC. The host used RCC's composer/upload/choice/CDP/lock adapters inside its own runner. Ten roles and 13 initial tasks grew to 17 job records through owner repairs and reverification; the counters in older summaries were not a complete later ledger.

## A send is an uncertain side effect

```mermaid
flowchart LR
    A[Eligible dependency] --> B[Target and model readback]
    B --> C[Composer filled and verified]
    C --> D[Persist SEND_UNCERTAIN]
    D --> E[Click send once]
    E --> F{Exact prompt echo?}
    F -->|yes| G[Observe anchored turn]
    F -->|no| U[UNCERTAIN: reconcile, no resend]
    G --> H[Stable text plus affirmative terminal evidence]
    H --> I[Capture response and artifacts]
    I --> J[Hash and content gate]
```

The case runner's [completion rule](materials/transport/rules.mjs) requires three consistent anchored observations spanning at least ten seconds: same prompt, turn key, assistant identity and response text; complete turn state; scoped final regenerate affordance; no Stop control. Stable text alone is not enough. Completion still proves only that the observed reply finished. Content, source identity and release status are checked separately.

Before browser dispatch recovery, the operator checks runner PID and lock ownership. A healthy runner's state is not edited. A missing target can be rebound only with unique room/turn evidence; an uncertain send is never blindly repeated. This is why waiting on a dependency or stopping at ambiguity can be correct even when the user perceives a stall. The process still failed operationally when repeated manual “next/continue” became necessary: safety without useful progress visibility is an incomplete orchestration experience.

## Why byte slicing was necessary

Published download controls did not consistently yield host files. Large inline Base64 payloads were vulnerable to truncation or corruption. The fallback requested a **bounded slice of existing bytes**, one final JSON block per reply. It did not ask the worker to regenerate an approximation of the source.

The W10 archive `PAPERFOLD-W10-REVERIFY-SOURCE-TRANSFER.zip` was **212,683 bytes**, pinned SHA256:

```text
680ee19c3a98145fa4f127ca74be18da29aaea2ad737270660c8328b6618f417
```

At 4,096 bytes per slice, `ceil(212683/4096) = 52`: indices 0–50 contain 4,096 bytes and index 51 contains 3,787 bytes. Byte ranges are half-open: `[index*4096, min((index+1)*4096,totalBytes))`. Base64 of a full slice needs 5,464 characters, which is smaller than a whole archive response.

The actual envelope was:

```json
{
  "schema": "paperfold.file-chunk.v1",
  "path": "PAPERFOLD-W10-REVERIFY-SOURCE-TRANSFER.zip",
  "index": 0,
  "total": 52,
  "fileSha256": "<pinned whole-file SHA256>",
  "chunkSha256": "<SHA256 of this raw byte slice>",
  "content_base64": "<actual bytes, not regenerated source>"
}
```

The [series handler](materials/transport/series-delivery.mjs) checked expected index, path, count, decoded length and chunk hash; the [assembler](materials/transport/chunk-delivery.mjs) rejected missing/duplicate/out-of-order-inconsistent metadata and checked the concatenated hash. Host review independently verified total length and the pinned whole-archive hash before safe extraction. An inconsistent chunk 49 was preserved as rejected evidence and corrected through a bounded, completed-turn recovery. No uncertain original submission was simply resent.

W5's 18,620-byte interaction document used five slices; W8's final 15,021-byte contrast archive used four. These are transport counts, not extra worker roles. Slicing fixed reliable delivery at significant round-trip cost. The preferred future route is a verified native artifact download or supported binary attachment channel; slices should be the bounded fallback.

## File integrity is necessary but not semantic proof

Extraction rejects absolute/traversal paths, Windows drive/colon/backslash ambiguities, duplicate case-insensitive names and unsupported ownership. Joining relative POSIX archive paths through path APIs avoids Linux-to-Windows slash mistakes. The baseline ZIP remains immutable. A changed-files package is overlaid into an isolated baseline copy, not mistaken for a complete repository.

A hash proves byte identity. It cannot prove a file implements Capture correctly. A structural Stage III gate expected PASS and initially rejected W10's honest BLOCKED closure; that was an orchestration/content-gate mismatch, not failed transport. The correct response was to retain source delivery and pursue native evidence, not endlessly send W10 back through integration until it produced a green label.

## What to put in the next prompt

Separate task status, transport status and acceptance status. Require exact prompt/turn reconciliation, a maximum active count, durable evidence paths, bounded recovery budgets and no resend after ambiguity. For large artifacts, pin identity/size/hash first and define safe binary fallback before requesting a long inline response.
