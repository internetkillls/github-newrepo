# The user's criteria and how this review interprets them

Source: [What To Seek when I want to create Something](https://app.notion.com/p/3fd0056a56ff806b9b81cdf1a27b3873). Retrieved through Notion on 19 October 2026. Page ID `3fd0056a56ff806b9b81cdf1a27b3873`; returned last edit 18 October 2026 12:54 UTC, Source=Self, State=To review, verification=unverified. The fetch returned the page content, with no truncation or unknown-block warning. No Notion page was modified.

The source puts causal problem clarification and the human situation before technology. For complex problems it calls for a simpler flow, schema or decision tree. It then asks for atomic functions, nearby precedents, the relevant data and operational rules; the simplest usable representation; and a before/after check of whether the problem disappeared.

For prompting, the note proposes deliverable-led Work Breakdown Structure, role/lens plus AntiSlop, task, a general project story, and a concrete human phenomenon. It warns that false clarification can displace intuition, and that fluent description can miss how people actually operate. This review treats those as design requirements to investigate, not as empirical proof about every LLM or every human.

Two interpretations are explicit additions by the reviewer:

1. A WBS supplies decomposition and accountability. Calling it an expert system does not by itself provide a domain rule base, validated inference engine or deterministic behavior. Future prompts should specify those rules and gates if that is the intended effect.
2. “General story” and “human phenomenon” should be separate evidence views that are reconciled. The note's warning about parallel generation is respected by not treating two independently fluent narratives as proof they describe the same experience. It need not prevent parallel collection of nonconflicting artifacts.

The review therefore asks: **Does each decision connect an observed problem to an atomic function, an interaction/state model, and an outcome capable of being tested?** Where that link was not measured, the document says so.
