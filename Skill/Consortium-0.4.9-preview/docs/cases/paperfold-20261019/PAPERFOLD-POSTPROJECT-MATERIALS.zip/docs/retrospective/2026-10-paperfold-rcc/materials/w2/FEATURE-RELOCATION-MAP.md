# W2 — Complete feature relocation inventory (Paperfold v0.8)

**Meaning:** CURRENT is source-observed under supplied 0.8; TARGET is a **proposal**, not implementation. `Implemented` means code/UI handler exists, not Chrome-witnessed correct. `Prototype` = separate gated files; `Deferred` = no present functional promise. Projection rows must not cause DB reclassification.

| ID | Existing source feature / source anchor | Current status | W2 proposed destination / preservation rule |
|---|---|---|---|
| F01 | MV3 Side Panel, action, background (`manifest.json`) | Implemented declaration | Single shell for side/full tab; full-tab launcher **proposed only**, no manifest permission change. |
| F02 | Cards selection/create/delete (`sidepanel.html` `noteSelect`, `newNoteButton`, `deleteNoteButton`; `sidepanel.js` `loadNotes`, `createNote`, `deleteActiveNote`) | Implemented | Cards screen; destructive action behind confirmation. |
| F03 | Markdown CM6 edit, undo/format, Live/Reading, zoom (`cm-editor.js`, `sidepanel.js` `renderActiveNote`, `flushNoteSave`) | Implemented | Cards editor + contextual text toolbar; maintain save promise/selection. |
| F04 | Slash, @, wiki, math, citation, reminder, markdown helpers (`cm-editor.js`, `markdown.js`, `cues.js`) | Implemented | Editor command palette, source citation and syntax help. |
| F05 | Per-Card tab auto-attach policy and cue mode (`sidepanel.html` `capturePolicy`, `cueMode`) | Implemented | Card → Options → Capture policy / Writing cues; preserve settings. |
| F06 | Boards / Maincards CRUD, perspective, body (`card-model.js`, `sidepanel.js` `maincardsDialog`) | Implemented | Boards, clearly separated from collection folder; user-facing Board only. |
| F07 | Board memberships, classifications and typed edges (`db.js`, `card-model.js`, `maincardsDialog`) | Implemented | Board detail → Cards and Connections. Never mutate `maincards`/`memberships`/`cardEdges` schema. |
| F08 | Board flatten export (`card-model.js`, `exportMaincardButton`) | Implemented | Board → More → Export flatten. |
| F09 | Linked tabs / Sources (`db.js` `sources`,`links`; `sidepanel.js` `attachTab`, `renderSources`) | Implemented | Library → Sources; source inspector links to Cards, preserves ID. |
| F10 | Active tab refresh/attach + multi-tab picker (`sidepanel.js` `refreshCurrentTab`, `attachSelectedTabs`) | Implemented | Capture → Attach current / choose tabs; source list owns attachments, not Card creation. |
| F11 | Page scrape into paired Markdown scraps (`service-worker.js` EXTRACT_TAB; `sidepanel.js` `scrapeCurrentPage`) | Implemented, site grant possible | Capture → Save page excerpt; Library → Captures; explicit permission/error states. |
| F12 | Selected text clip, Web capture pending (`service-worker.js` CAPTURE_SELECTION; `sidepanel.js` `captureSelectionFromButton`,`consumePendingWebClip`) | Implemented | Capture → Selection or Chrome context menu → annotation composer. |
| F13 | DOM/TextQuote highlight and annotate (`service-worker.js` HIGHLIGHT_ANNOTATION; `sidepanel.js` `savePendingAnnotation`, `openAnnotationById`) | Implemented | Library → Annotations; source inspector quote + source anchor + reopen fallback. |
| F14 | Woven scraps (`db.js` scraps; `sidepanel.js` `renderScraps`) | Implemented | Library → Captures/Scraps; do not equate with external Source. |
| F15 | Local files/attachments and attachment comments (`db.js` attachments; `attachmentDialog`) | Implemented | Capture → File; Library → Attachments; preserve original binary where possible. |
| F16 | Browser bookmarks via Chrome (`manifest.json` `bookmarks`; `db.js` bookmarks; `sidepanel.js` source handling) | Implemented (coverage limited) | Library → Bookmarks facet; no universal Chrome history. |
| F17 | DOI detection, Crossref/DataCite metadata (`literature.js`, `service-worker.js`, `doiDialog`) | Implemented, live API unverified | Library → Literature; Source detail → DOI lookup, permission/lookup feedback. |
| F18 | Search chunks/vector/embedding (`embedding.js`, `provenance.js`, `sidepanel.js` `runSearch`) | Partial index for notes/sources | Library search UI must expose **supported scope** until heterogeneous query is built; no claim of full-text global index. |
| F19 | Reminders + notifications (`service-worker.js` `scheduleReminder`; `sidepanel.js` `scheduleReminder`) | Implemented | More → Reminders and Card editor inline token. |
| F20 | Activity log and retention (`db.js` logs, `sidepanel.js` `renderLogs`, settings keepLog) | Implemented | More → Activity, Settings → Advanced; explicit Clear all. |
| F21 | YAML templates Stub, Log, Tracker, Planner (`yaml.js`; `sidepanel.js` `insertYamlTemplate`) | Implemented | Cards → Insert template via / menu, not separate home row. |
| F22 | Workspace spreadsheet/calendar/flow/flatten (`workspace.js`, `workspaceDialog`) | Implemented projections | More → Workspace → four projections; scalable full-tab views. |
| F23 | Workspace review CSV / flatten JSON export (`workspace.js`, `sidepanel.js`) | Implemented | Workspace → Export menu with exact formats. |
| F24 | Thinking cue command library / configurable cues (`cues.js`, `cueDialog`, `cueEditor*`) | Implemented | Cards → Insert → Thinking cues; Settings → Writing tools. |
| F25 | Current Markdown download (`sidepanel.js` `exportActiveNote`) | Implemented | Cards → More → Export Markdown. |
| F26 | Woven tar.gz provenance package (`provenance.js` `createWovenBundleBlob`) | Implemented | More → Exports → Woven bundle; preserve authorship/citation IDs. |
| F27 | Full workspace archive (`provenance.js` `createWorkspaceBundleBlob`, `exportWorkspaceBackup`) | Implemented exporter only | Settings → Export & Backup; **do not claim archive restore/import exists**. |
| F28 | AI transport bundle (`provenance.js` `createAiTransportBundleBlob`) | Implemented export only | More → Export → AI transport; distinguish bundle creation from calling AI. |
| F29 | Search provider list / selected-text search (`workspace.js` providers; `service-worker.js` context menu) | Implemented | Quick Actions → Search selected text; Settings → Search providers. |
| F30 | Google Drive backup OAuth / scheduled backup (`service-worker.js`, `settingsDialog`) | Implemented code, live auth unverified | Settings → Integrations → Drive; no account status claim without handshake. |
| F31 | LAN/local sync companion push/pull (`sync.js`, companion server, `settingsDialog`) | Implemented code, live LAN unverified | Settings → Integrations → Local sync; visible risky merge explanation. |
| F32 | Export folder preference (`settingsDialog` `chooseExportFolderButton`) | Implemented code | Settings → Export & Backup. |
| F33 | Paper / Pure Black / System theme (`sidepanel.css`, theme setting) | Implemented, contrast unverified | Settings → Appearance; native system preference fallback. |
| F34 | Embedding provider selector (`settingsDialog` `embeddingProviderSelect`) | Implemented configuration | Settings → Search; avoid implying external neural backend exists. |
| F35 | Browser Sessions checkpointing (`browser-sessions.js`; `session-ui.js`) | Implemented P0 | Sessions root in full tab and More in side panel; preserved local profile scope. |
| F36 | Session name, Board link/unlink (`session-ui.js`, `sessionsDialog`) | Implemented P0 | Sessions → detail / Board associations, no automatic Card creation. |
| F37 | Session revisions / read-only recovery preview / explicit restore (`browser-sessions.js`, `session-ui.js`) | Implemented P0, Chrome crash witness pending | Sessions → Recover; confirmed preview before restoration, never silent. |
| F38 | Chrome context menus: command, attach, attachment, Boards, scrape, clip, selected-text search (`service-worker.js` `ensureContextMenus`) | Implemented declaration/handlers | External entry to common command/capture flow; maintain permission guard. |
| F39 | Quick cue keyboard command (`manifest.json` `open-cue-palette`) | Implemented declaration | Cards / global command action; preserve keyboard binding. |
| F40 | Discover lexical proposal engine (`prototypes/discover/lexical.js`, tests) | **GATED PROTOTYPE, not app** | Explore → Discover information + gate, no production accept button. |
| F41 | Query Studio AST encoder (`prototypes/discover/query-ast.js`, tests) | **GATED PROTOTYPE, not app** | Explore → Query Studio information + URL preview fixture, no real provider open until security gate. |
| F42 | Smart collections / automatic AI summaries / OCR | **ABSENT** | Not shown as implemented; no invented Karakeep parity. |
| F43 | Full-tab workspace launcher / popup | **ABSENT per `docs/FEATURE-AUDIT.md`** | Full-tab design as proposed future container/entry, not assumed shipped. |
| F44 | Import/restore entire archive | **ABSENT/UNVERIFIED** | Export & Backup → “Import unavailable”; do not create restore action. |
| F45 | Chrome native browsing history/closed-tab history | **ABSENT / deferred** | Sessions displays only explicit persisted revisions; never pretend browser history index. |
| F46 | Automatic Discover acceptance, graph inference, remote neural search | **ABSENT / gated** | Explored read-only; relationships always unconfirmed and never auto-persist. |
| F47 | Error/empty/loading/permission guard (`sidepanel.js` and dialogs mixed states) | Partly implemented, E2E unverified | Reusable state presenter in every surface; tests for distinct, semantically announced outcomes. |
| F48 | UI icon treatment and app header mark (`sidepanel.html` img, `sidepanel.css`) | Existing decorative icon, contrast unverified | Text-only in-app Paperfold; required manifest icons retained; focus/disabled audit. |

## Backing stores (all present, no schema edits)

`notes, sources, links, logs, settings, scraps, annotations, chunks, ir, bookmarks, backups, transports, attachments, maincards, memberships, cardEdges, syncRuns, browserSessions, sessionRevisions` (`db.js`). A Library aggregate is a read-only projection with source-type fidelity. A Board filter must follow `maincards → memberships → notes → links → sources`, and it must not infer membership merely from matching URLs. Other objects may lack direct Board membership; display “no Board association,” not fabricate one.

## Explicit dispositions

Source-grounded app functionalities F01–F39 receive proposed destinations. Gated modules F40–F41 retain prototype labels. Absent/deferred F42–F46 remain not implemented. F47–F48 specify non-functional requirements. Reopening evidence: actual source code for a missing feature (or failing current handler test) supersedes classification; W4 should request targeted evidence before accepting stronger claims.
