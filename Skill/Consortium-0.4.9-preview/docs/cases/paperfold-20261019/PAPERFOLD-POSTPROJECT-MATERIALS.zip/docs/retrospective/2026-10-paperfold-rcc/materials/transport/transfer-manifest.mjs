import {queuePiece} from './series-delivery.mjs';
export function handleTransferManifest(job,base,event){
 if(!job.awaitTransferManifest)return false;
 const manifests=[];for(const raw of job.codeBlocks||[]){try{const o=JSON.parse(raw.replace(/^json\s*/i,''));if(o.schema==='paperfold.transfer-manifest.v1')manifests.push(o);}catch{}}
 if(manifests.length!==1)throw Error('Expected one transfer archive manifest');
 const m=manifests[0];if(m.path!==(job.expectedTransferManifestPath||'W8-SOURCE-TRANSFER.zip')||!Number.isInteger(m.bytes)||m.bytes<1||m.bytes>262144||!/^[a-f0-9]{64}$/.test(m.sha256)||(job.pinnedTransferHash&&m.sha256!==job.pinnedTransferHash))throw Error('Invalid transfer manifest');
 job.seriesPath=m.path;job.seriesBytes=m.bytes;job.seriesCount=Math.ceil(m.bytes/4096);job.expectedTransferHash=m.sha256;job.collectedChunks=[];job.chunkSeries=true;job.awaitTransferManifest=false;queuePiece(job,base,event);return true;
}
