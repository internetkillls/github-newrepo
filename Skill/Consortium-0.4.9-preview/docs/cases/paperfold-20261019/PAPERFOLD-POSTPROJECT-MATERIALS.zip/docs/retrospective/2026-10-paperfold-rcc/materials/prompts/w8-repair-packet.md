TASK: w8-repair; WORKER: w8; same role-owned room, not a new specialist. Mandatory AntiSlop and RMC remain in force. Preserve canonical W4/W7 architecture and exact source ownership. Baseline source.zip SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. Original mission/method/source attachments are inside the outer w8-repair-INPUTS.zip with the dependency archive; unpack nested ZIPs. The reviewed-artifacts folders contain the actual validated sources and specifications. Work only in an isolated extraction; preserve schema, permissions and user data.
Repair the W10 confirmed missing production contextual popover markup and Capture-review dialog hooks within ONLY sidepanel.html and sidepanel.css. Preserve all baseline IDs and W7 routes. Use existing W7 API placement; if truly unspecified, report precise upstream design debt. Define exact DOM IDs/data attributes, buttons and event contract in W8-REPAIR-HANDSHAKE.md so W9 can implement handlers without guessing. No fake success or source persistence in HTML/CSS fixtures. Add positive/negative accessibility/positioning/resize/theme tests. Do not modify JS. Preserve exact source byte hashes in the patch manifest.
DELIVERY: actual complete changed source files plus reports/tests, hashes and accurate limits. Prefer a compact source-transfer ZIP excluding unchanged baseline and screenshots. Supply real rcc_delivery.v1 JSON or paperfold.file-chunk.v1 blocks in FINAL REPLY when possible, with original raw-byte hashes, each chunk <=4096 bytes. Never output placeholders. Required files: ["W8-REPAIR-REPORT.md", "SOURCE-HASH-MANIFEST.json", "W8-REPAIR-HANDSHAKE.md"]. SOURCE-HASH-MANIFEST.json must have sourceSha256 and changedFiles array of path/sha256 for all changed owned production files. Final JSON control: schema=paperfold.handoff.v1, task=w8-repair, sourceSha256=6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10, canonical=false, stage=null, status=PASS only for actual owned exit criteria (otherwise BLOCKED), decisions/rejected/evidence/tests/debts/reopenCondition. Stage III closure requires accurate release/native/data gate results; do not declare PASS from fixtures alone.
W10 VERIFIED FAILURE REPORT:
# W10 Integration Report — PAPERFOLD-UI-20261016

**Canonical Stage III: BLOCKED.** Role I1 CLOSURE-ONLY; verifier is also integrator, not blind independent review. Exact original source ZIP SHA256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10` verified. No Git metadata supplied. No application installation/deployment/profile/schema/permission change.

## Evidence → specification → implementation → preview → compare → diagnose → correct → validate → handoff

- **Evidence/source gate:** immutable source.zip SHA-256 matches, all 76 SOURCE-MANIFEST.json file byte sizes and hashes match. W4 Stage I and W7 Stage II canonical PASS contracts consumed, not redesigned. W7 ownership exact: W8 `sidepanel.html`, `sidepanel.css`; W9 `sidepanel.js`, with no overlap. Every builder SHA-256 matches corresponding delivered file. No third-party work invented.
- **Specification gate:** W7 `INTERACTION-SPEC.md`, `COMPONENT-API-CONTRACT.md`, `RESPONSIVE-CONTRACT.md`, `DESIGN-TOKENS.md`, `ACCEPTANCE-MATRIX.md`; W4 `COMPONENT-CONTRACTS.json` and feature routing. Route destinations and the persistence-before-feedback rule retained.
- **Implementation:** apply W8 and W9 byte-identical source patches to isolated supplied v0.8 baseline; 73 other original source files remain byte-identical. W10 mechanical edits to `sidepanel.js` only: synchronize `[data-pf-active]` with W8 CSS in `activateRoute()`, dismiss native More on navigation/Escape/outside click. No domain-schema/permissions edits. Final actual byte hashes are in `SOURCE-HASH-MANIFEST.json`.
- **Preview/compare:** W8 CSS-only 336 layout cases/42 dialog/42 More cases PASS; W9 adapter fixture 6 width cases PASS; **W10 first combined Chromium fixture** reproduced blank Boards/Library/Find/Sessions after navigation at 280–800 px (zero visible `data-pf-view` panels), despite active `aria-current`. `sidepanel.css` line around `.pf-page:not([data-pf-active="true"])` suppresses the panels, while original W9 `activateRoute()` only toggled `hidden`/`.hidden`.
- **Diagnose/correct:** W10 sets explicit `node.dataset.pfActive=String(active)` at the W8/W9 boundary; it also closes native More disclosure on route exit/Escape/outside. No new route, UI control, or schema introduced.
- **Validate:** rerun 8 W9 VM behavior probes, six existing JS regression suites, v0.5 archive suite, Python v0.7 server-security suite and Node syntax: all re-run PASS after the mechanical edit. W10 real Chromium **combined W8 HTML/CSS plus actual W9 adapter functions**: 336 navigation/surface probes, 42 dialog focus/Escape/sizing probes, 42 More-disclosure Escape probes, reduced motion probe PASS across 280/320/360/420/600/800/1110 × 400/700 × Paper/Black/System. This is **not the fully bootstrapped extension, IndexedDB or native Chrome Side Panel**. Captured images are clearly labeled `combined-*` fixture captures.

## Blocking discrepancies / reopen targets

1. **W9 Capture approval bypass — CONFIRMED source/control deficiency**: `elements.attachCurrentButton.addEventListener('click', () => attachTab(state.currentTab,'manual'))` binds global Capture straight to `attachTab()`; `attachTab` uses `put('sources',source)` and `put('links',...)` without a confirmation stage. Stage II INTERACTION-SPEC says Capture must open review before commit. Reopen **W9**, coordinate W8 native dialog hook if needed; positive test confirms preview then explicit commit and negative canceled review creates zero `sources`/`links` writes. Existing W9 `reviewSourceCitation()` stages insertion but does not stage Capture.
2. **No production contextual popover surface — CONFIRMED markup absence:** `sidepanel.html` contains zero `[data-pf-popover-trigger]`, zero `[data-pf-popover]`, zero `[data-pf-drawer]` while W9 supplied optional `togglePopover()/toggleDrawer()`. W9 fixture showing them is not production DOM. Reopen **W8/W9**, and W7 only if a component placement/API decision truly remains undefined; require accessible trigger, observed menu positioning/keyboard and focus restoration in full source.
3. **Native extension runtime and safety — UNVERIFIED:** no service worker observed in isolated headless Chromium; cannot honestly claim installed Side Panel, context menu, permissions, real IndexedDB persistence, editor undo/IME, native zoom or populated-data restore. Reopen **W10 runtime verification** when genuine Side Panel + disposable populated-test profile is available. Production deployment stays blocked.

## Component-boundary QA (adapted Visual Pipeline)

| ID/surface | Token/size/states/interaction | Preview, comparison, diagnosis, validation | Result |
|---|---|---|---|
| UI-W10-01 Shell/routes | W7 Paper/Black/System; 280–1110; `aria-current`, `[data-pf-active]`, focus | Headless Chromium full W8 DOM/CSS+W9 route adapter; pre-fix blank panels, post-fix 336 routes | FIXED+FIXTURE-TESTED |
| UI-W10-02 Editor | W4 Card editor/CM6 host, dirty/pending/saved/failed, caret and mobile width | `#noteEditorHost` and IDs retained; W9 8 VM behavior tests; integrated browser editor actual boot/persistence not exercised | UNIT-TESTED; BROWSER UNVERIFIED |
| UI-W10-03 Library/Boards/Sources | membership explicit, staged citation, no implicit Board creation | W9 VM zero Board-on-open, staged citation cancel/stale; integrated route visible; Capture bypass found | BLOCKED capture |
| UI-W10-04 Find/Sessions | v0.8 existing search/session data pathways; 280–1110 | existing v0.8 regressions PASS; route visible combined; no real session restore | BUILT+UNIT-TESTED; RESTORE UNVERIFIED |
| UI-W10-05 Modal/More/popover | Native `<dialog>`, Escape focus restore; disclosure; W7 motion | 42 DOM dialog and 42 disclosure cases PASS; production custom popover DOM absent | BLOCKED popover |
| UI-W10-06 Appearance/zoom/a11y | Paper/Black/System, high-contrast text, reduced motion | W8 six sampled text contrast cases >=4.5, W10 reduced motion and themes; real native zoom/AT unknown | PARTIALLY VERIFIED |
| UI-W10-07 Discover/Query | Read-only gated | HTML has static explanatory routes, no invented productive controls; gated v0.8 tests PASS | PASS for gating; runtime unknown |

## AntiSlop negative controls, findings and unknowns

- Rejected hash mismatch/overlapping ownership/unowned mutation: mechanical checks (positive input verified; intersection empty); unchanged 73 original paths independently SHA-checked.
- Negative control **observed**: a route with `aria-current` but missing `data-pf-active` yielded zero visible panels; corrected condition retested.
- Negative controls **tested by W9 VM**: rejected save does not announce success, canceled/stale citation does not insert, empty Boards entry creates no Board. These are VM probes, not IndexedDB runtime evidence.
- Negative control **observed by source**: a popover API without a markup trigger is not a functional menu; fixture screenshots cannot cure missing production hook.
- Negative controls **not executed**: cancel Capture zero write, filled-database schema migration, deleted/recovered local archives, denied Chrome permission, native 200% zoom, assistive technology.

## Official references (design justification only)

- Chrome Side Panel API: https://developer.chrome.com/docs/extensions/reference/api/sidePanel — actual browser side-panel extension requires its own runtime context; a fixture is not this test.
- MDN `showModal`: https://developer.mozilla.org/en-US/docs/Web/API/HTMLDialogElement/showModal — top-layer/inert semantics support retaining native dialog; doesn't prove W10 implementation focus trap in an installed extension.
- Obsidian Web Clipper: https://obsidian.md/help/web-clipper/capture — shows deliberate capture flow and context-menu entry as an external research pattern; Paperfold still needs its own save/review evidence.

**Handoff:** candidate is source-complete for review with W10's narrow mechanical fix. Stage III is BLOCKED pending named W8/W9 repairs and true Chrome/data safety gates. It is not release-ready.

## RMC task-intent and failure routing receipt

- **Intake/route/frame (S0–S2):** the governing task is *integrate and verify* frozen W4/W7 contracts, not restart architecture selection. Accept `source.zip` at the pinned v0.8 hash; regard worker closure PASS as scoped assertions, not inherited browser evidence. Require candidate package plus truthful stage status.
- **Evidence/materialize (S3–S4):** index 76 immutable source files and W7 ownership sets; compare actual DOM/CSS selector `[data-pf-active]` with W9 route event source, not narrative claims. Name the contradiction as a mechanical state handshake.
- **Falsification/repair (S5–S7):** combined Chromium test before repair found `aria-current=boards` while zero route panels rendered. Changing W9 `data-pf-active` and rerunning the *same type of test* disconfirmed that failing state. As a near miss, standalone W8 336 visual previews passed precisely because they manually injected route state; this is a negative control against using isolated screenshots as integrated proof. Source inspection separately defeats Capture review and production-popover completion claims.
- **Stabilize/deliver (S8–S9):** preserve successes only within their tested jurisdictions, reject Stage III PASS because the mandatory Capture/Popover and native Chrome/data gates are open, and name W8/W9/W10 reopen predicates. This is a limited repair plus a falsifiable BLOCKED closure, not a generalized quality score.

RELEASE GATES:
# W10 Release Gate

**NO DEPLOYMENT — BLOCKED.** Candidate is a source-review artifact, not production or a recommendation to install over an active Chrome profile.

| Gate | Status | Reason / reopen |
|---|---|---|
| Current v0.8 source integrity & preservation | PASS | 76/76 original file manifest, 73 untouched |
| W4/W7 canonical contract identity | PASS | W4 Stage I, W7 Stage II + exact disjoint W8/W9 ownership |
| W8/W9 patch hashes | PASS | All 3 delivered source hashes verified |
| Merge conflict and syntax | PASS | One W10 mechanical JS handshake patch and post-change Node syntax |
| Existing Node & Python regressions | PASS | Existing suites and W9 VM pass post-merge, receipts present |
| Combined adapter DOM routes | PASS scoped | Chromium W8 markup/CSS + W9 adapter functions, 336 probes, no full app bootstrap |
| Capture review before source write | BLOCKED | W9 direct `attachTab()` commit on Capture; W9 reopen |
| Real contextual popover DOM | BLOCKED | No trigger/popover markup in W8; W8/W9 reopen |
| Installed/native Chrome Side Panel | UNVERIFIED | Disposable Chromium no service worker registered; W10 reopen |
| Actual CM6 edit-save-reload/undo/IME | UNVERIFIED | W9 isolated storage VM is not IndexedDB |
| Permission denial, context-menu path, real session restore | UNVERIFIED | Requires extension runtime |
| Populated-data migration & archives restoration | UNVERIFIED | No populated user data touched; controlled disposable fixtures needed |
| Native zoom and assistive-technology review | UNVERIFIED | No native Side Panel/AT |

Release condition: W9 supplies staged capture with cancel zero-write evidence; W8/W9 supply and test real popover markup/action/keyboard; W10 reproduces full bootstrapped Side Panel journeys with disposable seeded records, archive restore/recovery, permission denial and native zoom, no critical regression. Only then re-adjudicate Stage III.
