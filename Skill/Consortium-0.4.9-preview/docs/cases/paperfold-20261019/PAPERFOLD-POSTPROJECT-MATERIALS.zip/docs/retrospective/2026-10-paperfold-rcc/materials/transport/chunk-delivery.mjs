import {createHash} from 'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
export function assembleChunks(blocks){
 const parts=[];
 for(const raw of blocks||[]){let o;try{o=JSON.parse(raw.replace(/^json\s*/i,''));}catch{continue;}if(o.schema==='paperfold.file-chunk.v1')parts.push(o);}
 if(!parts.length)return null;
 const files=[];for(const path of new Set(parts.map(p=>p.path))){const group=parts.filter(p=>p.path===path),first=group[0];
  if(!Number.isInteger(first.total)||first.total<1||first.total>64||group.length!==first.total)throw Error('Incomplete chunk delivery');
  if(new Set(group.map(p=>p.index)).size!==group.length)throw Error('Duplicate chunk');
  group.sort((a,b)=>a.index-b.index);
  const buffers=group.map((p,i)=>{if(p.index!==i||p.total!==first.total||p.fileSha256!==first.fileSha256||typeof p.content_base64!=='string'||!/^[A-Za-z0-9+/]*={0,2}$/.test(p.content_base64))throw Error('Invalid chunk metadata');const bytes=Buffer.from(p.content_base64,'base64');if(bytes.length>8192||hash(bytes)!==p.chunkSha256)throw Error('Corrupt chunk');return bytes;});
  const bytes=Buffer.concat(buffers);if(hash(bytes)!==first.fileSha256)throw Error('Whole-file hash mismatch');files.push({path,content_base64:bytes.toString('base64'),sha256:first.fileSha256});
 }return {rcc_delivery:'v1',files,tests:[],debts:['Only debate Markdown transferred; full archive evidence unavailable']};
}
