import {createRequire} from 'node:module';import {mkdirSync,writeFileSync} from 'node:fs';import {join} from 'node:path';
const require=createRequire('C:/Users/joshu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root='D:/Dev/.engineering/rcc/paperfold-ui-20261016/host-review';
const out=join(root,'native-evidence');mkdirSync(out,{recursive:true});
const profile=join(root,'disposable-chrome-profile');
const receipt={schema:'paperfold.host-native-smoke.v1',startedAt:new Date().toISOString(),profile,extension:join(root,'candidate'),browserExecutable:'C:/Program Files/Google/Chrome/Application/chrome.exe',cases:[],console:[],pageErrors:[],nativeSidePanel:'UNVERIFIED: extension-page smoke is not native panel evidence'};
let context;
const test=(name,status,detail)=>receipt.cases.push({name,status,detail});
try{
 context=await chromium.launchPersistentContext(profile,{executablePath:receipt.browserExecutable,headless:true,ignoreDefaultArgs:['--disable-extensions'],args:['--enable-unsafe-extension-debugging'],viewport:{width:420,height:800},timeout:25000});
 receipt.browserVersion=context.browser().version();const cdp=await context.browser().newBrowserCDPSession();
 const loaded=await cdp.send('Extensions.loadUnpacked',{path:receipt.extension});receipt.extensionId=loaded.id;test('native Chrome unpacked extension load','PASS',loaded);
 const page=await context.newPage();page.on('pageerror',e=>receipt.pageErrors.push(String(e)));page.on('console',m=>{if(['error','warning'].includes(m.type()))receipt.console.push({type:m.type(),text:m.text().slice(0,1200)})});
 await page.goto(`chrome-extension://${loaded.id}/sidepanel.html`,{waitUntil:'domcontentloaded',timeout:15000});
 await page.waitForFunction(()=>!document.querySelector('#attachCurrentButton')?.disabled,{timeout:15000});
 test('fully bootstrapped extension page','PASS',await page.evaluate(()=>({title:document.title,editor:!!document.querySelector('.cm-editor'),captureEnabled:!document.querySelector('#attachCurrentButton').disabled})));
 for(const route of ['boards','library','find','sessions','write']){
  if(!await page.locator(`[data-pf-route="${route}"]:visible`).count())await page.locator('.pf-more summary').click();
  await page.locator(`[data-pf-route="${route}"]:visible`).first().click();const view=page.locator(`[data-pf-view="${route}"]`);
  if(!await view.isVisible()||await view.getAttribute('data-pf-active')!=='true')throw Error(`Hidden route ${route}`);
 }test('five actual extension route transitions','PASS');
 await page.locator('[data-pf-route="library"]').first().click();await page.locator('#pfSourceContextTrigger').click();
 if(!await page.locator('#pfSourceContextPopover').isVisible())throw Error('Context popover absent');await page.keyboard.press('End');
 receipt.menuEnd=await page.evaluate(()=>document.activeElement.textContent.trim());await page.keyboard.press('Escape');
 if(await page.locator('#pfSourceContextPopover').isVisible()||await page.evaluate(()=>document.activeElement.id)!=='pfSourceContextTrigger')throw Error('Popover focus/dismissal failed');
 test('actual contextual popover keyboard dismissal','PASS',{end:receipt.menuEnd});
 receipt.idb=await page.evaluate(async()=>{const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('tabwoven-notes');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});try{const stores=[...db.objectStoreNames];const counts={};for(const store of stores){counts[store]=await new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).count();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}return {version:db.version,stores,counts}}finally{db.close()}});
 for(const key of ['notes','sources','links'])if(!receipt.idb.stores.includes(key))throw Error('Missing actual IDB store '+key);
 test('actual extension IndexedDB schema','PASS',receipt.idb);
 await page.screenshot({path:join(out,'actual-extension-library.png'),fullPage:true});
 receipt.status='SMOKE_PASS';
}catch(error){receipt.status='BLOCKED';receipt.error=String(error.stack||error);test('native extension journey','BLOCKED',String(error));}
finally{await context?.close();receipt.finishedAt=new Date().toISOString();writeFileSync(join(out,'native-smoke.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));}
