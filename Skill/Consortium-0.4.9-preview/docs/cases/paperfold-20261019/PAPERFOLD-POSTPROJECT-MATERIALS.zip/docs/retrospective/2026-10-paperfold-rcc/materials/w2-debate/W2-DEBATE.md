# W2 Debate — evidence-bearing challenge and revision

**Case:** PAPERFOLD-UI-20261016 · **Task:** `w2-debate` · **Role:** W2, Consortium I · **Independence:** I0 SHARED *for this round*, following the original I2 BLIND submission. **Not an adjudication.**

**Source identity:** SHA-256 `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10`, verified against the uploaded 76-entry v0.8 manifest. Git data absent. Original W2 proposal is preserved verbatim at `ORIGINAL/W2-PROPOSAL.md`, and its complete 46-entry original delivery is preserved as `ORIGINAL/W2-INITIAL-DELIVERY.zip` (SHA-256 `ca170f7bae712c7289362b5119d226a69acb58bdece0cc56db9335edd5288ba3`). Nothing in the original has been overwritten.

## 1. The shared problem; what is and is not measured

All candidates reject the monolithic vertical composition of `sidepanel.html:10–22,28–40,94–211` and preserve CodeMirror, `db.js` object identity, and gated Discover/Query. They differ in **where the user begins an inquiry** and in **what happens at the transition between a Source and a Card**. A suite's count cannot decide the architecture: W1's 111 granular source capabilities, W2's 48 feature groups and W3's 52 feature groups use different units of analysis; similarly, 57/95/67 fixture tests are not a normalized comparison of task performance.

These objections are **risk hypotheses supported by proposal structures**, not observations of users failing an implemented extension. The revised fixture is a local visual interaction witness, not a production save, browser capture, CM6 caret test, real permissions test or deployment witness. W4 alone selects a canonical architecture.

## 2. Challenge to W1 — editorial/writing-first

**Strongest quality:** W1 protects the expensive cognitive state of writing: a remembered Card, constrained CM6 editor, Live/Reading as modes rather than pages, and contextual Sources drawer; reference `W1-PROPOSAL.md §1, §2 WRITE, §4 J1, §6`. Its emphasis on returning the caret to the correct Card is a stronger transaction boundary than the **original** W2 fixture's direct insertion into the currently loaded textarea.

**Most consequential UX failure risk:** The current Card owns the landing view even when the research task is retrieval. A user seeking a saved quotation must change mode, go to Library or Search, inspect provenance, then return. Under `≤699px`, four destinations are `Write | Boards | Library | More`; *Search* and *Sessions* live inside More (`W1 §2, §3 S05/S08`). The separate Library/Search journeys may create a detour through two retrieval entrypoints, and source-to-Card context may be lost when the editor takes priority. This is a **proposed topology risk**, not measured search latency.

**Everyday journey W1 handles better than W2:** Editing a long Card, opening its linked DOI or annotation from the Sources drawer, inserting a citation, and resuming the same selected sentence without selection/undo loss. W1 §4 J1 and §6 explicitly carry this contract; the W2 original demo did not choose a destination Card before insertion. If the dominant daily job is uninterrupted note writing, W1 may outperform W2.

**Real narrow Side Panel constraint:** At 280–320 CSS px the editor's formatting controls, title, source drawer, save feedback and navigation cannot share permanent horizontal space. W1 proposes 5 visible formatting controls plus Format overflow (`W1 §6`), bottom navigation and a full-height source sheet (`W1 §5`). The challenge is the **transition back**: a sheet dismiss must restore exact CM6 selection and focus, and hidden Search/Sessions must remain discoverable without command-palette literacy. A screenshot cannot prove either. Concrete hostile probe: 280px at 200% zoom, cursor inside Markdown, reopen a long annotation, insert and undo; verify unchanged editor state and no occluded primary action.

**Design-changing insight for W2:** Source citation cannot simply execute against an assumed active editor. A real destination must be named and acknowledged before any insertion, and there must be a one-action return from that Card to the originating source.

## 3. Challenge to W3 — contextual/Board-first

**Strongest quality:** W3 expresses Board + active Card + current/linked Source as **independent IDs forming a continuous working context**, not one generic entity. It makes browsing-to-capture-to-writing part of a single journey while Session stays a separately protected browser state (`W3-PROPOSAL.md §A–D`, especially J1). The explicit command-adapter proposal (`W3 §B`) is a useful Stage II interface responsibility, though those commands are **not** current APIs.

**Most consequential UX failure risk:** Default Context invites a Board decision before some genuinely unassociated evidence inquiries. A researcher checking an unrelated bibliography reference or bookmark may not know—or want to decide—which Board governs it. A Board selector in a 280px shell can also imply false default membership if context leaks into a capture commit. W3 explicitly says it does not force Board assignment; nevertheless the navigation's visual primacy (`Context | Write | Library | Find | Sessions`, `W3 §A–C`) must pass a **Board-less first-capture** test. This is a risk of the IA emphasis, not proof of a forced Board in code.

**Everyday journey W3 handles better than W2:** While browsing within an established research Board, capture selected text, annotate it, attach it to the active Card and return to writing. W3 makes current page and Board question visible from Context, reducing contextual reconstruction (`W3 §C compact Context, §D J1`). The original W2 Library-first flow can require choosing or reconstructing Board/Card association after retrieval.

**Real narrow Side Panel constraint:** W3 has five compact bottom destinations, a Board selector, Capture, and More in the 280px shell (`W3 §C1, §E`). At 200% scaling, these must remain labeled, operable with keyboard and screen reader, and not require inaccessible horizontal dock scrolling. W3 reports a 3px fixture overflow corrected with wrapping/scroll fallback (`W3 §E`), which is **fixture evidence, not real browser zoom proof**. Falsifier: at 280px / 200% native zoom, the Sessions destination or Capture button is unreachable without horizontal pan or focus fails to return after a dialog.

**Design-changing insight for W2:** Preserve a lightweight *working thread* (last Source and active Card) across Library→Write without establishing a new Board-owned workspace layer, loading an automatic tab history, or making Board selection mandatory.

## 4. Revision R1 of W2 (material, explicitly not a merged canonical candidate)

**Retained:** Library remains default; type-aware Sources, bookmarks, scraps, annotations, literature and files remain a **projection** across existing stores, never a new homogeneous DB entity. Boards and Cards remain separate; Sessions, prototype-gated Discover/Query Studio, Chrome native context menu, settings, three themes, and narrow single-pane rules stay unchanged. No permanent extra root tab, no generic Context landing, no AI dashboard, no auto-capture.

**Changed at the Source–Card seam:**

1. **Explicit destination:** `Insert citation` now opens a scoped dialog naming the selected source ID/provenance and target Card before mutating the in-memory fixture. Selecting a different Card warns that the citation appends at its end; the existing Card draft is retained. Cancellation has no mutation. In production, the operation MUST be transactional and must not report a successful save until IndexedDB acknowledges it; this fixture cannot implement that.
2. **Bidirectional handoff:** Library has a compact `Working Card → Resume Card` affordance. After source inspection, `Resume current Card` remains available in source detail. Cards has `Last evidence → Back to Source`. The latter restores source ID, Library query, type/Board filters and drill-down state in this fixture; actual CM6 selection/undo restoration remains a mandatory production test.
3. **Type guard:** Raw bookmarks and attachments with no verified citation anchor cannot use the fixture's `Insert citation` operation. An annotation or captured scrap uses its source reference when provided; this guard is **not** a claim that production can never cite a bookmark URL—the correct route is to establish a source/reference identity first.
4. **Width discipline:** Both handoff affordances wrap at ≤359px and introduce no new page or icon strip. At width ≥800px the existing rail/list/detail composition survives. No fixed app aspect ratio or third editor column is introduced.

### Revised task flow

```text
Library (Source + type + Board facets, no compulsory Board)
  → Source detail [inspect origin, id, linked Card]
  → Insert citation [source ID shown]
  → Choose target Card [explicit]
  → Confirm [fixture insertion only; no persisted-success claim]
  → Cards [retain original source ID; draft is not dropped]
  → Back to Source [restore query/facets/drill-down]
  → Resume current Card [one action]
```

R1 does **not** replace W1's focus-aware editor architecture or W3's cross-domain command-adapter proposal. It repairs a concrete deficiency in the original W2 candidate without displacing its collection-centered thesis. W4 should compare this revised seam against the unmodified competitors as evidence of responsiveness, not as proof W2 wins.

## 5. Discriminating tests for W4 and Stage II, not invented user-study results

| Probe | Candidate comparison | Falsifier and close negative control | Status |
|---|---|---|---|
| T1 Find source→cite→return | W1 Write-first vs W2 Library-first vs W3 Context-first | Count *intentional* navigation actions and wrong-Card insertions on 280 and 800px. Negative: citation targets a different Card than current. | R1 fixture 56 checks PASS; comparative human test UNVERIFIED |
| T2 Board-less capture | W3 active context vs W2 unassociated collection | Capture without selecting Board must not attach it to last active Board. Negative: user intentionally sets Board, association then must persist. | Design contract only, real Chrome UNVERIFIED |
| T3 Editor caret/undo | W1 editor drawer vs W2 R1 source drill-down | Cite at nonterminal selection, switch Card and return, undo in real CM6. Negative: same Card vs different target. Any wrong insertion, undo loss, or stale commit fails. | R1 demo textarea only; production UNVERIFIED |
| T4 280px native zoom | all | 100/150/200% browser zoom, 280/320/360/420/600/800px, three themes; no offscreen primary action or horizontal root overflow. Negative: long URL with 200% text. | R1 Chromium CSS-zoom proxy and width checks PASS; native Chrome UNVERIFIED |
| T5 Permission and prototype honesty | all | Denied site permission ⇒ no capture write; Discover cannot create typed edge; Query preview ⇒ no request before explicit send. Negative: allowed HTTPS needs real ack. | Fixture only; real Chrome UNVERIFIED |
| T6 Source identity survives mixed filters | W2 original vs W2 R1 | Facet then source→cite→Card→back, same source ID/query/facets. Negative: an excluded result must notify and offer explicit reset rather than silently display wrong object. | R1 fixture PASS for filtered round-trip; excluded-source production case UNVERIFIED |
| T7 Session identity isolation | all | Preview non-mutating, restore needs confirm and valid missing HTTP(S) tabs; negative: already-open and restricted URLs. | Source/spec only; live tabs UNVERIFIED |

The measured 56 assertions come from `REVISED-TEST-RECEIPTS.json`, not from W1 or W3. The earlier W2 suite (95 PASS) and seven baseline source suites are **inherited evidence** included in original ZIP, not freshly rerun in this round. These counts MUST NOT be used as comparative quality scores.

## 6. Applied method, evidence boundary and negative controls

**AntiSlop:** access boundary (one current source ZIP, three recorded proposals + verified closures, no private worker state); scope boundary (debate only, no release); source/version check (76 entries); architectural detector (no new DB store, no framework swap, no duplicate primary nav); interaction detector (source/target and cancel/no-write), narrow detector (280–800 screenshot and no root overflow), evidence detector (Chromium fixture != installed Chrome), product detector (Discover/Query remain gated). A close negative control, *different Card target*, exposed the original W2 shortcut and motivated R1.

**RMC:** compare/decide was the governing regime, with design-debug for the narrow citation seam. Inputs and stakes were framed by source object distinctions; each rival's strongest case was stated before failure risk; the rival-triggered falsifier (wrong-card citation) guided the minimal revision; non-comparable test counts were deliberately not ranked; remaining proof debts go to W4/Stage II instead of an invented winner.

**Adapted Visual Pipeline:** Evidence: source hash + W1/W2/W3 proposals and source anchors. Specification: R1 component delta (`REVISION-BOUNDARY-DELTA.json`). Composition: revised HTML/CSS/JS fixture. Preview: ten revised screenshots. Compare: old W2 seam vs R1, and W1/W3 stronger journeys. Diagnose: wrong target, lost return context. Correct: target chooser, bidirectional handoff, type guard. Validate: 56 fixture assertions, JavaScript syntax, ZIP entry CRC/hash. Handoff: this W2 noncanonical closure. Each changed UI boundary has requirement, size, token, state, interaction, theme, accessibility, reference, preview and acceptance fields in the delta JSON.

**Verified source anchors:** `manifest.json:42–44` (Side Panel route, no full-tab entrypoint); `db.js:1–8,89–100` (stores including `notes`, `maincards`, `memberships`, `cardEdges`); `sidepanel.html:28,94–97,137–180,715–740` (note editor, literature, annotations, session dialog); `session-ui.js:23,40,54` (`PF_SESSION_*`); `service-worker.js:109–115` (`EXTRACT_TAB`/`CAPTURE_SELECTION`); `prototypes/discover/*`, `docs/followup/03-UX-DISCOVERY-AND-QUERY.md` (prototype status). A source anchor warrants existence, **not** tested behavior.

**Official reference-system corroboration** (verified as documentation, not as Paperfold behavior): [Karakeep lists](https://docs.karakeep.app/using-karakeep/lists/) and [search syntax](https://docs.karakeep.app/using-karakeep/search-query-language/) demonstrate different retrieval facets; [WorldBrain Memex README](https://github.com/worldbrain/Memex) explicitly discusses full-text retrieval plus saved-page highlights/annotations; [Obsidian Web Clipper capture](https://obsidian.md/help/web-clipper/capture) separates inspected content, metadata and an explicit save. W2 borrows the *inspect → explicit act* principle, not their data engines, accounts, permissions or automation.

**Risks/debts:** W1's 111 granular relocation rows vs W2's 48 grouped rows are not yet proven semantically equivalent. Review the named W1 row-level map against W2 before claiming complete parity (see `FEATURE-GRANULARITY-AUDIT.md`). Real Chrome v0.8 runtime, actual CM6, IndexedDB transaction acknowledgment, 200% native zoom, screen readers, archive restore, host permission denial, Drive/LAN, and an installed full-tab route remain UNVERIFIED. No direct production files or user Chrome profiles were modified. No other workers were created.

## 7. W2 debate-scoped decision and reopen condition

**W2 contribution, not adjudication:** preserve collection-first entry, adopt R1 explicit Source→target Card handoff and return-context control; reject simply adding a dedicated Context root or silently inheriting the editor's current Card ID. Keep W1 writing-fidelity and W3 Board-context continuity as serious competitors to be measured. W4 must choose the Stage I canonical architecture.

**Reopen if:** a verified W1 granular source feature lacks any W2 relocation, a production CM6 test shows R1 loses selection/undo or edits the wrong Card, the 280px real Side Panel hides a return/citation action at 200% zoom, or an observed user task shows retrieval/context overhead materially exceeds a rival. These are falsifiers, not speculative failure claims.
