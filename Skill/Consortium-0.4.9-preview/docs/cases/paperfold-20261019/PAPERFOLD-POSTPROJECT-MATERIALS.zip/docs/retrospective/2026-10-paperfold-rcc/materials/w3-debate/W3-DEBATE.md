# W3 — Recorded challenge and material self-revision

**Case:** `PAPERFOLD-UI-20261016` · **Task:** `w3-debate` · **Role:** same W3 room, I0 SHARED **during debate only**. This document is not W4 adjudication and makes **no** canonical selection. **Source identity:** `6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10` (verified actual ZIP). All 76 source paths matched the supplied manifest. No original source, IndexedDB, Chrome permissions, runtime profile, or other designer's deliverable was modified.

## 1. Access, prior decisions, and evidence admissibility

Read the three **recorded original** proposals from the supplied dependencies; verified their archived hashes against `DEPENDENCIES.json`:

| Role | Original proposal | Artifact SHA-256 | Scope of evidence |
|---|---|---|---|
| W1 | `w1/recovered/PAPERFOLD-W1-EDITORIAL-HANDOFF.zip!/W1-PROPOSAL.md` | `ab9afb331c93a0df58b567620c5284d63c5727c444aacbc0bc8f0011bbf1e672` | Editorial navigation, 15 surfaces, 111 source-mapped relocation entries, fixture screenshots/tests; not extension behavior |
| W2 | `w2/recovered/PAPERFOLD-W2-RESEARCH-COLLECTION-WIREFRAMES.zip!/W2-PROPOSAL.md` | `ca170f7bae712c7289362b5119d226a69acb58bdece0cc56db9335edd5288ba3` | Library-first navigation, 15 surfaces, 48 grouped relocation entries, fixture screenshots/tests; not extension behavior |
| W3 | `w3/recovered/PAPERFOLD-W3-CONTEXTUAL-WIREFRAMES.zip!/W3-PROPOSAL.md` | `5a548e53aac9d0d66626c74c80ed9830af57c1d5142388a7b75d14d54887dc7f` | Context continuity, 15 surfaces, 52 grouped relocation entries, fixture screenshots/tests; no installed Chrome runtime |

The **original W3 proposal and its complete ZIP** are preserved byte-for-byte at `ORIGINAL/PAPERFOLD-W3-CONTEXTUAL-WIREFRAMES.zip` inside this debate delivery. New work lives exclusively in `REVISED-WIREFRAMES/` and the debate contracts. Source locations: `baseline/manifest.json` side panel entry; `baseline/db.js` stores `maincards`, `memberships`, `cardEdges`, `browserSessions`, `sessionRevisions`; `baseline/service-worker.js` handlers `CAPTURE_SELECTION`, `EXTRACT_TAB`, `PF_SESSION_PREVIEW`, `PF_SESSION_RESTORE`; original `sidepanel.html`/`sidepanel.js` monolithic view. Reference code is not a proof of runtime success. Relocation-entry totals use **different units of analysis**, so 111 vs 48 vs 52 is **not** a score.

## 2. Formal challenge of W1 — editorial / writing-first

**Strongest quality, affirmatively:** A Card is a stable working surface, not an optional tab wedged behind data management. W1's **J1** explicitly sequences Markdown editing, a Source drawer, citation insertion at the memorized cursor, and focus restoration, while preserving Board membership semantics and existing CM6 (`W1-PROPOSAL.md`, §§2, 4, 6; `WIREFRAMES/index.html`; `evidence/fixture-280-paper.png`). That is a stronger *editing-first articulation* than W3's original Context landing. Its rejection of a framework rewrite directly matches `cm-editor.js` and user data-preservation constraints.

**Most consequential foreseeable UX failure:** Making **Write** the default and relegating **Search and Sessions to More** risks turning source inspection and browser recovery into exceptional side tasks. A person starting from a saved article must first leave the writer before source provenance is inspectable; a person rescuing tabs must discover a hidden route. W1's Library stays top-level, but the *source detail → evidence evaluation → return-to-result context* is not the dominant flow. This is a **design risk**, not a witnessed failed Chrome action or a claim the W1 prototype cannot navigate.

**Everyday journey where W1 beats W3:** A researcher already writing a complex Markdown argument wants to insert an annotated quote at an exact cursor position, undo it, and continue typing. W1 J1 is a direct, first-class user journey and its 280px fixture shows the note/editor and source action together. Original W3 asks the user to orient to Board context before choosing Write (unless retained state is already in Card). The W1 proposal has a better specified caret-and-citation acceptance path, though **real CM6 persistence remains untested for both**.

**Concrete narrow-side-panel challenge:** At 280px, W1's bottom navigation has four destinations; nevertheless its writing surface must accommodate card selector, Board reference, formatting, reader switch and Source drawer. The captured `evidence/fixture-280-paper.png` illustrates how these controls consume much of the first viewport before body text. More is a reachable but additional step for Sessions/Search. Test at 280px with 200% native browser zoom and an open Source panel—do not equate a CSS screenshot with that outcome.

**Falsifier of critique:** If cold-start library retrieval, source inspection and Session recovery are completed by untrained users with equal-or-fewer navigation actions and without loss of result/caret state compared with W3, the asserted retrieval friction is defeated.

## 3. Formal challenge of W2 — research collection / Library-first

**Strongest quality, affirmatively:** W2 unifies discoverability of saved heterogeneous evidence without collapsing Source, annotation, Capture, bookmark or Card into one owner. Its `Library → source detail → provenance/DOI → associated Cards → explicit citation` flow and `Back to Library` behavior are the clearest **source verification and re-entry contract** among the recorded proposals (`W2-PROPOSAL.md`, §§Proposed IA and J1–J3; `PREVIEWS/library-280-paper.png`, `PREVIEWS/detail-320-paper.png`). The 280px screenshot visibly labels object kinds instead of relying on an abstract knowledge icon.

**Most consequential foreseeable UX failure:** Library-first as a *standing landing state* can fragment the browsing→capture→active-Board→draft arc, particularly when Board context and a selected Card are required but not visible on the Library results screen. A user who repeatedly clips evidence into one evolving note incurs contextual destination selection; a newly captured object may appear collected without clear next interpretive action. W2 addresses lineage and Card insertion in J2/J5, so this is a **cost hypothesis**, not a claim of missing functionality. Its proposed generic Library projection needs integration/query semantics that the baseline does not yet prove for all object types.

**Everyday journey where W2 beats W3:** A user has forgotten where an annotated source was saved but remembers its host/phrase. W2 gives type filters, text search and detailed provenance from the landing Library without first selecting a Board; W3's earlier `Context` view privileges the current Board and sends historical retrieval to Library/Find. This difference matters with no selected Board and with sources independent of Cards.

**Concrete narrow-side-panel challenge:** W2's 280px `PREVIEWS/library-280-paper.png` puts Search, Type, Board and Sort above the first full source record: explicit controls aid discovery but consume vertical space, especially at 200% text scaling. Its source detail must be drill-down with a reliable Back-to-results token; three-pane desktop treatment cannot be squeezed into the Chrome Side Panel. Sessions live under More at ≤359px, creating a discoverability tradeoff similar to W1.

**Falsifier of critique:** If ongoing capture into an active Board+Card from the W2 Library route requires no extra target confirmations and preserves selection/caret with a comparable task error rate to W3, the supposed context-fragmentation penalty is defeated.

## 4. Self-critique of original W3

The first W3 screenshot `receipts/W3-320-context-paper.png` shows **five** compact nav buttons `Context | Write | Library | Find | Sessions`. The label **Context** forces a conceptual decoding step, and five labels are fragile at 280px/200% scaling even if fixture layout technically fits. More seriously, W3's original `data-source` action opens a generic Source modal rather than a **stable source identity inspection route**. The original `route()` cleared `state.filter`, so returning from inspected evidence could discard the retrieval trail. Original Board switch could silently select the first member Card; selecting an unlinked Card could silently change Board context. These are verified **fixture source-code risks**, not failures observed in a real extension.

**Material revision proposed for adjudication (not adopted canonically):** Preserve **continuity of independent object IDs** but make the Board entry explicit, reduce compact destinations, and add a reversible Source-detail route. The delta is intentionally narrow; W3 does **not** incorporate W1's editor-first landing or W2's Library-first landing wholesale.

1. **W3-R01 / Name and density:** Four compact nav destinations `Boards | Write | Library | Find`; existing wide rail retains explicit `Sessions`. Chrome Side Panel Sessions is in the **visibly labeled More** menu, **first item**, and in the Board's `Current browsing → Sessions` contextual link. **Tradeoff:** from a non-Board screen, direct Session access grows from one nav click to More→Sessions (two). The 4-slot grouping is visually less brittle than five compressed labels; verify first-click discovery with humans before adoption.
2. **W3-R02 / Source route:** `Library/Find → Source detail → Back to originating results`. Preserve current Library type and filter or Find query. Source detail displays type, origin URL, Board association as filter (not ownership), explicit provenance limits and citation handoff. It does not claim DOM TextQuote/DOI retrieval. This borrows W2's *specific repair to retrieval continuity*, not its root architecture.
3. **W3-R03 / Editor handoff:** Source-to-Card citation is an explicitly labeled **fixture-only** action; selected token is inserted at the remembered in-memory draft selection. The acceptance test uses a deliberately non-terminal cursor. W1's stronger real CM6 transaction specification remains the implementation criterion, not something fixture insertion certifies.
4. **W3-R04 / No implicit context mutation:** Switching Board does not change active Card ID. Opening a Card from global Library does not silently change active Board ID or create a `membership`; an unlinked Card renders an explicit warning. This clarifies W3's central principle under an adversarial near miss.
5. **W3-R05 / Non-obscuring status:** The original fixture status announcement obscured Session preview and Source detail in screenshots. Status has been moved into normal document flow with `aria-live=polite`; navigation clears stale announcement. Screenshot preview updated. This is a demonstrated local diagnosis/correction, not cosmetic full-app certification.

### Revision acceptance and defeating evidence

| Claim | Observed fixture result | Required real-app falsifier before final adoption |
|---|---|---|
| Four compact destinations never overflow at 280–600px | `REVISED-WIREFRAMES` Playwright `no_root_overflow_*` PASS | Actual Side Panel @ 200% and keyboard focus reveals clipped/unreachable primary navigation |
| Sessions remain discoverable | More→Sessions PASS; Board `Current browsing` link retained | ≥2 of 10 untrained users cannot find recovery in 45 s (threshold proposed, not measured) |
| Source-return retains retrieval context | Library filter + kind and Find query round trips PASS | Real results selection/scroll/caret lost, or filter/query silently reset after provenance inspection |
| Source insertion keeps exact draft insertion point | Mid-string fixture citation PASS | Any wrong-Card insertion, lost CM6 selection, undo or persistence mismatch in real extension |
| Cross-Board Card opening makes no implicit ownership change | Fixture Board/Card IDs unchanged and warning PASS | Existing membership/edges silently mutated or identity swapped in real data |
| Restrictions are truthful | Gated Discover/Query, denied permission, disabled restore and no outbound requests PASS | Any hidden edge write, automatic external query, tab restore or deceptive Saved feedback |
| The contextual opening reduces switching vs both rivals | **UNVERIFIED**: no participant A/B study | Representative task timings/error rate show Board-first overhead exceeds benefit |

An intentional **counterargument** remains unresolved: hiding Sessions in More may worsen recovery discoverability more than four-slot navigation helps. W4 should treat that tradeoff as live; a recoverable Session badge/CTA on Context may only appear if there is a genuine recovery condition, never as a fake notification.

## 5. Per-component adapted Visual Pipeline record

Baseline unchanged for the other 11 W3 component boundaries; `ORIGINAL/...zip!/COMPONENT-AND-RESPONSIVE-CONTRACT.md` retains **W3-S01–S15**. Changed boundaries undergo explicit Evidence → Specification → Composition → Preview → Compare → Diagnose → Correct → Validate → Handoff:

| Contract | Surface/journey & real source | Tokens / viewport / states / accessibility | Preview, comparison, diagnosis, correction | Acceptance |
|---|---|---|---|---|
| W3-R01 | S01/S03/S08/S15, Board and recover Session; `sidepanel.html/js`, `session-ui.js` | Source `--bg/--text/--accent`; 280,320,360,420,600,800,1200; nav current/available, More closed/open; labeled buttons, keyboard tab order | Original W3 320 screenshot had 5 tab labels; revised 320 and 280 previews with 4 plus explicit More; W2/W1 both demonstrate 4-slot space economy | Fixture 7 root overflow checks + More→Sessions pass; actual Zoom/Chrome not witnessed |
| W3-R02 | S04/S05/S09, inspect saved Source then return; `provenance.js`, `sidepanel.js` | No new colors; intrinsic text wrapping, single-pane ≤600; type/URL/context/empty/error are separate; Back button focusable, provenance readable | W2 `detail-320` makes retrieval route explicit; W3 original modal lacked inspect-return; revised `W3-DEBATE-320-source-paper.png` inspected and reworked | Fixture Library type/filter and Find query roundtrips pass; real TextQuote/scroll-focus continuity unverified |
| W3-R03 | S02/S09, Card insertion; `cm-editor.js`, `markdown.js` | Accent only on deliberate primary action; 280–1200; source selected/citation inserted/unsaved/error; keyboard caret target, SR-status confirmation | W1 J1 prioritizes caret; source-to-Card fixture tested with nonterminal cursor after leaving view; no CM6 in fixture | Exact string offset assertion passes; production save/undo/IME unverified |
| W3-R04 | S03/S04/S08, Board filtering with shared Cards; `db.js`, `card-model.js`, `session-model.js` | Warn tone on unlinked Card, no implicit write; Board selected/foreign Card; readable at narrow widths | Original W3 event handler auto-switched Card on Board selection; revised warning and state invariance tested | Board ID / Card ID assertions pass; no source-store writes |
| W3-R05 | S13/S15, feedback beside content; `sidepanel.css` | Inherit source theme; status announced/hidden; no pointer overlay, polite live region | First revised screenshot had status overlay obscuring Source metadata; moved to document flow; later preview re-inspected | Screenshot no overlapping status + existing Playwright checks pass; screen reader not witnessed |

No `@media` breakpoint is based on a false assumption of panel aspect ratio. Image/video aspect-ratio handling is unchanged; this revision does not introduce imagery. Full-tab, actual Chrome extension, multiple panes and display mode consistency remain Stage II/III acceptance responsibilities.

## 6. Methods actually applied and near-miss negative controls

- **AntiSlop/router + engineering:** access and scope separated across source, three verified original ZIPs, W3 revised fixture and unavailable installed Chrome. Audited `C/N/L` — architectural duplication, source provenance, route/focus/permission truth, and responsive overflows. Repaired **earliest failed dependency**: source inspection/return state and silent Board/Card change, rather than decorating menus. No simulated save is counted as persisted.
- **RMC controller + stage machine + task intent:** current question is one structured I0 debate, **not** redesign approval or production implementation. Compared three mutually distinct starting modes with explicit falsifiers, preserved category boundaries, stopped at scope-limited handoff. Original W3 I2 artifact is immutable; I0 review of peers begins only in this follow-up.
- **Visual Pipeline:** requirement IDs and state/size/theme/accessibility/source anchors above; HTML/CSS/JS composition is runnable; first preview exposed status-overlay defect; correction is visibly re-previewed and re-tested. Tests report their actual runtime rather than claiming Chrome extension safety.
- **Negative control NC1:** selecting a Card unlinked to selected Board does not change `board` or `memberships`; warn instead. **NC2:** loading Source detail and returning does not erase Find query or Library type/filter. **NC3:** clicking gated external Query, Discover Accept or recovery Restore does not execute action. **NC4:** fixture captures and citation insertions do not claim IndexedDB persistence. **NC5:** source truth remains pinned to v0.8, not v0.7. **NC6:** screenshot of 280px fixture is not a witness of native browser zoom.

`receipts/W3-DEBATE-TEST-RECEIPT.json` records **40/40 isolated Chromium fixture assertions passing**, including zero page errors and zero network requests. `node --check` completed with exit 0. A failed assertion during local development came from the *test locator itself* (`.item` included hidden inspector elements), and an expected-string offset typo; both were repaired by target-scoping and calculating the actual insertion index, then retested. That is not evidence the app had an observed citation corruption.

## 7. Official reference patterns: narrowly relevant, not evidence of Paperfold superiority

- Notion official sidebar guide, https://www.notion.com/help/navigate-with-the-sidebar — explicit navigation and pin/return semantics; transfer as a discoverability criterion, **not** infinite nested pages in a 280px Side Panel.
- Karakeep official search language, https://docs.karakeep.app/using-karakeep/search-query-language/ — source-type filters, query qualifiers; strengthens W2's retrieval hypothesis, but Paperfold does not thereby acquire equivalent indexing.
- Obsidian official web clipper guide, https://obsidian.md/help/web-clipper — selection/capture/metadata review quality target; **not** permission to copy vault architecture or expand Chrome permissions.
- Tiptap focus command documentation, https://tiptap.dev/docs/editor/api/commands/selection/focus — a selection-preserving editor command is an interaction criterion; **not** reason to replace installed CM6.

These official URLs are first-party reference descriptions, not measured comparisons, user testing, or runtime evidence. If a URL is unavailable in the consumer environment, retain it as a research pointer rather than a dependent assumption.

## 8. Handoff boundary and unresolved gate

W4 should compare W1 editing throughput, W2 provenance-first retrieval and W3 cross-context continuity, not total feature-count or screenshot count. The revision strengthens **W3** in response to critiques; it does **not** ask W4 to synthesize all candidates. No design winner is selected here. W3 debate owned exit: reading all three recorded original proposals, providing a serious four-axis challenge for each rival, identifying and validating a material own revision, preserving W3 I2 artifact and stating limitations. **PASS only for that scope**.

**Open debt:** Participant A/B and discoverability tests; real Chrome Side Panel 280–800px/200% zoom, keyboard+assistive tech, CM6 selection/undo/persistence, real source anchor resolution, permission denial, Session preview/restore, populated workspace migration and clean archive restore, full-tab entrypoint and production acceptance. Production deploy remains blocked.

**Reopen trigger:** a verified interaction showing Session retrieval hidden/unfindable, Card identity or Board membership silently changed, citation inserted in wrong Card/caret, lost source-result filters, any overflow/inaccessible primary action at 280–420px, unpermitted capture/tab/outbound action, or omitted source behavior in the preserved map. Send such evidence to W4 as a defeating observation; do not assert canonical precedence.
