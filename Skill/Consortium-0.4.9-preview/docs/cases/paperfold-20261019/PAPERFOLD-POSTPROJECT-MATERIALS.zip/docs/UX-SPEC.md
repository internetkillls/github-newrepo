# C — P0 UX and interaction contract

Visual direction: Paperfold Paper/Pure Black/System settings remain as delivered in v0.7. P0 adds one lightweight Session entry in the side panel. No new typography assets or unlicensed font distribution.

## Board surface

- Header button **B** opens Boards. Board = previously named Maincard; all existing Cards stay linked.
- `/board`, `/add-to-board`, `@board`, `@add-to-board` are primary commands; original variants remain compatible aliases.
- Legacy backing element IDs and fields are intentionally not renamed; renaming DOM IDs without complete JS integration breaks current UI.

## Sessions surface

```text
Paperfold side panel
├─ Current Card selector  [New] [Delete]
├─ Browser Sessions [Sessions]   (status and count)
├─ CM6 editor and source/annotation workflow (unchanged)
└─ Board / Search / Export tools (unchanged)

Sessions modal
  Saved Sessions [selector]
  Session name [text] [Rename]
  Associate with Board [selector] [Link] [Unlink]
  Tabs / groups / revision / status
  Revision history [selector]
  [Preview recovery] [Restore missing tabs...]
  Preview: missing URLs, skipped URLs, number of groups
```

## Journeys within P0

A. Automatic preservation: browser event → debounce → normalize → DB snapshot + revision; control shows saved Sessions after Refresh; no manual Save required.

B. Browser crash/restart: startup reconciliation marks orphaned Session `RECOVERY_NEEDED`; clicking Sessions lists it; Preview computes missing HTTP(S) tabs; Restore requires explicit confirmation.

C. Accidental closure: select an earlier revision → Preview → Restore missing URLs into a *new* window. Original open tabs are not closed. Native tab group reconstruction is best-effort for tabs created by this restore.

E. Board association: select Session and existing Board → Link Board. No Card is automatically created from any tab and no Card membership is changed.

L. Upgrade: user exports current v0.7 workspace before copying release files; on first v0.8 startup schema v5 adds two stores without renaming existing records; verify Cards, Boards and source annotations afterward.

## Pending interactions (P1–P4)

Group drag/drop; browser bookmark folder conversion; search across closed history; popup/full-tab management; New Tab override; suspended restoration; device-level conflict resolution; bulk graph layout. These controls are intentionally not shown as if implemented.

## States and accessibility

Empty: 'No session captured yet.' Status text is announced with `role=status`.
Failure: visible error in Session preview and header status; Restore disabled on failures or unpreviewed revisions.
Permission: graceful omission of group metadata when tabGroups querying fails; existing tab list still saved.
Preview: no mutation; Restore disabled until a successful preview finds missing tabs.
Confirmation: clear count and new-window promise; user must confirm.
Motion: no added animation; inherited Paperfold color tokens; pointer and keyboard-accessible native dialog fields.

## Settings contract for P0

No new configurable policy switches yet. Autosave is enabled by extension runtime; snapshot coalescing is 350ms, period alarm is 1 minute and revision cap is 60. These are internal conservative defaults, not deceptive no-op settings. Optional restore modes, history permissions, tagging taxonomies and sync policies are deferred until witnessed browser behavior exists.
