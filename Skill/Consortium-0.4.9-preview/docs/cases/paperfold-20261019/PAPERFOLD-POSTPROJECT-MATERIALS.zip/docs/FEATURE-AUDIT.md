# A — Paperfold P0 source-grounded feature audit

Input: `Paperfold-v0.7.0(2).zip`, 53 ZIP entries. This report compares v0.7 source implementation with the supplied Session Manager Contract. The original ZIP was not modified. TabXpert screenshots were referenced in the contract but were not available as viewable image attachments; no screenshot observations are asserted.

Statuses: `SOURCE-OBSERVED`, `PARTIAL`, `ABSENT`, `UNVERIFIED`. SOURCE-OBSERVED is not BROWSER-WITNESSED.

| Requirement | Original v0.7 status | Source evidence / implementation boundary | P0 delivered in 0.8 staging |
|---|---|---|---|
| Manifest MV3, side panel | SOURCE-OBSERVED | `manifest.json` declares service worker, sidePanel, tab permissions | Preserved |
| Notes/Cards and Markdown | SOURCE-OBSERVED | `sidepanel.js`, `cm-editor.js`, `db.js:notes` | Preserved, no DB record rename |
| Boards (legacy Maincards) | PARTIAL naming | `card-model.js`, `db.js:maincards,memberships,cardEdges`, `sidepanel.html` still displays Maincards | Board display name and `/board`, `@board`, plus command aliases |
| Source/annotation capture | SOURCE-OBSERVED | `service-worker.js`: EXTRACT_TAB, CAPTURE_SELECTION, HIGHLIGHT_ANNOTATION | Preserved; independent browser QA still required |
| Bookmark handling | SOURCE-OBSERVED | `db.js:bookmarks`, `sidepanel.js` bookmark UI, `chrome.bookmarks` | Preserved, no new scope conversion |
| DOI/literature | SOURCE-OBSERVED | `literature.js`, `service-worker.js` metadata access, `sidepanel.js` dialogue | Preserved; live DOI API not witnessed |
| Existing tags/YAML | PARTIAL | `yaml.js`, `workspace.js` projections; no universal session tag model | Deferred |
| Search/indexing | PARTIAL | `embedding.js`, `workspace.js`; note/source chunk search | Unified Session/bookmark search deferred |
| Automatic session tracking | ABSENT | No browser-session store or background session observer in v0.7 | New `browser-sessions.js`, event-based checkpointing |
| Stable session identity | ABSENT | Browser tab and window IDs not modeled | UUID session and tab record IDs, runtime IDs excluded from snapshots |
| Session revisions | ABSENT | No revision store in v0.7 `db.js` | `sessionRevisions` store, up to 60 revisions per session |
| Crash recovery | ABSENT | No session restore path | Missing-tab preview, explicit restore, `RECOVERY_NEEDED` state; actual crash witness outstanding |
| Native tab groups | ABSENT as durable session data | `tabGroups` absent in v0.7 manifest | Preserve saved group membership/title/color/collapse; full drag/drop deferred |
| Session ↔ Board association | ABSENT | No Session entity | `boardIds` on Session refer to legacy `maincards.id` |
| Session bookmarks/closed-tab history | ABSENT | Original bookmarks and logs not logically session-bound | Deferred; revision history is not a universal closed-tab ledger |
| Cloud backup | PARTIAL | `service-worker.js` Google Drive backup and local sync config | No new cloud session syncing; local archives include sessions; scheduled cloud sessions excluded |
| Multi-device conflict resolution | ABSENT | `sync.js` supports coarse timestamp merges of workspace records | Deferred; session `profileScope` local-only |
| Popup, full management tab, dedicated window | ABSENT | `manifest.json` side panel only | Deferred |
| New Tab replacement | ABSENT | No `chrome_url_overrides` | Deferred |
| Tab suspension and scalable restore | ABSENT | No discard/lazy tab manager | Deferred; P0 opens only missing tabs |
| Native browser history | ABSENT | No `history` permission | Deferred; history permission not requested |
| Backup restore import | ABSENT/UNVERIFIED | Export generator and archive verifier exist; no general in-extension restore import | Archive now includes session objects; clean-room restore not implemented |
| UI/accessibility end-to-end | UNVERIFIED | Source markup exists; no browser receipt for this revision | Mock and static checks only; Chrome witness needed |

**Known misclassification to avoid:** a Board is a persistent research perspective, not a Chrome window; a Session is a recoverable browsing context, not a durable Card. Legacy store/field names `maincards`, `maincardId` remain compatibility schema; they are not user-facing product terminology.
