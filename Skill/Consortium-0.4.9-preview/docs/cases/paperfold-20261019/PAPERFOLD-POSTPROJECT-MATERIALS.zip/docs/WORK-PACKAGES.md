# D — Phased implementation packages

| ID | Package | Verification gate | Status |
|---|---|---|---|
| P0-01 | Baseline inventory, immutable input copy | Source audit anchored to actual paths | SOURCE-OBSERVED |
| P0-02 | Additive v5 store transaction + revision retention | Commit unit scenario; no changes to old store schema | CODE-WRITTEN / UNIT-TESTED (mock repo) |
| P0-03 | Event observer, coalescing, stable session matching | Repeated snapshots do not duplicate IDs; navigation adds revision | UNIT-TESTED (mock browser) |
| P0-04 | Restart/restore preview and URL deduplication | Missing/restored-only tabs; source revision unchanged | UNIT-TESTED (mock browser) |
| P0-05 | Session–Board reference + Board wording | Board records unchanged; legacy commands still resolve | STATIC-CHECKED / UNIT-TESTED |
| P0-06 | Local archive coverage | Manifest counts + database/session files in `.wv.tar.gz` | UNIT-TESTED |
| P0-07 | Chrome isolated-profile restart witness | Real launch, 2 windows, group, kill/restart and recovery | UNVERIFIED, required before production deployment |
| P1 | Drag/drop groups, bookmark folders, unified search | Chrome browser integration tests | DEFERRED |
| P2 | Cross-profile device sync and restore import | Offline conflicts and round-trip on two profiles | DEFERRED |
| P3 | Popup/full-tab settings surfaces | UI parity and keyboard tests | DEFERRED |
| P4 | Native discard/lazy restore performance | Measured 10/50/100/300-tab workloads | DEFERRED |

No remote GitHub change, active-profile change, or destructive migration is performed in this build.
