# B — P0 Architecture Decision Record

## ADR-001 — Distinguish research graph from browser runtime

**Accepted for staging:** Board = legacy `maincards` record, Card = `notes`, Source = `sources`, their links/memberships/typed edges remain unchanged. Session = separate `browserSessions` record containing saved ordered Tab Records, native group metadata, and `boardIds`. A session record never owns or cascades deletion into research stores. `boardIds` is a reference, not a parent-child containment rule. One Board can be referenced by multiple Sessions.

**Rejected:** reinterpreting Maincards as Sessions, deleting Cards on Session close, persistently relying on Chrome tab/group/window IDs.

## ADR-002 — Additive IndexedDB v5

Two new stores only: `browserSessions` (indexed `updatedAt`, `status`) and `sessionRevisions` (indexed `sessionId`, `createdAt`). Existing DB name `tabwoven-notes` and original 17 stores remain unchanged. `commitSessionCheckpoint` writes parent plus revision in a **single readwrite transaction**, pruning oldest revisions beyond 60. Existing `maincards`, membership keys and IR schema are retained.

**Tradeoff:** Data format is forward-only relative to v0.7; older extension code cannot simply open schema v5. A verified separate pre-install `.wv.tar.gz` copy is mandatory. Export success alone does not prove successful restore.

## ADR-003 — Event-driven checkpoints

`service-worker.js` binds `browser-sessions.js` at import. Chrome tab/window/group events are coalesced to 350ms then reconciled through `windows.getAll({populate:true})` and `tabGroups.query`. A periodic alarm (one-minute reconciliation) supplies an additional opportunity to catch up. Changed snapshots increment the existing logical Session revision; equal content hashes cause no new revision. Changes to identity or display metadata do not fork a logical session. Last 60 revisions retained.

**Boundaries:** polling is not a zero-loss crash guarantee; unexpected process termination before a committed checkpoint can lose recent changes. Actual latency and revision compaction have not been measured in Chrome.

## ADR-004 — Recovery is explicit, duplicate-averse

At startup, unmatched previously ACTIVE sessions become `RECOVERY_NEEDED`. Matching uses conservative ordered URLs/pinned signature; ambiguous matches do not auto-merge. Restore is **user-confirmed**, creates a separate window for missing HTTP(S) URLs, skips already-open same URLs, attempts native group reconstruction, and preserves source revision unchanged. It does not claim restoration of form state, scroll, cookies, login state, post data, or JS heap. Tabs with Chrome-internal URLs are excluded. A restored window is a new logical working session.

**Rejected for P0:** automatic reopening on startup, closing/replacing existing tabs, matching unrelated sessions by fuzzy similarity, undoing Chrome's native restore.

## ADR-005 — Privacy and backup boundaries

Incognito windows are ignored. Known token-looking URL query keys and fragments are stripped from persisted URLs; this does not guarantee removal of every private identifier embedded in paths or unconventional queries. No content/cookie/form-body collection is introduced by session tracker. Session history is included only in explicit local `.wv.tar.gz` workspace exports; existing scheduled Google Drive and LAN metadata sync do **not** start uploading it automatically. `tabGroups` permission is added. Browser-wide `history`, `sessions`, and broad host permissions are not added.

**Future decision:** P2 sync requires per-device identity, per-operation IDs/conflict handling and user consent, not `updatedAt` last-write-wins. Cloud backup and cross-profile editing are distinct.

## ADR-006 — Board nomenclature without schema rename

The displayed title, control captions, modal explanation, and commands use Board. Legacy `/maincard`, `@maincard` remain aliases, while `maincards`, `maincardId`, `tabwoven.*` archive schema strings remain internal compatibility boundaries. New Markdown Board projections use `.board.md`. Legacy `.maincard.md` exports can still be read as Markdown; no existing note is renamed on disk by the upgrade.

## Alternatives not chosen

- A parallel database with duplicated research records: rejected due to reconciliation and data-loss risk.
- `chrome.storage.local` only: tempting for Sessions but lacks compound IndexedDB revision transaction and indexes.
- An always-running background timer: inappropriate for MV3 service worker lifecycle.
- Immediate cloud sync: unsafe without conflict and privacy gates.
- Full tab manager/graph redesign first: does not improve durability until session invariants pass.
