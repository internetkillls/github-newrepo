/**
 * Independent red-team regression specification for Paperfold v0.8 Discover.
 * Run: node Paperfold-v0.8-Discover-Adversarial-Tests.mjs /path/to/paperfold
 * Exits nonzero while contract violations remain; this is NOT a green baseline test.
 * No network or writes to the supplied Paperfold project.
 */
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root=resolve(process.argv[2]||process.cwd());
const {validateQueryPlan}=await import(pathToFileURL(resolve(root,'prototypes/discover/query-ast.js')).href);
const {buildLexicalProfile,proposeCrossBoardLinks}=await import(pathToFileURL(resolve(root,'prototypes/discover/lexical.js')).href);
let passes=0,failures=0;
function test(name,operation){
  try{operation();passes++;console.log(`PASS  ${name}`)}
  catch(error){failures++;console.log(`FAIL  ${name}\n      ${error.message}`)}
}
const q=(terms,other={})=>validateQueryPlan({provider:'google',terms,...other});
test('Control chars are rejected consistently across consecutive calls',()=>{
  assert.throws(()=>q(['x\ny']),/printable/);
  assert.throws(()=>q(['a\nb']),/printable/);
});
test('Unstructured terms cannot add raw search operators',()=>{
  assert.throws(()=>q(['research','site:private-example.invalid']),/operator|literal|unsafe/i);
});
test('Impossible calendar dates are rejected',()=>{
  assert.throws(()=>q(['research'],{after:'2025-02-30'}),/date/i);
});
test('More than eight terms must not disappear silently',()=>{
  assert.throws(()=>q(['one','two','three','four','five','six','seven','eight','nine']),/term|eight|limit/i);
});
const sameDocument=[
  {id:'d1',approved:true,boardIds:['A'],title:'Feedback systems',text:'Feedback in visual loops'},
  {id:'d2',approved:true,boardIds:['B'],title:'Feedback systems',text:'Feedback loop design'},
  {id:'d1',approved:true,boardIds:['C'],title:'Feedback systems',text:'Feedback in visual loops'},
];
test('Proposed connection IDs are unique within one result',()=>{
  const ids=proposeCrossBoardLinks(sameDocument).map(x=>x.id);
  assert.equal(ids.length,new Set(ids).size);
});
test('Cross-Board suggestions require known Boards on both sides',()=>{
  const docs=[
    {id:'x',approved:true,title:'cybernetic pattern',text:'complex cybernetic pattern'},
    {id:'y',approved:true,title:'cybernetic pattern',text:'nonlinear cybernetic pattern'}
  ];
  assert.equal(proposeCrossBoardLinks(docs).length,0);
});
test('A normal query with a valid date is accepted',()=>{
  const x=q(['Bhaskar critical naturalism'],{after:'2025-02-28'});
  assert.match(x.query,/Bhaskar critical naturalism/);
});
test('Unapproved documents never appear in profile',()=>{
  const x=buildLexicalProfile([
    {id:'a',approved:true,text:'causal powers emergence'},
    {id:'b',approved:true,text:'causal powers and institutions'},
    {id:'secret',approved:false,text:'private neuroscience secret'}
  ]);
  assert(!x.docs.includes('secret'));
});
test('Related-to is a proposal, not a truth-claiming graph edge',()=>{
  const x=proposeCrossBoardLinks(sameDocument);
  assert(x.every(a=>a.type==='related-to'&&a.status==='PROPOSED'));
});

// Additional boundary cases: preserve all nine independent tests above, unchanged.
const rejects=(plan,re)=>assert.throws(()=>validateQueryPlan(plan),re);
const plan=(provider,terms,other={})=>({provider,terms,...other});
test('Control characters remain invalid across alternating valid/invalid inputs and structured scalars',()=>{
  for(const bad of ['x\ny','x\ry','x\0y','x\u001fy','x\u007fy']){
    rejects(plan('google',[bad]),/printable/);
    assert.match(q(['Filsafat ilmu dan ketahanan nasional']).query,/ketahanan nasional/);
    rejects(plan('google',[bad]),/printable/);
  }
  rejects(plan('google',['ordinary'],{exclude:['x\ny']}),/printable/);
  rejects(plan('google',['ordinary'],{site:'x\ny.org'}),/printable/);
  rejects(plan('google',['ordinary'],{filetype:'p\ndf'}),/printable/);
  rejects(plan('google',['ordinary'],{after:'2025-01\n01'}),/printable/);
  rejects(plan('duckduckgo',['ordinary'],{intitle:'title\nunsafe'}),/printable/);
  rejects(plan('duckduckgo',['ordinary'],{inurl:'url\nunsafe'}),/printable/);
});
test('Reserved or escaped literal operators are rejected, without punctuation overblocking',()=>{
  for(const operator of ['site:foo.bar','filetype:pdf','intitle:test','inurl:test','before:2025-01-01','after:2025-01-01','cache:example.org','allintext:topic','ext:pdf','source:news','link:example.org']){
    rejects(plan('google',['research '+operator]),/operator|literal|unsafe/i);
    rejects(plan('duckduckgo',['research '+operator]),/operator|literal|unsafe/i);
    rejects(plan('google',['research'],{exclude:[operator]}),/operator|literal|unsafe/i);
  }
  for(const unsafe of ['-foo','research -foo','"research"','research\\"escape','research\\escaped'])rejects(plan('google',[unsafe]),/operator|literal|unsafe/i);
  for(const safe of ['C++ programming','biaya: manfaat','Fides et Ratio','COVID-19','socio-technical methods','rasio 1:2']){
    assert.match(q([safe]).query,new RegExp(safe.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
  }
});
test('Provider-supported structured fields work, unsupported ones are refused',()=>{
  const google=validateQueryPlan(plan('google',['filsafat ilmu'],{site:'example.org',filetype:'pdf',before:'2025-02-28',after:'2024-02-29',exclude:['irrelevant']}));
  for(const fragment of ['site:example.org','filetype:pdf','before:2025-02-28','after:2024-02-29','-irrelevant'])assert(google.query.includes(fragment));
  const ddg=validateQueryPlan(plan('duckduckgo',['research'],{intitle:'critical realism',inurl:'method',site:'example.org',filetype:'pdf'}));
  assert(ddg.query.includes('intitle:critical_realism'));
  assert(ddg.query.includes('inurl:method'));
  rejects(plan('google',['research'],{intitle:'title'}),/unsupported/);
  rejects(plan('google',['research'],{inurl:'url'}),/unsupported/);
  rejects(plan('duckduckgo',['research'],{after:'2025-02-28'}),/unsupported/);
  rejects(plan('duckduckgo',['research'],{before:'2025-02-28'}),/unsupported/);
  for(const output of [google,ddg]){
    assert.equal(new URL(output.url).searchParams.get('q'),output.query);
    assert.equal(output.requiresExplicitExternalSearch,true);
  }
});
test('Date validation enforces Gregorian leap rules and exact formatting',()=>{
  for(const date of ['2025-02-28','2024-02-29','2000-02-29'])assert(q(['research'],{after:date}).query.includes('after:'+date));
  for(const date of ['2025-02-29','2025-02-30','1900-02-29','2025-00-01','2025-13-01','2025-01-00','2025-01-32','2025-2-28','2025-02-1','0000-01-01','2025/02/28','not a date'])rejects(plan('google',['research'],{after:date}),/date/);
});
test('Term shapes and limits cannot silently omit or bypass validation',()=>{
  for(const terms of ['a term',null,{},42])rejects(plan('google',terms),/array/);
  for(const entry of [null,undefined,[],{},42,{text:' '},{text:42},{text:'valid',exact:'true'},{text:'valid',exact:1}])rejects(plan('google',[entry]),/term|printable/);
  rejects(plan('google',new Array(2)),/term/);
  rejects(plan('google',Array(9).fill('topic')),/eight|term|limit/);
  assert.equal(q(['one','two','three','four','five','six','seven','eight']).query.split(' ').length,8);
  rejects(plan('google',['research'],{exclude:'advertisement'}),/array/);
  rejects(plan('google',[{text:'research',exact:true}],{exclude:['-invalid']}),/unsafe/i);
  rejects(plan('google',['x'.repeat(140),'y'.repeat(140),'z'.repeat(140)]),/400/);
});
test('Duplicate document IDs retain first valid record without duplicating pairs',()=>{
  const docs=[
    {id:'a',approved:true,boardIds:['board1'],sourceId:'source-first',title:'feedback loops',text:'feedback shared method'},
    {id:'b',approved:true,boardIds:['board2'],title:'feedback loops',text:'feedback different method'},
    {id:'a',approved:true,boardIds:['board2'],sourceId:'source-conflict',title:'feedback loops',text:'feedback shared method'},
  ];
  const proposals=proposeCrossBoardLinks(docs);
  assert.equal(proposals.length,1);
  assert.equal(proposals[0].id,'proposal:a|b');
  assert.equal(proposals[0].provenance.find(x=>x.docId==='a').sourceId,'source-first');
  assert.equal(proposeCrossBoardLinks(docs,{dismissedPairs:['a|b']}).length,0);
});
test('Proposal identities cannot collide when IDs contain separators',()=>{
  const docs=['a|b','c','a','b|c'].map((id,i)=>({id,approved:true,boardIds:['board'+i],title:'feedback loops',text:'feedback distinctive'+i+' model'}));
  const proposals=proposeCrossBoardLinks(docs,{maxResults:30});
  const ids=proposals.map(x=>x.id);
  assert(proposals.length>=4);
  assert.equal(ids.length,new Set(ids).size);
  assert(proposals.every(x=>docs.some(d=>d.id===x.leftId)&&docs.some(d=>d.id===x.rightId)&&x.leftId!==x.rightId));
});
test('Unknown, malformed, shared or private Board memberships never become cross-Board proposals',()=>{
  const base={approved:true,title:'feedback loops',text:'feedback meaningful model'};
  const invalid=[
    {id:'no-memberships'}, {id:'empty',boardIds:[]}, {id:'string',boardIds:'board1'},
    {id:'null-entry',boardIds:[null]}, {id:'blank',boardIds:[' ']},
    {id:'not-approved',approved:false,boardIds:['board8']},{id:'private',private:true,boardIds:['board9']}
  ].map(x=>({...base,...x}));
  const valid=[{...base,id:'one',boardIds:['A']},{...base,id:'two',boardIds:['A','B']}];
  assert.equal(proposeCrossBoardLinks(invalid.concat(valid)).length,0);
  const disjoint=[{...base,id:'left',boardIds:['A'],text:'feedback useful method'},{...base,id:'right',boardIds:['B'],text:'feedback differing model'}];
  assert.equal(proposeCrossBoardLinks(disjoint).length,1);
});
console.log(JSON.stringify({status:failures===0?'ALL_CONTRACTS_MET':'REPAIRS_REQUIRED',passes,failures}));
process.exitCode=failures?1:0;
