"""Real Chromium DOM/CSS + extracted ACTUAL W9 adapter functions; not an extension runtime test."""
import argparse, json, re, tempfile, shutil
from pathlib import Path
from playwright.sync_api import sync_playwright

p=argparse.ArgumentParser();p.add_argument('--patch',type=Path,default=Path.cwd());p.add_argument('--w9-source',type=Path,required=True);p.add_argument('--chromium',type=Path,default=None);a=p.parse_args()
js=a.w9_source.read_text()
def extract(a,b):
 assert js.count(a)==1,(a,js.count(a));return js[js.index(a):js.index(b)]
fragments=[extract('function initializeInteractionShell()','async function activateRoute('),extract('async function activateRoute(','function announceStatus('),extract('function openDialog(','async function reviewSourceCitation('),extract('function dismissPopover(','function fileTimestamp(')]
# W10 documented mechanical integration fix: data-pf-active synchronization is applied ONLY in the fixture.
# The deliverable NEVER changes sidepanel.js.
fragments[1]=fragments[1].replace('const active = node === view;', 'const active = node === view; node.dataset.pfActive = String(active);')
assert 'node.dataset.pfActive = String(active)' in fragments[1]
# Adapter functions are copied from frozen W9 source in memory. Stubs provide ONLY unavailable storage/CM6 state; no fake save implementation.
bridge='''const PF_ROUTES=new Set(['write','boards','library','find','sessions','explore','query','settings']);
const PF_FOCUS='button:not([disabled]),[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
const state={ui:{dialogOpeners:new Map(),popover:null,popoverOpener:null,route:'write',routeScroll:new Map()},settings:{}};
const elements={saveStatus:document.getElementById('saveStatus')};
function preserveEditorSelection(){ return null; }
function announceStatus(){}
function applyPaperfoldTheme(){}
window.__probeWrites=0;
document.getElementById('attachCurrentButton').addEventListener('click',()=>window.__probeWrites++);
''' + '\n'.join(fragments)+'''
initializeInteractionShell();
window.__pfProbe={state,openDialog,closeDialog,togglePopover,positionPopover,handlePopoverKeydown};
'''
html=(a.patch/'sidepanel.html').read_text(); html=re.sub(r'\s*<script type="module" src="(?:session-ui|sidepanel)\.js"></script>', '', html)
html=html.replace('<link rel="stylesheet" href="sidepanel.css" />','<style>'+ (a.patch/'sidepanel.css').read_text()+'</style>')
with tempfile.TemporaryDirectory() as temp:
 t=Path(temp);(t/'sidepanel.html').write_text(html);(t/'sidepanel.css').write_bytes((a.patch/'sidepanel.css').read_bytes())
 outcomes=[];examples=[]
 with sync_playwright() as pw:
  binary=str(a.chromium) if a.chromium else (shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome') or shutil.which('msedge'))
  opts={'headless':True};
  if binary: opts['executable_path']=binary
  browser=pw.chromium.launch(**opts)
  for w,h,theme in [(280,400,'black'),(320,700,'paper'),(800,700,'system'),(1110,400,'black'),(420,400,'paper'),(600,700,'system')]:
     context=browser.new_context(viewport={'width':w,'height':h},color_scheme='dark' if theme in ('black','system') else 'light',reduced_motion='reduce')
     page=context.new_page();page.set_content(html,wait_until='domcontentloaded')
     page.evaluate('(theme)=>document.documentElement.setAttribute("data-paperfold-theme",theme)','system' if theme=='system' else theme)
     page.evaluate(bridge)
     # Show Library route with ACTUAL W9 activateRoute; avoids manually cheating on CSS visibility.
     page.locator('[data-pf-route="library"]').first.click(); assert page.locator('[data-pf-view="library"]').is_visible(),('route',w,h,theme)
     opener=page.locator('#pfSourceContextTrigger');opener.click()
     menu=page.locator('#pfSourceContextPopover');assert menu.is_visible(),('popover not opening',w,h,theme)
     assert opener.get_attribute('aria-expanded')=='true'
     assert page.evaluate('document.activeElement?.getAttribute("role")')=='menuitem'
     bbox=menu.bounding_box()
     assert bbox and bbox['x']>=-1 and bbox['y']>=-1 and bbox['x']+bbox['width']<=w+1 and bbox['y']+bbox['height']<=h+1,('overflow',w,h,theme,bbox)
     assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),('root overflow',w,h,theme)
     # Sample WCAG text contrast for each theme against the opaque popover surface (not a full accessibility audit).
     contrast=page.evaluate('''() => {
       const fg=getComputedStyle(document.querySelector('#pfSourceContextPopover [role="menuitem"]')).color;
       const bg=getComputedStyle(document.querySelector('#pfSourceContextPopover')).backgroundColor;
       function lum(s) { const v=s.match(/[0-9.]+/g).slice(0,3).map(Number).map(x=>{const a=x/255;return a<=0.04045?a/12.92:Math.pow((a+0.055)/1.055,2.4)});return .2126*v[0]+.7152*v[1]+.0722*v[2];}
       const a=lum(fg),b=lum(bg);return {fg,bg,ratio:(Math.max(a,b)+.05)/(Math.min(a,b)+.05)};
     }''')
     assert contrast['ratio']>=4.5,('contrast',w,h,theme,contrast)
     # W9 keyboard roving and focus return.
     page.keyboard.press('End'); assert page.evaluate('document.activeElement?.textContent.trim()')=='Return to Card'
     page.keyboard.press('Home'); assert page.evaluate('document.activeElement?.textContent.trim()')=='Find related material'
     page.keyboard.press('Escape');assert not menu.is_visible() and opener.get_attribute('aria-expanded')=='false'
     assert page.evaluate('document.activeElement?.id')=='pfSourceContextTrigger'
     # W9 outside click. Must not write or commit.
     opener.click();page.locator('[data-pf-view="library"] h1').click();assert not menu.is_visible()
     # Route action from popover uses actual W9 activateRoute, never write.
     opener.click(); menu.locator('[data-pf-route="find"]').click()
     assert page.locator('[data-pf-view="find"]').is_visible() and not menu.is_visible(),('route menu',w,h,theme)
     # Capture global action stays disabled; the old W9 direct listener remains unsafe until repaired.
     page.locator('[data-pf-route="library"]').first.click()
     assert page.locator('#attachCurrentButton').is_disabled()
     assert page.evaluate('window.__probeWrites')==0
     # W9 must replace the legacy direct listener before enabling capture. Use an enabled fixture opener to measure W9 dialog focus restoration.
     page.evaluate('window.__pfProbe.openDialog("pfCaptureReviewDialog",document.querySelector("#pfSourceContextTrigger"))'); dialog=page.locator('#pfCaptureReviewDialog')
     assert dialog.evaluate('(node)=>node.open') and dialog.is_visible()
     assert page.locator('#pfCaptureCommitButton').is_disabled()
     assert page.evaluate('window.__probeWrites')==0,('capture bypass',w,h,theme)
     r=dialog.bounding_box();assert r and r['x']>=-1 and r['y']>=-1 and r['x']+r['width']<=w+1 and r['y']+r['height']<=h+1,('dialog overflow',w,h,theme,r)
     # Verify metadata doesn't cause unescaped HTML injection: no dynamically filled content here.
     page.locator('#pfCaptureCancelButton').click();assert not dialog.evaluate('(node)=>node.open')
     page.wait_for_function('document.activeElement?.id === "pfSourceContextTrigger"',timeout=1500)
     assert page.evaluate('window.__probeWrites')==0, ('writes',w,h,theme)
     # Native Escape cancellation also must be non-mutating.
     page.evaluate('window.__pfProbe.openDialog("pfCaptureReviewDialog",document.querySelector("#pfSourceContextTrigger"))');page.keyboard.press('Escape');assert not dialog.evaluate('(node)=>node.open') and page.evaluate('window.__probeWrites')==0
     # Native resize while popover open calls the actual W9 positioning listener.
     page.locator('[data-pf-route="library"]').first.click();opener.click();neww=max(280,w-12)
     page.set_viewport_size({'width':neww,'height':h})
     page.wait_for_timeout(80)  # wait for queued native resize and W9 positionPopover listener
     bbox=menu.bounding_box();assert bbox and bbox['x']>=-1 and bbox['x']+bbox['width']<=neww+1,('resize',w,h,theme,bbox)
     # Reduced motion must disable animation.
     assert page.evaluate('parseFloat(getComputedStyle(document.querySelector("#pfCaptureReviewDialog")).animationDuration||"0")')<=0.001
     outcomes.append({'width':w,'height':h,'theme':theme,'status':'PASS','menuBounds':bbox,'menuContrast':contrast,'saveWrites':0})
     if (w,h,theme) in [(280,400,'black'),(320,700,'paper'),(800,700,'system')]:
      examples.append({'width':w,'height':h,'theme':theme})
     context.close()
  browser.close()
 print(json.dumps({'cases':len(outcomes),'passed':len(outcomes),'adapter':'W9 original overlay functions plus W10 data-pf-active fixture-only shim; Capture disabled pending W9 handler replacement','notTested':'extension bootstrap, IndexedDB, real capture write, native Side Panel, accessibility technology','examples':examples,'outcomes':outcomes},indent=2))
