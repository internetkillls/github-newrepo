import os
import subprocess
import sys
import pathlib

root=pathlib.Path(__file__).parents[1]
server=root/'companion/tabwoven_sync_server.py'
base=[sys.executable, str(server), '--host','0.0.0.0','--port','0','--data-dir', '/tmp/paperfold-test-data']
for token in ('', 'too-short'):
    proc=subprocess.run(base+(['--token',token] if token else []),capture_output=True,text=True,timeout=10)
    assert proc.returncode != 0, 'Insecure LAN launch unexpectedly accepted'
    assert 'requires --token' in proc.stderr, proc.stderr
print('PASS: LAN server rejects anonymous and short-token bindings')
