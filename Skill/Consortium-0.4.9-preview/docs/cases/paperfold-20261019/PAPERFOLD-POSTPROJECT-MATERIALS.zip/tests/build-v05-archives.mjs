import { writeFile } from 'node:fs/promises';
import { ensureFrontmatter, noteTemplate } from '../yaml.js';
import { buildCalendarItems, buildFlowGraph, buildReviewRows, calendarCsv, flowToMermaid, reviewCsv } from '../workspace.js';
import { createAiTransportBundleBlob, createWovenBundleBlob, createWorkspaceBundleBlob } from '../provenance.js';
const note={id:'n1',title:'Test Note',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),body:ensureFrontmatter('See [[Other]].\n',noteTemplate('tracker'))};
const other={id:'n2',title:'Other',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),body:'Body'};
const sources=[{id:'s1',title:'Example',url:'https://example.com'}];
const links=[{id:'l1',noteId:'n1',sourceId:'s1',reason:'test'}];
const scraps=[{id:'sc1',noteId:'n1',sourceId:'s1',sequence:1,fileName:'Test Note.scrap1.md',markdown:'# Captured\nText'}];
const annotations=[]; const chunks=[]; const ir=[]; const bookmarks=[]; const transports=[{id:'t1',kind:'test',destination:'downloads',createdAt:new Date().toISOString(),noteId:'n1'}];
const notes=[note,other]; const rows=buildReviewRows({notes,sources,links,scraps,annotations,transports}); const calendar=buildCalendarItems({notes,transports}); const graph=buildFlowGraph({notes,sources,links,scraps,annotations});
const blobs={
 note:await createWovenBundleBlob({note,sources,links,scraps,annotations,chunks,ir,bookmarks}),
 workspace:await createWorkspaceBundleBlob({notes,sources,links,scraps,annotations,chunks,ir,bookmarks,settings:[],backups:[],transports}),
 ai:await createAiTransportBundleBlob({name:'Test',prompt:'Summarize',scope:'workspace',notes,rows,calendar,graph,sources,annotations,scraps,ir,csv:reviewCsv(rows),calendarCsv:calendarCsv(calendar),mermaid:flowToMermaid(graph)})
};
for(const [name,blob] of Object.entries(blobs)) await writeFile(`/tmp/${name}.tar.gz`,Buffer.from(await blob.arrayBuffer()));
