"""Minimal W7/W8/W9 seam and ownership checks, without invented runtime claims.
Run in a W8+W9 assembled working copy: python TESTS/test_w9_repair_static.py --w8-dir PATH
"""
import argparse, pathlib, re, sys, json
p=argparse.ArgumentParser();p.add_argument('--w8-dir',type=pathlib.Path,required=True);p.add_argument('--w9-dir',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]);a=p.parse_args()
js=(a.w9_dir/'sidepanel.js').read_text()
html=(a.w8_dir/'sidepanel.html').read_text()
css=(a.w8_dir/'sidepanel.css').read_text()
checks={
 'W8 capture initially disabled':bool(re.search(r'id="attachCurrentButton"[^>]*\bdisabled\b',html)),
 'W8 review dialog':bool(re.search(r'<dialog[^>]+id="pfCaptureReviewDialog"[^>]+data-pf-capture-review',html)),
 'W8 capture preview fields':all(f'id="{x}"' in html for x in ('pfCaptureReviewPageTitle','pfCaptureReviewPageUrl','pfCaptureReviewMode','pfCaptureReviewStatus','pfCaptureCancelButton','pfCaptureCommitButton')),
 'W8 real contextual trigger and menu':all(x in html for x in ('id="pfSourceContextTrigger"','data-pf-popover-trigger="source-context"','id="pfSourceContextPopover"','data-pf-popover="source-context"')),
 'W8 CSS active handshake':'[data-pf-active="true"]' in css or 'data-pf-active="true"' in css,
 'legacy global direct-write listener absent':'elements.attachCurrentButton.addEventListener("click", () => attachTab' not in js,
 'capture controller initialized before enable': 'bindCaptureReview();' in js and 'trigger.disabled = true;' in js and 'trigger.disabled = false;' in js,
 'reviewed Capture two-store transaction':'database.transaction(["sources", "links"], "readwrite")' in js,
 'capture writes only after explicit commit':'reviewedCapture: true, previewNoteId: noteId' in js and 'captureReview.pending = true;' in js,
 'save acknowledged before success':'await acknowledged; // Both stores committed before any success signal.' in js,
 'W10 route data handshake':'node.dataset.pfActive = String(active)' in js,
 'W10 More closes on Escape/outside/navigation':all(x in js for x in ('event.target.closest?.("details.pf-more")', 'const more = document.querySelector("details.pf-more[open]")','if (more) more.open = false; // W10 mechanical More close-on-navigation.')),
 'popover keyboard and dismissal':all(x in js for x in ('handlePopoverKeydown(event)','ArrowDown','ArrowUp','"Escape"','dismissPopover({ restoreFocus: false })')),
 'no captured HTML interpretation':'document.getElementById("pfCaptureReviewPageTitle").textContent' in js and 'document.getElementById("pfCaptureReviewPageUrl").textContent' in js,
 'capture const initialized before top-level initialize':'const captureReview =' in js and js.index('const captureReview =') < js.index('await initialize();'),
}
print(json.dumps({'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks},indent=2))
sys.exit(0 if all(checks.values()) else 1)
