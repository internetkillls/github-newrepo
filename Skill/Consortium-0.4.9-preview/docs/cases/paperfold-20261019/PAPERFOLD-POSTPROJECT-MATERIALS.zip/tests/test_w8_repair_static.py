"""W8 repair DOM ownership and negative-control tests; no application writes."""
import argparse, hashlib, json, re
from pathlib import Path
from bs4 import BeautifulSoup

p=argparse.ArgumentParser();p.add_argument('--patch',type=Path,default=Path.cwd());p.add_argument('--baseline',type=Path,required=True);p.add_argument('--prior-w8',type=Path,required=True);p.add_argument('--w9-source',type=Path,required=True); a=p.parse_args()
H=(a.patch/'sidepanel.html').read_text(); C=(a.patch/'sidepanel.css').read_text(); orig=(a.baseline/'sidepanel.html').read_text(); prior=(a.prior_w8/'sidepanel.html').read_text(); J=a.w9_source.read_text(); s=BeautifulSoup(H,'html.parser')
checks=[]
def check(name,value):
 checks.append(dict(name=name,pass_=bool(value))); assert value,name
ids=lambda t:re.findall(r'\bid="([^"]+)"',t)
newids=ids(H)
check('original IDs unique and retained', len(newids)==len(set(newids)) and set(ids(orig)).issubset(set(newids)))
check('W8 IDs retained',set(ids(prior)).issubset(set(newids)))
check('exact W7 routes retained',set(re.findall(r'data-pf-view="([^"]+)"',H))=={'write','boards','library','find','sessions','explore','query','settings'})
trigger=s.find(id='pfSourceContextTrigger');menu=s.find(id='pfSourceContextPopover')
check('context trigger is an accessible button',trigger and trigger.name=='button' and trigger.get('type')=='button' and trigger.get('aria-expanded')=='false' and trigger.get('aria-haspopup')=='menu' and trigger.get('data-pf-popover-trigger')=='source-context' and trigger.get('aria-controls')=='pfSourceContextPopover')
check('menu hidden on initial load, correct pairing', menu and menu.has_attr('hidden') and menu.get('role')=='menu' and menu.get('data-pf-popover')=='source-context' and menu.get('aria-label'))
items=menu.find_all(attrs={'role':'menuitem'})
check('context menu real W7 route actions only', len(items)==3 and all(b.name=='button' and b.get('type')=='button' and b.get('data-pf-route') in {'write','find','boards'} and not b.has_attr('data-pf-action') for b in items))
check('menu resize/keyboard adapter exists W9',all(token in J for token in ['function togglePopover(trigger)','function positionPopover(trigger, popover)','function handlePopoverKeydown(event)','window.addEventListener("resize"','event.key === "Escape"']))
d=s.find(id='pfCaptureReviewDialog');cap=s.find(id='attachCurrentButton');commit=s.find(id='pfCaptureCommitButton');cancel=s.find(id='pfCaptureCancelButton')
check('Capture disabled pending W9 staged handler',cap and cap.has_attr('disabled') and cap.has_attr('data-pf-capture-trigger') and cap.get('aria-controls')=='pfCaptureReviewDialog' and cap.get('aria-describedby')=='pfCaptureReviewGateStatus' and not cap.has_attr('data-pf-open-dialog'))
check('native review dialog initially closed',d and d.name=='dialog' and not d.has_attr('open') and d.has_attr('data-pf-modal') and d.has_attr('data-pf-capture-review') and d.get('aria-labelledby')=='pfCaptureReviewTitle')
check('read-only metadata fields explicit',all(s.find(id=i) and s.find(id=i).get('data-pf-capture-field')==field for i,field in [('pfCaptureReviewPageTitle','title'),('pfCaptureReviewPageUrl','url'),('pfCaptureReviewMode','mode')]))
check('status region announced',s.find(id='pfCaptureReviewStatus').get('aria-live')=='polite')
check('save is gated disabled by default',commit and commit.get('type')=='button' and commit.has_attr('disabled') and commit.has_attr('data-pf-capture-commit') and not commit.has_attr('data-pf-close-dialog'))
check('cancel is explicit noncommit action',cancel and cancel.get('type')=='button' and cancel.get('data-pf-close-dialog')=='pfCaptureReviewDialog')
check('no auto submit / fake hidden persistence',not d.find('form') and not d.find('script') and not d.find(attrs={'type':'submit'}))
check('W9 original direct capture remains an OPEN DEBT', 'attachCurrentButton.addEventListener' in J and 'attachTab(state.currentTab' in J)
check('CSS supports hidden and viewport positioning',all(x in C for x in ['.pf-source-context-popover','position: fixed','max-inline-size: calc(100vw - 16px)','max-block-size: calc(100dvh - 16px)','[data-pf-capture-commit]:disabled','@media (max-width: 340px)','@media (max-height: 400px)','prefers-reduced-motion']))
check('no JS production changed (owned set)',(a.patch/'sidepanel.js').exists() is False)
print(json.dumps({'tests':len(checks),'passed':sum(x['pass_'] for x in checks),'checks':checks},indent=2))
