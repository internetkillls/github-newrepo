#!/usr/bin/env python3
"""Paperfold W10 disposable extension-context probe.
Run: python TESTS/native_disposable_sidepanel.py --extension . --receipt native-receipt.json
Requires Python playwright+Chromium with unpacked MV3 extension loading enabled.
NEVER passes production/native UI, archive restore, or real Chrome user profile gates by itself.
"""
import argparse, json, pathlib, shutil, tempfile, traceback
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

p = argparse.ArgumentParser()
p.add_argument('--extension',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent.parent)
p.add_argument('--receipt',type=pathlib.Path,default=pathlib.Path('native-disposable-receipt.json'))
p.add_argument('--browser',type=pathlib.Path,help='Chromium executable; optional, use Playwright Chromium by default')
p.add_argument('--headed',action='store_true',help='Display disposable browser for manual side-panel checks')
a = p.parse_args()
ext = a.extension.resolve(strict=True)
if not (ext/'manifest.json').is_file() or not (ext/'sidepanel.html').is_file():
 raise SystemExit('BLOCKED: extension folder does not contain actual Paperfold manifest and sidepanel')
record = {'schema':'paperfold.w10.disposable-runtime.v1','extension':str(ext),
          'ownership':'one isolated temporary profile; no daily Chrome data or schema touched',
          'cases':[],'nativeSidePanel':'UNVERIFIED: extension page smoke cannot prove native Chrome Side Panel',
          'archiveRestore':'UNVERIFIED: requires seeded archive recovery protocol',
          'assistiveTechnology':'UNVERIFIED: requires real AT operator'}
def result(name,status,detail=None):
 entry={'name':name,'status':status}
 if detail is not None:entry['detail']=str(detail)[:2000]
 record['cases'].append(entry)
 print(name,status,str(detail or '')[:100])
try:
 with tempfile.TemporaryDirectory(prefix='paperfold-w10-isolated-') as user_dir:
  with sync_playwright() as pw:
   flags=[f'--disable-extensions-except={ext}',f'--load-extension={ext}']
   opts={'user_data_dir':user_dir,'headless':not a.headed,'args':flags,'timeout':20000}
   if a.browser:opts['executable_path']=str(a.browser.resolve(strict=True))
   try:context=pw.chromium.launch_persistent_context(**opts)
   except Exception as e:
    result('disposable-Chromium-extension-launch','BLOCKED',e)
   else:
    try:
     worker=context.service_workers[0] if context.service_workers else context.wait_for_event('serviceworker',timeout=8000)
     extension_id=worker.url.split('/')[2]
     result('MV3-service-worker-observed','PASS',f'chrome-extension://{extension_id}/')
     page=context.new_page();url=f'chrome-extension://{extension_id}/sidepanel.html'
     page.goto(url,wait_until='domcontentloaded',timeout=12000)
     page.locator('[data-pf-view="library"]').wait_for(timeout=12000)
     page.wait_for_function('!document.querySelector("#attachCurrentButton").disabled',timeout=12000)
     result('fully-bootstrapped-extension-page','PASS','DOM plus imported ES modules and initialize() returned enough to enable Capture')
     for route in ('boards','library','find','sessions','write'):
      page.locator(f'[data-pf-route="{route}"]').first.click(timeout=5000)
      view=page.locator(f'[data-pf-view="{route}"]')
      assert view.is_visible() and view.get_attribute('data-pf-active')=='true'
     result('real-extension-route-visibility','PASS','five live route transitions')
     page.locator('[data-pf-route="library"]').first.click()
     page.locator('#pfSourceContextTrigger').click()
     assert page.locator('#pfSourceContextPopover').is_visible()
     page.keyboard.press('End');assert page.evaluate('document.activeElement.textContent.trim()')=='Return to Card'
     page.keyboard.press('Escape');assert not page.locator('#pfSourceContextPopover').is_visible()
     assert page.evaluate('document.activeElement.id')=='pfSourceContextTrigger'
     result('real-extension-contextual-popover','PASS','trigger, End, Escape, focus restoration')
     # Real browser IDB, not a fixture. Creates only disposable-profile records.
     seed=page.evaluate('''async () => {
      const req=indexedDB.open('tabwoven-notes');
      const db=await new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)});
      const existing=[...db.objectStoreNames]; db.close(); return existing;
     }''')
     assert 'notes' in seed and 'sources' in seed and 'links' in seed
     result('real-extension-IDB-schema-open','PASS',','.join(seed))
     # A user-opened local extension page may lack an ordinary HTTP tab: require fail-closed, not a fabricated commit.
     page.locator('#attachCurrentButton').click()
     page.wait_for_timeout(350)
     assert page.locator('#pfCaptureReviewDialog').evaluate('(e)=>e.open')
     page.locator('#pfCaptureCancelButton').click()
     assert not page.locator('#pfCaptureReviewDialog').evaluate('(e)=>e.open')
     result('real-extension-Capture-cancel','PASS','native dialog opened and closed; storage-diff requires seeded fixture')
     # User data not supplied: do not certify migration, populated restore, or system permissions.
     for name in ('native Chrome Side Panel mounted','full CM6 save reload undo IME','seeded Capture atomicity and transaction abort',
       'populated archive restoration','permission prompt/denial','native 100/150/200% zoom','assistive technology'):
      result(name,'UNVERIFIED','Requires explicit disposable seeded host-native follow-up')
    except Exception as e:
     result('extension-journey','BLOCKED',repr(e)+'\n'+traceback.format_exc(limit=2))
    finally:context.close()
except Exception as e:
 result('probe-environment','BLOCKED',repr(e))
a.receipt.parent.mkdir(parents=True,exist_ok=True)
a.receipt.write_text(json.dumps(record,indent=2),encoding='utf-8')
print('Receipt:',a.receipt)
if not any(x['status']=='PASS' for x in record['cases']):raise SystemExit(2)
