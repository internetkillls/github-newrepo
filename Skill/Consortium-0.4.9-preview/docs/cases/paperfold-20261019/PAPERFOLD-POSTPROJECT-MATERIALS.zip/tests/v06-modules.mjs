import assert from 'node:assert/strict';
import { writeFile, mkdtemp, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  attachmentFileName,
  buildMaincardProjection,
  createMaincard,
  createMembership,
  createTypedEdge,
  flattenMaincard,
  maincardFileName,
  maincardToMermaid
} from '../card-model.js';
import { mergeSnapshotRecords, normalizeSyncConfig, preserveLocalAttachmentBlob } from '../sync.js';
import { buildFlowGraph, buildReviewRows, flowToMermaid } from '../workspace.js';
import { createWorkspaceBundleBlob } from '../provenance.js';

if (!globalThis.crypto?.randomUUID) {
  const { webcrypto } = await import('node:crypto');
  globalThis.crypto = webcrypto;
}

const notes = [
  { id: 'n1', title: 'Question', body: 'What follows?', createdAt: '2026-07-26T01:00:00Z', updatedAt: '2026-07-26T02:00:00Z' },
  { id: 'n2', title: 'Answer', body: 'A candidate answer.', createdAt: '2026-07-26T01:00:00Z', updatedAt: '2026-07-26T03:00:00Z' }
];
const maincard = { ...createMaincard('Inquiry Window'), id: 'm1' };
const memberships = [
  createMembership({ maincardId: 'm1', cardId: 'n1', role: 'question', classification: 'origin' }),
  createMembership({ maincardId: 'm1', cardId: 'n2', role: 'card', classification: 'candidate' })
];
const edge = { ...createTypedEdge({ fromId: 'n2', toId: 'n1', type: 'answers', classification: 'erotetic', maincardId: 'm1' }), id: 'e1' };
const scraps = [{ id: 's1', noteId: 'n1', sequence: 1, fileName: 'Question.scrap1.md', sourceId: 'src1' }];
const annotations = [{ id: 'a1', noteId: 'n1', sourceId: 'src1', quote: { exact: 'quoted' } }];
const attachments = [{
  id: 'att1', noteId: 'n2', noteTitle: 'Answer', sequence: 1,
  fileName: 'evidence.txt', markdownFileName: attachmentFileName('Answer', 1),
  mimeType: 'text/plain', size: 8, textContent: 'evidence', markdown: 'evidence',
  rawBlob: new Blob(['evidence'], { type: 'text/plain' }),
  createdAt: '2026-07-26T04:00:00Z', updatedAt: '2026-07-26T04:00:00Z'
}];

assert.equal(maincardFileName('Inquiry Window'), 'Inquiry Window.maincard.md');
assert.equal(attachmentFileName('Answer', 2), 'Answer.attachment2.md');
const projection = buildMaincardProjection({ maincard, notes, memberships, edges: [edge], scraps, annotations, attachments });
assert.equal(projection.cards.length, 2);
assert.equal(projection.subcards.length, 3);
assert.ok(projection.edges.some((item) => item.type === 'answers'));
assert.equal(flattenMaincard(projection).schema, 'tabwoven.maincard.flatten/1');
assert.match(maincardToMermaid(projection), /answers/);

const graph = buildFlowGraph({ notes, scraps, annotations, attachments, maincards: [maincard], memberships, cardEdges: [edge], sources: [{ id: 'src1', title: 'Source', url: 'https://example.com' }], links: [] });
assert.ok(graph.nodes.some((node) => node.type === 'maincard'));
assert.ok(graph.nodes.some((node) => node.subtype === 'attachment'));
assert.ok(graph.edges.some((item) => item.type === 'answers'));
assert.match(flowToMermaid(graph), /Inquiry Window/);

const rows = buildReviewRows({ notes, attachments, memberships });
assert.equal(rows.find((row) => row.note_id === 'n2').attachment_count, 1);
assert.equal(rows.find((row) => row.note_id === 'n1').maincard_count, 1);

const local = [{ id: 'n1', updatedAt: '2026-07-26T01:00:00Z', value: 'old' }];
const remote = [{ id: 'n1', updatedAt: '2026-07-26T02:00:00Z', value: 'new' }, { id: 'n2', updatedAt: '2026-07-26T01:00:00Z' }];
const merged = mergeSnapshotRecords(local, remote);
assert.equal(merged.find((item) => item.id === 'n1').value, 'new');
assert.equal(merged.length, 2);
assert.equal(normalizeSyncConfig({ baseUrl: 'http://127.0.0.1:8765/' }).baseUrl, 'http://127.0.0.1:8765');
const preservedBlob = new Blob(['binary']);
const restoredAttachment = preserveLocalAttachmentBlob({ id: 'att1', updatedAt: '2026-07-26T05:00:00Z' }, { id: 'att1', rawBlob: preservedBlob });
assert.equal(restoredAttachment.rawBlob, preservedBlob);

const blob = await createWorkspaceBundleBlob({
  notes, sources: [], links: [], scraps, annotations, chunks: [], ir: [], bookmarks: [],
  settings: [{ key: 'localSync', value: { baseUrl: 'http://127.0.0.1:8765', token: 'supersecret' } }],
  backups: [], transports: [],
  attachments, maincards: [maincard], memberships, cardEdges: [edge], syncRuns: [], includeVectors: true
});
assert.ok(blob.size > 1500);
const dir = await mkdtemp(join(tmpdir(), 'tabwoven-v06-'));
const archivePath = join(dir, 'workspace.wv.tar.gz');
const archiveBuffer = Buffer.from(await blob.arrayBuffer());
await writeFile(archivePath, archiveBuffer);
const archiveText = (await import('node:zlib')).gunzipSync(archiveBuffer).toString('utf8');
assert.ok(!archiveText.includes('supersecret'));
assert.ok(archiveText.includes('[redacted]'));
console.log(JSON.stringify({ cards: projection.cards.length, subcards: projection.subcards.length, graphNodes: graph.nodes.length, graphEdges: graph.edges.length, archivePath, archiveBytes: blob.size }));
