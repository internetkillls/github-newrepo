/** Real sidepanel.js functions evaluated in an isolated Node VM, with IndexedDB service stubs.
 * Evidence scope: behavioral unit probes, NOT production extension or Chrome Side Panel.
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const source = readFileSync(new URL('../sidepanel.js', import.meta.url), 'utf8');
const withoutImports = source.replace(/^import[\s\S]*?from "[^"]+";\s*$/gm, '');
assert(!withoutImports.includes('from "./db.js"'), 'imports stripped only in test harness');
const program = withoutImports.replace('await initialize();', '');
const createLatch = () => { let resolve; const promise = new Promise(r => {resolve = r}); return { promise, resolve }; };
class FakeElement {
  constructor(id='') { this.id=id; this.dataset={}; this.attributes={}; this.style={}; this.children=[]; this.classList={add(){}, remove(){},toggle(){}}; this.hidden=false; this.disabled=false; this.open=false; this.value=''; this.textContent=''; this.isConnected=true; this.handlers={}; }
  setAttribute(k,v) { this.attributes[k]=String(v); }
  getAttribute(k) { return this.attributes[k] ?? null; }
  removeAttribute(k) { delete this.attributes[k]; }
  hasAttribute(k) { return Object.hasOwn(this.attributes,k); }
  append(...xs) { this.children.push(...xs); }
  appendChild(x) { this.children.push(x); }
  addEventListener(k, fn) { (this.handlers[k] ||= []).push(fn); }
  fire(k) { for (const fn of this.handlers[k] || []) fn({target:this}); }
  focus() { this.focused = true; }
  replaceChildren(...xs) { this.children=xs; }
  querySelector(selector) { return this.children.find(x => x.id===selector.slice(1)) ?? null; }
  querySelectorAll() { return this.children.filter(x => x instanceof FakeElement); }
  showModal() { this.open=true; }
  close() { this.open=false; this.fire('close'); }
  remove() { this.isConnected=false; }
  getBoundingClientRect() { return {left:16,right:72,top:16,bottom:42}; }
}
const dom = new Map();
const el = (id) => dom.get(id) || (dom.set(id, new FakeElement(id)),dom.get(id));
const body = new FakeElement('body');
const doc = {
  body, documentElement: new FakeElement('html'),
  activeElement: el('editor'),
  getElementById: el,
  querySelector(selector) { if (selector==='dialog[open]') return [...dom.values(),...body.children].find(x=>x.open) || null; if (selector==='[data-pf-toast]') return body.children.find(x=>x.dataset.pfToast!==undefined) || null; return null; },
  querySelectorAll(){return[];},
  createElement(tag){return new FakeElement(tag);},
  addEventListener(){}
};
let failNext = false, noteWrites = 0, noteLatch = null;
const records = new Map();
const repo = {
  async put(store,item) {
    if (store==='notes') { noteWrites += 1; if (noteLatch) {const pending=noteLatch; noteLatch=null; await pending.promise;} }
    if (failNext) {failNext=false; throw new Error('simulated IndexedDB rejection');}
    records.set(`${store}:${item.id||item.key}`,structuredClone(item));
  },
  async get(store,id) {return records.get(`${store}:${id}`) || null;}
};
const context = vm.createContext({
  console, Element:FakeElement, document:doc,
  window:{matchMedia:(q)=>({matches:q.includes('color') ? false:true,addEventListener(){}}),innerWidth:320,innerHeight:700},
  navigator:{},crypto:webcrypto,structuredClone,setTimeout,clearTimeout,requestAnimationFrame:fn=>fn(),
  cloneDefaultCueLibrary:()=>({}),normalizeSearchProviders:x=>x,DEFAULT_SEARCH_PROVIDERS:[], normalizeSyncConfig:()=>({}),
  put:repo.put,get:repo.get,embedText:async ()=>[1,2],parseFrontmatter:()=>({hasFrontmatter:false}),
  ensureFrontmatter:x=>x, now:()=>new Date().toISOString(),
  renderNoteSelector:()=>{},renderScraps:async()=>{},renderAttachments:async()=>{},
  getAllByIndex:async()=>[],getAll:async()=>[],
  chrome:{}, URL, Intl
});
vm.runInContext(program,context,{filename:'sidepanel.js'});
const run = async (code) => vm.runInContext(code,context);
const state = await run('state');
const note = { id:'card-1',title:'Original',body:'Old',embeddingProvider:'local-hash-v1',updatedAt:'2026-01-01T00:00:00.000Z' };
state.notes=[note];state.activeNoteId=note.id;
el('noteTitle').value='Original';el('noteBody').value='Old';
let editorDoc='Old';state.editor={getValue:()=>editorDoc,setValue:v=>{editorDoc=v;},getSelection:()=>({start:editorDoc.length,end:editorDoc.length}),setSelection(){},focus(){},replaceRange(start,end,text){editorDoc=editorDoc.slice(0,start)+text+editorDoc.slice(end);},applyFormat(){} };

// G1: no optimistic status before the IndexedDB write resolves.
editorDoc='New draft';el('noteBody').value=editorDoc;
await run('scheduleSave()');
const latch=createLatch();noteLatch=latch;
const writing=run('saveActiveNote()');
await new Promise(r=>setImmediate(r));
assert.equal(el('saveStatus').textContent,'Saving…');
assert.equal(note.body,'Old');
const duplicate=run('saveActiveNote()');
assert.equal(noteWrites,1,'duplicate write deduplicated while in flight');
latch.resolve();
assert.equal(await writing,true);assert.equal(await duplicate,true);
assert.equal(el('saveStatus').textContent,'Saved locally');
assert.equal(records.get('notes:card-1').body,'New draft');
assert.equal(noteWrites,1);
console.log('PASS G1: DB acknowledgement and duplicate save deduplication');

// G2: a failing write leaves the editor draft and original persisted record intact.
editorDoc='Not persisted';el('noteBody').value=editorDoc;
await run('scheduleSave()'); failNext=true;
assert.equal(await run('saveActiveNote()'),false);
assert.equal(el('saveStatus').dataset.state,'error');
assert.equal(editorDoc,'Not persisted');
assert.equal(records.get('notes:card-1').body,'New draft');
let blocked=false;try{await run('flushNoteSave()')}catch{blocked=true}
// Now a retry may succeed: either blocked is true, or a real persistence ACK happened.
assert(blocked || records.get('notes:card-1').body==='Not persisted');
console.log('PASS G2: failed save keeps draft, retry/guard requires real ACK');

// G3: settings persistence rollback, not optimistic success.
state.settings.paperfoldTheme='paper';el('paperfoldTheme').value='black';failNext=true;
await run('updateThemeSetting("black")');
assert.equal(state.settings.paperfoldTheme,'paper');
assert.equal(el('paperfoldTheme').value,'paper');
await run('updateThemeSetting("black")');
assert.equal(state.settings.paperfoldTheme,'black');
assert.equal(records.get('settings:paperfoldTheme').value,'black');
console.log('PASS G3: theme rollback and persisted selection');

// G4: native modal opens only once and returns focus to opener when closed.
const dialog=el('sampleDialog'),opener=el('sampleButton');
await run('openDialog("sampleDialog",document.getElementById("sampleButton"))');
assert(dialog.open);await run('closeDialog("sampleDialog","cancel")');
assert(!dialog.open); // close handler installed by initializeInteractionShell in actual init.
console.log('PASS G4: modal show/close mechanics');

// G5: citation staging canceled before any mutation. The only action is dialog close.
const sourceRecord={id:'src:example',title:'Example',url:'https://example.org',citationKey:'example'};
records.set('sources:src:example',sourceRecord);
const writesBefore=noteWrites;
const opened=await run('reviewSourceCitation("src:example",document.getElementById("sampleButton"))');
assert.equal(opened,true);
const review=body.children.find(x=>x.id==='dialog' && x.open);
assert(review);
const actions=review.children[0].children.at(-1);
const cancel=actions.children[0];
cancel.fire('click');
assert.equal(noteWrites,writesBefore);
assert.equal(editorDoc, records.get('notes:card-1').body);
console.log('PASS G5: cancel staged source citation performs zero Card writes');

// G6: no source citation when the Card changes during review.
await run('reviewSourceCitation("src:example",document.getElementById("sampleButton"))');
const review2=body.children.find(x=>x.id==='dialog' && x.open);
const confirm=review2.children[0].children.at(-1).children[1];
state.noteRevision += 1; confirm.fire('click');
assert.equal(noteWrites,writesBefore);
console.log('PASS G6: stale citation selection rejected');
// G7: route activation is state-only and restores previous view scroll.
const writeView=new FakeElement('writeView'),boardView=new FakeElement('boardView');
writeView.dataset.pfView='write';writeView.scrollTop=61;
boardView.dataset.pfView='boards';boardView.hidden=true;
const writeNav=new FakeElement('writeNav'),boardsNav=new FakeElement('boardsNav');
writeNav.dataset.pfRoute='write'; boardsNav.dataset.pfRoute='boards';
doc.querySelectorAll=(selector)=>selector==='[data-pf-view]'?[writeView,boardView]:selector==='[data-pf-route]'?[writeNav,boardsNav]:[];
state.ui.route='write';
assert.equal(await run('activateRoute("boards")'),true);
assert(writeView.hidden);assert(!boardView.hidden);
assert.equal(state.ui.routeScroll.get('write'),61);
assert.equal(boardsNav.getAttribute('aria-current'),'page');
console.log('PASS G7: route activation preserves scroll and navigation state');

// G8: empty Board navigation is read-only (legacy code previously auto-created Board 1).
await run('openMaincardsDialog()');
assert.equal([...records.keys()].filter(k=>k.startsWith('maincards:')).length,0);
console.log('PASS G8: opening empty Boards causes zero Board creations');
console.log(JSON.stringify({status:'PASS',scope:'isolated vm, real W9 functions, fake persistence',cases:8,noteWrites}));
