import {
  clear,
  get,
  getAll,
  getAllByIndex,
  getByIndex,
  put,
  putMany,
  remove
} from "./db.js";
import { cosineSimilarity, embedText } from "./embedding.js";
import {
  DEFAULT_CUE_LIBRARY,
  cloneDefaultCueLibrary,
  cueLibraryToEditableText,
  editableTextToCues,
  suggestCues
} from "./cues.js";
import { renderMarkdown } from "./markdown.js";
import { createMarkdownEditor } from "./cm-editor.js";
import { extractDois, normalizeDoi, doiUrl, resolveDoi } from "./literature.js";
import {
  annotationCitationToken,
  buildEmbeddedChunks,
  citationKeyForSource,
  createAiTransportBundleBlob,
  createWovenBundleBlob,
  createWorkspaceBundleBlob,
  scrapFileName,
  safeFileStem
} from "./provenance.js";
import { ensureFrontmatter, noteTemplate, parseFrontmatter, stringifyFrontmatter } from "./yaml.js";
import {
  DEFAULT_SEARCH_PROVIDERS,
  buildCalendarItems,
  buildFlowGraph,
  buildReviewRows,
  calendarCsv,
  editableTextToProviders,
  flattenWorkspace,
  flowToMermaid,
  normalizeSearchProviders,
  providerUrl,
  providersToEditableText,
  reviewCsv
} from "./workspace.js";
import {
  DEFAULT_EDGE_TYPES,
  attachmentFileName,
  buildMaincardProjection,
  createMaincard,
  createMembership,
  createTypedEdge,
  flattenMaincard,
  maincardToMermaid
} from "./card-model.js";
import {
  mergeSnapshotRecords,
  normalizeSyncConfig,
  preserveLocalAttachmentBlob,
  pullSnapshot,
  pushArchive,
  pushSnapshot,
  testSyncServer
} from "./sync.js";

const state = {
  notes: [],
  maincards: [],
  activeNoteId: null,
  activeMaincardId: null,
  currentTab: null,
  settings: {
    keepLog: true,
    embeddingProvider: "local-hash-v1",
    cueLibrary: cloneDefaultCueLibrary(),
    editorZoom: 1,
    searchProviders: normalizeSearchProviders(DEFAULT_SEARCH_PROVIDERS),
    exportDestination: "downloads",
    localSync: normalizeSyncConfig(),
    paperfoldTheme: "paper"
  },
  editor: null,
  editorLoading: false,
  saveTimer: null,
  maincardSaveTimer: null,
  autoCaptureInFlight: false,
  editorView: "write",
  editorSelection: { start: 0, end: 0 },
  tabPickerMode: { insertLinks: false },
  pendingClip: null,
  altCandidate: false,
  workspaceView: "spreadsheet",
  workspaceData: null,
  driveStatus: null,
  ui: { route: "write", routeScroll: new Map(), popover: null, popoverOpener: null, toastTimer: null, dialogOpeners: new WeakMap() },
  noteRevision: 0,
  savedNoteRevision: 0,
  noteSaveInFlight: null,
  maincardSaveInFlight: null
};

const elementIds = [
  "noteSelect",
  "newNoteButton",
  "deleteNoteButton",
  "noteTitle",
  "noteBody",
  "noteEditorHost",
  "notePreview",
  "capturePolicy",
  "cueMode",
  "saveStatus",
  "markdownToolbar",
  "writeTabButton",
  "previewTabButton",
  "zoomOutButton",
  "zoomResetButton",
  "zoomInButton",
  "exportButton",
  "exportBundleButton",
  "workspaceButton",
  "maincardsButton",
  "aiTransportButton",
  "openWorkspaceButton",
  "insertStubButton",
  "insertLogButton",
  "insertTrackerButton",
  "insertPlannerButton",
  "cueButton",
  "cueDialog",
  "cuePaletteMode",
  "cueSearchInput",
  "cueList",
  "cueItemTemplate",
  "currentTabTitle",
  "refreshCurrentTabButton",
  "attachCurrentButton",
  "addTabsButton",
  "scrapeCurrentButton",
  "detectDoiButton", "literatureList", "doiDialog", "closeDoiButton", "doiManualInput", "lookupDoiButton", "doiResults", "doiStatus", "paperfoldTheme",
  "clipSelectionButton",
  "manualAttachmentButton",
  "grantSiteButton",
  "permissionHint",
  "sourceList",
  "sourceCount",
  "scrapList",
  "scrapCount",
  "attachmentList",
  "attachmentCount",
  "annotationList",
  "annotationCount",
  "annotationDialog",
  "annotationForm",
  "annotationQuote",
  "annotationComment",
  "annotationInsertCitation",
  "saveAnnotationButton",
  "attachmentDialog",
  "attachmentForm",
  "attachmentFiles",
  "attachmentComment",
  "saveAttachmentButton",
  "maincardsDialog",
  "maincardSelect",
  "newMaincardButton",
  "deleteMaincardButton",
  "exportMaincardButton",
  "maincardTitle",
  "maincardPerspective",
  "maincardBody",
  "maincardNotePicker",
  "maincardMembershipRole",
  "maincardMembershipClass",
  "addCardsToMaincardButton",
  "addActiveCardButton",
  "maincardGrid",
  "edgeFromSelect",
  "edgeTypeSelect",
  "edgeToSelect",
  "edgeLabelInput",
  "addTypedEdgeButton",
  "typedEdgeList",
  "searchInput",
  "searchButton",
  "searchResults",
  "newReminderButton",
  "reminderList",
  "reminderDialog",
  "reminderForm",
  "reminderWhen",
  "reminderMessage",
  "scheduleReminderButton",
  "activitySection",
  "clearLogButton",
  "logList",
  "tabPickerDialog",
  "tabPickerList",
  "attachSelectedTabsButton",
  "workspaceDialog",
  "workspaceSpreadsheetTab",
  "workspaceCalendarTab",
  "workspaceFlowTab",
  "workspaceFlattenTab",
  "workspaceFilter",
  "exportReviewCsvButton",
  "exportFlattenButton",
  "workspaceAiButton",
  "workspaceSpreadsheetView",
  "workspaceCalendarView",
  "workspaceFlowView",
  "workspaceFlattenView",
  "workspaceFlattenText",
  "aiTransportDialog",
  "aiTransportForm",
  "aiTransportScope",
  "aiCueMode",
  "aiCustomPrompt",
  "aiDestination",
  "createAiTransportButton",
  "settingsDialog",
  "settingsButton",
  "keepLogToggle",
  "embeddingProviderSelect",
  "exportWorkspaceButton",
  "searchProviderEditor",
  "saveSearchProvidersButton",
  "resetSearchProvidersButton",
  "searchProviderStatus",
  "chooseExportFolderButton",
  "clearExportFolderButton",
  "exportFolderStatus",
  "googleClientId",
  "googleDriveSchedule",
  "connectGoogleDriveButton",
  "backupGoogleDriveButton",
  "disconnectGoogleDriveButton",
  "googleDriveStatus",
  "googleRedirectUri",
  "localSyncUrl",
  "localSyncToken",
  "localSyncSchedule",
  "testLocalSyncButton",
  "pushLocalSyncButton",
  "pullLocalSyncButton",
  "localSyncStatus",
  "cueEditorMode",
  "cueEditorText",
  "saveCueSetButton",
  "resetCueSetButton",
  "cueEditorStatus",
  "sourceItemTemplate",
  "scrapItemTemplate",
  "attachmentItemTemplate",
  "annotationItemTemplate",
  "logItemTemplate"
];

const elements = Object.fromEntries(elementIds.map((id) => [id, document.getElementById(id)]));

await initialize();

async function initialize() {
  await loadSettings();
  await ensureMigrationBackup();
  try { await navigator.storage?.persist?.(); } catch {}
  await loadNotes();
  applyPaperfoldTheme();
  await loadMaincards();
  initializeEditor();
  bindEvents();
  initializeInteractionShell();
  await refreshCurrentTab();
  await renderActiveNote();
  await renderLogs();
  await renderReminders();
  renderSettings();
  await consumePendingCueRequest();
  await consumePendingNavigation();
  await consumePendingWebClip();
  await consumePendingPageAction();
}


function initializeEditor() {
  const note = activeNote();
  state.editor?.destroy();
  state.editor = createMarkdownEditor({
    host: elements.noteEditorHost,
    hiddenTextarea: elements.noteBody,
    initialDoc: note?.body || "",
    initialZoom: state.settings.editorZoom,
    getNotes: () => state.notes,
    getOpenTabs: async () => {
      const response = await chrome.runtime.sendMessage({ type: "GET_WINDOW_TABS" });
      return response?.ok ? response.tabs : [];
    },
    onOpenNote: (noteId) => void openNoteById(noteId),
    onOpenAnnotation: (annotationId) => void openAnnotationById(annotationId),
    onOpenCue: () => void openCueDialog(),
    onOpenTabPicker: (options) => void openTabPicker(options),
    onOpenSettings: () => openSettingsDialog(),
    onExport: () => void exportActiveNote(),
    onExportBundle: () => void exportActiveBundle(),
    onExportWorkspace: () => void exportWorkspaceBackup(),
    onScrapeCurrent: () => void scrapeCurrentPage(),
    onDetectDoi: () => void openDoiDialog(),
    onClipSelection: () => void captureSelectionFromButton(),
    onNewNote: () => void createNote(),
    onOpenReminder: () => openReminderDialog(),
    onAttachCurrent: () => void attachCurrentFromCommand(),
    onUseTab: (tab) => void attachTab(tab, "at-web"),
    getSearchProviders: () => state.settings.searchProviders,
    onInsertTemplate: (kind) => void insertYamlTemplate(kind),
    onOpenWorkspace: (view) => void openWorkspaceDialog(view),
    onOpenMaincards: () => void openMaincardsDialog(),
    onManualAttachment: () => openAttachmentDialog(),
    onAddActiveToMaincard: () => void addActiveCardToCurrentMaincard(),
    onLocalSyncPush: () => void pushLocalWorkspace(),
    onLocalSyncPull: () => void pullLocalWorkspace(),
    onLocalSyncTest: () => void testLocalSyncConnection(),
    onStickyExport: () => void exportStickyNotesProjection(),
    onOpenAiTransport: () => openAiTransportDialog(),
    onDriveBackup: () => void backupGoogleDriveNow(),
    onSearchProvider: (providerId) => void searchEditorSelection(providerId),
    onZoom: (change) => void adjustEditorZoom(change),
    onChange: (value) => {
      elements.noteBody.value = value;
      rememberEditorSelection();
      if (state.editorLoading) return;
      scheduleSave();
      const active = activeNote();
      if (active?.capturePolicy === "on-write" && value.trim()) void autoAttachCurrentTab();
    }
  });
  renderZoomControl();
}

function openSettingsDialog() {
  renderSettings();
  openDialog("settingsDialog");
}

function bindEvents() {
  elements.newNoteButton.addEventListener("click", () => void createNote());
  elements.deleteNoteButton.addEventListener("click", deleteActiveNote);
  elements.noteSelect.addEventListener("change", async () => {
    const nextId = elements.noteSelect.value;
    try {
      await flushNoteSave();
      await putSetting("activeNoteId", nextId);
      state.activeNoteId = nextId;
      await renderActiveNote();
    } catch (error) {
      elements.noteSelect.value = state.activeNoteId;
      announceStatus(`Cannot change Card while its changes are unsaved: ${error.message || error}`, "error");
    }
  });

  elements.noteTitle.addEventListener("input", scheduleSave);
  elements.exportButton.addEventListener("click", exportActiveNote);
  elements.exportBundleButton.addEventListener("click", exportActiveBundle);
  elements.workspaceButton.addEventListener("click", () => void openWorkspaceDialog("spreadsheet"));
  elements.maincardsButton.addEventListener("click", () => void openMaincardsDialog());
  elements.openWorkspaceButton.addEventListener("click", () => void openWorkspaceDialog("spreadsheet"));
  elements.aiTransportButton.addEventListener("click", openAiTransportDialog);
  elements.insertStubButton.addEventListener("click", () => void insertYamlTemplate("stub"));
  elements.insertLogButton.addEventListener("click", () => void insertYamlTemplate("log"));
  elements.insertTrackerButton.addEventListener("click", () => void insertYamlTemplate("tracker"));
  elements.insertPlannerButton.addEventListener("click", () => void insertYamlTemplate("planner"));
  elements.zoomOutButton.addEventListener("click", () => void adjustEditorZoom(-0.1));
  elements.zoomResetButton.addEventListener("click", () => void adjustEditorZoom("reset"));
  elements.zoomInButton.addEventListener("click", () => void adjustEditorZoom(0.1));
  elements.newReminderButton.addEventListener("click", openReminderDialog);
  elements.reminderForm.addEventListener("submit", scheduleReminder);

  elements.capturePolicy.addEventListener("change", async () => {
    const note = activeNote();
    if (!note) return;
    note.capturePolicy = elements.capturePolicy.value;
    note.updatedAt = now();
    await put("notes", note);
    await recordLog("capture-policy", `Capture policy set to ${note.capturePolicy}.`, note.id);
    await loadNotes(false);
  });

  elements.cueMode.addEventListener("change", async () => {
    const note = activeNote();
    if (!note) return;
    note.cueMode = elements.cueMode.value;
    note.updatedAt = now();
    await put("notes", note);
    await loadNotes(false);
  });

  elements.markdownToolbar.addEventListener("pointerdown", (event) => {
    if (event.target.closest("[data-format]") && event.pointerType !== "touch") {
      rememberEditorSelection();
      event.preventDefault(); // retain CodeMirror selection before click command
    }
  });
  elements.markdownToolbar.addEventListener("click", (event) => {
    const button = event.target.closest("[data-format]");
    if (!button) return;
    if (event.isComposing) return;
    applyMarkdownFormat(button.dataset.format);
  });
  elements.writeTabButton.addEventListener("click", () => setEditorView("write"));
  elements.previewTabButton.addEventListener("click", () => setEditorView("preview"));

  elements.cueButton.addEventListener("click", openCueDialog);
  elements.cuePaletteMode.addEventListener("change", renderCueList);
  elements.cueSearchInput.addEventListener("input", renderCueList);
  elements.cueDialog.querySelector(".notation-strip").addEventListener("click", (event) => {
    const button = event.target.closest("[data-insert]");
    if (!button) return;
    restoreEditorSelection();
    insertTextAtCursor(button.dataset.insert);
    closeDialog("cueDialog", "explicit");
  });

  elements.refreshCurrentTabButton.addEventListener("click", refreshCurrentTab);
  elements.attachCurrentButton.addEventListener("click", () => attachTab(state.currentTab, "manual"));
  elements.addTabsButton.addEventListener("click", () => void openTabPicker());
  elements.scrapeCurrentButton.addEventListener("click", () => void scrapeCurrentPage());
  elements.detectDoiButton.addEventListener("click", () => void openDoiDialog());
  elements.closeDoiButton.addEventListener("click", () => closeDialog("doiDialog", "cancel"));
  elements.lookupDoiButton.addEventListener("click", () => void lookupManualDoi());
  elements.doiManualInput.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); void lookupManualDoi(); } });
  elements.paperfoldTheme.addEventListener("change", () => void updateThemeSetting(elements.paperfoldTheme.value));
  elements.clipSelectionButton.addEventListener("click", () => void captureSelectionFromButton());
  elements.manualAttachmentButton.addEventListener("click", openAttachmentDialog);
  elements.attachmentForm.addEventListener("submit", saveManualAttachments);
  elements.grantSiteButton.addEventListener("click", grantCurrentSite);
  elements.annotationForm.addEventListener("submit", savePendingAnnotation);
  elements.attachSelectedTabsButton.addEventListener("click", attachSelectedTabs);

  elements.maincardSelect.addEventListener("change", async () => {
    if (!(await saveActiveMaincard())) return;
    state.activeMaincardId = elements.maincardSelect.value || null;
    await putSetting("activeMaincardId", state.activeMaincardId);
    await renderMaincardDialog();
  });
  elements.newMaincardButton.addEventListener("click", () => void createNewMaincard());
  elements.deleteMaincardButton.addEventListener("click", () => void deleteCurrentMaincard());
  elements.exportMaincardButton.addEventListener("click", () => void exportCurrentMaincardFlatten());
  elements.maincardTitle.addEventListener("input", scheduleMaincardSave);
  elements.maincardPerspective.addEventListener("input", scheduleMaincardSave);
  elements.maincardBody.addEventListener("input", scheduleMaincardSave);
  elements.addCardsToMaincardButton.addEventListener("click", () => void addSelectedCardsToMaincard());
  elements.addActiveCardButton.addEventListener("click", () => void addActiveCardToCurrentMaincard());
  elements.addTypedEdgeButton.addEventListener("click", () => void addTypedEdgeFromDialog());

  elements.searchButton.addEventListener("click", runSearch);
  elements.searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") void runSearch();
  });

  elements.clearLogButton.addEventListener("click", async () => {
    if (!confirm("Clear the entire activity log? Notes and linked tabs will remain.")) return;
    await clear("logs");
    await renderLogs();
  });

  elements.settingsButton.addEventListener("click", openSettingsDialog);
  for (const button of [elements.workspaceSpreadsheetTab, elements.workspaceCalendarTab, elements.workspaceFlowTab, elements.workspaceFlattenTab]) {
    button.addEventListener("click", () => void setWorkspaceView(button.dataset.view));
  }
  elements.workspaceFilter.addEventListener("input", renderWorkspaceCurrentView);
  elements.exportReviewCsvButton.addEventListener("click", () => void exportWorkspaceReviewCsv());
  elements.exportFlattenButton.addEventListener("click", () => void exportWorkspaceFlatten());
  elements.workspaceAiButton.addEventListener("click", openAiTransportDialog);
  elements.aiTransportForm.addEventListener("submit", createAiTransport);
  elements.saveSearchProvidersButton.addEventListener("click", saveSearchProviders);
  elements.resetSearchProvidersButton.addEventListener("click", resetSearchProviders);
  elements.chooseExportFolderButton.addEventListener("click", chooseExportFolder);
  elements.clearExportFolderButton.addEventListener("click", clearExportFolder);
  elements.connectGoogleDriveButton.addEventListener("click", connectGoogleDrive);
  elements.backupGoogleDriveButton.addEventListener("click", backupGoogleDriveNow);
  elements.disconnectGoogleDriveButton.addEventListener("click", disconnectGoogleDrive);
  elements.googleDriveSchedule.addEventListener("change", configureGoogleDrive);
  elements.testLocalSyncButton.addEventListener("click", () => void testLocalSyncConnection());
  elements.pushLocalSyncButton.addEventListener("click", () => void pushLocalWorkspace());
  elements.pullLocalSyncButton.addEventListener("click", () => void pullLocalWorkspace());
  for (const field of [elements.localSyncUrl, elements.localSyncToken, elements.localSyncSchedule]) {
    field.addEventListener("change", () => void saveLocalSyncConfig());
  }
  elements.keepLogToggle.addEventListener("change", async () => {
    const previous = state.settings.keepLog;
    try {
      await putSetting("keepLog", elements.keepLogToggle.checked);
      state.settings.keepLog = elements.keepLogToggle.checked;
      renderSettings();
      announceStatus("Activity log preference saved.", "success");
    } catch (error) {
      state.settings.keepLog = previous;
      elements.keepLogToggle.checked = previous;
      announceStatus(`Preference not saved: ${error.message || error}`, "error");
    }
  });
  elements.embeddingProviderSelect.addEventListener("change", async () => {
    const previous = state.settings.embeddingProvider;
    const candidate = elements.embeddingProviderSelect.value;
    try {
      await putSetting("embeddingProvider", candidate);
      state.settings.embeddingProvider = candidate;
      announceStatus("Embedding preference saved.", "success");
    } catch (error) {
      state.settings.embeddingProvider = previous;
      elements.embeddingProviderSelect.value = previous;
      announceStatus(`Preference not saved: ${error.message || error}`, "error");
    }
  });
  elements.exportWorkspaceButton.addEventListener("click", () => void exportWorkspaceBackup());
  elements.cueEditorMode.addEventListener("change", loadCueEditor);
  elements.saveCueSetButton.addEventListener("click", saveCueSet);
  elements.resetCueSetButton.addEventListener("click", resetCueSet);

  elements.notePreview.addEventListener("click", handlePreviewClick);

  document.addEventListener("keydown", handleDocumentKeydown, true);
  document.addEventListener("keyup", handleDocumentKeyup, true);
  window.addEventListener("blur", () => { state.altCandidate = false; });

  chrome.tabs.onActivated.addListener(() => void refreshCurrentTab());
  chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
    if (tab.active && (changeInfo.url || changeInfo.title || changeInfo.status === "complete")) {
      void refreshCurrentTab();
    }
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "session" && changes.openCueAt?.newValue) void consumePendingCueRequest();
    if (areaName === "session" && changes.openNoteId?.newValue) void consumePendingNavigation();
    if (areaName === "session" && changes.pendingWebClip?.newValue) void consumePendingWebClip();
    if (areaName === "session" && changes.pendingPageAction?.newValue) void consumePendingPageAction();
    if (areaName === "local" && changes.reminders) void renderReminders();
    if (areaName === "local" && (changes.googleDriveAuth || changes.googleDriveConfig || changes.googleDriveLastBackup)) void refreshGoogleDriveStatus();
  });
}

async function loadSettings() {
  const [keepLog, embeddingProvider, activeNoteId, activeMaincardId, cueLibrary, editorZoom, searchProviders, exportDestination, localSync, paperfoldTheme] = await Promise.all([
    get("settings", "keepLog"),
    get("settings", "embeddingProvider"),
    get("settings", "activeNoteId"),
    get("settings", "activeMaincardId"),
    get("settings", "cueLibrary"),
    get("settings", "editorZoom"),
    get("settings", "searchProviders"),
    get("settings", "exportDestination"),
    get("settings", "localSync"),
    get("settings", "paperfoldTheme")
  ]);
  state.settings.keepLog = keepLog?.value ?? true;
  state.settings.embeddingProvider = embeddingProvider?.value ?? "local-hash-v1";
  state.activeNoteId = activeNoteId?.value ?? null;
  state.activeMaincardId = activeMaincardId?.value ?? null;
  state.settings.cueLibrary = mergeCueLibrary(cueLibrary?.value);
  state.settings.editorZoom = clampZoom(editorZoom?.value ?? 1);
  state.settings.searchProviders = normalizeSearchProviders(searchProviders?.value || DEFAULT_SEARCH_PROVIDERS);
  state.settings.exportDestination = exportDestination?.value || "downloads";
  state.settings.localSync = normalizeSyncConfig(localSync?.value || {});
  state.settings.paperfoldTheme = ["paper", "black", "auto"].includes(paperfoldTheme?.value) ? paperfoldTheme.value : "paper";
  await chrome.runtime.sendMessage({ type: "SYNC_SEARCH_PROVIDERS", providers: state.settings.searchProviders }).catch(() => {});
}

function mergeCueLibrary(saved) {
  const merged = cloneDefaultCueLibrary();
  if (!saved || typeof saved !== "object") return merged;
  for (const [key, value] of Object.entries(saved)) {
    if (!merged[key] || !value || typeof value !== "object") continue;
    merged[key] = {
      ...merged[key],
      ...value,
      cues: Array.isArray(value.cues) ? value.cues : merged[key].cues
    };
  }
  return merged;
}

async function loadNotes(render = true) {
  state.notes = (await getAll("notes")).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  for (const note of state.notes) {
    note.capturePolicy ||= "manual";
    note.cueMode ||= "adaptive";
  }
  if (!state.notes.length) {
    const note = await makeNote("New Card");
    state.notes = [note];
    state.activeNoteId = note.id;
  }
  if (!state.notes.some((note) => note.id === state.activeNoteId)) {
    state.activeNoteId = state.notes[0].id;
  }
  await putSetting("activeNoteId", state.activeNoteId);
  if (render) renderNoteSelector();
}

function renderNoteSelector() {
  elements.noteSelect.replaceChildren();
  for (const note of state.notes) {
    const option = document.createElement("option");
    option.value = note.id;
    option.textContent = note.title || "Untitled note";
    option.selected = note.id === state.activeNoteId;
    elements.noteSelect.append(option);
  }
}

async function renderActiveNote() {
  renderNoteSelector();
  const note = activeNote();
  if (!note) return;
  elements.noteTitle.value = note.title;
  elements.noteBody.value = note.body || "";
  state.editorLoading = true;
  state.editor?.setValue(note.body || "");
  state.editorLoading = false;
  elements.capturePolicy.value = note.capturePolicy || "manual";
  elements.cueMode.value = note.cueMode || "adaptive";
  elements.saveStatus.textContent = "Saved locally";
  state.savedNoteRevision = state.noteRevision;
  elements.saveStatus.dataset.state = "saved";
  state.editorSelection = { start: 0, end: 0 };
  renderZoomControl();
  if (state.editorView === "preview") renderPreview();
  await Promise.all([renderSources(), renderScraps(), renderAttachments(), renderAnnotations(), renderReminders(), renderLiterature()]);
}

function activeNote() {
  return state.notes.find((note) => note.id === state.activeNoteId) || null;
}

async function openNoteById(noteId) {
  if (!state.notes.some((note) => note.id === noteId)) return;
  await flushNoteSave();
  state.activeNoteId = noteId;
  await putSetting("activeNoteId", noteId);
  await renderActiveNote();
  setEditorView("write");
}

async function createNote(title) {
  const safeTitle = normalizeNoteTitle(title, `Card ${state.notes.length + 1}`);
  await flushNoteSave();
  const note = await makeNote(safeTitle);
  state.activeNoteId = note.id;
  await recordLog("note-created", `Created “${note.title}”.`, note.id);
  await loadNotes();
  await renderActiveNote();
  setEditorView("write");
  elements.noteTitle.focus();
  elements.noteTitle.select();
  return note;
}

async function makeNote(title) {
  const timestamp = now();
  const note = {
    id: crypto.randomUUID(),
    title: normalizeNoteTitle(title, "Untitled note"),
    body: "",
    capturePolicy: "manual",
    cueMode: "adaptive",
    embedding: [],
    embeddingProvider: state.settings.embeddingProvider,
    createdAt: timestamp,
    updatedAt: timestamp
  };
  await put("notes", note);
  return note;
}

function normalizeNoteTitle(value, fallback) {
  if (typeof value !== "string") return fallback;
  const normalized = value.trim();
  return normalized || fallback;
}

async function deleteActiveNote() {
  const note = activeNote();
  if (!note || !confirm(`Delete “${note.title || "Untitled note"}”? Linked source snapshots used by other notes will remain.`)) return;

  const [links, scraps, annotations, chunks, attachments, memberships, fromEdges, toEdges] = await Promise.all([
    getAllByIndex("links", "noteId", note.id),
    getAllByIndex("scraps", "noteId", note.id),
    getAllByIndex("annotations", "noteId", note.id),
    getAllByIndex("chunks", "noteId", note.id),
    getAllByIndex("attachments", "noteId", note.id),
    getAllByIndex("memberships", "cardId", note.id),
    getAllByIndex("cardEdges", "fromId", note.id),
    getAllByIndex("cardEdges", "toId", note.id)
  ]);
  for (const annotation of annotations) await remove("annotations", annotation.id);
  for (const attachment of attachments) await remove("attachments", attachment.id);
  for (const membership of memberships) await remove("memberships", membership.id);
  for (const edge of [...fromEdges, ...toEdges]) await remove("cardEdges", edge.id);
  for (const chunk of chunks) await remove("chunks", chunk.id);
  for (const scrap of scraps) await remove("scraps", scrap.id);
  for (const link of links) {
    await remove("links", link.id);
    await garbageCollectSource(link.sourceId);
  }
  await recordIr("note.delete", { noteId: note.id, scraps: scraps.length, annotations: annotations.length, attachments: attachments.length, memberships: memberships.length }, null);
  await remove("notes", note.id);
  await recordLog("note-deleted", `Deleted “${note.title || "Untitled note"}”.`, null);
  state.activeNoteId = null;
  await loadNotes();
  await renderActiveNote();
}

function reconcileSave(receipt) {
  const saved = receipt?.ok === true && receipt.persisted === true;
  const status = elements.saveStatus;
  if (saved) {
    state.savedNoteRevision = Math.max(state.savedNoteRevision, receipt.revision);
    if (state.noteRevision === receipt.revision) {
      status.textContent = "Saved locally";
      status.dataset.state = "saved";
      status.setAttribute("role", "status");
      announceStatus("Card saved locally.", "success");
    } else {
      status.textContent = "Unsaved changes";
      status.dataset.state = "dirty";
    }
  } else {
    status.textContent = "Save failed — changes retained in editor";
    status.dataset.state = "error";
    status.setAttribute("role", "alert");
    announceStatus(`Card not saved: ${receipt?.error?.message || receipt?.error || "unknown error"}. Retry by editing or selecting Save.`, "error");
  }
  return saved;
}

function scheduleSave() {
  state.noteRevision += 1;
  elements.saveStatus.textContent = "Unsaved changes";
  elements.saveStatus.dataset.state = "dirty";
  clearTimeout(state.saveTimer);
  state.saveTimer = setTimeout(() => {
    state.saveTimer = null;
    void saveActiveNote();
  }, 450);
}

async function flushNoteSave() {
  if (state.saveTimer) {
    clearTimeout(state.saveTimer);
    state.saveTimer = null;
  }
  if (state.noteSaveInFlight) await state.noteSaveInFlight;
  if (state.noteRevision > state.savedNoteRevision) await saveActiveNote();
  if (state.noteRevision > state.savedNoteRevision) throw new Error("Card has unsaved changes; the requested action was not completed.");
}

async function saveActiveNote() {
  clearTimeout(state.saveTimer);
  state.saveTimer = null;
  // Serialize: never let an earlier write overwrite a newer edit.
  if (state.noteSaveInFlight) {
    await state.noteSaveInFlight;
    if (state.noteRevision <= state.savedNoteRevision) return true;
  }
  const base = activeNote();
  if (!base || state.noteRevision <= state.savedNoteRevision) return true;
  const revision = state.noteRevision;
  const note = { ...base };
  const oldTitle = note.title;
  note.title = elements.noteTitle.value.trim() || "Untitled note";
  note.body = state.editor?.getValue() ?? elements.noteBody.value;
  note.updatedAt = now();
  const properties = parseFrontmatter(note.body);
  if (properties.hasFrontmatter && Object.prototype.hasOwnProperty.call(properties.properties, "updated")) {
    note.body = ensureFrontmatter(note.body, { updated: note.updatedAt.slice(0, 16) });
  }
  note.embeddingProvider = state.settings.embeddingProvider;
  elements.saveStatus.textContent = "Saving…";
  elements.saveStatus.dataset.state = "saving";
  const write = (async () => {
    try {
      note.embedding = await embedText(`${note.title}\n${note.body}`, note.embeddingProvider);
      await put("notes", note); // acknowledged persistence is the only success gate
      const current = state.notes.findIndex((item) => item.id === note.id);
      if (current >= 0) state.notes[current] = note;
      if (note.id === state.activeNoteId && revision === state.noteRevision) {
        if (note.body !== (state.editor?.getValue() ?? elements.noteBody.value)) {
          state.editorLoading = true;
          try { state.editor?.setValue(note.body, { preserveSelection: true }); }
          finally { state.editorLoading = false; }
        }
        elements.noteBody.value = note.body;
      }
      reconcileSave({ ok: true, persisted: true, revision });
      if (oldTitle !== note.title) {
        try {
          const [scraps, attachments] = await Promise.all([
            getAllByIndex("scraps", "noteId", note.id),
            getAllByIndex("attachments", "noteId", note.id)
          ]);
          for (const scrap of scraps) {
            await put("scraps", { ...scrap, fileName: scrapFileName(note.title, scrap.sequence), updatedAt: now() });
          }
          for (const attachment of attachments) {
            await put("attachments", { ...attachment, noteTitle: note.title, markdownFileName: attachmentFileName(note.title, attachment.sequence), updatedAt: now() });
          }
          renderNoteSelector();
          await Promise.all([renderScraps(), renderAttachments()]);
        } catch (error) {
          announceStatus(`Card saved, but linked file labels could not refresh: ${error.message || error}`, "error");
        }
      }
      return true;
    } catch (error) {
      reconcileSave({ ok: false, error, revision });
      return false;
    }
  })();
  state.noteSaveInFlight = write;
  try { return await write; }
  finally {
    if (state.noteSaveInFlight === write) state.noteSaveInFlight = null;
    // A newer edit is still dirty, but do not repeat a failed write in a busy loop.
    if (state.noteRevision > revision && !state.saveTimer) {
      state.saveTimer = setTimeout(() => { state.saveTimer = null; void saveActiveNote(); }, 450);
    }
  }
}

function setEditorView(view) {
  state.editorView = view;
  const preview = view === "preview";
  elements.noteEditorHost.classList.toggle("hidden", preview);
  elements.notePreview.classList.toggle("hidden", !preview);
  elements.markdownToolbar.classList.toggle("hidden", preview);
  elements.writeTabButton.classList.toggle("active", !preview);
  elements.previewTabButton.classList.toggle("active", preview);
  elements.writeTabButton.setAttribute("aria-selected", String(!preview));
  elements.previewTabButton.setAttribute("aria-selected", String(preview));
  if (preview) {
    renderPreview();
  } else {
    requestAnimationFrame(() => state.editor?.focus());
  }
}

function renderPreview() {
  const value = state.editor?.getValue() ?? elements.noteBody.value;
  elements.notePreview.innerHTML = renderMarkdown(value);
  if (!value.trim()) elements.notePreview.innerHTML = '<p class="empty-state">Nothing to preview yet.</p>';
}

async function handlePreviewClick(event) {
  const checkbox = event.target.closest('input[type="checkbox"][data-source-line]');
  if (checkbox) {
    const lineNumber = Number(checkbox.dataset.sourceLine);
    const value = state.editor?.getValue() ?? elements.noteBody.value;
    const lines = value.replace(/\r\n?/g, "\n").split("\n");
    if (Number.isInteger(lineNumber) && lines[lineNumber] !== undefined) {
      lines[lineNumber] = lines[lineNumber].replace(/\[([ xX])\]/, checkbox.checked ? "[x]" : "[ ]");
      state.editor?.setValue(lines.join("\n"), { preserveSelection: true });
      scheduleSave();
      renderPreview();
    }
    return;
  }

  const citation = event.target.closest("[data-annotation-id]");
  if (citation) {
    await openAnnotationById(citation.dataset.annotationId);
    return;
  }

  const wikiLink = event.target.closest("[data-wikilink]");
  if (!wikiLink) return;
  const target = wikiLink.dataset.wikilink.trim();
  const existing = state.notes.find((note) => note.title.trim().toLocaleLowerCase() === target.toLocaleLowerCase());
  if (existing) {
    await openNoteById(existing.id);
    return;
  }
  if (confirm(`Create note “${target}”?`)) await createNote(target);
}

function applyMarkdownFormat(format) {
  setEditorView("write");
  restoreEditorSelection();
  state.editor?.applyFormat(format);
  rememberEditorSelection();
}

function replaceEditorRange(start, end, replacement, selectionStart, selectionEnd) {
  state.editor?.replaceRange(start, end, replacement, selectionStart, selectionEnd);
  rememberEditorSelection();
}

function insertTextAtCursor(text) {
  setEditorView("write");
  restoreEditorSelection();
  const editor = state.editor;
  if (!editor) return;
  const selection = editor.getSelection();
  const value = editor.getValue();
  let insertion = String(text || "");
  const before = value.slice(0, selection.start);
  const after = value.slice(selection.end);
  const isBlock = insertion.includes("\n") || /^#{1,6}\s/.test(insertion);
  if (isBlock && before && !before.endsWith("\n")) insertion = `\n${insertion}`;
  if (isBlock && after && !insertion.endsWith("\n")) insertion += "\n";
  editor.replaceRange(selection.start, selection.end, insertion);
  rememberEditorSelection();
}

function rememberEditorSelection() {
  const selection = state.editor?.getSelection();
  if (!selection) return;
  state.editorSelection = { start: selection.start, end: selection.end };
}

function restoreEditorSelection() {
  setEditorView("write");
  const max = state.editor?.getValue().length || 0;
  state.editor?.setSelection(
    Math.min(state.editorSelection.start, max),
    Math.min(state.editorSelection.end, max)
  );
}

function clampZoom(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 1;
  return Math.round(Math.max(0.75, Math.min(1.75, numeric)) * 10) / 10;
}

function renderZoomControl() {
  const percent = Math.round(state.settings.editorZoom * 100);
  elements.zoomResetButton.textContent = `${percent}%`;
  elements.zoomOutButton.disabled = state.settings.editorZoom <= 0.75;
  elements.zoomInButton.disabled = state.settings.editorZoom >= 1.75;
  state.editor?.setZoom(state.settings.editorZoom);
}

async function adjustEditorZoom(change) {
  const next = change === "reset"
    ? 1
    : clampZoom(state.settings.editorZoom + Number(change || 0));
  state.settings.editorZoom = next;
  await putSetting("editorZoom", next);
  renderZoomControl();
}

async function exportActiveNote() {
  const note = activeNote();
  if (!note) return;
  await flushNoteSave();
  const body = state.editor?.getValue() ?? note.body ?? "";
  const blob = new Blob([body], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${safeFilename(note.title || "Untitled note")}.md`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  await recordLog("note-exported", `Exported “${note.title}” as Markdown.`, note.id);
}

function safeFilename(value) {
  const clean = String(value || "Untitled note")
    .replace(/[\/:*?"<>|]/g, "-")
    .replace(/\s+/g, " ")
    .trim();
  return clean.slice(0, 120) || "Untitled note";
}

function handleDocumentKeydown(event) {
  if (event.key === "Alt" && !event.repeat && !event.ctrlKey && !event.metaKey && !event.shiftKey) {
    state.altCandidate = true;
    return;
  }
  if (event.altKey) state.altCandidate = false;
  if (event.key === "Escape") {
    if (state.ui.popover) { event.preventDefault(); dismissPopover(); }
    const drawer = document.querySelector('[data-pf-drawer]:not([hidden])');
    if (drawer && !document.querySelector("dialog[open]")) {
      event.preventDefault(); closeDrawer(drawer);
    }
  }
}

function handleDocumentKeyup(event) {
  if (event.key !== "Alt") return;
  if (state.altCandidate) {
    event.preventDefault();
    openCueDialog();
  }
  state.altCandidate = false;
}

async function consumePendingCueRequest() {
  try {
    const { openCueAt } = await chrome.storage.session.get("openCueAt");
    if (!openCueAt) return;
    await chrome.storage.session.remove("openCueAt");
    setTimeout(openCueDialog, 40);
  } catch {
    // Storage session is unavailable only on unsupported Chrome versions.
  }
}

async function consumePendingNavigation() {
  try {
    const { openNoteId } = await chrome.storage.session.get("openNoteId");
    if (!openNoteId) return;
    await chrome.storage.session.remove("openNoteId");
    await openNoteById(openNoteId);
  } catch {
    // Session storage is unavailable only on unsupported Chrome versions.
  }
}

async function openCueDialog() {
  rememberEditorSelection();
  const note = activeNote();
  elements.cuePaletteMode.value = note?.cueMode || "adaptive";
  elements.cueSearchInput.value = "";
  await renderCueList();
  openDialog("cueDialog");
  requestAnimationFrame(() => elements.cueSearchInput.focus());
}

async function renderCueList() {
  const note = activeNote();
  if (!note) return;
  const selectedMode = elements.cuePaletteMode.value;
  const links = await getAllByIndex("links", "noteId", note.id);
  const cues = suggestCues({
    mode: selectedMode,
    title: elements.noteTitle.value,
    body: state.editor?.getValue() ?? elements.noteBody.value,
    hasLinkedTabs: links.length > 0,
    library: state.settings.cueLibrary
  });
  const query = elements.cueSearchInput.value.trim().toLocaleLowerCase();
  const filtered = cues.filter((cue) =>
    `${cue.label} ${cue.description} ${cue.template}`.toLocaleLowerCase().includes(query)
  );

  elements.cueList.replaceChildren();
  if (!filtered.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = selectedMode === "custom"
      ? "No custom cues yet. Add them in Settings → Edit cue library."
      : "No cues match this filter.";
    elements.cueList.append(empty);
    return;
  }

  for (const cue of filtered) {
    const fragment = elements.cueItemTemplate.content.cloneNode(true);
    const item = fragment.querySelector(".cue-item");
    fragment.querySelector(".cue-label").textContent = cue.label;
    const modeKey = cue.mode || selectedMode;
    fragment.querySelector(".cue-mode").textContent = state.settings.cueLibrary[modeKey]?.label || "Cue";
    fragment.querySelector(".cue-description").textContent = cue.description || truncate(cue.template, 100);
    item.addEventListener("click", () => {
      restoreEditorSelection();
      insertTextAtCursor(cue.template);
      closeDialog("cueDialog", "explicit");
    });
    elements.cueList.append(item);
  }
}

function loadCueEditor() {
  const mode = elements.cueEditorMode.value;
  elements.cueEditorText.value = cueLibraryToEditableText(state.settings.cueLibrary, mode);
  elements.cueEditorStatus.textContent = "";
}

async function saveCueSet() {
  const mode = elements.cueEditorMode.value;
  state.settings.cueLibrary[mode].cues = editableTextToCues(elements.cueEditorText.value);
  await putSetting("cueLibrary", state.settings.cueLibrary);
  elements.cueEditorStatus.textContent = `Saved ${state.settings.cueLibrary[mode].cues.length} cue(s) for ${state.settings.cueLibrary[mode].label}.`;
}

async function resetCueSet() {
  const mode = elements.cueEditorMode.value;
  if (!confirm(`Reset ${state.settings.cueLibrary[mode].label} cues to the bundled defaults?`)) return;
  state.settings.cueLibrary[mode] = structuredClone(DEFAULT_CUE_LIBRARY[mode]);
  await putSetting("cueLibrary", state.settings.cueLibrary);
  loadCueEditor();
  elements.cueEditorStatus.textContent = "Cue set reset.";
}

function openReminderDialog() {
  const note = activeNote();
  if (!note) return;
  rememberEditorSelection();
  const defaultTime = new Date(Date.now() + 60 * 60 * 1000);
  defaultTime.setMinutes(Math.ceil(defaultTime.getMinutes() / 5) * 5, 0, 0);
  elements.reminderWhen.value = toDateTimeLocalValue(defaultTime);
  elements.reminderMessage.value = note.title || "Review this note";
  openDialog("reminderDialog");
  requestAnimationFrame(() => elements.reminderWhen.focus());
}

async function scheduleReminder(event) {
  event.preventDefault();
  const note = activeNote();
  if (!note) return;
  const when = new Date(elements.reminderWhen.value);
  const message = elements.reminderMessage.value.trim();
  if (!message || !Number.isFinite(when.getTime()) || when.getTime() <= Date.now()) {
    alert("Choose a valid future date and message.");
    return;
  }

  const reminder = {
    id: crypto.randomUUID(),
    noteId: note.id,
    noteTitle: note.title,
    message,
    when: when.toISOString(),
    createdAt: now(),
    status: "scheduled"
  };
  const response = await chrome.runtime.sendMessage({ type: "SCHEDULE_REMINDER", reminder });
  if (!response?.ok) {
    alert(`Unable to schedule reminder: ${response?.error || "Unknown error"}`);
    return;
  }

  closeDialog("reminderDialog", "complete");
  restoreEditorSelection();
  insertTextAtCursor(`@remind(${formatReminderToken(when)}; ${message})`);
  await recordLog("reminder-scheduled", `Reminder set for ${formatDate(when.toISOString())}: ${message}`, note.id);
  await renderReminders();
}

async function renderReminders() {
  const note = activeNote();
  if (!note) return;
  let response;
  try {
    response = await chrome.runtime.sendMessage({ type: "GET_REMINDERS" });
  } catch {
    response = { ok: false, reminders: [] };
  }
  const reminders = (response?.ok ? response.reminders : [])
    .filter((item) => item.noteId === note.id && item.status !== "dismissed")
    .sort((a, b) => a.when.localeCompare(b.when));
  elements.reminderList.replaceChildren();
  if (!reminders.length) {
    elements.reminderList.className = "stack empty-state";
    elements.reminderList.textContent = "No scheduled reminders.";
    return;
  }
  elements.reminderList.className = "stack";
  for (const reminder of reminders) {
    const item = document.createElement("article");
    item.className = "list-item reminder-item";
    const content = document.createElement("div");
    content.className = "grow min-width-0";
    const title = document.createElement("strong");
    title.textContent = reminder.message;
    const detail = document.createElement("p");
    detail.className = "muted";
    detail.textContent = `${formatDate(reminder.when)}${reminder.status === "fired" ? " · notified" : ""}`;
    content.append(title, detail);
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "danger icon-button";
    cancel.title = "Cancel reminder";
    cancel.textContent = "✕";
    cancel.addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ type: "CANCEL_REMINDER", reminderId: reminder.id });
      await recordLog("reminder-cancelled", `Cancelled reminder: ${reminder.message}`, note.id);
      await renderReminders();
    });
    item.append(content, cancel);
    elements.reminderList.append(item);
  }
}

function toDateTimeLocalValue(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function formatReminderToken(date) {
  return toDateTimeLocalValue(date).replace("T", " ");
}

async function refreshCurrentTab() {
  const response = await chrome.runtime.sendMessage({ type: "GET_ACTIVE_TAB" });
  state.currentTab = response?.ok ? response.tab : null;
  elements.currentTabTitle.textContent = state.currentTab
    ? `${state.currentTab.title} — ${shortUrl(state.currentTab.url)}`
    : "No active browser tab.";
  await updatePermissionUi();
}

async function updatePermissionUi() {
  const url = state.currentTab?.url || "";
  if (!/^https?:\/\//i.test(url)) {
    elements.grantSiteButton.classList.add("hidden");
    elements.permissionHint.classList.toggle("hidden", !url);
    elements.permissionHint.textContent = url ? "This page can be linked by metadata, but Chrome does not allow its text to be read." : "";
    return;
  }

  const pattern = `${new URL(url).origin}/*`;
  const granted = await chrome.permissions.contains({ origins: [pattern] });
  elements.grantSiteButton.classList.toggle("hidden", granted);
  elements.permissionHint.classList.toggle("hidden", granted);
  elements.permissionHint.textContent = granted
    ? ""
    : "The tab can be linked now using title and URL. Enable page text to capture and embed its readable content.";
}

async function grantCurrentSite() {
  const url = state.currentTab?.url;
  if (!url || !/^https?:\/\//i.test(url)) return;
  const originPattern = `${new URL(url).origin}/*`;
  const granted = await chrome.permissions.request({ origins: [originPattern] });
  await updatePermissionUi();
  if (granted) {
    await attachTab(state.currentTab, "permission-granted", { refreshExisting: true });
    announceStatus("Site permission granted; current source refreshed.", "success");
  } else {
    announceStatus("Site permission was not granted. Existing Notes and links are unchanged.", "error");
  }
}

async function autoAttachCurrentTab() {
  if (state.autoCaptureInFlight) return;
  state.autoCaptureInFlight = true;
  try {
    await refreshCurrentTab();
    await attachTab(state.currentTab, "on-write");
  } finally {
    state.autoCaptureInFlight = false;
  }
}

async function attachTab(tab, reason = "manual", options = {}) {
  const note = activeNote();
  if (!note || !tab?.url) return;

  const extraction = await chrome.runtime.sendMessage({
    type: "EXTRACT_TAB",
    tabId: tab.id,
    url: tab.url
  });
  const snapshot = extraction?.ok && extraction.snapshot ? extraction.snapshot : null;
  const canonicalUrl = normalizeUrl(snapshot?.canonicalUrl || tab.url);
  const sourceId = sourceIdForUrl(canonicalUrl);
  const existingLink = await getByIndex("links", "noteSource", [note.id, sourceId]);
  if (existingLink && !options.refreshExisting) return get("sources", sourceId);

  const previousById = await get("sources", sourceId);
  const previousByUrl = await getByIndex("sources", "url", canonicalUrl);
  const previousSource = previousById || previousByUrl;
  const source = {
    id: sourceId,
    citationKey: previousSource?.citationKey || citationKeyForSource(sourceId),
    url: canonicalUrl,
    title: snapshot?.title || tab.title || previousSource?.title || "Untitled tab",
    favIconUrl: tab.favIconUrl || previousSource?.favIconUrl || "",
    description: snapshot?.description || previousSource?.description || "",
    siteName: snapshot?.siteName || previousSource?.siteName || "",
    authors: snapshot?.authors || previousSource?.authors || [],
    publishedAt: snapshot?.publishedAt || previousSource?.publishedAt || "",
    headings: snapshot?.headings || previousSource?.headings || [],
    text: snapshot?.text || previousSource?.text || "",
    markdown: snapshot?.markdown || previousSource?.markdown || "",
    plainLines: snapshot?.plainLines || previousSource?.plainLines || [],
    lineMap: snapshot?.lineMap || previousSource?.lineMap || [],
    domHtml: snapshot?.domHtml || previousSource?.domHtml || "",
    jsonLd: snapshot?.jsonLd || previousSource?.jsonLd || [],
    apiResources: snapshot?.apiResources || previousSource?.apiResources || [],
    contentHash: snapshot?.contentHash || previousSource?.contentHash || "",
    capturedAt: snapshot?.capturedAt || previousSource?.capturedAt || null,
    readable: Boolean(snapshot) || Boolean(previousSource?.readable),
    needsPermission: Boolean(extraction?.needsPermission),
    embeddingProvider: state.settings.embeddingProvider,
    embedding: [],
    createdAt: previousSource?.createdAt || now(),
    updatedAt: now()
  };
  source.embedding = await embedText(sourceText(source), source.embeddingProvider);
  if (previousSource && previousSource.id !== sourceId) {
    const oldLinks = await getAllByIndex("links", "sourceId", previousSource.id);
    for (const oldLink of oldLinks) {
      const duplicate = await getByIndex("links", "noteSource", [oldLink.noteId, sourceId]);
      if (duplicate) await remove("links", oldLink.id);
      else await put("links", { ...oldLink, sourceId });
    }
    await remove("sources", previousSource.id);
  }
  await put("sources", source);

  if (!existingLink) {
    await put("links", {
      id: crypto.randomUUID(),
      noteId: note.id,
      sourceId,
      reason,
      createdAt: now()
    });
    await recordLog("source-attached", `Attached “${source.title}” to “${note.title}” (${reason}).`, note.id);
  } else {
    await recordLog("source-refreshed", `Refreshed “${source.title}”.`, note.id);
  }

  await recordIr(existingLink ? "source.refresh" : "source.attach", {
    sourceId: source.id,
    reason,
    contentHash: source.contentHash,
    readable: source.readable
  }, note.id);
  await renderSources();
  await updatePermissionUi();
  return source;
}

async function attachCurrentFromCommand() {
  await refreshCurrentTab();
  const source = await attachTab(state.currentTab, "slash-command");
  if (source?.url) insertTextAtCursor(markdownLink(source.title, source.url));
}

async function openTabPicker(options = {}) {
  rememberEditorSelection();
  state.tabPickerMode = { insertLinks: Boolean(options.insertLinks) };
  const response = await chrome.runtime.sendMessage({ type: "GET_WINDOW_TABS" });
  const tabs = response?.ok ? response.tabs : [];
  elements.tabPickerList.replaceChildren();
  elements.attachSelectedTabsButton.textContent = state.tabPickerMode.insertLinks
    ? "Attach and insert links"
    : "Attach selected";

  for (const tab of tabs.filter((item) => item.url)) {
    const label = document.createElement("label");
    label.className = "picker-option";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = String(tab.id);
    checkbox.dataset.tab = JSON.stringify(tab);
    const text = document.createElement("span");
    text.title = tab.url;
    text.textContent = `${tab.title} — ${shortUrl(tab.url)}`;
    label.append(checkbox, text);
    elements.tabPickerList.append(label);
  }
  openDialog("tabPickerDialog");
}

async function attachSelectedTabs(event) {
  event.preventDefault();
  const selected = [...elements.tabPickerList.querySelectorAll('input[type="checkbox"]:checked')];
  const sources = [];
  for (const checkbox of selected) {
    const tab = JSON.parse(checkbox.dataset.tab);
    const source = await attachTab(tab, "tab-picker");
    if (source) sources.push(source);
  }
  closeDialog("tabPickerDialog", "complete");
  if (state.tabPickerMode.insertLinks && sources.length) {
    restoreEditorSelection();
    insertTextAtCursor(sources.map((source) => markdownLink(source.title, source.url)).join("\n"));
  }
  state.tabPickerMode = { insertLinks: false };
}

function markdownLink(title, url) {
  const label = String(title || url || "Link").replace(/[\[\]]/g, "");
  return `[${label}](${url})`;
}

async function renderSources() {
  const note = activeNote();
  if (!note) return;
  const links = await getAllByIndex("links", "noteId", note.id);
  const sourcePairs = await Promise.all(
    links.map(async (link) => ({ link, source: await get("sources", link.sourceId) }))
  );
  const validPairs = sourcePairs.filter((pair) => pair.source && pair.source.kind !== "literature");
  elements.sourceCount.textContent = String(validPairs.length);
  elements.sourceList.replaceChildren();

  if (!validPairs.length) {
    elements.sourceList.className = "stack empty-state";
    elements.sourceList.textContent = "No tabs linked to this note.";
    return;
  }
  elements.sourceList.className = "stack";

  for (const { link, source } of validPairs) {
    const fragment = elements.sourceItemTemplate.content.cloneNode(true);
    const item = fragment.querySelector(".source-item");
    const favicon = fragment.querySelector(".favicon");
    favicon.src = source.favIconUrl || fallbackFavicon();
    favicon.addEventListener("error", () => { favicon.src = fallbackFavicon(); }, { once: true });
    const title = fragment.querySelector(".source-title");
    title.textContent = source.title;
    title.href = source.url;
    fragment.querySelector(".source-url").textContent = shortUrl(source.url);
    fragment.querySelector(".source-meta").textContent = source.readable
      ? `Page text captured · ${formatDate(source.updatedAt)}`
      : `Metadata only${source.needsPermission ? " · page permission needed" : ""}`;

    const bookmarkButton = fragment.querySelector(".bookmark-source");
    const browserBookmarks = await chrome.bookmarks.search({ url: source.url });
    const linkedBookmark = (await getAllByIndex("bookmarks", "sourceId", source.id))[0] || null;
    const existingBookmark = browserBookmarks[0] || (linkedBookmark?.chromeBookmarkId ? await chrome.bookmarks.get(linkedBookmark.chromeBookmarkId).then((items) => items[0]).catch(() => null) : null);
    bookmarkButton.classList.toggle("is-bookmarked", Boolean(existingBookmark));
    bookmarkButton.textContent = existingBookmark ? "★" : "☆";
    bookmarkButton.title = existingBookmark ? "Bookmark related to this source" : "Create Chrome bookmark and relate it";
    bookmarkButton.addEventListener("click", async () => {
      const bookmark = existingBookmark || await chrome.bookmarks.create({ title: source.title, url: source.url });
      await put("bookmarks", {
        id: `bm:${source.id}`,
        sourceId: source.id,
        chromeBookmarkId: bookmark.id,
        title: bookmark.title,
        url: bookmark.url,
        linkedAt: now()
      });
      await recordIr("bookmark.link", { sourceId: source.id, chromeBookmarkId: bookmark.id }, note.id);
      await renderSources();
    });

    fragment.querySelector(".refresh-source").addEventListener("click", async () => {
      const tabsResponse = await chrome.runtime.sendMessage({ type: "GET_WINDOW_TABS" });
      const matchingTab = tabsResponse?.tabs?.find((tab) => normalizeUrl(tab.url) === normalizeUrl(source.url));
      if (!matchingTab) {
        alert("Open this page in a tab before refreshing its snapshot.");
        return;
      }
      await attachTab(matchingTab, "refresh", { refreshExisting: true });
    });

    fragment.querySelector(".unlink-source").addEventListener("click", async () => {
      await remove("links", link.id);
      await garbageCollectSource(source.id);
      await recordLog("source-unlinked", `Unlinked “${source.title}” from “${note.title}”.`, note.id);
      await renderSources();
    });
    elements.sourceList.append(item);
  }
}

function applyPaperfoldTheme() {
  const theme = state.settings.paperfoldTheme;
  if (theme === "auto") document.documentElement.removeAttribute("data-paperfold-theme");
  else document.documentElement.dataset.paperfoldTheme = theme;
  document.documentElement.dataset.pfThemeResolved = theme === "auto"
    ? (window.matchMedia?.("(prefers-color-scheme: dark)")?.matches ? "black" : "paper") : theme;
  document.documentElement.dataset.pfReducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ? "true" : "false";
}

async function renderLiterature() {
  const note = activeNote();
  if (!note) return;
  const links = await getAllByIndex("links", "noteId", note.id);
  const records = (await Promise.all(links.map(async link => ({ link, source: await get("sources", link.sourceId) })))).filter(x => x.source?.kind === "literature");
  elements.literatureList.replaceChildren();
  elements.literatureList.classList.toggle("empty-state", records.length === 0);
  if (!records.length) { elements.literatureList.textContent = "No literature linked yet. Use Find DOI."; return; }
  for (const {link, source} of records) {
    const row = document.createElement("div"); row.className = "list-item doi-result";
    const detail = document.createElement("div");
    const title = document.createElement("a"); title.textContent = source.title; title.href = source.url; title.target = "_blank"; title.rel = "noreferrer";
    const caption = document.createElement("p"); caption.className = "muted";
    caption.textContent = `${source.doi} · ${source.metadataProvider || "manual"} · [@${source.citationKey}]`;
    detail.append(title, caption);
    const cite = document.createElement("button"); cite.type = "button"; cite.className = "secondary"; cite.textContent = "Cite";
    cite.addEventListener("click", () => void reviewSourceCitation(source.id, cite));
    const unlink = document.createElement("button"); unlink.type = "button"; unlink.className = "icon-button danger"; unlink.textContent = "×"; unlink.title = "Unlink literature from this note";
    unlink.addEventListener("click", async () => { await remove("links", link.id); await garbageCollectSource(source.id); await recordIr("literature.unlink", { sourceId: source.id, doi: source.doi }, note.id); await renderLiterature(); });
    row.append(detail, cite, unlink); elements.literatureList.append(row);
  }
}

async function openDoiDialog() {
  const note = activeNote(); if (!note) return;
  elements.doiResults.replaceChildren(); elements.doiStatus.textContent = "Scanning note and current page…";
  openDialog("doiDialog");
  const occurrences = new Map();
  for (const match of extractDois(note.body || "")) occurrences.set(match.doi, { ...match, origin: "note" });
  const tab = state.currentTab;
  if (tab?.id && /^https?:/.test(tab.url || "")) {
    try {
      const response = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
        const meta = [...document.querySelectorAll('meta[name="citation_doi"], meta[name="dc.identifier"], meta[name="DC.Identifier"], meta[name="prism.doi"]')]
          .map(x => x.content).filter(Boolean);
        const text = (document.body?.innerText || "").slice(0, 150000);
        return { meta, text };
      }});
      const data = response?.[0]?.result;
      for (const match of extractDois([...(data?.meta || []), data?.text || ""].join("\n"))) {
        if (!occurrences.has(match.doi)) occurrences.set(match.doi, { ...match, origin: "page" });
      }
    } catch { /* Chrome restricted page or no temporary site permission. Note scan remains available. */ }
  }
  for (const occurrence of occurrences.values()) appendDoiCandidate(occurrence);
  elements.doiStatus.textContent = occurrences.size ? `${occurrences.size} unique DOI(s). Choose Attach to resolve metadata.` : "No DOI found. Paste an identifier below. Browser permission may be required for page detection.";
}

async function lookupManualDoi() {
  const doi = normalizeDoi(elements.doiManualInput.value);
  if (!doi) { elements.doiStatus.textContent = "Invalid DOI. Expected 10.xxxx/suffix."; return; }
  appendDoiCandidate({ doi, origin: "manual", index: null, line: null });
  elements.doiStatus.textContent = "DOI ready. Select Attach to retrieve bibliographic metadata.";
}

function appendDoiCandidate(candidate) {
  if ([...elements.doiResults.querySelectorAll('[data-doi]')].some(x => x.dataset.doi === candidate.doi)) return;
  const row = document.createElement("div"); row.className = "list-item doi-result"; row.dataset.doi = candidate.doi;
  const info = document.createElement("div");
  const name = document.createElement("strong"); name.textContent = candidate.doi;
  const origin = document.createElement("p"); origin.className = "muted"; origin.textContent = `Found in ${candidate.origin}${candidate.line ? ` · line ${candidate.line}` : ""}`;
  info.append(name, origin);
  const btn = document.createElement("button"); btn.textContent = "Attach"; btn.type = "button";
  btn.addEventListener("click", async () => {
    btn.disabled = true; btn.textContent = "Resolving…"; elements.doiStatus.textContent = "Only DOI identifier sent to Crossref / DataCite.";
    try { const source = await attachLiterature(candidate); btn.textContent = "Attached"; elements.doiStatus.textContent = `Attached ${source.title}.`; }
    catch(error) { btn.disabled = false; btn.textContent = "Retry"; elements.doiStatus.textContent = String(error.message || error); }
  });
  row.append(info,btn); elements.doiResults.append(row);
}

async function attachLiterature(candidate) {
  const note = activeNote(); if (!note) throw new Error("No active note");
  const doi = normalizeDoi(candidate.doi); if (!doi) throw new Error("Invalid DOI");
  const url = doiUrl(doi);
  // Sharing the canonical source avoids duplicating one work across multiple notes.
  const previous = await getByIndex("sources", "url", url);
  const resolved = previous?.kind === "literature" ? null : await resolveDoi(doi);
  const source = previous?.kind === "literature" ? previous : {
    ...previous,
    ...resolved,
    id: previous?.id || sourceIdForUrl(url),
    citationKey: previous?.citationKey || citationKeyForSource(sourceIdForUrl(url)),
    text: previous?.text || "", markdown: previous?.markdown || "",
    headings: previous?.headings || [], plainLines: previous?.plainLines || [], lineMap: previous?.lineMap || [],
    readable: previous?.readable || false, needsPermission: false,
    embeddingProvider: state.settings.embeddingProvider,
    embedding: [], capturedAt: previous?.capturedAt || now(), createdAt: previous?.createdAt || now(), updatedAt: now()
  };
  if (previous?.kind !== "literature") { source.embedding = await embedText(sourceText(source), source.embeddingProvider); await put("sources", source); }
  const linked = await getByIndex("links", "noteSource", [note.id, source.id]);
  if (!linked) await put("links", { id: crypto.randomUUID(), noteId: note.id, sourceId: source.id, reason: "doi-literature", createdAt: now() });
  await recordIr("literature.attach", { sourceId: source.id, doi, metadataProvider: source.metadataProvider, occurrence: { origin: candidate.origin, line: candidate.line ?? null, offset: candidate.index ?? null } }, note.id);
  await renderLiterature();
  return source;
}

async function garbageCollectSource(sourceId) {
  const [remainingLinks, scraps, annotations, bookmarks] = await Promise.all([
    getAllByIndex("links", "sourceId", sourceId),
    getAllByIndex("scraps", "sourceId", sourceId),
    getAllByIndex("annotations", "sourceId", sourceId),
    getAllByIndex("bookmarks", "sourceId", sourceId)
  ]);
  if (!remainingLinks.length && !scraps.length && !annotations.length && !bookmarks.length) await remove("sources", sourceId);
}

async function runSearch() {
  const query = elements.searchInput.value.trim();
  if (!query) return;
  elements.searchResults.textContent = "Searching…";
  const queryVector = await embedText(query, state.settings.embeddingProvider);
  const [notes, sources, chunks] = await Promise.all([getAll("notes"), getAll("sources"), getAll("chunks")]);
  const results = [
    ...notes.map((note) => ({
      kind: "note",
      id: note.id,
      title: note.title,
      detail: truncate(note.body, 150),
      score: cosineSimilarity(queryVector, note.embedding || [])
    })),
    ...sources.map((source) => ({
      kind: "source",
      id: source.id,
      title: source.title,
      detail: shortUrl(source.url),
      url: source.url,
      score: cosineSimilarity(queryVector, source.embedding || [])
    })),
    ...chunks.map((chunk) => ({
      kind: "chunk",
      id: chunk.id,
      noteId: chunk.noteId,
      title: `Scrap lines ${chunk.fromLine}–${chunk.toLine}`,
      detail: truncate(chunk.text, 170),
      score: cosineSimilarity(queryVector, chunk.embedding || [])
    }))
  ]
    .filter((result) => result.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 12);

  elements.searchResults.replaceChildren();
  if (!results.length) {
    elements.searchResults.className = "stack empty-state";
    elements.searchResults.textContent = "No matching vectors.";
    return;
  }
  elements.searchResults.className = "stack";
  for (const result of results) {
    const item = document.createElement("article");
    item.className = "list-item search-result";
    const content = document.createElement("div");
    content.className = "grow min-width-0";
    const title = document.createElement("strong");
    title.textContent = `${result.kind === "note" ? "Note" : result.kind === "source" ? "Tab" : "Scrap"}: ${result.title}`;
    const detail = document.createElement("p");
    detail.className = "muted";
    detail.textContent = result.detail || "";
    const score = document.createElement("span");
    score.className = "badge search-score";
    score.textContent = result.score.toFixed(4);
    content.append(title, detail);
    item.append(content, score);
    item.addEventListener("click", async () => {
      if (result.kind === "note" || result.kind === "chunk") {
        const noteId = result.kind === "note" ? result.id : result.noteId;
        if (!noteId) return;
        await flushNoteSave();
        state.activeNoteId = noteId;
        await putSetting("activeNoteId", noteId);
        await renderActiveNote();
      } else {
        chrome.tabs.create({ url: result.url });
      }
    });
    elements.searchResults.append(item);
  }
}


async function ensureMigrationBackup() {
  const migrations = [
    {
      marker: "migrationBackup:v0.3-v0.4",
      fromVersion: "0.3.x",
      toVersion: "0.4.0",
      stores: ["notes", "sources", "links", "logs", "settings"]
    },
    {
      marker: "migrationBackup:v0.4-v0.5",
      fromVersion: "0.4.0",
      toVersion: "0.5.0",
      stores: ["notes", "sources", "links", "logs", "settings", "scraps", "annotations", "chunks", "ir", "bookmarks", "backups"]
    },
    {
      marker: "migrationBackup:v0.5-v0.6",
      fromVersion: "0.5.0",
      toVersion: "0.6.0",
      stores: ["notes", "sources", "links", "logs", "settings", "scraps", "annotations", "chunks", "ir", "bookmarks", "backups", "transports"]
    }
  ];
  for (const migration of migrations) {
    const marker = await get("settings", migration.marker);
    if (marker?.value) continue;
    const values = await Promise.all(migration.stores.map((store) => getAll(store)));
    const data = Object.fromEntries(migration.stores.map((store, index) => [store, store === "backups" ? values[index].map(({ data: _data, ...meta }) => meta) : values[index]]));
    await put("backups", {
      id: `backup:${migration.fromVersion}:${Date.now()}`,
      fromVersion: migration.fromVersion,
      toVersion: migration.toVersion,
      createdAt: now(),
      data
    });
    await putSetting(migration.marker, true);
  }
}

async function recordIr(kind, payload = {}, noteId = null) {
  await put("ir", {
    id: crypto.randomUUID(),
    kind,
    noteId,
    payload,
    createdAt: now(),
    schema: "tabwoven.ir/1"
  });
}

async function scrapeCurrentPage() {
  const note = activeNote();
  if (!note) return;
  await refreshCurrentTab();
  const tab = state.currentTab;
  if (!tab?.url || !/^https?:\/\//i.test(tab.url)) {
    alert("This page cannot be scraped.");
    return;
  }
  const pattern = `${new URL(tab.url).origin}/*`;
  let granted = await chrome.permissions.contains({ origins: [pattern] });
  if (!granted) granted = await chrome.permissions.request({ origins: [pattern] });
  if (!granted) return;
  const source = await attachTab(tab, "scrap", { refreshExisting: true });
  if (!source?.markdown) {
    alert("No readable Markdown could be extracted from this page.");
    return;
  }
  const scrap = await createScrapFromSource(note, source);
  await recordLog("scrap-created", `Created ${scrap.fileName}.`, note.id);
  await renderScraps();
}

async function createScrapFromSource(note, source) {
  const current = await getAllByIndex("scraps", "noteId", note.id);
  const sequence = current.reduce((max, item) => Math.max(max, Number(item.sequence) || 0), 0) + 1;
  const timestamp = now();
  const scrap = {
    id: `scrap:${crypto.randomUUID()}`,
    noteId: note.id,
    sourceId: source.id,
    sequence,
    fileName: scrapFileName(note.title, sequence),
    title: source.title,
    url: source.url,
    markdown: source.markdown || source.text || "",
    plainLines: source.plainLines || [],
    lineMap: source.lineMap || [],
    contentHash: source.contentHash || stableHash(source.markdown || source.text || ""),
    capturedAt: source.capturedAt || timestamp,
    hidden: {
      domHtml: source.domHtml || "",
      jsonLd: source.jsonLd || [],
      apiResources: source.apiResources || []
    },
    createdAt: timestamp,
    updatedAt: timestamp
  };
  await put("scraps", scrap);
  const chunks = await buildEmbeddedChunks({
    owner: scrap,
    ownerType: "scrap",
    noteId: note.id,
    sourceId: source.id,
    providerId: state.settings.embeddingProvider
  });
  await putMany("chunks", chunks);
  await recordIr("scrap.create", {
    scrapId: scrap.id,
    sourceId: source.id,
    sequence,
    fileName: scrap.fileName,
    contentHash: scrap.contentHash,
    lines: scrap.markdown.split(/\r?\n/).length
  }, note.id);
  return scrap;
}

async function renderScraps() {
  const note = activeNote();
  if (!note) return;
  const scraps = (await getAllByIndex("scraps", "noteId", note.id)).sort((a, b) => a.sequence - b.sequence);
  elements.scrapCount.textContent = String(scraps.length);
  elements.scrapList.replaceChildren();
  if (!scraps.length) {
    elements.scrapList.className = "stack empty-state";
    elements.scrapList.textContent = "No page scraps for this note.";
    return;
  }
  elements.scrapList.className = "stack";
  for (const scrap of scraps) {
    const fragment = elements.scrapItemTemplate.content.cloneNode(true);
    fragment.querySelector(".scrap-name").textContent = scrap.fileName;
    fragment.querySelector(".scrap-meta").textContent = `${scrap.markdown.split(/\r?\n/).length} lines · ${shortUrl(scrap.url)} · ${formatDate(scrap.capturedAt)}`;
    fragment.querySelector(".export-scrap").addEventListener("click", () => downloadText(scrap.markdown, scrap.fileName, "text/markdown"));
    fragment.querySelector(".delete-scrap").addEventListener("click", async () => {
      if (!confirm(`Delete ${scrap.fileName} and its derived vector chunks?`)) return;
      for (const chunk of await getAllByIndex("chunks", "ownerId", scrap.id)) await remove("chunks", chunk.id);
      for (const annotation of await getAllByIndex("annotations", "scrapId", scrap.id)) await remove("annotations", annotation.id);
      await remove("scraps", scrap.id);
      await recordIr("scrap.delete", { scrapId: scrap.id }, note.id);
      await Promise.all([renderScraps(), renderAnnotations()]);
    });
    elements.scrapList.append(fragment);
  }
}

async function captureSelectionFromButton() {
  await refreshCurrentTab();
  const tab = state.currentTab;
  if (!tab?.id || !/^https?:\/\//i.test(tab.url || "")) {
    alert("Select text on an ordinary web page first.");
    return;
  }
  const pattern = `${new URL(tab.url).origin}/*`;
  let granted = await chrome.permissions.contains({ origins: [pattern] });
  if (!granted) granted = await chrome.permissions.request({ origins: [pattern] });
  if (!granted) return;
  const response = await chrome.runtime.sendMessage({ type: "CAPTURE_SELECTION", tabId: tab.id, url: tab.url });
  if (!response?.ok) {
    alert(response?.error || "No page selection was found. Select text in the page, then try again.");
    return;
  }
  const extraction = await chrome.runtime.sendMessage({ type: "EXTRACT_TAB", tabId: tab.id, url: tab.url });
  openAnnotationDialog({ ...response.clip, snapshot: extraction?.snapshot || null, tab });
}

async function consumePendingWebClip() {
  const stored = await chrome.storage.session.get(["pendingWebClip", "pendingWebClipAt"]);
  if (!stored.pendingWebClip) return;
  await chrome.storage.session.remove(["pendingWebClip", "pendingWebClipAt"]);
  openAnnotationDialog(stored.pendingWebClip);
}

function openAnnotationDialog(clip) {
  if (!clip?.exact) return;
  rememberEditorSelection();
  state.pendingClip = clip;
  elements.annotationQuote.textContent = clip.exact;
  elements.annotationComment.value = "";
  elements.annotationInsertCitation.checked = true;
  openDialog("annotationDialog");
  requestAnimationFrame(() => elements.annotationComment.focus());
}

async function savePendingAnnotation(event) {
  event.preventDefault();
  const note = activeNote();
  const clip = state.pendingClip;
  if (!note || !clip) return;
  let source = await getByIndex("sources", "url", normalizeUrl(clip.pageUrl));
  if (!source) source = await upsertSourceFromClip(note, clip);
  else {
    const existingLink = await getByIndex("links", "noteSource", [note.id, source.id]);
    if (!existingLink) await put("links", { id: crypto.randomUUID(), noteId: note.id, sourceId: source.id, reason: "annotation", createdAt: now() });
  }
  let scrap = null;
  const scraps = await getAllByIndex("scraps", "noteId", note.id);
  scrap = scraps.find((item) => item.sourceId === source.id && item.contentHash && item.contentHash === source.contentHash) || null;
  if (!scrap && source.markdown) scrap = await createScrapFromSource(note, source);
  const lineRange = scrap ? findSelectionLineRange(scrap.plainLines, clip.exact) : { fromLine: null, toLine: null, strategy: "unresolved" };
  const selection = state.editor?.getSelection() || { start: 0 };
  const body = state.editor?.getValue() || "";
  const noteLine = body.slice(0, selection.start).split("\n").length;
  const noteLineText = body.split("\n")[noteLine - 1] || "";
  const annotation = {
    id: `ann:${crypto.randomUUID()}`,
    citationKey: `tw-ann-${crypto.randomUUID().slice(0, 8)}`,
    noteId: note.id,
    sourceId: source.id,
    scrapId: scrap?.id || null,
    comment: elements.annotationComment.value.trim(),
    quote: { exact: clip.exact, rawExact: clip.rawExact || clip.exact, prefix: clip.prefix || "", suffix: clip.suffix || "" },
    anchors: clip.anchors || {},
    sourceLines: lineRange,
    noteAnchor: { line: noteLine, offset: selection.start, lineText: noteLineText, blockHash: stableHash(noteLineText) },
    pageTitle: clip.pageTitle || source.title,
    pageUrl: source.url,
    headings: clip.headings || [],
    createdAt: now(),
    updatedAt: now()
  };
  await put("annotations", annotation);
  const token = annotationCitationToken(annotation, source);
  if (elements.annotationInsertCitation.checked) {
    restoreEditorSelection();
    const comment = (annotation.comment || "Source annotation").replace(/\n/g, "\n> ");
    const quoted = annotation.quote.exact.replace(/\n/g, "\n> ");
    insertTextAtCursor(`> [!source] ${comment}\n> “${quoted}” ${token}`);
  }
  await recordIr("annotation.create", {
    annotationId: annotation.id,
    sourceId: source.id,
    scrapId: scrap?.id || null,
    sourceLines: lineRange,
    anchors: annotation.anchors,
    quoteHash: stableHash(annotation.quote.exact)
  }, note.id);
  await recordLog("annotation-created", `Annotated “${truncate(annotation.quote.exact, 70)}”.`, note.id);
  state.pendingClip = null;
  closeDialog("annotationDialog", "complete");
  await Promise.all([renderSources(), renderScraps(), renderAnnotations()]);
}

async function upsertSourceFromClip(note, clip) {
  const snapshot = clip.snapshot || {};
  const url = snapshot.canonicalUrl || clip.pageUrl;
  const id = sourceIdForUrl(url);
  const previous = await get("sources", id);
  const source = {
    id,
    citationKey: previous?.citationKey || citationKeyForSource(id),
    url,
    title: snapshot.title || clip.pageTitle || previous?.title || "Untitled page",
    favIconUrl: clip.tab?.favIconUrl || previous?.favIconUrl || "",
    description: snapshot.description || previous?.description || "",
    siteName: snapshot.siteName || previous?.siteName || "",
    authors: snapshot.authors || previous?.authors || [],
    publishedAt: snapshot.publishedAt || previous?.publishedAt || "",
    headings: snapshot.headings || previous?.headings || [],
    text: snapshot.text || previous?.text || clip.exact,
    markdown: snapshot.markdown || previous?.markdown || clip.exact,
    plainLines: snapshot.plainLines || previous?.plainLines || [clip.exact],
    lineMap: snapshot.lineMap || previous?.lineMap || [],
    domHtml: snapshot.domHtml || previous?.domHtml || "",
    jsonLd: snapshot.jsonLd || previous?.jsonLd || [],
    apiResources: snapshot.apiResources || previous?.apiResources || [],
    contentHash: snapshot.contentHash || previous?.contentHash || stableHash(snapshot.markdown || clip.exact),
    capturedAt: snapshot.capturedAt || clip.capturedAt || now(),
    readable: Boolean(snapshot.markdown) || Boolean(previous?.readable),
    needsPermission: false,
    embeddingProvider: state.settings.embeddingProvider,
    embedding: [],
    createdAt: previous?.createdAt || now(),
    updatedAt: now()
  };
  source.embedding = await embedText(sourceText(source), source.embeddingProvider);
  await put("sources", source);
  const link = await getByIndex("links", "noteSource", [note.id, id]);
  if (!link) await put("links", { id: crypto.randomUUID(), noteId: note.id, sourceId: id, reason: "annotation", createdAt: now() });
  return source;
}

function findSelectionLineRange(plainLines, exact) {
  const lines = Array.isArray(plainLines) ? plainLines.map((line) => String(line || "").replace(/\s+/g, " ").trim()) : [];
  const needle = String(exact || "").replace(/\s+/g, " ").trim();
  if (!needle || !lines.length) return { fromLine: null, toLine: null, strategy: "unresolved" };
  const starts = [];
  let flat = "";
  for (let index = 0; index < lines.length; index += 1) {
    if (flat) flat += " ";
    starts.push(flat.length);
    flat += lines[index];
  }
  const position = flat.indexOf(needle);
  if (position < 0) {
    const hit = lines.findIndex((line) => line.includes(needle) || (line.length > 20 && needle.includes(line)));
    return hit >= 0 ? { fromLine: hit + 1, toLine: hit + 1, strategy: "line-fuzzy" } : { fromLine: null, toLine: null, strategy: "unresolved" };
  }
  const endPosition = position + needle.length;
  let fromLine = 1;
  let toLine = lines.length;
  for (let index = 0; index < starts.length; index += 1) {
    const lineEnd = starts[index] + lines[index].length;
    if (position >= starts[index] && position <= lineEnd) { fromLine = index + 1; break; }
  }
  for (let index = fromLine - 1; index < starts.length; index += 1) {
    const lineEnd = starts[index] + lines[index].length;
    if (endPosition <= lineEnd) { toLine = index + 1; break; }
  }
  return { fromLine, toLine, strategy: "text-quote" };
}

async function renderAnnotations() {
  const note = activeNote();
  if (!note) return;
  const annotations = (await getAllByIndex("annotations", "noteId", note.id)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  elements.annotationCount.textContent = String(annotations.length);
  elements.annotationList.replaceChildren();
  if (!annotations.length) {
    elements.annotationList.className = "stack empty-state";
    elements.annotationList.textContent = "No annotations for this note.";
    return;
  }
  elements.annotationList.className = "stack";
  for (const annotation of annotations) {
    const fragment = elements.annotationItemTemplate.content.cloneNode(true);
    fragment.querySelector(".annotation-exact").textContent = truncate(annotation.quote?.exact, 280);
    const comment = fragment.querySelector(".annotation-comment");
    comment.textContent = annotation.comment || "";
    comment.classList.toggle("hidden", !annotation.comment);
    const lines = annotation.sourceLines?.fromLine
      ? `lines ${annotation.sourceLines.fromLine}${annotation.sourceLines.toLine !== annotation.sourceLines.fromLine ? `–${annotation.sourceLines.toLine}` : ""}`
      : "line unresolved";
    fragment.querySelector(".annotation-meta").textContent = `${shortUrl(annotation.pageUrl)} · ${lines} · ${formatDate(annotation.createdAt)}`;
    fragment.querySelector(".open-annotation").addEventListener("click", () => void openAnnotationById(annotation.id));
    fragment.querySelector(".insert-annotation").addEventListener("click", (event) => {
      void reviewSourceCitation(annotation.sourceId, event.currentTarget, { annotation });
    });
    fragment.querySelector(".delete-annotation").addEventListener("click", async () => {
      await remove("annotations", annotation.id);
      await recordIr("annotation.delete", { annotationId: annotation.id }, note.id);
      await renderAnnotations();
    });
    elements.annotationList.append(fragment);
  }
}

async function openAnnotationById(annotationId) {
  const annotation = await get("annotations", annotationId);
  if (!annotation) return;
  const source = await get("sources", annotation.sourceId);
  const url = source?.url || annotation.pageUrl;
  if (!url) return;
  const tabs = await chrome.tabs.query({});
  let tab = tabs.find((item) => normalizeUrl(item.url || "") === normalizeUrl(url));
  if (!tab) tab = await chrome.tabs.create({ url, active: true });
  else {
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
  }
  await waitForTabComplete(tab.id);
  const response = await chrome.runtime.sendMessage({ type: "HIGHLIGHT_ANNOTATION", tabId: tab.id, annotation });
  await recordIr("annotation.resolve", { annotationId, result: response?.result || null }, annotation.noteId);
  if (!response?.ok || !response.result?.resolved) alert("The page opened, but the passage could not be resolved automatically. The stored quote and scrap line remain available in Paperfold.");
}

async function waitForTabComplete(tabId, timeout = 12000) {
  const current = await chrome.tabs.get(tabId);
  if (current.status === "complete") return;
  await new Promise((resolve) => {
    const timer = setTimeout(done, timeout);
    function done() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }
    function listener(updatedId, info) {
      if (updatedId === tabId && info.status === "complete") done();
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function exportActiveBundle() {
  const note = activeNote();
  if (!note) return;
  await flushNoteSave();
  const [scraps, annotations, links, allIr, chunks, attachments, memberships, allMaincards, allCardEdges] = await Promise.all([
    getAllByIndex("scraps", "noteId", note.id),
    getAllByIndex("annotations", "noteId", note.id),
    getAllByIndex("links", "noteId", note.id),
    getAllByIndex("ir", "noteId", note.id),
    getAllByIndex("chunks", "noteId", note.id),
    getAllByIndex("attachments", "noteId", note.id),
    getAllByIndex("memberships", "cardId", note.id),
    getAll("maincards"),
    getAll("cardEdges")
  ]);
  const sources = (await Promise.all(links.map((link) => get("sources", link.sourceId)))).filter(Boolean);
  const sourceIds = new Set(sources.map((source) => source.id));
  const bookmarks = (await getAll("bookmarks")).filter((item) => sourceIds.has(item.sourceId));
  const maincardIds = new Set(memberships.map((item) => item.maincardId));
  const maincards = allMaincards.filter((item) => maincardIds.has(item.id));
  const cardEdges = allCardEdges.filter((edge) => edge.fromId === note.id || edge.toId === note.id || maincardIds.has(edge.maincardId));
  const blob = await createWovenBundleBlob({ note, scraps, annotations, sources, links, bookmarks, ir: allIr, chunks, attachments, maincards, memberships, cardEdges, includeVectors: true });
  const ext = blob.type === "application/gzip" ? "wv.tar.gz" : "wv.tar";
  await downloadBlob(blob, `${safeFileStem(note.title)}.${ext}`);
  await recordLog("bundle-exported", `Exported woven bundle for “${note.title}”.`, note.id);
  await recordIr("bundle.export", { scraps: scraps.length, annotations: annotations.length, chunks: chunks.length }, note.id);
}

async function exportWorkspaceBackup() {
  await flushNoteSave();
  const [notes, sources, links, scraps, annotations, chunks, ir, bookmarks, settings, backups, transports, attachments, maincards, memberships, cardEdges, syncRuns, browserSessions, sessionRevisions] = await Promise.all([
    getAll("notes"),
    getAll("sources"),
    getAll("links"),
    getAll("scraps"),
    getAll("annotations"),
    getAll("chunks"),
    getAll("ir"),
    getAll("bookmarks"),
    getAll("settings"),
    getAll("backups"),
    getAll("transports"),
    getAll("attachments"),
    getAll("maincards"),
    getAll("memberships"),
    getAll("cardEdges"),
    getAll("syncRuns"),
    getAll("browserSessions"),
    getAll("sessionRevisions")
  ]);
  const blob = await createWorkspaceBundleBlob({
    notes, sources, links, scraps, annotations, chunks, ir, bookmarks, settings, backups, transports,
    attachments, maincards, memberships, cardEdges, syncRuns, browserSessions, sessionRevisions, includeVectors: true
  });
  const timestamp = fileTimestamp();
  const ext = blob.type === "application/gzip" ? "wv.tar.gz" : "wv.tar";
  const filename = `Paperfold/Backups/paperfold-workspace-${timestamp}.${ext}`;
  await downloadBlob(blob, filename, { saveAs: false, destination: state.settings.exportDestination });
  const transport = await recordTransport({ kind: "workspace-backup", destination: state.settings.exportDestination, noteId: null, name: filename, metadata: { notes: notes.length, scraps: scraps.length, attachments: attachments.length, maincards: maincards.length } });
  await recordLog("workspace-backup", `Exported workspace backup with ${notes.length} notes and ${scraps.length} scraps.`, state.activeNoteId);
  await recordIr("workspace.export", {
    transportId: transport.id,
    notes: notes.length,
    sources: sources.length,
    scraps: scraps.length,
    annotations: annotations.length,
    chunks: chunks.length,
    attachments: attachments.length,
    maincards: maincards.length,
    cardEdges: cardEdges.length
  }, state.activeNoteId);
}

function downloadText(text, filename, mime = "text/plain", options = {}) {
  return downloadBlob(new Blob([String(text || "")], { type: `${mime};charset=utf-8` }), filename, options);
}

async function downloadBlob(blob, filename, options = {}) {
  const destination = options.destination || "downloads";
  if (destination === "chosen-folder") {
    await writeBlobToChosenFolder(blob, filename);
    return;
  }
  const url = URL.createObjectURL(blob);
  try {
    await chrome.downloads.download({ url, filename, saveAs: options.saveAs ?? true });
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }
}

async function recordLog(action, detail, noteId) {
  if (!state.settings.keepLog) return;
  await put("logs", {
    id: crypto.randomUUID(),
    action,
    detail,
    noteId,
    createdAt: now()
  });
  await renderLogs();
}

async function renderLogs() {
  const logs = (await getAll("logs"))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 100);
  elements.logList.replaceChildren();
  elements.activitySection.classList.toggle("hidden", !state.settings.keepLog);
  if (!logs.length) {
    elements.logList.className = "stack empty-state";
    elements.logList.textContent = "No activity recorded.";
    return;
  }
  elements.logList.className = "stack";
  for (const log of logs) {
    const fragment = elements.logItemTemplate.content.cloneNode(true);
    fragment.querySelector(".log-action").textContent = humanizeAction(log.action);
    fragment.querySelector(".log-detail").textContent = log.detail;
    fragment.querySelector(".log-time").textContent = formatDate(log.createdAt);
    fragment.querySelector(".delete-log").addEventListener("click", async () => {
      await remove("logs", log.id);
      await renderLogs();
    });
    elements.logList.append(fragment);
  }
}

async function insertYamlTemplate(kind) {
  const note = activeNote();
  if (!note) return;
  await flushNoteSave();
  const defaults = noteTemplate(kind);
  if (kind === "youtube") {
    try {
      await refreshCurrentTab();
      const url = new URL(state.currentTab?.url || "");
      if (url.hostname.includes("youtube.com")) defaults.video_id = url.searchParams.get("v") || "";
      if (url.hostname === "youtu.be") defaults.video_id = url.pathname.slice(1);
      defaults.source_url = state.currentTab?.url || "";
    } catch {}
  }
  if (kind === "zotero") defaults.integration = "zotero-compatible";
  if (kind === "market-research") defaults.safety_scope = "research-only";
  const value = ensureFrontmatter(state.editor.getValue(), defaults);
  state.editorLoading = true;
  state.editor.setValue(value, { preserveSelection: true });
  state.editorLoading = false;
  elements.noteBody.value = value;
  scheduleSave(); // direct programmatic CM6 writes bypass the onChange callback
  if (!(await saveActiveNote())) return;
  await recordLog("yaml-template", `Applied ${kind} YAML properties to “${note.title}”.`, note.id);
  await recordIr("note.properties", { template: kind, properties: defaults }, note.id);
  state.editor.focus();
}

async function loadWorkspaceData() {
  await flushNoteSave();
  const [notes, sources, links, scraps, annotations, ir, transports, attachments, maincards, memberships, cardEdges] = await Promise.all([
    getAll("notes"),
    getAll("sources"),
    getAll("links"),
    getAll("scraps"),
    getAll("annotations"),
    getAll("ir"),
    getAll("transports"),
    getAll("attachments"),
    getAll("maincards"),
    getAll("memberships"),
    getAll("cardEdges")
  ]);
  let reminders = [];
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_REMINDERS" });
    if (response?.ok) reminders = response.reminders || [];
  } catch {}
  const rows = buildReviewRows({ notes, sources, links, scraps, annotations, reminders, transports, attachments, memberships });
  const calendarItems = buildCalendarItems({ notes, reminders, transports });
  const graph = buildFlowGraph({ notes, sources, links, scraps, annotations, attachments, maincards, memberships, cardEdges });
  state.workspaceData = {
    notes, sources, links, scraps, annotations, reminders, ir, transports, attachments, maincards, memberships, cardEdges,
    rows, calendarItems, graph,
    flatten: flattenWorkspace({ rows, calendarItems, graph })
  };
  return state.workspaceData;
}

async function openWorkspaceDialog(view = "spreadsheet") {
  await loadWorkspaceData();
  setWorkspaceView(view, { render: false });
  renderWorkspaceCurrentView();
  openDialog("workspaceDialog");
}

function setWorkspaceView(view, options = {}) {
  const allowed = new Set(["spreadsheet", "calendar", "flow", "flatten"]);
  state.workspaceView = allowed.has(view) ? view : "spreadsheet";
  const pairs = [
    [elements.workspaceSpreadsheetTab, elements.workspaceSpreadsheetView, "spreadsheet"],
    [elements.workspaceCalendarTab, elements.workspaceCalendarView, "calendar"],
    [elements.workspaceFlowTab, elements.workspaceFlowView, "flow"],
    [elements.workspaceFlattenTab, elements.workspaceFlattenView, "flatten"]
  ];
  for (const [tab, panel, name] of pairs) {
    tab.classList.toggle("active", name === state.workspaceView);
    panel.classList.toggle("hidden", name !== state.workspaceView);
  }
  if (options.render !== false) renderWorkspaceCurrentView();
}

function workspaceFilterText() {
  return String(elements.workspaceFilter.value || "").trim().toLocaleLowerCase();
}

function filteredWorkspaceRows() {
  const rows = state.workspaceData?.rows || [];
  const query = workspaceFilterText();
  if (!query) return rows;
  return rows.filter((row) => Object.values(row).some((value) => String(Array.isArray(value) ? value.join(" ") : value ?? "").toLocaleLowerCase().includes(query)));
}

function filteredCalendarItems() {
  const items = state.workspaceData?.calendarItems || [];
  const query = workspaceFilterText();
  if (!query) return items;
  const acceptedIds = new Set(filteredWorkspaceRows().map((row) => row.note_id));
  return items.filter((item) => acceptedIds.has(item.noteId) || String(item.title || "").toLocaleLowerCase().includes(query));
}

function filteredFlowGraph() {
  const graph = state.workspaceData?.graph || { nodes: [], edges: [] };
  const query = workspaceFilterText();
  if (!query) return graph;
  const accepted = new Set(graph.nodes.filter((node) => String(node.label || "").toLocaleLowerCase().includes(query)).map((node) => node.id));
  for (const edge of graph.edges) {
    if (accepted.has(edge.from)) accepted.add(edge.to);
    if (accepted.has(edge.to)) accepted.add(edge.from);
  }
  return {
    nodes: graph.nodes.filter((node) => accepted.has(node.id)),
    edges: graph.edges.filter((edge) => accepted.has(edge.from) && accepted.has(edge.to))
  };
}

function renderWorkspaceCurrentView() {
  if (!state.workspaceData) return;
  if (state.workspaceView === "spreadsheet") renderWorkspaceSpreadsheet();
  if (state.workspaceView === "calendar") renderWorkspaceCalendar();
  if (state.workspaceView === "flow") renderWorkspaceFlow();
  if (state.workspaceView === "flatten") renderWorkspaceFlatten();
}

function renderWorkspaceSpreadsheet() {
  const rows = filteredWorkspaceRows();
  const preferred = ["title", "type", "status", "domain", "purpose", "objective", "next_action", "due", "review", "progress", "source_count", "scrap_count", "annotation_count", "attachment_count", "maincard_count", "reminder_count", "transport_count", "updated_at"];
  const discovered = new Set();
  for (const row of rows) for (const key of Object.keys(row)) discovered.add(key);
  const columns = [...preferred.filter((key) => discovered.has(key)), ...[...discovered].filter((key) => !preferred.includes(key) && !["note_id", "created_at"].includes(key)).slice(0, 12)];
  const table = document.createElement("table");
  table.className = "review-table";
  const thead = document.createElement("thead");
  const header = document.createElement("tr");
  for (const key of columns) {
    const th = document.createElement("th");
    th.textContent = key.replaceAll("_", " ");
    header.append(th);
  }
  thead.append(header);
  const tbody = document.createElement("tbody");
  for (const row of rows) {
    const tr = document.createElement("tr");
    for (const key of columns) {
      const td = document.createElement("td");
      const value = Array.isArray(row[key]) ? row[key].join(" · ") : row[key] ?? "";
      if (key === "title") {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "review-note-link";
        button.textContent = String(value || "Untitled note");
        button.addEventListener("click", () => void openWorkspaceNote(row.note_id));
        td.append(button);
      } else td.textContent = String(value);
      tr.append(td);
    }
    tbody.append(tr);
  }
  table.append(thead, tbody);
  elements.workspaceSpreadsheetView.replaceChildren(table);
  if (!rows.length) elements.workspaceSpreadsheetView.textContent = "No notes match this projection.";
}

function renderWorkspaceCalendar() {
  const items = filteredCalendarItems();
  const base = items.length ? new Date(items.find((item) => new Date(item.date).getMonth() === new Date().getMonth())?.date || items[0].date) : new Date();
  const year = base.getFullYear();
  const month = base.getMonth();
  const first = new Date(year, month, 1);
  const start = new Date(year, month, 1 - first.getDay());
  const layout = document.createElement("div");
  layout.className = "calendar-layout";
  const monthWrap = document.createElement("div");
  const title = document.createElement("h3");
  title.textContent = first.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  const grid = document.createElement("div");
  grid.className = "calendar-month";
  for (const name of ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]) {
    const label = document.createElement("div");
    label.className = "calendar-weekday";
    label.textContent = name;
    grid.append(label);
  }
  const byDay = new Map();
  for (const item of items) {
    const key = localDateKey(new Date(item.date));
    const list = byDay.get(key) || [];
    list.push(item);
    byDay.set(key, list);
  }
  const today = localDateKey(new Date());
  for (let offset = 0; offset < 42; offset += 1) {
    const date = new Date(start);
    date.setDate(start.getDate() + offset);
    const cell = document.createElement("div");
    cell.className = "calendar-day";
    if (date.getMonth() !== month) cell.classList.add("outside");
    if (localDateKey(date) === today) cell.classList.add("today");
    const number = document.createElement("span");
    number.className = "calendar-number";
    number.textContent = String(date.getDate());
    cell.append(number);
    for (const item of (byDay.get(localDateKey(date)) || []).slice(0, 4)) {
      const event = document.createElement("button");
      event.type = "button";
      event.className = "calendar-event";
      event.title = `${item.field}: ${item.title}`;
      event.textContent = item.title;
      if (item.noteId) event.addEventListener("click", () => void openWorkspaceNote(item.noteId));
      cell.append(event);
    }
    grid.append(cell);
  }
  monthWrap.append(title, grid);
  const agenda = document.createElement("div");
  agenda.className = "calendar-agenda";
  const agendaTitle = document.createElement("h3");
  agendaTitle.textContent = "Agenda";
  agenda.append(agendaTitle);
  for (const item of items.slice(0, 80)) {
    const card = document.createElement("article");
    card.className = "calendar-agenda-item";
    const strong = document.createElement("strong");
    strong.textContent = item.title;
    const detail = document.createElement("p");
    detail.className = "muted";
    detail.textContent = `${new Date(item.date).toLocaleString()} · ${item.field}`;
    card.append(strong, detail);
    if (item.noteId) card.addEventListener("click", () => void openWorkspaceNote(item.noteId));
    agenda.append(card);
  }
  layout.append(monthWrap, agenda);
  elements.workspaceCalendarView.replaceChildren(layout);
}

function renderWorkspaceFlow() {
  const graph = filteredFlowGraph();
  const svgNs = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNs, "svg");
  svg.classList.add("flow-canvas");
  const width = Math.max(900, Math.ceil(graph.nodes.length / 4) * 230 + 160);
  const height = Math.max(520, Math.min(12, graph.nodes.length) * 95 + 100);
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.setAttribute("width", String(width));
  svg.setAttribute("height", String(height));
  const defs = document.createElementNS(svgNs, "defs");
  const marker = document.createElementNS(svgNs, "marker");
  marker.setAttribute("id", "arrow"); marker.setAttribute("viewBox", "0 0 10 10"); marker.setAttribute("refX", "9"); marker.setAttribute("refY", "5"); marker.setAttribute("markerWidth", "6"); marker.setAttribute("markerHeight", "6"); marker.setAttribute("orient", "auto-start-reverse");
  const path = document.createElementNS(svgNs, "path");
  path.setAttribute("d", "M 0 0 L 10 5 L 0 10 z"); path.setAttribute("fill", "currentColor");
  marker.append(path); defs.append(marker); svg.append(defs);
  const positions = new Map();
  const notes = graph.nodes.filter((node) => node.type === "note");
  const sources = graph.nodes.filter((node) => node.type !== "note");
  const layoutNodes = [...notes, ...sources];
  const columns = 4;
  for (let index = 0; index < layoutNodes.length; index += 1) {
    const node = layoutNodes[index];
    const column = Math.floor(index / Math.max(1, Math.ceil(layoutNodes.length / columns)));
    const row = index % Math.max(1, Math.ceil(layoutNodes.length / columns));
    positions.set(node.id, { x: 50 + column * 230, y: 50 + row * 90, w: 180, h: 46 });
  }
  for (const edge of graph.edges) {
    const from = positions.get(edge.from); const to = positions.get(edge.to);
    if (!from || !to) continue;
    const line = document.createElementNS(svgNs, "path");
    const x1 = from.x + from.w; const y1 = from.y + from.h / 2; const x2 = to.x; const y2 = to.y + to.h / 2;
    const mid = (x1 + x2) / 2;
    line.setAttribute("d", `M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`);
    line.setAttribute("class", `flow-edge ${edge.type || ""}`);
    svg.append(line);
  }
  for (const node of layoutNodes) {
    const pos = positions.get(node.id);
    const group = document.createElementNS(svgNs, "g");
    group.setAttribute("class", `flow-node ${node.type}`);
    group.setAttribute("transform", `translate(${pos.x},${pos.y})`);
    const rect = document.createElementNS(svgNs, "rect");
    rect.setAttribute("width", String(pos.w)); rect.setAttribute("height", String(pos.h));
    const text = document.createElementNS(svgNs, "text");
    text.setAttribute("x", "10"); text.setAttribute("y", "20");
    const label = String(node.label || "Untitled");
    text.textContent = label.length > 25 ? `${label.slice(0, 24)}…` : label;
    const sub = document.createElementNS(svgNs, "text");
    sub.setAttribute("x", "10"); sub.setAttribute("y", "36"); sub.setAttribute("opacity", ".65");
    sub.textContent = node.type;
    group.append(rect, text, sub);
    group.addEventListener("click", () => {
      if (node.type === "note") void openWorkspaceNote(node.id);
      else if (node.url) void chrome.tabs.create({ url: node.url });
    });
    svg.append(group);
  }
  elements.workspaceFlowView.replaceChildren(svg);
  if (!graph.nodes.length) elements.workspaceFlowView.textContent = "No provenance relations match this filter.";
}

function renderWorkspaceFlatten() {
  const rows = filteredWorkspaceRows();
  const calendarItems = filteredCalendarItems();
  const graph = filteredFlowGraph();
  const flat = flattenWorkspace({ rows, calendarItems, graph, scope: workspaceFilterText() ? "filtered-workspace" : "workspace" });
  elements.workspaceFlattenText.value = JSON.stringify(flat, null, 2);
}

async function openWorkspaceNote(noteId) {
  closeDialog("workspaceDialog", "complete");
  await openNoteById(noteId);
}

async function exportWorkspaceReviewCsv() {
  if (!state.workspaceData) await loadWorkspaceData();
  const rows = filteredWorkspaceRows();
  await downloadText(reviewCsv(rows), `Tabwoven/Reviews/tabwoven-review-${fileTimestamp()}.csv`, "text/csv", { saveAs: false });
  await recordTransport({ kind: "spreadsheet-export", destination: "downloads", name: "Workspace review CSV", metadata: { rows: rows.length } });
}

async function exportWorkspaceFlatten() {
  if (!state.workspaceData) await loadWorkspaceData();
  const rows = filteredWorkspaceRows();
  const calendarItems = filteredCalendarItems();
  const graph = filteredFlowGraph();
  const flat = flattenWorkspace({ rows, calendarItems, graph, scope: workspaceFilterText() ? "filtered-workspace" : "workspace" });
  await downloadText(JSON.stringify(flat, null, 2) + "\n", `Tabwoven/Flatten/tabwoven-flatten-${fileTimestamp()}.json`, "application/json", { saveAs: false });
  await recordTransport({ kind: "flatten-export", destination: "downloads", name: "Workspace flatten JSON", metadata: { rows: rows.length, nodes: graph.nodes.length, edges: graph.edges.length } });
}

function openAiTransportDialog() {
  elements.aiTransportScope.value = elements.workspaceDialog.open ? "workspace" : "active";
  elements.aiDestination.value = state.settings.exportDestination === "chosen-folder" ? "chosen-folder" : "downloads";
  elements.paperfoldTheme.value = state.settings.paperfoldTheme;
  elements.localSyncUrl.value = state.settings.localSync.baseUrl;
  elements.localSyncToken.value = state.settings.localSync.token;
  elements.localSyncSchedule.value = state.settings.localSync.schedule;
  renderLocalSyncStatus(state.settings.localSync.enabled ? `Configured: ${state.settings.localSync.baseUrl}` : "Local sync is manual/off.");
  elements.aiCustomPrompt.closest("label").classList.toggle("hidden", elements.aiCueMode.value !== "custom");
  elements.aiCueMode.onchange = () => elements.aiCustomPrompt.closest("label").classList.toggle("hidden", elements.aiCueMode.value !== "custom");
  openDialog("aiTransportDialog");
}

async function createAiTransport(event) {
  event.preventDefault();
  const data = await loadWorkspaceData();
  const scope = elements.aiTransportScope.value;
  const active = activeNote();
  const noteIds = scope === "active" && active ? new Set([active.id]) : new Set(data.notes.map((note) => note.id));
  const notes = data.notes.filter((note) => noteIds.has(note.id));
  const rows = data.rows.filter((row) => noteIds.has(row.note_id));
  const calendarItems = data.calendarItems.filter((item) => !item.noteId || noteIds.has(item.noteId));
  const graph = scope === "active" && active ? graphForNote(data.graph, active.id) : data.graph;
  const sourceIds = new Set(data.links.filter((link) => noteIds.has(link.noteId)).map((link) => link.sourceId));
  const sources = data.sources.filter((source) => sourceIds.has(source.id));
  const annotations = data.annotations.filter((item) => noteIds.has(item.noteId));
  const scraps = data.scraps.filter((item) => noteIds.has(item.noteId));
  const attachments = data.attachments.filter((item) => noteIds.has(item.noteId));
  const memberships = data.memberships.filter((item) => noteIds.has(item.cardId));
  const maincardIds = new Set(memberships.map((item) => item.maincardId));
  const maincards = data.maincards.filter((item) => maincardIds.has(item.id));
  const cardEdges = data.cardEdges.filter((edge) => noteIds.has(edge.fromId) || noteIds.has(edge.toId) || maincardIds.has(edge.maincardId));
  const ir = data.ir.filter((item) => !item.noteId || noteIds.has(item.noteId));
  const prompt = resolveAiPrompt(elements.aiCueMode.value, elements.aiCustomPrompt.value, active);
  const name = scope === "active" && active ? `${active.title} AI transport` : "Paperfold workspace AI transport";
  const blob = await createAiTransportBundleBlob({
    name, prompt, scope, notes, rows, calendar: calendarItems, graph, sources, annotations, scraps, attachments, maincards, memberships, cardEdges, ir,
    csv: reviewCsv(rows), calendarCsv: calendarCsv(calendarItems), mermaid: flowToMermaid(graph)
  });
  const ext = blob.type === "application/gzip" ? "wv.tar.gz" : "wv.tar";
  const filename = `${safeFileStem(scope === "active" && active ? active.title : "tabwoven-workspace")}-ai-${fileTimestamp()}.${ext}`;
  const destination = elements.aiDestination.value;
  await downloadBlob(blob, `Tabwoven/AI/${filename}`, { saveAs: false, destination });
  const transport = await recordTransport({
    kind: "ai-context", destination, noteId: scope === "active" ? active?.id || null : null, name: filename,
    metadata: { scope, cueMode: elements.aiCueMode.value, notes: notes.length, sources: sources.length, annotations: annotations.length, graphNodes: graph.nodes.length }
  });
  await recordIr("transport.ai", { transportId: transport.id, ...transport.metadata, destination }, transport.noteId);
  await recordLog("ai-transport", `Created ${filename} with ${notes.length} note(s).`, transport.noteId);
  closeDialog("aiTransportDialog", "complete");
}

function resolveAiPrompt(mode, customPrompt, note) {
  if (mode === "custom") return String(customPrompt || "").trim();
  if (mode !== "note" || !note) return "";
  const cueSet = state.settings.cueLibrary[note.cueMode] || state.settings.cueLibrary.capture;
  const first = cueSet?.cues?.[0];
  if (!first) return `Explain and summarize the supplied context for the inquiry in “${note.title}”.`;
  return `Use this agreed ${cueSet.label} cue while interpreting the supplied context. Preserve provenance and distinguish quotation, observation, inference, and recommendation.\n\n${first.template}`;
}

function graphForNote(graph, noteId) {
  const accepted = new Set([noteId]);
  for (const edge of graph.edges) if (edge.from === noteId || edge.to === noteId) { accepted.add(edge.from); accepted.add(edge.to); }
  return { nodes: graph.nodes.filter((node) => accepted.has(node.id)), edges: graph.edges.filter((edge) => accepted.has(edge.from) && accepted.has(edge.to)) };
}

async function recordTransport({ kind, destination, noteId = state.activeNoteId, name, metadata = {} }) {
  const transport = { id: crypto.randomUUID(), kind, destination, noteId: noteId || null, name, metadata, createdAt: now() };
  await put("transports", transport);
  return transport;
}

async function saveSearchProviders() {
  try {
    const providers = editableTextToProviders(elements.searchProviderEditor.value);
    if (!providers.length) throw new Error("Add at least one valid provider containing {query}.");
    state.settings.searchProviders = providers;
    await putSetting("searchProviders", providers);
    await chrome.runtime.sendMessage({ type: "SYNC_SEARCH_PROVIDERS", providers });
    elements.searchProviderStatus.textContent = `${providers.length} provider(s) saved. Reload completion by typing / or @ again.`;
    elements.searchProviderStatus.className = "muted ok";
  } catch (error) {
    elements.searchProviderStatus.textContent = String(error.message || error);
    elements.searchProviderStatus.className = "muted error";
  }
}

async function resetSearchProviders() {
  state.settings.searchProviders = normalizeSearchProviders(DEFAULT_SEARCH_PROVIDERS);
  elements.searchProviderEditor.value = providersToEditableText(state.settings.searchProviders);
  await putSetting("searchProviders", state.settings.searchProviders);
  await chrome.runtime.sendMessage({ type: "SYNC_SEARCH_PROVIDERS", providers: state.settings.searchProviders });
  elements.searchProviderStatus.textContent = "Default search and dork providers restored.";
  elements.searchProviderStatus.className = "muted ok";
}

async function chooseExportFolder() {
  if (typeof window.showDirectoryPicker !== "function") {
    alert("This Chrome build does not expose the File System Access directory picker here. Downloads/Tabwoven remains available.");
    return;
  }
  try {
    const handle = await window.showDirectoryPicker({ mode: "readwrite", id: "tabwoven-export" });
    await putSetting("exportDirectoryHandle", handle);
    state.settings.exportDestination = "chosen-folder";
    await putSetting("exportDestination", "chosen-folder");
    renderSettings();
  } catch (error) {
    if (error?.name !== "AbortError") alert(`Unable to choose folder: ${error.message || error}`);
  }
}

async function clearExportFolder() {
  await remove("settings", "exportDirectoryHandle");
  state.settings.exportDestination = "downloads";
  await putSetting("exportDestination", "downloads");
  renderSettings();
}

async function getChosenDirectoryHandle({ requestPermission = false } = {}) {
  const record = await get("settings", "exportDirectoryHandle");
  const handle = record?.value;
  if (!handle) return null;
  try {
    let permission = await handle.queryPermission?.({ mode: "readwrite" });
    if (permission !== "granted" && requestPermission) permission = await handle.requestPermission?.({ mode: "readwrite" });
    return permission === "granted" ? handle : null;
  } catch { return null; }
}

async function writeBlobToChosenFolder(blob, relativePath) {
  const root = await getChosenDirectoryHandle({ requestPermission: true });
  if (!root) throw new Error("The chosen folder is unavailable or permission was not granted.");
  const parts = String(relativePath || "export.bin").split("/").filter(Boolean);
  if (parts[0]?.toLocaleLowerCase() === "tabwoven") parts.shift();
  let directory = await root.getDirectoryHandle("Tabwoven", { create: true });
  while (parts.length > 1) directory = await directory.getDirectoryHandle(parts.shift(), { create: true });
  const file = await directory.getFileHandle(parts[0] || "export.bin", { create: true });
  const writable = await file.createWritable();
  await writable.write(blob);
  await writable.close();
}

async function connectGoogleDrive() {
  const clientId = elements.googleClientId.value.trim();
  elements.googleDriveStatus.textContent = "Connecting…";
  elements.googleDriveStatus.className = "muted";
  const response = await chrome.runtime.sendMessage({ type: "GOOGLE_DRIVE_CONNECT", clientId });
  if (!response?.ok) {
    elements.googleDriveStatus.textContent = response?.error || "Unable to connect Google Drive.";
    elements.googleDriveStatus.className = "muted error";
    return;
  }
  state.driveStatus = response.status;
  renderGoogleDriveStatus();
}

async function configureGoogleDrive() {
  const response = await chrome.runtime.sendMessage({
    type: "GOOGLE_DRIVE_CONFIGURE",
    config: { clientId: elements.googleClientId.value.trim(), schedule: elements.googleDriveSchedule.value }
  });
  if (!response?.ok) {
    elements.googleDriveStatus.textContent = response?.error || "Unable to save Google Drive settings.";
    elements.googleDriveStatus.className = "muted error";
    return;
  }
  await refreshGoogleDriveStatus();
}

async function backupGoogleDriveNow() {
  elements.googleDriveStatus.textContent = "Creating and uploading workspace backup…";
  elements.googleDriveStatus.className = "muted";
  const response = await chrome.runtime.sendMessage({ type: "GOOGLE_DRIVE_BACKUP_NOW" });
  if (!response?.ok) {
    elements.googleDriveStatus.textContent = response?.error || "Google Drive backup failed.";
    elements.googleDriveStatus.className = "muted error";
    return;
  }
  await recordLog("drive-backup", `Uploaded ${response.result.name} to Google Drive.`, state.activeNoteId);
  await refreshGoogleDriveStatus();
}

async function disconnectGoogleDrive() {
  if (!confirm("Disconnect Google Drive? Existing files in Drive will remain.")) return;
  await chrome.runtime.sendMessage({ type: "GOOGLE_DRIVE_DISCONNECT" });
  await refreshGoogleDriveStatus();
}

async function refreshGoogleDriveStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GOOGLE_DRIVE_STATUS" });
    if (response?.ok) state.driveStatus = response.status;
  } catch { state.driveStatus = null; }
  renderGoogleDriveStatus();
}

function renderGoogleDriveStatus() {
  const status = state.driveStatus;
  elements.googleClientId.value = status?.clientId || elements.googleClientId.value || "";
  elements.googleClientId.disabled = Boolean(status?.manifestConfigured);
  elements.googleDriveSchedule.value = status?.schedule || "off";
  elements.googleRedirectUri.textContent = status?.manifestConfigured
    ? "Official Chrome Identity mode is configured in manifest.json."
    : status?.redirectUri ? `Experimental PKCE fallback redirect: ${status.redirectUri}` : "";
  elements.backupGoogleDriveButton.disabled = !status?.connected;
  elements.disconnectGoogleDriveButton.disabled = !status?.connected;
  if (!status?.connected) {
    elements.googleDriveStatus.textContent = status?.manifestConfigured
      ? "OAuth manifest is configured but not connected. Click Connect."
      : "Not connected. The recommended setup is a Chrome Extension OAuth client declared in manifest.json; the client-ID field below is an experimental fallback.";
    elements.googleDriveStatus.className = "muted";
    return;
  }
  const last = status.lastBackup?.createdAt ? ` Last backup: ${formatDate(status.lastBackup.createdAt)}.` : " No backup uploaded yet.";
  const mode = status.mode === "chrome-identity" ? "Chrome Identity" : "PKCE fallback";
  elements.googleDriveStatus.textContent = `Connected via ${mode}. Schedule: ${status.schedule || "off"}.${last}`;
  elements.googleDriveStatus.className = "muted ok";
}

async function consumePendingPageAction() {
  let pending;
  try {
    const stored = await chrome.storage.session.get("pendingPageAction");
    pending = stored.pendingPageAction;
    if (pending) await chrome.storage.session.remove("pendingPageAction");
  } catch { return; }
  if (!pending?.action) return;
  await refreshCurrentTab();
  if (pending.action === "command") {
    state.editor.focus();
    state.editor.openCompletion();
  }
  if (pending.action === "attach") await attachTab(state.currentTab || pending.tab, "context-menu");
  if (pending.action === "scrape") await scrapeCurrentPage();
  if (pending.action === "attachment") openAttachmentDialog();
  if (pending.action === "maincard") await openMaincardsDialog();
}

async function searchEditorSelection(providerId) {
  const provider = state.settings.searchProviders.find((item) => item.id === providerId);
  if (!provider) return;
  const selection = state.editor.getSelection();
  const value = state.editor.getValue();
  let query = value.slice(selection.start, selection.end).trim();
  if (!query) query = prompt(`Search on ${provider.name}:`, "")?.trim() || "";
  if (!query) return;
  await chrome.tabs.create({ url: providerUrl(provider, query) });
  await recordLog("follow-up-search", `Searched “${truncate(query, 120)}” on ${provider.name}.`, state.activeNoteId);
  await recordIr("search.follow-up", { providerId: provider.id, providerName: provider.name, query }, state.activeNoteId);
}

function localDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}


async function loadMaincards() {
  state.maincards = (await getAll("maincards")).sort((a, b) => String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")));
  if (!state.maincards.some((item) => item.id === state.activeMaincardId)) state.activeMaincardId = state.maincards[0]?.id || null;
  await putSetting("activeMaincardId", state.activeMaincardId);
}

function activeMaincard() {
  return state.maincards.find((item) => item.id === state.activeMaincardId) || null;
}

function openAttachmentDialog() {
  elements.attachmentFiles.value = "";
  elements.attachmentComment.value = "";
  openDialog("attachmentDialog");
}

async function saveManualAttachments(event) {
  event.preventDefault();
  const note = activeNote();
  if (!note) return;
  const files = [...elements.attachmentFiles.files];
  if (!files.length) {
    alert("Choose at least one file.");
    return;
  }
  const existing = await getAllByIndex("attachments", "noteId", note.id);
  let sequence = existing.reduce((max, item) => Math.max(max, Number(item.sequence) || 0), 0);
  const comment = String(elements.attachmentComment.value || "").trim();
  for (const file of files) {
    sequence += 1;
    const timestamp = now();
    const textual = isTextualAttachment(file);
    const textContent = textual ? await file.text() : "";
    const markdownFileName = attachmentFileName(note.title, sequence);
    const markdown = [
      "---",
      "type: attachment",
      `attachment_sequence: ${sequence}`,
      `source_file: ${JSON.stringify(file.name)}`,
      `mime_type: ${JSON.stringify(file.type || "application/octet-stream")}`,
      `size_bytes: ${file.size}`,
      `attached: ${JSON.stringify(timestamp)}`,
      "---",
      "",
      comment ? `> ${comment.replace(/\n/g, "\n> ")}\n` : "",
      textContent || "Binary attachment preserved in the workspace bundle."
    ].filter(Boolean).join("\n");
    const attachment = {
      id: `attachment:${crypto.randomUUID()}`,
      noteId: note.id,
      noteTitle: note.title,
      sequence,
      title: file.name,
      fileName: file.name,
      markdownFileName,
      mimeType: file.type || "application/octet-stream",
      size: file.size,
      comment,
      textContent,
      markdown,
      rawBlob: file,
      contentHash: stableHash(`${file.name}:${file.size}:${file.lastModified}:${textContent.slice(0, 4096)}`),
      embeddingProvider: state.settings.embeddingProvider,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    await put("attachments", attachment);
    if (textContent.trim()) {
      const chunks = await buildEmbeddedChunks({ owner: attachment, ownerType: "attachment", noteId: note.id, sourceId: null, providerId: state.settings.embeddingProvider });
      await putMany("chunks", chunks);
    }
    await recordIr("attachment.create", {
      attachmentId: attachment.id,
      fileName: attachment.fileName,
      markdownFileName,
      mimeType: attachment.mimeType,
      size: attachment.size,
      contentHash: attachment.contentHash,
      embedded: Boolean(textContent.trim())
    }, note.id);
  }
  await recordLog("attachment-created", `Attached ${files.length} local file(s) to “${note.title}”.`, note.id);
  closeDialog("attachmentDialog", "complete");
  await renderAttachments();
}

async function renderAttachments() {
  const note = activeNote();
  if (!note) return;
  const attachments = (await getAllByIndex("attachments", "noteId", note.id)).sort((a, b) => Number(a.sequence) - Number(b.sequence));
  elements.attachmentCount.textContent = String(attachments.length);
  elements.attachmentList.replaceChildren();
  elements.attachmentList.classList.toggle("empty-state", !attachments.length);
  if (!attachments.length) {
    elements.attachmentList.textContent = "No manual attachments for this note.";
    return;
  }
  for (const attachment of attachments) {
    const fragment = elements.attachmentItemTemplate.content.cloneNode(true);
    fragment.querySelector(".attachment-name").textContent = attachment.markdownFileName || attachment.fileName;
    fragment.querySelector(".attachment-comment").textContent = attachment.comment || "";
    fragment.querySelector(".attachment-meta").textContent = `${attachment.mimeType || "file"} · ${formatBytes(attachment.size)} · ${formatDate(attachment.createdAt)}`;
    fragment.querySelector(".export-attachment").addEventListener("click", () => void downloadText(attachment.markdown || attachment.textContent || "", attachment.markdownFileName || attachmentFileName(note.title, attachment.sequence), "text/markdown"));
    fragment.querySelector(".delete-attachment").addEventListener("click", async () => {
      if (!confirm(`Delete attachment “${attachment.fileName}”?`)) return;
      const chunks = await getAllByIndex("chunks", "ownerId", attachment.id);
      for (const chunk of chunks) await remove("chunks", chunk.id);
      await remove("attachments", attachment.id);
      await recordIr("attachment.delete", { attachmentId: attachment.id, fileName: attachment.fileName }, note.id);
      await recordLog("attachment-deleted", `Deleted attachment “${attachment.fileName}”.`, note.id);
      await renderAttachments();
    });
    elements.attachmentList.append(fragment);
  }
}

function isTextualAttachment(file) {
  const type = String(file.type || "").toLocaleLowerCase();
  const name = String(file.name || "").toLocaleLowerCase();
  return type.startsWith("text/") || /\/(json|xml|javascript|csv)$/.test(type) || /\.(md|markdown|txt|csv|tsv|json|jsonl|ndjson|yaml|yml|xml|html?|css|js|mjs|cjs|ts|tsx|jsx|py|r|sql|tex|bib)$/i.test(name);
}

function formatBytes(value) {
  const bytes = Math.max(0, Number(value) || 0);
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

async function openMaincardsDialog() {
  await flushNoteSave();
  await loadMaincards();
  // An empty Board library is valid. Navigation must never create a record.
  await renderMaincardDialog();
  openDialog("maincardsDialog");
}

async function createNewMaincard(title = "New Board", options = {}) {
  const item = createMaincard(typeof title === "string" ? title : "New Board");
  await put("maincards", item);
  state.activeMaincardId = item.id;
  await putSetting("activeMaincardId", item.id);
  await loadMaincards();
  await recordIr("maincard.create", { maincardId: item.id, title: item.title }, state.activeNoteId);
  await recordLog("maincard-created", `Created Board “${item.title}”.`, state.activeNoteId);
  if (options.open !== false) await openMaincardsDialog();
  return item;
}

function scheduleMaincardSave() {
  clearTimeout(state.maincardSaveTimer);
  state.maincardSaveTimer = setTimeout(() => { state.maincardSaveTimer = null; void saveActiveMaincard(); }, 350);
}

async function saveActiveMaincard() {
  clearTimeout(state.maincardSaveTimer);
  state.maincardSaveTimer = null;
  if (state.maincardSaveInFlight) return await state.maincardSaveInFlight;
  const existing = activeMaincard();
  if (!existing) return false;
  const maincard = {
    ...existing,
    title: String(elements.maincardTitle.value || "Untitled Board").trim() || "Untitled Board",
    perspective: String(elements.maincardPerspective.value || "").trim(),
    body: String(elements.maincardBody.value || ""), updatedAt: now()
  };
  const write = (async () => {
    try {
      await put("maincards", maincard);
      await loadMaincards();
      renderMaincardSelector();
      announceStatus("Board changes saved locally.", "success");
      return true;
    } catch (error) {
      announceStatus(`Board was not saved; editor fields remain editable: ${error.message || error}`, "error");
      return false;
    }
  })();
  state.maincardSaveInFlight = write;
  try { return await write; }
  finally { if (state.maincardSaveInFlight === write) state.maincardSaveInFlight = null; }
}

async function deleteCurrentMaincard() {
  const maincard = activeMaincard();
  if (!maincard || !confirm(`Delete Board “${maincard.title}”? Cards and Subcards will remain.`)) return;
  const [memberships, edges] = await Promise.all([
    getAllByIndex("memberships", "maincardId", maincard.id),
    getAllByIndex("cardEdges", "maincardId", maincard.id)
  ]);
  for (const item of memberships) await remove("memberships", item.id);
  for (const edge of edges) await remove("cardEdges", edge.id);
  await remove("maincards", maincard.id);
  await recordIr("maincard.delete", { maincardId: maincard.id, memberships: memberships.length, edges: edges.length }, state.activeNoteId);
  state.activeMaincardId = null;
  await loadMaincards();
  // Deleting the last Board must not silently create another one.
  await renderMaincardDialog();
}

function renderMaincardSelector() {
  elements.maincardSelect.replaceChildren();
  for (const maincard of state.maincards) {
    const option = document.createElement("option");
    option.value = maincard.id;
    option.textContent = maincard.title || "Untitled Board";
    option.selected = maincard.id === state.activeMaincardId;
    elements.maincardSelect.append(option);
  }
}

async function renderMaincardDialog() {
  renderMaincardSelector();
  const maincard = activeMaincard();
  if (!maincard) {
    elements.maincardTitle.value = "";
    elements.maincardPerspective.value = "";
    elements.maincardBody.value = "";
    for (const id of ["maincardGrid", "typedEdgeList", "maincardNotePicker"]) elements[id]?.replaceChildren();
    for (const id of ["deleteMaincardButton", "exportMaincardButton", "addCardsToMaincardButton", "addActiveCardButton", "addTypedEdgeButton"]) {
      if (elements[id]) elements[id].disabled = true;
    }
    return;
  }
  for (const id of ["deleteMaincardButton", "exportMaincardButton", "addCardsToMaincardButton", "addActiveCardButton", "addTypedEdgeButton"]) {
    if (elements[id]) elements[id].disabled = false;
  }
  elements.maincardTitle.value = maincard.title || "";
  elements.maincardPerspective.value = maincard.perspective || "";
  elements.maincardBody.value = maincard.body || "";
  const [memberships, edges, scraps, annotations, attachments] = await Promise.all([
    getAllByIndex("memberships", "maincardId", maincard.id),
    getAll("cardEdges"),
    getAll("scraps"),
    getAll("annotations"),
    getAll("attachments")
  ]);
  const memberIds = new Set(memberships.map((item) => item.cardId));
  elements.maincardNotePicker.replaceChildren();
  for (const note of state.notes.filter((item) => !memberIds.has(item.id))) {
    const option = document.createElement("option");
    option.value = note.id;
    option.textContent = note.title || "Untitled note";
    elements.maincardNotePicker.append(option);
  }
  const projection = buildMaincardProjection({ maincard, notes: state.notes, memberships, edges, scraps, annotations, attachments });
  renderMaincardCards(projection);
  renderTypedEdges(projection);
  populateEdgeSelectors(projection);
}

function renderMaincardCards(projection) {
  elements.maincardGrid.replaceChildren();
  if (!projection.cards.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "This Maincard has no Cards yet.";
    elements.maincardGrid.append(empty);
    return;
  }
  for (const card of projection.cards) {
    const article = document.createElement("article");
    article.className = "maincard-card";
    const header = document.createElement("header");
    const title = document.createElement("button");
    title.type = "button";
    title.className = "ghost";
    title.textContent = card.title;
    title.addEventListener("click", async () => {
      closeDialog("maincardsDialog", "explicit");
      await openNoteById(card.id);
    });
    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "danger icon-button";
    removeButton.textContent = "✕";
    removeButton.title = "Remove Card from this Maincard";
    removeButton.addEventListener("click", async () => {
      await remove("memberships", `membership:${projection.maincard.id}:${card.id}`);
      await recordIr("membership.delete", { maincardId: projection.maincard.id, cardId: card.id }, card.id);
      await renderMaincardDialog();
    });
    header.append(title, removeButton);
    const role = document.createElement("span");
    role.className = "badge card-role";
    role.textContent = `${card.role} · ${card.classification}`;
    const excerpt = document.createElement("p");
    excerpt.className = "muted";
    excerpt.textContent = truncate(card.body, 180);
    const count = projection.subcards.filter((item) => item.noteId === card.id).length;
    const sub = document.createElement("small");
    sub.className = "muted";
    sub.textContent = `${count} Subcard(s)`;
    article.append(header, role, excerpt, sub);
    elements.maincardGrid.append(article);
  }
}

async function addSelectedCardsToMaincard() {
  const selected = [...elements.maincardNotePicker.selectedOptions].map((option) => option.value);
  await addCardsToMaincard(selected);
}

async function addActiveCardToCurrentMaincard() {
  if (!state.activeMaincardId) await openMaincardsDialog();
  if (!state.activeMaincardId || !state.activeNoteId) return;
  await addCardsToMaincard([state.activeNoteId]);
}

async function addCardsToMaincard(cardIds) {
  const maincard = activeMaincard();
  if (!maincard || !cardIds.length) return;
  const role = elements.maincardMembershipRole?.value || "card";
  const classification = String(elements.maincardMembershipClass?.value || "member").trim() || "member";
  for (const cardId of cardIds) {
    const membership = createMembership({ maincardId: maincard.id, cardId, role, classification });
    await put("memberships", membership);
    await recordIr("membership.create", { membershipId: membership.id, maincardId: maincard.id, cardId, role, classification }, cardId);
  }
  await recordLog("maincard-membership", `Added ${cardIds.length} Card(s) to “${maincard.title}”.`, state.activeNoteId);
  await renderMaincardDialog();
}

function populateEdgeSelectors(projection) {
  const endpoints = [
    { id: projection.maincard.id, kind: "maincard", label: `Board: ${projection.maincard.title}` },
    ...projection.cards.map((card) => ({ id: card.id, kind: "card", label: `Card: ${card.title}` })),
    ...projection.subcards.map((item) => ({ id: item.id, kind: item.kind, label: `${item.kind}: ${item.label}` }))
  ];
  for (const select of [elements.edgeFromSelect, elements.edgeToSelect]) {
    select.replaceChildren();
    for (const endpoint of endpoints) {
      const option = document.createElement("option");
      option.value = `${endpoint.kind}::${endpoint.id}`;
      option.textContent = endpoint.label;
      select.append(option);
    }
  }
  elements.edgeTypeSelect.replaceChildren();
  for (const type of DEFAULT_EDGE_TYPES) {
    const option = document.createElement("option");
    option.value = type.id;
    option.textContent = `${type.label} · ${type.domain}`;
    option.dataset.domain = type.domain;
    elements.edgeTypeSelect.append(option);
  }
  if (elements.edgeToSelect.options.length > 1) elements.edgeToSelect.selectedIndex = 1;
}

async function addTypedEdgeFromDialog() {
  const maincard = activeMaincard();
  if (!maincard) return;
  const [fromKind, fromId] = String(elements.edgeFromSelect.value).split("::");
  const [toKind, toId] = String(elements.edgeToSelect.value).split("::");
  if (!fromId || !toId || (fromKind === toKind && fromId === toId)) {
    alert("Choose two different endpoints.");
    return;
  }
  const type = elements.edgeTypeSelect.value;
  const typeDefinition = DEFAULT_EDGE_TYPES.find((item) => item.id === type);
  const edge = createTypedEdge({
    fromKind,
    fromId,
    toKind,
    toId,
    type,
    label: elements.edgeLabelInput.value,
    classification: typeDefinition?.domain || "custom",
    maincardId: maincard.id
  });
  await put("cardEdges", edge);
  elements.edgeLabelInput.value = "";
  await recordIr("edge.create", { edge }, state.activeNoteId);
  await recordLog("typed-edge", `Created ${edge.type} edge in “${maincard.title}”.`, state.activeNoteId);
  await renderMaincardDialog();
}

function renderTypedEdges(projection) {
  elements.typedEdgeList.replaceChildren();
  elements.typedEdgeList.classList.toggle("empty-state", !projection.edges.length);
  if (!projection.edges.length) {
    elements.typedEdgeList.textContent = "No typed edges yet.";
    return;
  }
  const labels = new Map([
    [projection.maincard.id, projection.maincard.title],
    ...projection.cards.map((item) => [item.id, item.title]),
    ...projection.subcards.map((item) => [item.id, item.label])
  ]);
  for (const edge of projection.edges) {
    const row = document.createElement("article");
    row.className = "list-item edge-row";
    const from = document.createElement("span");
    from.textContent = labels.get(edge.fromId) || edge.fromId;
    const relation = document.createElement("strong");
    relation.textContent = edge.label || edge.type;
    const to = document.createElement("span");
    to.textContent = labels.get(edge.toId) || edge.toId;
    const del = document.createElement("button");
    del.type = "button";
    del.className = "danger icon-button";
    del.textContent = "✕";
    del.addEventListener("click", async () => {
      await remove("cardEdges", edge.id);
      await recordIr("edge.delete", { edgeId: edge.id, type: edge.type }, state.activeNoteId);
      await renderMaincardDialog();
    });
    row.append(from, relation, to, del);
    elements.typedEdgeList.append(row);
  }
}

async function exportCurrentMaincardFlatten() {
  await saveActiveMaincard();
  const maincard = activeMaincard();
  if (!maincard) return;
  const [memberships, edges, scraps, annotations, attachments] = await Promise.all([
    getAllByIndex("memberships", "maincardId", maincard.id), getAll("cardEdges"), getAll("scraps"), getAll("annotations"), getAll("attachments")
  ]);
  const projection = buildMaincardProjection({ maincard, notes: state.notes, memberships, edges, scraps, annotations, attachments });
  const flat = flattenMaincard(projection);
  flat.mermaid = maincardToMermaid(projection);
  await downloadText(JSON.stringify(flat, null, 2) + "\n", `Paperfold/Boards/${safeFileStem(maincard.title)}.board.flatten.json`, "application/json", { saveAs: false });
  await recordIr("maincard.flatten.export", { maincardId: maincard.id, cards: projection.cards.length, subcards: projection.subcards.length, edges: projection.edges.length }, state.activeNoteId);
}

async function exportStickyNotesProjection() {
  await flushNoteSave();
  const notes = await getAll("notes");
  const projection = {
    schema: "tabwoven.sticky-projection/1",
    generatedAt: now(),
    notes: notes.map((note) => ({
      id: note.id,
      title: note.title || "Untitled note",
      text: String(note.body || "").replace(/^---[\s\S]*?---\s*/m, "").slice(0, 10000),
      updatedAt: note.updatedAt,
      source: "tabwoven"
    }))
  };
  const filename = `Tabwoven/Sticky/sticky-notes-${fileTimestamp()}.json`;
  await downloadText(JSON.stringify(projection, null, 2) + "\n", filename, "application/json", { saveAs: false, destination: state.settings.exportDestination });
  await recordIr("sticky.export", { filename, notes: projection.notes.length }, state.activeNoteId);
  await recordLog("sticky-export", `Exported ${projection.notes.length} note(s) as a sticky projection.`, state.activeNoteId);
}

async function saveLocalSyncConfig() {
  state.settings.localSync = normalizeSyncConfig({
    enabled: elements.localSyncSchedule.value !== "off",
    baseUrl: elements.localSyncUrl.value,
    token: elements.localSyncToken.value,
    schedule: elements.localSyncSchedule.value,
    pushArchive: true
  });
  await putSetting("localSync", state.settings.localSync);
  await chrome.runtime.sendMessage({ type: "LOCAL_SYNC_CONFIGURE", config: state.settings.localSync }).catch(() => {});
  renderLocalSyncStatus("Local sync configuration saved.", "ok");
}

async function testLocalSyncConnection() {
  try {
    await saveLocalSyncConfig();
    const result = await testSyncServer(state.settings.localSync);
    renderLocalSyncStatus(`Connected to ${result.service || "Paperfold Local Sync"} ${result.version || ""}.`, "ok");
  } catch (error) {
    renderLocalSyncStatus(String(error.message || error), "error");
  }
}

async function collectSyncSnapshot() {
  await flushNoteSave();
  const storeNames = ["notes", "sources", "links", "scraps", "annotations", "chunks", "ir", "bookmarks", "transports", "attachments", "maincards", "memberships", "cardEdges"];
  const values = await Promise.all(storeNames.map((store) => getAll(store)));
  const data = Object.fromEntries(storeNames.map((store, index) => [store, store === "attachments" ? values[index].map(({ rawBlob, ...metadata }) => metadata) : values[index]]));
  return { schema: "tabwoven.sync-snapshot/1", appVersion: "0.7.0", generatedAt: now(), data };
}

async function pushLocalWorkspace() {
  const startedAt = now();
  const run = { id: crypto.randomUUID(), direction: "push", status: "running", createdAt: startedAt, updatedAt: startedAt };
  await put("syncRuns", run);
  try {
    await saveLocalSyncConfig();
    const snapshot = await collectSyncSnapshot();
    const result = await pushSnapshot(state.settings.localSync, snapshot);
    if (state.settings.localSync.pushArchive) {
      const data = await collectWorkspaceForArchive();
      const blob = await createWorkspaceBundleBlob({ ...data, includeVectors: true });
      await pushArchive(state.settings.localSync, blob, `tabwoven-workspace-${fileTimestamp()}.wv.tar.gz`);
    }
    Object.assign(run, { status: "ok", updatedAt: now(), result });
    await put("syncRuns", run);
    await recordIr("sync.push", { syncRunId: run.id, server: state.settings.localSync.baseUrl }, state.activeNoteId);
    renderLocalSyncStatus(`Pushed workspace at ${formatDate(run.updatedAt)}.`, "ok");
  } catch (error) {
    Object.assign(run, { status: "error", updatedAt: now(), error: String(error.message || error) });
    await put("syncRuns", run);
    renderLocalSyncStatus(run.error, "error");
  }
}

async function pullLocalWorkspace() {
  if (!confirm("Pull and merge newer records from the local companion? Remote deletion is not applied automatically.")) return;
  const startedAt = now();
  const run = { id: crypto.randomUUID(), direction: "pull", status: "running", createdAt: startedAt, updatedAt: startedAt };
  await put("syncRuns", run);
  try {
    await saveLocalSyncConfig();
    const snapshot = await pullSnapshot(state.settings.localSync);
    if (snapshot.schema !== "tabwoven.sync-snapshot/1" || !snapshot.data) throw new Error("Unsupported sync snapshot.");
    const mergeStores = ["notes", "sources", "links", "scraps", "annotations", "chunks", "ir", "bookmarks", "transports", "attachments", "maincards", "memberships", "cardEdges"];
    let changed = 0;
    for (const store of mergeStores) {
      const local = await getAll(store);
      const localRecords = new Map(local.map((item) => [item.id ?? item.key, item]));
      const merged = mergeSnapshotRecords(local, snapshot.data[store] || []);
      const localMap = new Map(local.map((item) => [item.id ?? item.key, JSON.stringify(item)]));
      for (const item of merged) {
        const key = item.id ?? item.key;
        const existing = localRecords.get(key);
        const nextItem = store === "attachments"
          ? preserveLocalAttachmentBlob(item, existing)
          : item;
        if (localMap.get(key) !== JSON.stringify(nextItem)) {
          await put(store, nextItem);
          changed += 1;
        }
      }
    }
    Object.assign(run, { status: "ok", updatedAt: now(), result: { changed } });
    await put("syncRuns", run);
    await loadNotes();
    await loadMaincards();
    await renderActiveNote();
    await recordIr("sync.pull", { syncRunId: run.id, changed, server: state.settings.localSync.baseUrl }, state.activeNoteId);
    renderLocalSyncStatus(`Merged ${changed} newer record(s).`, "ok");
  } catch (error) {
    Object.assign(run, { status: "error", updatedAt: now(), error: String(error.message || error) });
    await put("syncRuns", run);
    renderLocalSyncStatus(run.error, "error");
  }
}

async function collectWorkspaceForArchive() {
  const names = ["notes", "sources", "links", "scraps", "annotations", "chunks", "ir", "bookmarks", "settings", "backups", "transports", "attachments", "maincards", "memberships", "cardEdges", "syncRuns", "browserSessions", "sessionRevisions"];
  const values = await Promise.all(names.map((name) => getAll(name)));
  return Object.fromEntries(names.map((name, index) => [name, values[index]]));
}

function renderLocalSyncStatus(message, tone = "") {
  elements.localSyncStatus.textContent = message;
  elements.localSyncStatus.className = `muted ${tone}`.trim();
}


/* W9 interaction adapter: additive to v0.8 IDs; W8 owns DOM/CSS. */
const PF_ROUTES = new Set(["write", "boards", "library", "more", "find", "search", "sessions", "explore", "query", "settings", "workspace", "states"]);
const PF_FOCUS = 'button:not([disabled]),[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

function initializeInteractionShell() {
  document.querySelectorAll("dialog").forEach((dialog) => {
    dialog.addEventListener("close", () => {
      const previous = state.ui.dialogOpeners.get(dialog);
      if (previous?.isConnected && typeof previous.focus === "function") previous.focus({ preventScroll: true });
      else document.querySelector('[data-pf-route][aria-current="page"]')?.focus({ preventScroll: true });
      state.ui.dialogOpeners.delete(dialog);
    });
    dialog.addEventListener("cancel", () => {
      // Native Escape cancellation is non-mutating and closes the top layer.
      dialog.dataset.pfDismissReason = "cancel";
    });
    dialog.addEventListener("click", (event) => {
      // Never close a confirmation dialog by clicking outside its content.
      if (event.target === dialog) event.preventDefault();
    });
  });
  document.addEventListener("click", (event) => {
    const routeButton = event.target.closest?.("[data-pf-route]");
    if (routeButton && !routeButton.disabled) {
      event.preventDefault();
      event.stopPropagation(); // route buttons may still carry legacy direct listeners
      void activateRoute(routeButton.dataset.pfRoute, routeButton);
      return;
    }
    const trigger = event.target.closest?.("[data-pf-popover-trigger]");
    if (trigger) {
      event.preventDefault();
      event.stopPropagation();
      togglePopover(trigger);
      return;
    }
    const disabledItem = event.target.closest?.('[role="menuitem"][aria-disabled="true"], [data-pf-action][aria-disabled="true"]');
    if (disabledItem) { event.preventDefault(); event.stopPropagation(); return; }
    const cite = event.target.closest?.("[data-pf-cite-source]");
    if (cite) {
      event.preventDefault();
      event.stopPropagation();
      void reviewSourceCitation(cite.dataset.pfCiteSource, cite);
      return;
    }
    const modalOpener = event.target.closest?.("[data-pf-open-dialog]");
    if (modalOpener) {
      event.preventDefault();
      openDialog(modalOpener.dataset.pfOpenDialog, modalOpener);
      return;
    }
    const modalCloser = event.target.closest?.("[data-pf-close-dialog]");
    if (modalCloser) {
      event.preventDefault();
      closeDialog(modalCloser.dataset.pfCloseDialog || modalCloser.closest('dialog'), "cancel");
      return;
    }
    const drawerToggle = event.target.closest?.("[data-pf-drawer-trigger]");
    if (drawerToggle) {
      event.preventDefault();
      toggleDrawer(drawerToggle);
      return;
    }
    if (event.target.closest?.("[data-pf-drawer-close]")) {
      const drawer = event.target.closest('[data-pf-drawer]') || document.querySelector('[data-pf-drawer]:not([hidden])');
      if (drawer) closeDrawer(drawer);
    }
    if (state.ui.popover && !state.ui.popover.contains(event.target)) dismissPopover({ restoreFocus: false });
  }, true);
  document.addEventListener("keydown", handlePopoverKeydown);
  window.addEventListener("resize", () => {
    if (state.ui.popover) positionPopover(state.ui.popoverOpener, state.ui.popover);
  }, { passive: true });
  document.addEventListener("scroll", () => {
    if (state.ui.popover) positionPopover(state.ui.popoverOpener, state.ui.popover);
  }, true);
  for (const media of ["(prefers-color-scheme: dark)", "(prefers-reduced-motion: reduce)"]) {
    window.matchMedia?.(media)?.addEventListener?.("change", applyPaperfoldTheme);
  }
  const initial = document.querySelector('[data-pf-route][aria-current="page"]')?.dataset.pfRoute || "write";
  if (document.querySelector("[data-pf-view]")) void activateRoute(initial, null, { initial: true });
  const status = elements.saveStatus;
  if (status) { status.setAttribute("aria-live", "polite"); status.dataset.state ||= "saved"; }
}

async function activateRoute(route, opener = null, options = {}) {
  if (route === "search") route = "find"; // W4 search ID is aliased to W7 Find.
  if (!PF_ROUTES.has(route)) return false;
  const candidates = [...document.querySelectorAll("[data-pf-view]")];
  const view = candidates.find((node) => node.dataset.pfView === route || (route === "find" && node.dataset.pfView === "search"));
  const previous = candidates.find((node) => !node.hidden && node.dataset.pfView === state.ui.route);
  if (previous && previous !== view) state.ui.routeScroll.set(state.ui.route, previous.scrollTop);
  if (view) {
    // Route switching does not call a domain write. The live editor instance is not rebuilt.
    candidates.forEach((node) => {
      const active = node === view;
      node.hidden = !active;
      node.classList.toggle("hidden", !active);
      node.setAttribute("aria-hidden", String(!active));
      if ("inert" in node) node.inert = !active;
    });
    const scroll = state.ui.routeScroll.get(route);
    if (Number.isFinite(scroll)) view.scrollTop = scroll;
    if (!options.initial) {
      const heading = view.querySelector("h1,h2,[data-pf-route-heading]");
      if (heading) {
        if (!heading.hasAttribute("tabindex")) heading.setAttribute("tabindex", "-1");
        heading.focus({ preventScroll: true });
      }
    }
  } else if (!options.initial) {
    // Legacy DOM fallback. Do not pretend gated prototypes are interactive.
    if (route === "boards") await openMaincardsDialog();
    else if (route === "settings") openSettingsDialog();
    else if (route === "workspace") await openWorkspaceDialog("spreadsheet");
    else if (route === "sessions") document.getElementById("sessionsOpenButton")?.click();
    else if (route === "find") elements.searchInput?.focus();
    else if (route === "library") elements.sourceList?.scrollIntoView({ block: "start" });
    else if (route === "query" || route === "explore") {
      announceStatus("This research prototype is gated and unavailable as an active workflow.", "error");
      return false;
    }
  }
  state.ui.route = route;
  document.querySelectorAll("[data-pf-route]").forEach((button) => {
    const selected = button.dataset.pfRoute === route || (route === "find" && button.dataset.pfRoute === "search");
    if (selected) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
    if (button.getAttribute("role") === "tab") button.setAttribute("aria-selected", String(selected));
  });
  if (opener) state.ui.lastRouteOpener = opener;
  dismissPopover({ restoreFocus: false });
  return true;
}

function announceStatus(message, kind = "info") {
  let toast = document.querySelector("[data-pf-toast]");
  if (!toast) {
    toast = document.createElement("div");
    toast.dataset.pfToast = "";
    toast.className = "pf-status-toast";
    toast.style.cssText = "position:fixed;bottom:16px;right:16px;z-index:2147483646;max-width:min(340px,calc(100vw - 32px));padding:10px 14px;border-radius:8px;background:var(--surface,#fff);color:var(--text,#222);box-shadow:var(--shadow,0 3px 18px #0002);";
    document.body.append(toast);
  }
  clearTimeout(state.ui.toastTimer);
  toast.hidden = false;
  toast.dataset.kind = kind;
  toast.setAttribute("role", kind === "error" ? "alert" : "status");
  toast.setAttribute("aria-live", kind === "error" ? "assertive" : "polite");
  toast.textContent = String(message);
  // The status is dismissible without removing the user's edit state.
  const dismiss = document.createElement("button");
  dismiss.type = "button";
  dismiss.textContent = "×";
  dismiss.setAttribute("aria-label", "Dismiss notification");
  dismiss.style.cssText = "margin-inline-start:12px;background:transparent;color:inherit;border:0;cursor:pointer";
  dismiss.addEventListener("click", () => { toast.hidden = true; });
  toast.append(dismiss);
  if (kind !== "error") state.ui.toastTimer = setTimeout(() => { toast.hidden = true; }, 3500);
}

async function updateThemeSetting(theme) {
  if (!["paper", "black", "auto"].includes(theme)) return;
  const previous = state.settings.paperfoldTheme;
  try {
    await putSetting("paperfoldTheme", theme);
    state.settings.paperfoldTheme = theme;
    applyPaperfoldTheme();
    announceStatus("Appearance preference saved.", "success");
  } catch (error) {
    state.settings.paperfoldTheme = previous;
    if (elements.paperfoldTheme) elements.paperfoldTheme.value = previous;
    applyPaperfoldTheme();
    announceStatus(`Theme not saved: ${error.message || error}`, "error");
  }
}

function preserveEditorSelection() {
  rememberEditorSelection();
  return { cardId: state.activeNoteId, range: { ...state.editorSelection } };
}

function openDialog(id, opener = document.activeElement) {
  const dialog = typeof id === "string" ? document.getElementById(id) : id;
  if (!dialog) return false;
  if (dialog.open) return true;
  const active = document.querySelector("dialog[open]");
  if (active && active !== dialog) {
    announceStatus("Close the current dialog before opening another.", "error");
    return false;
  }
  if (opener instanceof Element && opener !== document.body) state.ui.dialogOpeners.set(dialog, opener);
  try { dialog.showModal(); }
  catch (error) { announceStatus(`Dialog unavailable: ${error.message || error}`, "error"); return false; }
  requestAnimationFrame(() => {
    if (!dialog.open) return;
    const initial = dialog.querySelector("[autofocus],input:not([disabled]),button:not([disabled]),select:not([disabled]),textarea:not([disabled])");
    (initial || dialog).focus({ preventScroll: true });
  });
  return true;
}

function closeDialog(id, reason = "cancel") {
  const dialog = typeof id === "string" ? document.getElementById(id) : id;
  if (!dialog?.open) return false;
  dialog.dataset.pfDismissReason = reason;
  dialog.close(reason);
  return true;
}


async function reviewSourceCitation(sourceId, opener = document.activeElement, options = {}) {
  const card = activeNote();
  if (!card || !sourceId) { announceStatus("Select a Card and Source first.", "error"); return false; }
  const source = await get("sources", sourceId);
  if (!source) { announceStatus("Source unavailable; nothing was inserted.", "error"); return false; }
  const saved = preserveEditorSelection();
  const draft = state.editor?.getValue() ?? elements.noteBody.value;
  const revision = state.noteRevision;
  const dialog = document.createElement("dialog");
  dialog.className = "pf-source-review";
  dialog.setAttribute("aria-label", "Review source citation");
  const shell = document.createElement("div");
  shell.className = "dialog-shell";
  const heading = document.createElement("h2"); heading.textContent = options.annotation ? "Insert annotation citation?" : "Insert source citation?";
  const detail = document.createElement("p");
  detail.textContent = `${source.title || "Untitled source"} — ${source.url || "Locally saved reference"}` +
    (options.annotation?.quote?.exact ? ` — “${options.annotation.quote.exact.slice(0, 160)}”` : "");
  const actions = document.createElement("div"); actions.className = "dialog-actions";
  const cancel = document.createElement("button"); cancel.type = "button"; cancel.textContent = "Cancel";
  const insert = document.createElement("button"); insert.type = "button"; insert.textContent = "Insert citation";
  actions.append(cancel, insert); shell.append(heading, detail, actions); dialog.append(shell);
  document.body.append(dialog);
  dialog.addEventListener("close", () => {
    dialog.remove();
    if (opener?.isConnected) opener.focus({ preventScroll: true });
  }, { once: true });
  cancel.addEventListener("click", () => closeDialog(dialog, "cancel"));
  insert.addEventListener("click", () => {
    // Block stale-caret writes; cancel never touches IndexedDB or CM6.
    if (saved.cardId !== state.activeNoteId || state.noteRevision !== revision || (state.editor?.getValue() ?? elements.noteBody.value) !== draft) {
      announceStatus("The Card changed during review. Reopen citation at the intended cursor.", "error");
      closeDialog(dialog, "stale");
      return;
    }
    state.editorSelection = saved.range;
    insertTextAtCursor(options.annotation ? annotationCitationToken(options.annotation, source)
      : `[@${source.citationKey || citationKeyForSource(source.id)}]`);
    closeDialog(dialog, "insert");
  });
  if (!openDialog(dialog, opener)) { dialog.remove(); return false; }
  return true;
}

function dismissPopover({ restoreFocus = true } = {}) {
  const { popover, popoverOpener } = state.ui;
  if (!popover) return;
  popover.hidden = true;
  popover.classList.add("hidden");
  popoverOpener?.setAttribute("aria-expanded", "false");
  state.ui.popover = null;
  state.ui.popoverOpener = null;
  if (restoreFocus && popoverOpener?.isConnected) popoverOpener.focus({ preventScroll: true });
}

function togglePopover(trigger) {
  const name = trigger.dataset.pfPopoverTrigger;
  const popover = [...document.querySelectorAll("[data-pf-popover]")].find((node) => node.dataset.pfPopover === name);
  if (!popover) return;
  if (state.ui.popover === popover) { dismissPopover(); return; }
  preserveEditorSelection();
  dismissPopover({ restoreFocus: false });
  state.ui.popover = popover;
  state.ui.popoverOpener = trigger;
  popover.hidden = false;
  popover.classList.remove("hidden");
  trigger.setAttribute("aria-expanded", "true");
  if (!popover.hasAttribute("role")) popover.setAttribute("role", "menu");
  positionPopover(trigger, popover);
  const first = [...popover.querySelectorAll(PF_FOCUS)].find((el) => !el.disabled);
  first?.focus({ preventScroll: true });
}

function positionPopover(trigger, popover) {
  if (!trigger?.isConnected || !popover?.isConnected) return;
  const bounds = trigger.getBoundingClientRect();
  const width = Math.min(popover.offsetWidth || 240, window.innerWidth - 16);
  const left = Math.max(8, Math.min(bounds.left, window.innerWidth - width - 8));
  const spaceBelow = window.innerHeight - bounds.bottom;
  const top = spaceBelow >= Math.min(popover.offsetHeight, 240) || spaceBelow >= bounds.top
    ? bounds.bottom + 4 : Math.max(8, bounds.top - popover.offsetHeight - 4);
  Object.assign(popover.style, { position: "fixed", left: `${left}px`, top: `${Math.min(top, window.innerHeight - 8)}px`, maxHeight: `${Math.max(100, window.innerHeight - 16)}px`, overflowY: "auto" });
}

function handlePopoverKeydown(event) {
  const menu = state.ui.popover;
  if (!menu || !menu.contains(document.activeElement)) return;
  const choices = [...menu.querySelectorAll(PF_FOCUS)].filter((el) => !el.disabled && el.getAttribute("aria-disabled") !== "true");
  if (event.key === "Escape") { event.preventDefault(); dismissPopover(); return; }
  if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key) || !choices.length) return;
  event.preventDefault();
  const index = choices.indexOf(document.activeElement);
  const next = event.key === "Home" ? 0 : event.key === "End" ? choices.length - 1
    : event.key === "ArrowDown" ? (index + 1) % choices.length : (index + choices.length - 1) % choices.length;
  choices[next].focus({ preventScroll: true });
}

function toggleDrawer(trigger) {
  const id = trigger.dataset.pfDrawerTrigger;
  const drawer = [...document.querySelectorAll("[data-pf-drawer]")].find((node) => node.dataset.pfDrawer === id);
  if (!drawer) return;
  if (!drawer.hidden) { closeDrawer(drawer); return; }
  preserveEditorSelection();
  state.ui.drawerOpener = trigger;
  drawer.hidden = false;
  drawer.classList.remove("hidden");
  drawer.setAttribute("aria-hidden", "false");
  trigger.setAttribute("aria-expanded", "true");
  drawer.querySelector(PF_FOCUS)?.focus({ preventScroll: true });
}

function closeDrawer(drawer) {
  drawer.hidden = true;
  drawer.classList.add("hidden");
  drawer.setAttribute("aria-hidden", "true");
  const opener = state.ui.drawerOpener;
  opener?.setAttribute("aria-expanded", "false");
  if (opener?.isConnected) opener.focus({ preventScroll: true });
  state.ui.drawerOpener = null;
}

function fileTimestamp() {
  return new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}


function renderSettings() {
  elements.keepLogToggle.checked = state.settings.keepLog;
  elements.embeddingProviderSelect.value = state.settings.embeddingProvider;
  elements.activitySection.classList.toggle("hidden", !state.settings.keepLog);
  elements.searchProviderEditor.value = providersToEditableText(state.settings.searchProviders);
  elements.searchProviderStatus.textContent = `${state.settings.searchProviders.length} provider(s) available to /, @, and right-click search.`;
  elements.searchProviderStatus.className = "muted";
  elements.exportFolderStatus.textContent = state.settings.exportDestination === "chosen-folder"
    ? "Chosen local folder is preferred. Permission may be requested again before writing Paperfold files."
    : "Automatic exports use Downloads/Tabwoven.";
  elements.aiDestination.value = state.settings.exportDestination === "chosen-folder" ? "chosen-folder" : "downloads";
  elements.paperfoldTheme.value = state.settings.paperfoldTheme;
  elements.localSyncUrl.value = state.settings.localSync.baseUrl;
  elements.localSyncToken.value = state.settings.localSync.token;
  elements.localSyncSchedule.value = state.settings.localSync.schedule;
  renderLocalSyncStatus(state.settings.localSync.enabled ? `Configured: ${state.settings.localSync.baseUrl}` : "Local sync is manual/off.");
  if (!elements.cueEditorMode.value) elements.cueEditorMode.value = "critical";
  loadCueEditor();
  void refreshGoogleDriveStatus();
}

async function putSetting(key, value) {
  await put("settings", { key, value });
}

function sourceText(source) {
  return [
    source.title,
    source.url,
    source.description,
    ...(source.authors || []),
    ...(source.headings || []),
    source.markdown,
    source.text
  ].filter(Boolean).join("\n");
}

function sourceIdForUrl(url) {
  return `src:${stableHash(normalizeUrl(url))}`;
}

function normalizeUrl(url) {
  try {
    const parsed = new URL(url);
    parsed.hash = "";
    return parsed.toString();
  } catch {
    return url;
  }
}

function stableHash(value) {
  let hash = 0x811c9dc5;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

function now() {
  return new Date().toISOString();
}

function formatDate(value) {
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(value));
}

function shortUrl(url) {
  try {
    const parsed = new URL(url);
    return `${parsed.hostname}${parsed.pathname === "/" ? "" : parsed.pathname}`;
  } catch {
    return url;
  }
}

function truncate(text, length) {
  const clean = String(text || "").replace(/\s+/g, " ").trim();
  return clean.length > length ? `${clean.slice(0, length - 1)}…` : clean;
}

function humanizeAction(value) {
  return String(value)
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function fallbackFavicon() {
  return "data:image/svg+xml," + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"><rect width="16" height="16" rx="3" fill="#8b95a5"/><path d="M4 4h8v8H4z" fill="white" opacity=".8"/></svg>'
  );
}
