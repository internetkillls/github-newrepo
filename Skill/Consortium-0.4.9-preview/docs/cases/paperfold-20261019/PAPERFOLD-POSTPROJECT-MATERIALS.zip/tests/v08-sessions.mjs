import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createBrowserSessionManager } from '../browser-sessions.js';
import { normalizedTabs, normalizedGroups, snapshotHash, serializedSnapshot, recoverableUrl, missingRestoreTabs } from '../session-model.js';
import { createWorkspaceBundleBlob } from '../provenance.js';
const {webcrypto}=await import('node:crypto');
if(!globalThis.crypto?.randomUUID)globalThis.crypto=webcrypto;
const manifest=JSON.parse(readFileSync(new URL('../manifest.json',import.meta.url)));
assert.equal(manifest.version,'0.8.0');
assert.equal(manifest.name,'Paperfold');
const panelSrc=readFileSync(new URL('../sidepanel.js',import.meta.url),'utf8');
const cmSrc=readFileSync(new URL('../cm-editor.js',import.meta.url),'utf8');
assert.match(panelSrc,/onAddActiveToMaincard:\s*\(\)/,'board command callback passes the CM6 contract');
assert.match(cmSrc,/label:\s*"\/add-to-board"/);
assert.match(cmSrc,/completionAction\("@board"/);
assert(manifest.permissions.includes('tabGroups'));
assert.equal(recoverableUrl('https://example.org/path?token=PRIVATE&section=1#x'), 'https://example.org/path?section=1');
assert.equal(recoverableUrl('chrome://settings'),null);
const tabs=normalizedTabs([{id:10,index:0,url:'https://a.test/',title:'A',active:true,groupId:20},{id:11,index:1,url:'https://b.test/',title:'B',active:false,groupId:20}]);
const groups=normalizedGroups([{id:20,title:'Research',color:'blue'}],tabs);
const hash=snapshotHash(serializedSnapshot(tabs,groups));
assert.equal(hash,snapshotHash(serializedSnapshot(normalizedTabs([{id:101,index:0,url:'https://a.test/',title:'A',active:true,groupId:100},{id:102,index:1,url:'https://b.test/',title:'B',active:false,groupId:100}],tabs), normalizedGroups([{id:100,title:'Research',color:'blue'}], normalizedTabs([{id:101,index:0,url:'https://a.test/',title:'A',active:true,groupId:100},{id:102,index:1,url:'https://b.test/',title:'B',active:false,groupId:100}],tabs),groups))));
const mem={browserSessions:new Map(),sessionRevisions:new Map(),maincards:new Map([['board1',{id:'board1',title:'Research Board'}]])};
const repo={
  async get(store,key){return mem[store].get(key)},
  async getAll(store){return [...mem[store].values()]},
  async getAllByIndex(store,index,id){return [...mem[store].values()].filter(x=>x[index]===id)},
  async commitSessionCheckpoint(session, revision){mem.browserSessions.set(session.id, structuredClone(session));if(revision){mem.sessionRevisions.set(revision.id,structuredClone(revision));const revisions=[...mem.sessionRevisions.values()].filter(x=>x.sessionId===session.id).sort((a,b)=>a.sequence-b.sequence);for(const x of revisions.slice(0,Math.max(0,revisions.length-60)))mem.sessionRevisions.delete(x.id)}}
};
const makeEvent=()=>({listeners:[],addListener(fn){this.listeners.push(fn)},fire(...a){for(const l of this.listeners)l(...a)}});
let windows=[{id:1,incognito:false,tabs:[{id:10,index:0,url:'https://a.test/',title:'A',active:true,pinned:false,groupId:20},{id:11,index:1,url:'https://b.test/',title:'B',active:false,pinned:false,groupId:20}]}];
let groupsInWindow=[{id:20,windowId:1,title:'Research',color:'blue',collapsed:false}];
let tabSequence=30;
const storageSession={};
const browser={
 storage:{session:{async get(k){return {[k]:storageSession[k]}},async set(obj){Object.assign(storageSession,obj)}}},
 windows:{async getAll(){return structuredClone(windows)},async create({url}){const id=2+windows.length; const tab={id:tabSequence++,index:0,url,active:true,pinned:false,groupId:-1};const w={id,incognito:false,tabs:[tab]};windows.push(w);return structuredClone(w)},onCreated:makeEvent(),onRemoved:makeEvent()},
 tabs:{async create({windowId,url,active,pinned}){const w=windows.find(w=>w.id===windowId);const t={id:tabSequence++,index:w.tabs.length,url,active,pinned,groupId:-1};w.tabs.push(t);return structuredClone(t)},async move(id,{index}){const w=windows.find(w=>w.tabs.some(t=>t.id===id));const t=w.tabs.find(t=>t.id===id);t.index=index;return t},async update(id,p){const t=windows.flatMap(w=>w.tabs).find(t=>t.id===id);Object.assign(t,p);return t},async group({tabIds,createProperties}){const id=90;for(const t of windows.flatMap(w=>w.tabs))if(tabIds.includes(t.id))t.groupId=id;groupsInWindow.push({id,windowId:createProperties.windowId,title:'',color:'grey',collapsed:false});return id},onCreated:makeEvent(),onRemoved:makeEvent(),onUpdated:makeEvent(),onMoved:makeEvent(),onAttached:makeEvent(),onDetached:makeEvent(),onActivated:makeEvent()},
 tabGroups:{async query({windowId}){return structuredClone(groupsInWindow.filter(g=>g.windowId===windowId))},async update(id,updates){Object.assign(groupsInWindow.find(g=>g.id===id),updates)},onCreated:makeEvent(),onRemoved:makeEvent(),onUpdated:makeEvent(),onMoved:makeEvent()},
 alarms:{async create(){},onAlarm:makeEvent()}
};
const mgr=createBrowserSessionManager(browser,repo);
mgr.bind();
await mgr.start();
let sessions=await mgr.list();
assert.equal(sessions.length,1,'one logical session');
assert.equal((await mgr.history(sessions[0].id)).length,1);
await mgr.captureNow();await mgr.captureNow();
assert.equal((await mgr.list()).length,1,'repeated captures do not make duplicate sessions');
assert.equal((await mgr.history(sessions[0].id)).length,1,'unchanged snapshot does not create revision');
await mgr.assignBoard(sessions[0].id,'board1',true);
assert.deepEqual((await mgr.list())[0].boardIds,['board1']);
windows[0].tabs.pop();
await mgr.captureNow();
assert.equal((await mgr.history(sessions[0].id)).length,2);
const oldId=`${sessions[0].id}:r1`;
const preview=await mgr.preview(sessions[0].id,oldId);
assert.equal(preview.missing.length,1);
assert.equal(preview.missing[0].url,'https://b.test/');
const recovery=await mgr.restore(sessions[0].id,oldId);
assert.equal(recovery.created,1);
assert.equal(windows.length,2);
const restoredSession=[...mem.browserSessions.values()].find(x=>x.restoredFrom?.sessionId===sessions[0].id);
assert(restoredSession,'restore creates explicitly labeled working copy');
assert(restoredSession.tabs.every(t=>!sessions[0].tabs.some(orig=>orig.id===t.id)),'working copy gets distinct stable tab IDs');
assert.equal(mem.maincards.size,1,'research Board is not mutated by restore');
assert.equal(mem.browserSessions.get(sessions[0].id).boardIds[0],'board1');
const again=await mgr.preview(sessions[0].id,oldId);
assert.equal(again.missing.length,0,'existing restored URL is skipped');
// Simulate crash/startup with none of the old normal browser windows restored by Chrome.
windows=[];for(const key of Object.keys(storageSession))delete storageSession[key];
await mgr.start();
assert((await mgr.list()).some(s=>s.status==='RECOVERY_NEEDED'));
const bundle=await createWorkspaceBundleBlob({notes:[],sources:[],links:[],scraps:[],annotations:[],chunks:[],ir:[],bookmarks:[],settings:[],backups:[],transports:[],attachments:[],maincards:[],memberships:[],cardEdges:[],syncRuns:[],browserSessions:[...mem.browserSessions.values()],sessionRevisions:[...mem.sessionRevisions.values()]});
const tar=(await import('node:zlib')).gunzipSync(Buffer.from(await bundle.arrayBuffer())).toString('utf8');
assert.match(tar,/database\/browser-sessions\.json/);
assert.match(tar,/database\/session-revisions\.json/);
assert.match(tar,/https:\/\/a.test\//);
console.log(JSON.stringify({result:'PASS',sessions:mem.browserSessions.size,revisions:mem.sessionRevisions.size,archiveBytes:bundle.size,restoreCount:recovery.created}));
