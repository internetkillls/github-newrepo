#!/usr/bin/env python3
"""W10 reverify negative and positive seam controls. Source/static jurisdiction only."""
from pathlib import Path
import argparse,hashlib,json,re,sys
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,default=Path(__file__).resolve().parent.parent);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--w7-closure',type=Path,required=True);p.add_argument('--old-w9',type=Path,required=True);a=p.parse_args()
c=a.candidate; b=a.baseline
J=(c/'sidepanel.js').read_text();H=(c/'sidepanel.html').read_text();C=(c/'sidepanel.css').read_text();old=(a.old_w9).read_text(); oldH=(b/'sidepanel.html').read_text();W=json.loads(a.w7_closure.read_text())
checks={}
def check(name,condition):checks[name]=bool(condition)
check('ownership disjoint and exact',set(W['ownership']['w8'])=={'sidepanel.html','sidepanel.css'} and W['ownership']['w9']==['sidepanel.js'] and not(set(W['ownership']['w8'])&set(W['ownership']['w9'])))
check('negative baseline lacked popover',not all(x in oldH for x in ('id="pfSourceContextTrigger"','id="pfSourceContextPopover"')))
check('positive production contextual popover present',all(x in H for x in ('id="pfSourceContextTrigger"','id="pfSourceContextPopover"','data-pf-popover="source-context"')))
check('positive menu keyboard focus',all(x in J for x in ('function togglePopover(trigger)','function handlePopoverKeydown(event)','popver')) is False and all(x in J for x in ('function togglePopover(trigger)','function handlePopoverKeydown(event)','ArrowUp','ArrowDown','dismissPopover()')))
check('negative original W9 had direct Capture write', 'attachCurrentButton.addEventListener' in old and 'attachTab(state.currentTab' in old)
check('positive Capture cannot fall through direct write', 'elements.attachCurrentButton.addEventListener("click", () => attachTab' not in J and 'bindCaptureReview();' in J)
check('Capture modal and initially disabled control',all(x in H for x in ('id="pfCaptureReviewDialog"','id="pfCaptureCommitButton"','id="pfCaptureCancelButton"')) and re.search(r'id="attachCurrentButton"[^>]*\bdisabled\b',H) is not None)
check('Capture read-only metadata',all('document.getElementById("'+x+'").textContent' in J for x in ('pfCaptureReviewPageTitle','pfCaptureReviewPageUrl')))
check('Capture positive commit gated by permission/tab/card', 'await captureTabStillValid(tab)' in J and 'state.activeNoteId !== noteId' in J and 'reviewedCapture: true, previewNoteId: noteId' in J)
check('Capture negative canceled until ACK', 'database.transaction(["sources", "links"], "readwrite")' in J and 'await acknowledged; // Both stores committed before any success signal.' in J and 'captureReview.pending = true' in J)
check('route attr handshake', 'node.dataset.pfActive = String(active)' in J and '[data-pf-active="true"]' in C)
check('baseline security surfaces intact',all((c/f).read_bytes()==(b/f).read_bytes() for f in ['manifest.json','service-worker.js','db.js','sync.js']))
print(json.dumps({'schema':'paperfold.w10.boundary-controls.v1','scope':'source assertions, not runtime evidence','status':'PASS' if all(checks.values()) else 'FAIL','checks':checks},indent=2))
sys.exit(0 if all(checks.values()) else 1)
