import assert from 'node:assert/strict';
import { ensureFrontmatter, noteTemplate, parseFrontmatter } from '../yaml.js';
import { DEFAULT_SEARCH_PROVIDERS, buildCalendarItems, buildFlowGraph, buildReviewRows, editableTextToProviders, flattenWorkspace, flowToMermaid, providerUrl, providersToEditableText, reviewCsv } from '../workspace.js';
import { createAiTransportBundleBlob, createWovenBundleBlob, createWorkspaceBundleBlob } from '../provenance.js';

const notes = [
  { id: 'n1', title: 'Inquiry', createdAt: '2026-07-26T01:00:00Z', updatedAt: '2026-07-26T02:00:00Z', body: ensureFrontmatter('See [[Decision]].\n', { ...noteTemplate('tracker', new Date('2026-07-26T00:00:00Z')), due: '2026-07-30', progress: 25 }) },
  { id: 'n2', title: 'Decision', createdAt: '2026-07-26T01:00:00Z', updatedAt: '2026-07-26T02:00:00Z', body: ensureFrontmatter('Result.\n', noteTemplate('log', new Date('2026-07-26T00:00:00Z'))) }
];
const sources = [{ id: 's1', title: 'Source', url: 'https://example.com/a' }];
const links = [{ id: 'l1', noteId: 'n1', sourceId: 's1', reason: 'research' }];
const annotations = [{ id: 'a1', noteId: 'n1', sourceId: 's1' }];
const scraps = [{ id: 'p1', noteId: 'n1', sourceId: 's1', sequence: 1, fileName: 'Inquiry.scrap1.md', markdown: '# Source' }];
const transports = [{ id: 't1', noteId: 'n1', kind: 'ai-context', destination: 'downloads', createdAt: '2026-07-26T03:00:00Z' }];
const reminders = [{ id: 'r1', noteId: 'n1', when: '2026-07-29T09:00:00Z', message: 'Review' }];

assert.equal(parseFrontmatter(notes[0].body).properties.type, 'tracker');
assert.equal(parseFrontmatter(ensureFrontmatter(notes[0].body, { status: 'draft' })).properties.status, 'active', 'existing YAML must win over defaults');

const rows = buildReviewRows({ notes, sources, links, annotations, scraps, reminders, transports });
assert.equal(rows[0].source_count, 1);
assert.equal(rows[0].annotation_count, 1);
assert.equal(rows[0].transport_count, 1);
assert.match(reviewCsv(rows), /next_action/);

const calendar = buildCalendarItems({ notes, reminders, transports });
assert.ok(calendar.some((item) => item.field === 'due'));
assert.ok(calendar.some((item) => item.kind === 'reminder'));
const graph = buildFlowGraph({ notes, sources, links, annotations, scraps });
assert.ok(graph.edges.some((edge) => edge.type === 'wikilink'));
assert.ok(graph.edges.some((edge) => edge.type === 'annotation'));
assert.match(flowToMermaid(graph), /flowchart LR/);
const flat = flattenWorkspace({ rows, calendarItems: calendar, graph });
assert.equal(flat.schema, 'tabwoven.flatten/1');

const providerText = providersToEditableText(DEFAULT_SEARCH_PROVIDERS);
const providers = editableTextToProviders(providerText);
assert.ok(providers.length >= 6);
assert.match(providerUrl(providers[0], 'critical realism'), /critical%20realism/);

const aiBlob = await createAiTransportBundleBlob({ name: 'Test', prompt: 'Summarize.', notes, rows, calendar, graph, sources, annotations, scraps, ir: [], csv: reviewCsv(rows), calendarCsv: '', mermaid: flowToMermaid(graph) });
assert.ok(aiBlob.size > 1000);
const noteBlob = await createWovenBundleBlob({ note: notes[0], sources, links, scraps, annotations, bookmarks: [], ir: [], chunks: [], includeVectors: true });
assert.ok(noteBlob.size > 500);
const backupBlob = await createWorkspaceBundleBlob({ notes, sources, links, scraps, annotations, chunks: [], ir: [], bookmarks: [], settings: [], backups: [], transports, includeVectors: true });
assert.ok(backupBlob.size > 1000);

console.log(JSON.stringify({ rows: rows.length, calendar: calendar.length, nodes: graph.nodes.length, edges: graph.edges.length, aiBytes: aiBlob.size, backupBytes: backupBlob.size }));
