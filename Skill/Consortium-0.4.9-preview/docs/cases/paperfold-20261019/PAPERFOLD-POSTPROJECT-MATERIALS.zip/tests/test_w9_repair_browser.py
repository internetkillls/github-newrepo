"""Combined real W8 HTML/CSS + complete W9 functions in Chromium, with actual IndexedDB.
Not an installed extension or service-worker verification. Run: python TESTS/test_w9_repair_browser.py
"""
from pathlib import Path
import json, re, shutil, argparse
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--w8-dir',type=Path,default=root,help='Folder containing delivered W8-repair sidepanel.html/CSS')
a=parser.parse_args()
html = (a.w8_dir/'sidepanel.html').read_text()
css = (a.w8_dir/'sidepanel.css').read_text()
html=re.sub(r'<script[^>]*src="[^"]+\.js"[^>]*></script>', '',html)
html=re.sub(r'<link[^>]+href="sidepanel\.css"[^>]*>', lambda _:'<style>\n'+css+'\n</style>',html)
js=(root/'sidepanel.js').read_text()
js=re.sub(r'^import[\s\S]*?from "[^"]+";\s*$', '', js, flags=re.M)
assert js.count('await initialize();')==1
js=js.replace('await initialize();','/* Browser probe mounts the same app functions without full bootstrap. */')
shim='''
if (!crypto.randomUUID) crypto.randomUUID = () => `fixture-${Math.floor(Math.random()*1e12)}`;
const DEFAULT_SEARCH_PROVIDERS = [];
const cloneDefaultCueLibrary = () => ({});
const normalizeSearchProviders = x => x;
const normalizeSyncConfig = () => ({});
const citationKeyForSource = id => id;
const embedText = async () => [];
// Explicitly simulated transaction ACK: browser blocks real IndexedDB on opaque origin.
const fixtureRows={sources:new Map(),links:new Map()};
let failCommit=false;
const openDb=async()=>({transaction(stores,mode){
 const operations=[];
 const tx={oncomplete:null,onerror:null,onabort:null,error:null,abort(){
   tx.error=new Error('aborted');tx.onabort?.();
 },objectStore(store){return {put(record){operations.push([store,record]);}}}};
 setTimeout(()=>{
   if(tx.error)return;
   if(failCommit){failCommit=false;tx.error=new Error('simulated transaction abort');tx.onabort?.();return;}
   for(const [store,rec] of operations)fixtureRows[store].set(rec.id,structuredClone(rec));
   tx.oncomplete?.();
 },120);
 return tx;
}});
let permission=true, tab={id:17,url:'https://example.com/page',title:'<img src=x onerror=alert(1)>',favIconUrl:''};
let extractionCount=0;
window.chrome={
  permissions:{contains:async()=>permission},
  runtime:{sendMessage:async msg=>msg.type==='GET_ACTIVE_TAB'?{ok:true,tab:{...tab}}
    :msg.type==='EXTRACT_TAB'? (++extractionCount,{ok:true,snapshot:{title:tab.title,canonicalUrl:tab.url,description:'preview',text:'Test body'}}):{} }
};
const getByIndex=async(store,index,key)=>[...fixtureRows[store].values()]
  .find(rec=>index==='noteSource' && rec.noteId===key[0] && rec.sourceId===key[1]) || null;
const get=async(store,id)=>fixtureRows[store].get(id)||null;
const put=async()=>{throw new Error('unexpected non-transactional put')};
const getAllByIndex=async()=>[];
'''
post='''
// Only secondary audit/refresh depends on the unbootstrapped host; real capture storage uses IDB.
recordLog = async () => {};
recordIr = async () => {};
renderSources = async () => {};
updatePermissionUi = async () => {};
let toastMessages=[];
const announce=announceStatus;
announceStatus = function(message,kind){toastMessages.push({message,kind}); announce(message,kind);};
const captures=[];
async function snapshotCounts(){return {sources:fixtureRows.sources.size,links:fixtureRows.links.size};}
state.notes=[{id:'card-1',title:'Card 1',body:'draft'}];state.activeNoteId='card-1';
bindCaptureReview(); initializeInteractionShell();
document.addEventListener("keydown",handleDocumentKeydown,true);
window.probe={counts:snapshotCounts,toastMessages,setPermission:x=>permission=x,
 setTab:x=>tab=x,getTab:()=>tab,setCard:x=>state.activeNoteId=x,
 current:()=>({...captureReview}), active:()=>document.activeElement?.id,
 open:()=>document.getElementById('pfCaptureReviewDialog').open,
 failNext:()=>{failCommit=true;},
 menu:()=>state.ui.popover,
 route:()=>state.ui.route,
 extractCount:()=>extractionCount
};
'''

def await_count(page):
 count=page.evaluate('probe.counts()');return (count['sources'],count['links'])

with sync_playwright() as pw:
 binary=shutil.which('chromium') or shutil.which('google-chrome')
 browser=pw.chromium.launch(headless=True, executable_path=binary) if binary else pw.chromium.launch()
 outcomes=[]
 for w,h,theme in [(280,400,'paper'),(320,700,'black'),(420,400,'system'),(800,700,'paper')]:
  ctx=browser.new_context(viewport={'width':w,'height':h}, color_scheme='dark' if theme=='system' else 'light', reduced_motion='reduce')
  page=ctx.new_page();page.set_content(html);page.evaluate('(theme)=>document.documentElement.dataset.paperfoldTheme=theme',theme)
  page.on('pageerror',lambda err: print('PAGEERROR',err))
  page.add_script_tag(content=shim+js+post)
  page.wait_for_function('!document.querySelector("#attachCurrentButton").disabled')
  assert page.locator('#attachCurrentButton').is_enabled()
  # Route CSS handshake and native More dismissal.
  page.locator('[data-pf-route="library"]').first.click()
  assert page.locator('[data-pf-view="library"]').is_visible()
  assert page.locator('[data-pf-view="library"]').get_attribute('data-pf-active')=='true'
  trigger=page.locator('#pfSourceContextTrigger');trigger.click()
  menu=page.locator('#pfSourceContextPopover');assert menu.is_visible()
  assert page.evaluate('document.activeElement?.getAttribute("role")')=='menuitem'
  page.keyboard.press('End');assert page.evaluate('document.activeElement.textContent.trim()')=='Return to Card'
  page.keyboard.press('Home');assert page.evaluate('document.activeElement.textContent.trim()')=='Find related material'
  bbox=menu.bounding_box();assert bbox['x']>=-1 and bbox['y']>=-1 and bbox['x']+bbox['width']<=w+1 and bbox['y']+bbox['height']<=h+1,('menu clamp',bbox,w,h)
  page.keyboard.press('Escape');assert not menu.is_visible();assert page.evaluate('probe.active()')=='pfSourceContextTrigger'
  trigger.click();page.locator('[data-pf-view="library"] h1').click();assert not menu.is_visible()
  trigger.click();menu.locator('[data-pf-route="boards"]').click();assert page.locator('[data-pf-view="boards"]').is_visible()
  # More disclosure closes outside and Escape and on navigation.
  page.locator('details.pf-more summary').click();assert page.locator('details.pf-more').evaluate('(x)=>x.open')
  page.keyboard.press('Escape');assert not page.locator('details.pf-more').evaluate('(x)=>x.open')
  page.locator('details.pf-more summary').click();page.locator('[data-pf-route="library"]').first.click()
  assert not page.locator('details.pf-more').evaluate('(x)=>x.open')
  page.locator('details.pf-more summary').click();page.locator('[data-pf-view="library"] h1').click()
  assert not page.locator('details.pf-more').evaluate('(x)=>x.open')
  # Canceled preview before asynchronous ready and after ready = zero sources+links writes.
  page.locator('#attachCurrentButton').click()
  assert page.locator('#pfCaptureReviewDialog').evaluate('(x)=>x.open')
  assert await_count(page)==(0,0)
  page.locator('#pfCaptureCancelButton').click();assert await_count(page)==(0,0)
  assert page.evaluate('probe.active()')=='attachCurrentButton'
  page.locator('#attachCurrentButton').click();page.wait_for_function('!document.querySelector("#pfCaptureCommitButton").disabled')
  assert page.locator('#pfCaptureReviewPageTitle').inner_text()=='<img src=x onerror=alert(1)>'
  assert page.locator('#pfCaptureReviewDialog img').count()==0
  page.keyboard.press('Escape');assert await_count(page)==(0,0)
  # Denied host permission fail-closed.
  page.evaluate('probe.setPermission(false)');page.locator('#attachCurrentButton').click()
  page.wait_for_function('document.querySelector("#pfCaptureReviewStatus").textContent.includes("permission")')
  assert page.locator('#pfCaptureCommitButton').is_disabled()
  assert await_count(page)==(0,0)
  page.locator('#pfCaptureCancelButton').click();page.evaluate('probe.setPermission(true)')
  # Stale preview (tab changes) disables storage on confirm.
  page.locator('#attachCurrentButton').click();page.wait_for_function('!document.querySelector("#pfCaptureCommitButton").disabled')
  page.evaluate('probe.setTab({id:18,url:"https://example.org/stale",title:"other"})')
  page.locator('#pfCaptureCommitButton').click()
  page.wait_for_function('document.querySelector("#pfCaptureReviewStatus").textContent.includes("changed")')
  assert await_count(page)==(0,0)
  page.locator('#pfCaptureCancelButton').click()
  page.evaluate('probe.setTab({id:17,url:"https://example.com/page",title:"Safe",favIconUrl:""})')
  # Failed transaction ACK must not announce success or leave a half-committed Source.
  page.evaluate('probe.failNext()')
  page.locator('#attachCurrentButton').click();page.wait_for_function('!document.querySelector("#pfCaptureCommitButton").disabled')
  page.locator('#pfCaptureCommitButton').click()
  page.wait_for_function('document.querySelector("#pfCaptureReviewStatus").textContent.includes("not confirmed")')
  assert await_count(page)==(0,0)
  assert not page.evaluate('probe.toastMessages.some(x=>x.kind==="success")')
  page.locator('#pfCaptureCancelButton').click()
  # Confirm / concurrent duplicate pointer = one transaction, after both stores acknowledge.
  page.locator('#attachCurrentButton').click();page.wait_for_function('!document.querySelector("#pfCaptureCommitButton").disabled')
  pending=page.locator('#pfCaptureCommitButton').evaluate('''(x)=>{x.click();x.click();return {status:document.querySelector("#pfCaptureReviewStatus").textContent,saved:probe.toastMessages.some(x=>x.kind==="success")};}''')
  assert pending['status']=='Saving Source…' and not pending['saved']
  assert await_count(page)==(0,0)
  page.keyboard.press('Escape') # Escape cannot cancel a confirmation already committing.
  assert page.locator('#pfCaptureReviewDialog').evaluate('(x)=>x.open')
  page.wait_for_function('!document.querySelector("#pfCaptureReviewDialog").open')
  assert await_count(page)==(1,1),('commit counts',await_count(page))
  assert page.evaluate('probe.toastMessages.some(x=>x.kind==="success")')
  assert page.evaluate('probe.active()')=='attachCurrentButton'
  assert page.evaluate('matchMedia("(prefers-reduced-motion: reduce)").matches')
  reduced=page.locator('#pfSourceContextPopover').evaluate('(x)=>getComputedStyle(x).transitionDuration')
  assert all(float(x.strip().removesuffix('s'))<=.001 for x in reduced.split(',')),reduced
  # Repeated capture of same page cannot create duplicate link.
  page.locator('#attachCurrentButton').click();page.wait_for_function('!document.querySelector("#pfCaptureCommitButton").disabled')
  page.locator('#pfCaptureCommitButton').click();page.wait_for_function('!document.querySelector("#pfCaptureReviewDialog").open')
  assert await_count(page)==(1,1)
  outcomes.append({'viewport':f'{w}x{h}','theme':theme,'captureCancelZeroWrite':True,'permissionNegative':True,'staleNegative':True,'failedTransactionNegative':True,'dedup':True,'persistedSources':1,'persistedLinks':1,'popover':True,'route':True,'more':True})
  ctx.close()
 browser.close()
 print(json.dumps({'status':'PASS','scope':'actual W8 markup/CSS + complete W9 functions, simulated transaction acknowledgments in opaque-origin Chromium; NOT real IndexedDB or installed extension','cases':outcomes},indent=2))

