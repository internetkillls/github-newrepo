import assert from 'node:assert/strict';
import {buildLexicalProfile,proposeCrossBoardLinks} from '../prototypes/discover/lexical.js';
import {validateQueryPlan,makeResearchRecipes} from '../prototypes/discover/query-ast.js';
const corpus=[
{id:'a',approved:true,boardIds:['philosophy'],sourceId:'s1',title:'Critical realism',text:'Emergence causal powers and critical realism require explanatory critique.'},
{id:'b',approved:true,boardIds:['business'],sourceId:'s2',title:'Business causal powers',text:'Emergence and causal powers in market institutions.'},
{id:'c',approved:true,boardIds:['philosophy'],sourceId:'s3',title:'Critical realism critique',text:'Critical realism rejects some explanatory critique.'},
{id:'secret',approved:false,boardIds:['business'],title:'Invisible',text:'Secret neuroscience product launch'}
];
const prof=buildLexicalProfile(corpus);assert.equal(prof.documentCount,3);assert(prof.terms.some(x=>x.term==='causal powers'));assert(!prof.terms.some(x=>x.term.includes('neuroscience')));assert(prof.terms.every(x=>x.evidence.every(e=>e.docId!=='secret')));
assert.equal(buildLexicalProfile(corpus.slice(0,1)).status,'INSUFFICIENT_EVIDENCE');
assert.throws(()=>buildLexicalProfile([{id:'a',approved:true,language:'ja',text:'日本語'},...corpus]),/tokenization/);
let links=proposeCrossBoardLinks(corpus);assert(links.length>0);assert(links.every(l=>l.status==='PROPOSED'&&l.type==='related-to'));assert(links.every(l=>l.provenance.length===2));
const dismiss=[links[0].id.slice('proposal:'.length)];assert(!proposeCrossBoardLinks(corpus,{dismissedPairs:dismiss}).some(x=>x.id===links[0].id));
assert(!proposeCrossBoardLinks(corpus,{excludedIds:['b']}).some(x=>x.leftId==='b'||x.rightId==='b'));
const r=validateQueryPlan({provider:'google',terms:[{text:'emergence critical realism',exact:true}],site:'derivative.ca',filetype:'pdf',exclude:['advertisement']});
assert.equal(new URL(r.url).searchParams.get('q'),r.query);assert(r.query.includes('site:derivative.ca'));assert(r.requiresExplicitExternalSearch);
assert.throws(()=>validateQueryPlan({provider:'duckduckgo',terms:['topic'],filetype:'csv'}),/not supported/);
assert.throws(()=>validateQueryPlan({provider:'google',terms:['api_key=abcd']}),/Sensitive/);
assert.throws(()=>validateQueryPlan({provider:'google',terms:['hello@example.com']}),/Sensitive/);
assert.throws(()=>validateQueryPlan({provider:'google',terms:['topic'],site:'attacker.com/path'}),/Invalid site/);
assert.throws(()=>validateQueryPlan({provider:'google',terms:[]}),/required/);
assert.equal(makeResearchRecipes('critical realism').length,5);
console.log(JSON.stringify({status:'PASS',docs:prof.documentCount,terms:prof.terms.length,relatedProposals:links.length,queryRecipes:5,safety:'No storage or network APIs used'}));
