# Canonical information architecture / W4

## Domain ontology and routes

**Board** = project perspective (`maincards` legacy store, memberships and typed edges). **Card** = editable Markdown document (does not belong exclusively to one Board). **Source** = reference + provenance. **Capture** = selected saved representation of page/text/file. **Annotation** = anchored passage/comment, distinct from Source. **Session** = saved, versioned browser activity and recovery intent. **Discover** = unverified neutral relation *proposal*. **Query Studio** = AST and external query **preparation**, not outbound results. **Workspace** = derived Spreadsheet/Calendar/Flow/Flatten views, not duplicate documents. **Search** = explicit query over accurately described available scopes. Source provider integrations remain optional. Exports and restores are **different** safety gates.

```text
APP SHELL  Paperfold [text]                           [Capture]
├─ WRITE [landing; last active Card]       ◀── retained Card ID/caret
│  ├─ Card picker, new, title, Markdown/Reading, contextual formatting
│  ├─ Board context / membership (optional; may be unlinked)
│  ├─ Sources drawer → type-filtered evidence → stage/review citation
│  ├─ Find evidence → LIBRARY → Source inspector → stage/review in WRITE
│  └─ Card actions → Markdown export / AI transport / activity / properties
├─ BOARDS [top level] → Board detail → Cards/members/typed edges/export
├─ LIBRARY [top level] → typed saved objects/filter/query → inspector
│  ├─ Source + bookmarks + captures/scraps + annotations + attachments + DOI
│  └─ inspector: original URL / provenance / associated Card / stage citation
└─ MORE [top level on narrow]
   ├─ Find [search]  ← Cards and saved objects with explicit source scope
   ├─ Sessions → revisions → inspect preview → confirm Restore missing tabs
   ├─ Explore → Discover [GATED] | Query Studio [GATED, preview only]
   ├─ Workspace → Spreadsheet | Calendar | Flow | Flatten
   ├─ Contextual capture guide / States & permissions
   └─ Settings → Appearance | Writing/capture | Search/commands |
                 Data/backup/export | Integrations | Privacy/diagnostics
Chrome native context menu → explicit selection/page capture, attach, scrape,
                           annotate, Boards and configured external provider search
Proposed on-page popover → only after permission/trust review, never implied shipped
Expanded tab → proposed same-route projection; new entrypoint required
```

**Canonical route IDs:** `write`, `boards`, `library`, `search`, `sessions`, `explore`, `workspace`, `popover` (spec / unmounted), `states`, `settings`, `more`. Side Panel compact dock uses `write`, `boards`, `library`, `more`; expanded rail surfaces `write`, `boards`, `library`, `search` (Find), `sessions` and `more`; the latter lists every secondary route, never an unlabelled hidden control. `search` is labeled **Find** at UI affordance, retained route ID `search` for contract stability. *No* feature is silently deleted because a navigation tab disappears: W4's 111-row relocation map assigns every baseline feature and gate.

## Mandatory surface coverage matrix

| S | Surface | Entry | State / critical behavior |
|---|---|---|---|
| S01 | Shell and navigation | text Paperfold + four compact routes or labeled rail | same route IDs, pending navigation, no decorative logo |
| S02 | Markdown Card editor | Write | CM6 preserve draft/selection/undo; persisted/error acknowledged |
| S03 | Boards | Boards; Write Board context | many-to-many Card membership, deliberate typed edges, delete confirm |
| S04 | Library/bookmarks/Sources/captures | Library | saved typed items only, provenance, type/Board filters with return |
| S05 | Search/filter | More→Find or writing shortcut | exact honest scope; local-hash search not neural inference |
| S06 | Discover | More→Explore→Discover | GATED neutral suggestions; no automatic edge writes |
| S07 | Query Studio | More→Explore→Query Studio | GATED AST/URL preview; explicit external consent |
| S08 | Sessions | More→Sessions, wide rail Sessions | revision + preview and explicit recovery new window |
| S09 | Annotations/citations | Source inspector / Write Sources drawer | selection preserved, explicit destination and acknowledgement |
| S10 | Quick Capture, native menu | global Capture or native Chrome context | permission-relevant staged preview, no capture on hover |
| S11 | On-page popover | proposed capture contextual projection | SPEC ONLY: no content injection asserted in v0.8 |
| S12 | Settings / integrations | More→Settings | established options grouped, honest status, no invented account |
| S13 | Empty/loading/success/warning/error/denied | inline in every surface; States is demonstration route only | preserve draft, actionable retry, live region, no false success |
| S14 | Full-tab | expanded same-route layout at >=700; optional inspector >=1110 | SPEC ONLY: baseline manifest lacks full-tab entrypoint |
| S15 | Narrow Side Panel | 280–600 single lane, four readable nav labels | no root overflow, clipped primary action or unbounded menu |

## Critical journey contracts (functional intentions, not claims of deployed behavior)

**J01 Resume writing:** open panel → `write` last active Card → edit Markdown → save `dirty → saving → persisted/error`. Board is context, not editor ownership. On width change preserve Card ID, selection, undo and focus. Fixture demonstrates local in-memory editing only; Stage III must obtain IndexedDB ACK.

**J02 Citation from saved evidence:** Write at caret → Find evidence/Library → filter by type and text → inspect Source URL, kind and provenance → `Review insertion in Write` creates staged tuple `(sourceId, cardId, selectionRange, returnRoute, filters)` without mutation → Confirm commits one insertion transaction or Cancel returns to exact Library query/type. Stage III should revalidate target Card/revision and handle stale selection; may offer append fallback with user's choice, never silent drift.

**J03 Capture while browsing:** Chrome native selection or global Capture → choose explicit clip/annotation/scrape/attach mode → permission/page-URL check → preview origin/selection/target → review/confirm → service result/rollback or retry. Restricted URL, declined grant and canceled preview must change zero stored records. Optional Board choice cannot block unassigned capture.

**J04 Organize Board:** Boards → create/select Board → add existing Card (many-to-many, never clone) → edit role/classification → add typed edge by user assertion → export flatten/flow. Board deletion never silently deletes Cards; no inferred `supports` from Discover.

**J05 Recover interrupted Session:** More→Sessions → select saved session and revision → inspect eligibility (missing HTTP(S)/already-open/blocked) → Preview (no tabs created) → explicit confirm Restore new window → show acknowledged per-tab result. Board association is metadata; never move a Card on Session navigation.

**J06 Retrieve an annotation:** Library→Annotation type + query → inspect passage/source anchor and DOI/URL → open original if accessible, with fallback when TextQuote anchor stale → stage citation to target Card. Source identity never synthesized from search similarity alone.

**J07 Search/Find:** More→Find → type + Board scope + query → results distinguish Card/Source/Bookmark/etc.; local-hash suggestions labeled truthfully → inspect/return retains query. Production heterogeneous search semantics currently to be implemented or explicitly unavailable per type; do not misrepresent fixture as complete index.

**J08 Inspect advanced research:** More→Explore→Discover/Query Studio → explanatory gate; optional local AST preview only. No suggestion acceptance, typed edge write, provider request or authoritative research claim until test gates.

**J09 Settings/data:** More→Settings→Appearance/Integrations/Data → theme selection, source configuration status, Card Markdown export, archive backup. Persist setting/backup only after source service reports result. Archive export integrity does **not** prove restore safety.

**J10 Cross-surface continuity:** Change source filters while editor draft exists → cancel/review/confirm then return with Card ID/caret and Library query intact. Native Chrome context-menu remains outside Side Panel DOM; proposed popover is not a replacement for extension native menu.

## Explicit responsive architecture

| Available *container* CSS width | Composition | Minimum contract |
|---|---|---|
| 280px | compact header can wrap, editor single lane, four labeled dock items, full-width sheets/dialogs | all four destinations visible, no horizontal root overflow; nonprimary tools inside labeled actions |
| 320px | identical topology, inline formatting can scroll only with alternate menu | source inspect as drill-down; new, capture, and citation confirmations fit viewport |
| 360px | same one column, header/title align only if measured space | route and focus continuity; no right inspector |
| 420px | one column, flexible type chips and long URL wrapping | no hidden Save or source insertion behind scroll-only toolbar |
| 600px | one substantive content lane (not squashed desktop preview) | Library source inspector still drill-down |
| 700–1099px | labeled left rail ~196px (Write/Boards/Library/Find/Sessions/More) + constrained main/editor | no independent duplicate route state; meaningful whitespace |
| >=1110px | editor max width ~760px + optional context inspector ~260–300px | inspector is derivative/read-only; editor retains continuous focus |

Heights must remain fluid; dialogs fit remaining viewport with owned scrolling. `min-width:0` on grid and flex children; content wraps safely including URLs. Tabs are **not** moved into an icon-only rail. At 100–200% native zoom, repeat width assertions in real Chrome; `body.style.zoom=2` is only a fixture stress proxy and cannot fulfill the native zoom test. No fixed application aspect ratio. Image/video preview must keep intrinsic ratio.

**Keyboard/accessibility:** logical DOM order, labeled buttons and controls, visible `:focus-visible`, Escape/Cancel for dialogs, return focus to source trigger/editor, no hover-only commit, `aria-live` for confirmed status. Modal focus trap and external popover positioning are W5/W6 contracts, screen reader / native zoom W10 verification. Reduced-motion disables nonessential transitions; no motion required to finish a task. Paper/Pure Black/System must retain icon contrast without blanket asset inversion.

**Tokens from supplied v0.8:** `--bg`, `--surface`, `--surface-2`, `--text`, `--muted`, `--border`, `--accent`, `--accent-soft`, `--danger`, `--shadow`, `--mark`. Exact token values stay from baseline, no new branding palette.

## Navigation state and source ownership

State minimum: `activeCardId`, `selectedBoardId?`, `sourceId?`, `libraryQuery`, `libraryType`, `findQuery`, `selectedSessionId`, `revisionId?`, `editorSelection`, `editorUndo`, `draftDirtyState`, `pendingInsertion?`, `permissionState`, `theme` and route history. Absence of a Board is valid. Do not persist transient UI data by rewriting `maincards` or altering schema. State and commands must be connected through current `sidepanel.js` / `cm-editor.js` / `card-model.js` / `provenance.js` / `browser-sessions.js` / `service-worker.js` adapters, not a speculative replacement backend. Need explicit adapter API and file ownership in W7 Stage II.
