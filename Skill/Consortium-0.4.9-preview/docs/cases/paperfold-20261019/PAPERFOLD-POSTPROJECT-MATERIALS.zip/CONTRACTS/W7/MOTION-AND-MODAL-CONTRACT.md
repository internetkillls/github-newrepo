# MOTION-AND-MODAL-CONTRACT.md

Baseline v0.8 verified SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. W4 is canonical I1; W5 and W6 are advisory I1 closures. This document freezes Stage II contracts, not implemented behavior.

W5 governing motion tokens: `--motion-open:160ms`, `--motion-close:120ms`, `--motion-feedback:90ms`; opening `cubic-bezier(.2,.8,.2,1)`, closing `ease-in`. Hover opacity 80ms; pointer pressed scale .985; optional route fade 120ms. Animate opacity/transform only, never layout position for required controls. prefers-reduced-motion: reduce disables transitions and smooth scrolling. Motion never delays focus or persistence acknowledgment.

Dialogs: native dialog.showModal() where feasible; single active modal; opener captured; initial focus on heading or first safe action; Tab trapped by top layer; Escape cancels (unless irreversible operation already committed), backdrop cannot dismiss destructive confirmation; scroll within dialog max-height calc(100dvh - 32px), background inert; close restores opener or nearest surviving route heading. Menu: Escape closes, arrow navigation if menu semantics are used, focus return. Toast: polite status; errors use role=alert only when urgent. No save-success before storage acknowledgement. Short-height 400px must retain Close and primary action. Negative controls: reduced-motion does not remove focus; outside click does not delete; cancel does not insert citation.

W5 source-specific: success toast dismissible at 3.5s, failure persists; narrow drawer overlays instead of resizing editor; popovers flip within viewport without scroll lock; modal blocks background scroll. No duration represents persistence success.
