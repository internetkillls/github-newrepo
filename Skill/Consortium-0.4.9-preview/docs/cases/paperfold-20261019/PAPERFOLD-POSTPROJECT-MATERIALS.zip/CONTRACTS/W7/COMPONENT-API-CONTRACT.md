# COMPONENT-API-CONTRACT.md

Baseline v0.8 verified SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. W4 is canonical I1; W5 and W6 are advisory I1 closures. This document freezes Stage II contracts, not implemented behavior.

## Immutable data boundary
Do not change db.js, schema, service-worker.js, manifest.json, sync.js, card-model.js, session-model.js, provenance.js or browser-sessions.js. No migration. Keep baseline exports and all existing element IDs consumed by sidepanel.js, or add explicit adapter mapping with one-to-one IDs. New UI text says Board while DB remains maincards.

## W8 shell API
W8 owns sidepanel.html and sidepanel.css as complete replacement files. It must preserve every baseline JS-required DOM ID and required form semantics. New shell elements: [data-pf-route] route triggers; [data-pf-view] route panels; [data-pf-modal] modal root; [data-pf-toast] status. Existing IDs remain canonical compatibility layer. Route values write|boards|library|find|sessions|explore|query|settings. CSS tokens as DESIGN-TOKENS.md. W8 does not modify JavaScript.

## W9 behavior API
W9 owns sidepanel.js as complete replacement, retaining all existing imports, exports and persistence calls unless verified obsolete. Bind to W8 selectors via additive adapters: activateRoute(route), announceStatus(message,kind), openDialog(id,opener), closeDialog(id,reason), reconcileSave(receipt), preserveEditorSelection(). Functions are conceptual API requirements, not claims that baseline already exports them. W9 must feature-detect optional shell nodes and retain old IDs. W9 does not edit HTML or CSS.

## Integration handshake
Both independently test against identical immutable baseline; because each changes only one side of DOM/behavior, W10 alone assembles combined patch and resolves cross-file mismatch. W10 owns integration-only tests, build receipts, screenshots, bundle manifests and packaging; W10 may request W8/W9 corrections but must not silently modify their owned files. W8 and W9 MUST deliver exact complete file bytes, not diff fragments or assumed cherry-picks. No new runtime modules without W7 ownership amendment.

## Frozen interaction adapters (W5 correction)
W9 route controller must preserve per-surface scroll and dirty drafts; overlay controller distinguishes blocking dialog (scroll lock/focus trap) from popover (no scroll lock); context menu supports Arrow/Home/End; editor formatting preserves CM6 selection on pointerdown and composition; drag/drop performs no data mutation on hover; source preview and Discover suggestion are read-only until explicit confirmation; save/status adapter only announces success on storage acknowledgment and retains failure state. W8 supplies semantic control hooks and aria-pressed/live regions without removing baseline IDs. W10 verifies the paired implementation; these are API obligations, not existing named exports.
