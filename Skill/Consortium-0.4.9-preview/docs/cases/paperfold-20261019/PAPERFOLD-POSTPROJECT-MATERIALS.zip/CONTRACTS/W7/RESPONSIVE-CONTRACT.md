# RESPONSIVE-CONTRACT.md

Baseline v0.8 verified SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. W4 is canonical I1; W5 and W6 are advisory I1 closures. This document freezes Stage II contracts, not implemented behavior.

W6 adjudicated: compact dock below 700 CSS px; at >=700px labeled rail with Find and Sessions; at 280–320px wrap secondary metadata but retain Capture and four destinations; 360–600px single editorial column; at 800px rail + content; optional second context column only when usable width permits (existing W4 1110px precedent). Shell height content-driven; no fixed aspect ratio. Main content/editor own vertical scrolling. Only formatting strip and table-scroll region own horizontal overflow; root must not. Dialog internal scroll at viewport height 400px. Preserve image aspect ratios, wrap URLs, titles and excerpts. Required test grid: 280,320,360,420,600,800,1110 widths; 400/700 heights; Paper/Pure Black/System; 100/150/200% native browser zoom. W6 witnessed 108 fixture combinations, not extension integration or native zoom; builder must retest real Chrome.

## W6 validated source reconciliation
Validated W6 SHA256 `40eab9400dd330db9223719fe8d69f9446c20dba596614c08f5fd79f9c19d062`. Its component-boundary evidence and fixture constraints govern layout, while W5 governs focus, overlays and timing. At narrow widths, drawers overlay without shrinking editor. Do not infer native zoom from CSS-emulated zoom or screenshots; preserve test distinction.
