# ACCEPTANCE-MATRIX.md

Baseline v0.8 verified SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. W4 is canonical I1; W5 and W6 are advisory I1 closures. This document freezes Stage II contracts, not implemented behavior.

| Gate | Owner | Positive test | Negative control | Current status |
|---|---|---|---|---|
| Baseline identity | W7 | SHA256 source.zip equals pinned identity | reject differing ZIP | PASS observed |
| Disjoint exact ownership | W7 | paths exist, sets disjoint | duplicate path rejected | PASS observed |
| Dependency authority | W7 | W4 canonical; W5/W6 advisory | do not infer fixture=production | PASS documentary |
| Shell route visibility | W8/W10 | four dock routes and Capture visible at 280px | no duplicate Capture | SPEC only |
| DOM binding compatibility | W8/W9/W10 | baseline IDs and handlers reconcile | missing ID fails | SPEC only |
| Persistence safety | W9/W10 | save receipt before success | toast not write receipt | SPEC only |
| Citation safety | W9/W10 | cancel, insert, undo, IME | cancel no insertion | SPEC only |
| Modal a11y | W8/W9/W10 | focus trap, Escape, restore | reduced motion retains focus | SPEC only |
| Responsive | W10 | width×height×theme×native zoom | fixture not real Chrome | SPEC only |
| Data migration | W10 | unchanged schema and baseline records | no destructive default | SPEC only |

Visual Pipeline applied at shell, navigation, editor, library, modal, status and theme boundaries: evidence → specification → composition → preview → compare → diagnose → correct → validate → handoff. W4 previews and W6 fixture receipts are evidence of their own fixtures only. No Stage III production screenshot or behavior is certified here. Source assertions are not runtime tests. Reference-system external research not executed: access debt, no unverified citations.

## Added W5 regression gates (specified, not executed)
| Gate | Owner | Positive | Negative |
|---|---|---|---|
| Menu keyboard | W9/W10 | Arrow/Home/End; disabled reason | no double action |
| Editor toolbar | W9/W10 | pointerdown caret, aria-pressed, undo, IME | no lost selection |
| Narrow drawer | W8/W9/W10 | overlay, Escape, restore | editor width unchanged |
| Drag/drop | W9/W10 | valid target and confirmed commit | hover/cancel no write |
| Discover | W9/W10 | accept/reject review | suggestion not inserted automatically |
| Toast and save | W9/W10 | ACK, 3.5s success, persistent error | no optimistic success |
| Permission failure | W9/W10 | guidance, safe retry | no auto permission request |
