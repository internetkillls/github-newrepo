# BUILD-PARTITION.md

Baseline v0.8 verified SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. W4 is canonical I1; W5 and W6 are advisory I1 closures. This document freezes Stage II contracts, not implemented behavior.

## Machine-readable disjoint ownership
```json
{"w8":["sidepanel.html","sidepanel.css"],"w9":["sidepanel.js"]}
```

Source inspection: sidepanel.js 3262 lines, sidepanel.html 740 lines, sidepanel.css 504 lines; JS imports db, editor, provenance, card, session, workspace and sync modules. This is a monolithic UI binding; splitting sidepanel.js between workers would create simultaneous ownership and incompatible independent builds. W8 receives HTML/CSS; W9 receives JS; both build against original source.zip SHA256. W10 explicitly owns `tests/w10-ui-integration.mjs`, `tests/w10-browser-e2e.mjs`, `INTEGRATION-REPORT.md`, `SOURCE-HASH-MANIFEST.json`, final packaged archive, and all integration screenshots. These are newly created paths; baseline files `manifest.json`, `service-worker.js`, `db.js`, `card-model.js`, `session-model.js`, `sync.js`, `browser-sessions.js` remain immutable unless new stage approval. W8 must not assume W9 JS exists; W9 must tolerate original DOM while W10 validates combined DOM. W10 must not claim merge passes until Chrome runtime and persistence witnesses execute.

## Feasibility and coverage
Every UI change in the canonical shell is owned by W8, every event/route/state change by W9, and joint behavior verification by W10. No overlapping paths. Hard stop if W8 drops any JS-referenced DOM ID or W9 introduces required selectors absent from W8. If unavoidable edits to shared data modules arise, escalate and reopen W7 ownership rather than ad hoc cross-edit.

## W5/W6 ownership reconciliation
Validated W5's 14 behaviors split along existing shell/behavior boundary: W8 semantic DOM, overlays and responsive CSS; W9 event routing, focus, selection, persistence and transactions. W6 layout remains W8-owned; joint focus/resize tests are W10-owned. No additional source file required by the documentary review. Ownership unchanged, conditional on Stage III runtime evidence.
