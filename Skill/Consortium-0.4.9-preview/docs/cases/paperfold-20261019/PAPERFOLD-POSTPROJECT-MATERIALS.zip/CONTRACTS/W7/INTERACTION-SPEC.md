# INTERACTION-SPEC.md

Baseline v0.8 verified SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. W4 is canonical I1; W5 and W6 are advisory I1 closures. This document freezes Stage II contracts, not implemented behavior.

## Frozen routes and navigation
Write, Boards, Library, More are four compact dock destinations. Wide rail adds Find and Sessions; More exposes Explore, Query Studio, Settings, and utilities without new primary tabs. No Context home. Capture is a global action, distinct from brand text and contextual workspace. Board is UI vocabulary; `maincards` remains storage vocabulary. Preserve Card membership on library selection.

## Event contracts
All controls are semantic buttons/links/inputs with accessible names; active navigation uses aria-current=page. Keyboard Enter/Space activate controls; Escape closes transient overlays without data mutation. Context menu click never performs destructive action. Capture and source-insert open review before committing. Save shows pending → acknowledged → failed/retry; toast alone never constitutes success. Modal close restores focus to triggering control. Editor selection survives citation review cancellation and insertion undo; IME composition must not be interrupted. Source link/unlink is explicit and separately reversible where supported. Sessions are recoverable context, never a Board alias. Search filters must not silently rewrite query. A failed storage operation preserves editable draft.

## Boundaries and negative controls
Shell navigation → destination heading → active state → focus return. Editor → citation dialog → confirm/cancel → storage receipt. Library → Board/Card membership unchanged unless explicit membership command. Cancel source preview → no citation inserted. Duplicate save click while pending → one write intent, not two. Missing permission → explanatory non-destructive error, not silent success.

## W5 fully reviewed — frozen 14-interaction boundary matrix
W5 validated document SHA256 `4d939cb2ddab4e8ab1cade1cd178b9081e0a634bdc232194274c0470dea8b95d`. W4 remains structural authority; W5 supplies behavior. All fourteen W5 interaction classes are mapped below; no production verification is inferred.

| Interaction | Trigger / committed state | Focus / interruption / negative control |
|---|---|---|
| Modal | explicit trigger; commit only on Confirm | trap blocking dialog, restore opener; destructive backdrop cannot commit |
| Popover | trigger anchored, viewport-flipped | Escape/outside dismiss; preserve editor caret and scroll |
| Context menu | explicit menu action once | Arrow/Home/End navigate; disabled reason shown; no accidental destructive click |
| Hover/press | affordance only | 80ms hover, pointer-only scale .985; visible keyboard focus |
| Navigation | Write/Boards/Library/More route | immediate switch, optional 120ms fade; retain unsaved draft and per-route scroll |
| Drawer | narrow panel overlays editor | Escape/Close and opener focus restore; no editor resizing |
| Drag/drop | validated target then explicit commit | Escape cancels, hover does not mutate membership |
| Editor formatting | explicit toolbar command | pointerdown preserves CM6 caret; aria-pressed; IME and undo intact |
| Source preview | read-only → staged citation confirmation | require Card + caret; cancel makes zero Card writes |
| Collection selection | filter/view update | never silently changes Board/Card membership |
| Toast | acknowledged success or actionable failure | success dismissible after 3.5s; error persistent, live regions appropriate |
| Save indicator | dirty→saving→saved on storage ACK | failed write retains draft; duplicate click deduplicated |
| Discover review | suggestion→review→accept/reject | no automatic insertion, no hidden side effects |
| Recovery/error | failed operation→safe retry | preserve existing data; permission denial gives guidance, no automatic request |

Each boundary follows Evidence → Specification → Composition → Preview → Compare → Diagnose → Correct → Validate → Handoff. W5's repeated generic paragraphs do not constitute fourteen executed production tests.
