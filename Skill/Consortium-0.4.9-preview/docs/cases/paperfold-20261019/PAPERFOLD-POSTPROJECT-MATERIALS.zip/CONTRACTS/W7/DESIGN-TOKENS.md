# DESIGN-TOKENS.md

Baseline v0.8 verified SHA256 6a6fc35292e50a8e945e87d8dd1f3df60cfe0c8cd0ba9f73c29a9022cb00cc10. W4 is canonical I1; W5 and W6 are advisory I1 closures. This document freezes Stage II contracts, not implemented behavior.

Tokens are CSS custom properties; existing palette values remain authoritative until visually measured in the baseline CSS, rather than invented colors. Semantic aliases: --pf-bg, --pf-surface, --pf-text, --pf-muted, --pf-border-subtle, --pf-accent, --pf-danger, --pf-focus; aliases MUST map to the existing Paper/Pure Black/System theme values in sidepanel.css. Spacing: 4,8,12,16,24,32px (--pf-space-1..6); radii 4,8,12px; type 12/14/16/20/28px, line height 1.45 body and 1.2 headings. Focus ring 2px solid semantic accent with 2px offset; never color alone for state. No decorative header logo. Avoid nested outlines and heavy card shadows. Icon contrast must be measured for each theme; no claimed WCAG PASS without measurements. Motion values governed by MOTION-AND-MODAL-CONTRACT.md. All new aliases resolve in all three themes; existing tokens are not deleted.

## Resolved W5 motion aliases
`--motion-open:160ms; --motion-close:120ms; --motion-feedback:90ms; --motion-ease-open:cubic-bezier(.2,.8,.2,1); --motion-ease-close:ease-in;` plus `@media (prefers-reduced-motion:reduce)` zero duration. The earlier generic 120/180/240ms motion set is superseded. Hover opacity 80ms; pointer-only press transform .985; route fade optional 120ms.
